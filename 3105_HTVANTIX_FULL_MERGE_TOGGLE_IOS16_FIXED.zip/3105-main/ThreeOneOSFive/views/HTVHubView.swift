import SwiftUI

struct HTVHubView: View {
    @EnvironmentObject private var session: AppSession
    @State private var key = ""
    @State private var revealKey = false

    var body: some View {
        NavigationStack {
            Group {
                if session.isUnlocked {
                    gamesView
                } else {
                    accessView
                }
            }
            .background(HTBackground())
            .navigationTitle("HTVANTIX")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                if key.isEmpty { key = session.savedLicenseKey }
                await session.bootstrap()
            }
        }
    }

    private var accessView: some View {
        ScrollView {
            VStack(spacing: 18) {
                VStack(spacing: 8) {
                    Image(systemName: "shield.lefthalf.filled")
                        .font(.system(size: 44, weight: .black))
                        .foregroundStyle(HTTheme.accent)
                    Text("HTVANTIX")
                        .font(.system(size: 30, weight: .black))
                    Text("ONLINE ACCESS")
                        .font(.system(size: 11, weight: .black, design: .monospaced))
                        .tracking(1.2)
                        .foregroundStyle(HTTheme.secondary)
                }
                .padding(.top, 24)

                HTCard {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("LICENSE KEY")
                            .font(.system(size: 12, weight: .heavy, design: .monospaced))
                            .foregroundStyle(HTTheme.secondary)

                        HStack(spacing: 8) {
                            Group {
                                if revealKey { TextField("Enter activation key", text: $key) }
                                else { SecureField("Enter activation key", text: $key) }
                            }
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()

                            Button { revealKey.toggle() } label: {
                                Image(systemName: revealKey ? "eye.slash.fill" : "eye.fill")
                                    .frame(width: 40, height: 40)
                            }
                        }
                        .padding(.horizontal, 14)
                        .frame(height: 56)
                        .background(Color.black.opacity(0.45))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(HTTheme.strongBorder))
                        .clipShape(RoundedRectangle(cornerRadius: 14))

                        if case .error(let message) = session.licenseState {
                            Text(message)
                                .font(.system(size: 13, weight: .medium))
                                .foregroundStyle(HTTheme.danger)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        if let message = session.backendConfigurationMessage {
                            Text(message)
                                .font(.system(size: 12))
                                .foregroundStyle(HTTheme.warning)
                        }

                        Button {
                            Task { await session.activate(key: key) }
                        } label: {
                            if case .checking = session.licenseState {
                                ProgressView().tint(.black)
                            } else {
                                Label("Activate", systemImage: "key.fill")
                            }
                        }
                        .buttonStyle(HTPrimaryButton())
                    }
                }

                HTCard {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("DEVICE")
                            .font(.system(size: 11, weight: .black, design: .monospaced))
                            .foregroundStyle(HTTheme.secondary)
                        Text(session.deviceID)
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundStyle(Color.white.opacity(0.5))
                            .textSelection(.enabled)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .frame(maxWidth: 720)
            .padding(18)
            .frame(maxWidth: .infinity)
        }
    }

    private var gamesView: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("GAME LIBRARY")
                            .font(.system(size: 11, weight: .black, design: .monospaced))
                            .foregroundStyle(HTTheme.secondary)
                        Text("เลือกเกม")
                            .font(.system(size: 28, weight: .black))
                    }
                    Spacer()
                    Button {
                        Task { await session.loadGames() }
                    } label: { Image(systemName: "arrow.clockwise") }
                    .buttonStyle(.plain)
                    .foregroundStyle(HTTheme.accent)
                }

                if let error = session.lastError, !error.isEmpty {
                    HTCard { Text(error).foregroundStyle(HTTheme.danger) }
                }

                if session.isLoadingGames {
                    HTCard { HStack { ProgressView(); Text("Loading games…") } }
                } else if session.games.isEmpty {
                    HTCard {
                        VStack(spacing: 10) {
                            Image(systemName: "gamecontroller")
                                .font(.system(size: 34))
                            Text("ยังไม่มีเกมจากหลังบ้าน")
                                .foregroundStyle(HTTheme.secondary)
                        }
                        .frame(maxWidth: .infinity)
                    }
                } else {
                    ForEach(sortedGames) { game in
                        NavigationLink(destination: HTVGamePackagesView(game: game)) {
                            HTCard {
                                HStack(spacing: 14) {
                                    RoundedRectangle(cornerRadius: 14)
                                        .fill(Color(hex: game.bannerColor ?? "") ?? HTTheme.surface2)
                                        .frame(width: 56, height: 56)
                                        .overlay(Image(systemName: "gamecontroller.fill").font(.system(size: 22)))
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(displayGameName(game))
                                            .font(.system(size: 18, weight: .bold))
                                            .foregroundStyle(.white)
                                        Text(game.subtitle ?? game.bundleID ?? game.id)
                                            .font(.system(size: 12))
                                            .foregroundStyle(HTTheme.secondary)
                                            .lineLimit(2)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundStyle(HTTheme.secondary)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }

                Button("ออกจากคีย์") { session.signOut() }
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(HTTheme.danger)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
            }
            .frame(maxWidth: 760)
            .padding(18)
            .frame(maxWidth: .infinity)
        }
        .refreshable { await session.loadGames() }
    }

    private var sortedGames: [RemoteGameSummary] {
        session.games.sorted { a, b in
            gamePriority(a) < gamePriority(b)
        }
    }

    private func gamePriority(_ game: RemoteGameSummary) -> Int {
        let value = (game.id + " " + game.name).lowercased()
        if value.contains("ffmax") || value.contains("free fire max") || value.contains("max") { return 1 }
        if value.contains("ff") || value.contains("free fire") { return 0 }
        return 10 + (game.order ?? 0)
    }

    private func displayGameName(_ game: RemoteGameSummary) -> String {
        let value = (game.id + " " + game.name).lowercased()
        if value.contains("ffmax") || value.contains("free fire max") { return "Free Fire MAX" }
        if value.contains("ff") || value.contains("free fire") { return "Free Fire" }
        return game.name
    }
}

private struct HTVGamePackagesView: View {
    @EnvironmentObject private var session: AppSession
    let game: RemoteGameSummary

    @State private var patches: [RemotePatchSummary] = []
    @State private var selectedCategory = "shoot"
    @State private var loading = false
    @State private var changingID: String?
    @State private var enabledIDs = Set<String>()
    @State private var errorMessage: String?

    private let categories: [(String, String)] = [
        ("shoot", "ไฟล์ยิง"),
        ("visual", "ไฟล์มอง"),
        ("skin_free", "มอดสกิน ฟรี"),
        ("other", "อื่นๆ")
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                categoryBar

                if loading {
                    HTCard { HStack { ProgressView(); Text("Loading…") } }
                } else if filtered.isEmpty {
                    HTCard {
                        Text("ยังไม่มีรายการในหมวดนี้")
                            .foregroundStyle(HTTheme.secondary)
                            .frame(maxWidth: .infinity)
                    }
                } else {
                    ForEach(filtered) { patch in
                        patchCard(patch)
                    }
                }
            }
            .frame(maxWidth: 760)
            .padding(18)
            .frame(maxWidth: .infinity)
        }
        .background(HTBackground())
        .navigationTitle(game.name)
        .navigationBarTitleDisplayMode(.inline)
        .task {
            enabledIDs = HTVRemotePatchToggleStore.enabledPatchIDs()
            await load()
        }
        .refreshable { await load() }
        .alert("HTVANTIX", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) { Button("OK", role: .cancel) {} } message: { Text(errorMessage ?? "") }
    }

    private var categoryBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(categories, id: \.0) { item in
                    Button { selectedCategory = item.0 } label: {
                        Text(item.1)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(selectedCategory == item.0 ? .black : .white)
                            .padding(.horizontal, 14)
                            .frame(height: 40)
                            .background(selectedCategory == item.0 ? HTTheme.accent : HTTheme.surface2, in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var filtered: [RemotePatchSummary] {
        patches.filter { normalized($0.category) == selectedCategory }
    }

    private func normalized(_ raw: String?) -> String {
        switch (raw ?? "other").lowercased() {
        case "shoot", "aim", "aimbot", "ยิง": return "shoot"
        case "visual", "esp", "มอง": return "visual"
        case "skin_free", "skin", "skins", "มอดสกิน": return "skin_free"
        default: return "other"
        }
    }

    private func patchCard(_ patch: RemotePatchSummary) -> some View {
        let isEnabled = enabledIDs.contains(patch.id)
        let isChanging = changingID == patch.id

        return HTCard {
            HStack(spacing: 14) {
                VStack(alignment: .leading, spacing: 5) {
                    HStack(spacing: 8) {
                        Text(patch.title)
                            .font(.system(size: 17, weight: .bold))
                        if let version = patch.version {
                            HTStatusPill(text: "v\(version)")
                        }
                    }

                    if let detail = patch.detail {
                        Text(detail)
                            .font(.system(size: 12))
                            .foregroundStyle(HTTheme.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    Text(isEnabled ? "เปิดใช้งานอยู่" : "ปิดอยู่")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(isEnabled ? HTTheme.success : HTTheme.secondary)
                }

                Spacer(minLength: 12)

                if isChanging {
                    ProgressView()
                        .tint(HTTheme.accent)
                        .frame(width: 52)
                } else {
                    Toggle("", isOn: Binding(
                        get: { enabledIDs.contains(patch.id) },
                        set: { newValue in
                            Task { await setPatch(patch, enabled: newValue) }
                        }
                    ))
                    .labelsHidden()
                    .tint(HTTheme.accent)
                    .disabled(changingID != nil)
                }
            }
        }
    }

    private func load() async {
        loading = true
        defer { loading = false }
        do {
            patches = try await session.patches(for: game)
            enabledIDs = HTVRemotePatchToggleStore.enabledPatchIDs()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    @MainActor
    private func setPatch(_ patch: RemotePatchSummary, enabled: Bool) async {
        guard changingID == nil else { return }
        changingID = patch.id
        defer { changingID = nil }

        do {
            if enabled {
                // The package is fetched internally; there is intentionally no
                // user-facing download/export flow. Application still goes
                // through the original 3105 patch transaction engine.
                let package = try await session.download(patch)
                defer { try? FileManager.default.removeItem(at: package.localURL) }

                let data = try Data(contentsOf: package.localURL)
                let decoded = try PatchPackageCodec.decode(data, password: patch.password)
                _ = try DevicePatchService.apply(project: decoded.project)

                HTVRemotePatchToggleStore.markEnabled(
                    patchID: patch.id,
                    projectID: decoded.project.id
                )
                enabledIDs.insert(patch.id)
            } else {
                guard let projectID = HTVRemotePatchToggleStore.projectID(for: patch.id) else {
                    HTVRemotePatchToggleStore.markDisabled(patchID: patch.id)
                    enabledIDs.remove(patch.id)
                    return
                }

                guard let receipt = DevicePatchService.latestReceipt(projectID: projectID) else {
                    HTVRemotePatchToggleStore.markDisabled(patchID: patch.id)
                    enabledIDs.remove(patch.id)
                    return
                }

                try DevicePatchService.restore(receipt: receipt)
                HTVRemotePatchToggleStore.markDisabled(patchID: patch.id)
                enabledIDs.remove(patch.id)
            }
        } catch {
            // Keep the visible toggle in the last known-good state if apply or
            // restore fails.
            enabledIDs = HTVRemotePatchToggleStore.enabledPatchIDs()
            errorMessage = error.localizedDescription
        }
    }
}

private enum HTVRemotePatchToggleStore {
    private static let defaultsKey = "htvantix.remotePatch.projectIDs.v1"

    static func projectID(for patchID: String) -> UUID? {
        guard let raw = dictionary()[patchID] else { return nil }
        return UUID(uuidString: raw)
    }

    static func enabledPatchIDs() -> Set<String> {
        Set(dictionary().compactMap { key, value in
            guard let projectID = UUID(uuidString: value),
                  DevicePatchService.latestReceipt(projectID: projectID) != nil else {
                return nil
            }
            return key
        })
    }

    static func markEnabled(patchID: String, projectID: UUID) {
        var values = dictionary()
        values[patchID] = projectID.uuidString
        UserDefaults.standard.set(values, forKey: defaultsKey)
    }

    static func markDisabled(patchID: String) {
        var values = dictionary()
        values.removeValue(forKey: patchID)
        UserDefaults.standard.set(values, forKey: defaultsKey)
    }

    private static func dictionary() -> [String: String] {
        UserDefaults.standard.dictionary(forKey: defaultsKey) as? [String: String] ?? [:]
    }
}
