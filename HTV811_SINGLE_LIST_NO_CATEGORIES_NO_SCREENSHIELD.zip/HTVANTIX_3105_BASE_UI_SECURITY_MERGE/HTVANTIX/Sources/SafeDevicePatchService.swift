import Foundation

/// Safe integration layer for the original 3105 package/transaction format.
///
/// This service intentionally resolves only containers that this app is
/// legitimately allowed to access. The original 3105 source remains preserved
/// separately and is not modified by this integration.
enum SafeDevicePatchService {
    private static let fm = FileManager.default
    private static let packageMapKey = "HTVANTIX.Safe3105.ProjectMap.v1"

    static func apply(packageData: Data, remotePackageID: String) throws -> PatchTransactionReceipt {
        let summary = try PatchPackageCodec.inspect(packageData)
        guard !summary.isPasswordProtected else {
            throw PatchPackageError.invalidPasswordOrCorruptedPackage
        }

        let decoded = try PatchPackageCodec.decode(packageData, password: nil)
        let project = decoded.project

        let roots = try resolvedContainers(for: project.allBundleIdentifiers)
        let receipt = try PatchTransaction.apply(
            project: project,
            backupRoot: try backupRootURL(),
            containerResolver: { bundleID in
                guard let root = roots[bundleID] else {
                    throw PatchPackageError.targetAppUnavailable(bundleID)
                }
                return root
            }
        )

        storeProjectID(project.id, forRemotePackageID: remotePackageID)
        return receipt
    }

    static func restore(remotePackageID: String) throws {
        guard let projectID = storedProjectID(forRemotePackageID: remotePackageID),
              let receipt = PatchTransaction.latestReceipt(
                projectID: projectID,
                backupRoot: try backupRootURL()
              ) else {
            throw PatchPackageError.restoreFailed
        }

        let bundleIDs = try PatchTransaction.requiredBundleIdentifiers(for: receipt)
        let roots = try resolvedContainers(for: bundleIDs)

        try PatchTransaction.restore(
            receipt: receipt,
            containerResolver: { bundleID in
                guard let root = roots[bundleID] else {
                    throw PatchPackageError.targetAppUnavailable(bundleID)
                }
                return root
            }
        )

        removeStoredProjectID(forRemotePackageID: remotePackageID)
    }

    static func isApplied(remotePackageID: String) -> Bool {
        guard let projectID = storedProjectID(forRemotePackageID: remotePackageID),
              let backupRoot = try? backupRootURL() else { return false }
        return PatchTransaction.latestReceipt(projectID: projectID, backupRoot: backupRoot) != nil
    }

    static func removeDownloadedPackage(_ package: RemotePackage) throws {
        let root = try downloadCacheRootURL()
        let cached = root.appendingPathComponent(package.id, isDirectory: false)
        if fm.fileExists(atPath: cached.path) {
            try fm.removeItem(at: cached)
        }
    }

    /// Copies the verified download into Application Support before decoding it.
    /// This avoids depending on the lifetime of a temporary URL returned by URLSession.
    static func stageVerifiedDownload(_ source: URL, package: RemotePackage) throws -> URL {
        let root = try downloadCacheRootURL()
        let target = root.appendingPathComponent(package.id, isDirectory: false)
        if fm.fileExists(atPath: target.path) {
            try fm.removeItem(at: target)
        }
        try fm.copyItem(at: source, to: target)
        return target
    }

    private static func resolvedContainers(for bundleIDs: [String]) throws -> [String: URL] {
        var roots: [String: URL] = [:]
        for bundleID in bundleIDs {
            roots[bundleID] = try resolveAuthorizedContainer(bundleID: bundleID)
        }
        return roots
    }

    private static func resolveAuthorizedContainer(bundleID: String) throws -> URL {
        let canonical = try PatchPathValidator.canonicalBundleIdentifier(bundleID)
        guard canonical == bundleID else {
            throw PatchPackageError.invalidBundleIdentifier
        }

        // Normal iOS sandbox access: this application may directly access only
        // its own data container unless another OS-authorized shared container
        // has explicitly been configured.
        guard let ownBundleID = Bundle.main.bundleIdentifier,
              bundleID == ownBundleID else {
            throw PatchPackageError.targetAppUnavailable(bundleID)
        }

        return PatchPathValidator.canonicalFileURL(
            URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true)
        )
    }

    private static func backupRootURL() throws -> URL {
        let base = try fm.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let root = base
            .appendingPathComponent("HTVANTIX", isDirectory: true)
            .appendingPathComponent("3105Backups", isDirectory: true)
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }

    private static func downloadCacheRootURL() throws -> URL {
        let base = try fm.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let root = base
            .appendingPathComponent("HTVANTIX", isDirectory: true)
            .appendingPathComponent("3105Packages", isDirectory: true)
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }

    private static func storedProjectID(forRemotePackageID packageID: String) -> UUID? {
        let map = UserDefaults.standard.dictionary(forKey: packageMapKey) as? [String: String] ?? [:]
        guard let raw = map[packageID] else { return nil }
        return UUID(uuidString: raw)
    }

    private static func storeProjectID(_ projectID: UUID, forRemotePackageID packageID: String) {
        var map = UserDefaults.standard.dictionary(forKey: packageMapKey) as? [String: String] ?? [:]
        map[packageID] = projectID.uuidString
        UserDefaults.standard.set(map, forKey: packageMapKey)
    }

    private static func removeStoredProjectID(forRemotePackageID packageID: String) {
        var map = UserDefaults.standard.dictionary(forKey: packageMapKey) as? [String: String] ?? [:]
        map.removeValue(forKey: packageID)
        UserDefaults.standard.set(map, forKey: packageMapKey)
    }
}
