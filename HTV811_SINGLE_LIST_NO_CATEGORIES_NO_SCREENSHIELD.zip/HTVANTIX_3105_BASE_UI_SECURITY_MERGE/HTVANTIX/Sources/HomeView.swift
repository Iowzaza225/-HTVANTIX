import SwiftUI
import UIKit
import Darwin

struct HomeView: View {
    @EnvironmentObject private var app: AppCoordinator

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    header
                    deviceCard
                    gameCard(id: "ff", title: "Free Fire", image: "FreeFireIcon")
                    gameCard(id: "ffmax", title: "Free Fire MAX", image: "FreeFireMaxIcon")
                    licenseCard
                    updateCard
                    Text("HTVANTIX • v\(BuildIdentity.version) (\(BuildIdentity.build)) • \(BuildIdentity.buildID)")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(HTTheme.muted2)
                        .padding(.top, 4)
                }
                .padding(18)
            }
            .background(HTBackground())
            .toolbar(.hidden, for: .navigationBar)
            .refreshable { await app.refreshPackages() }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image("HTBrandIcon")
                .resizable()
                .scaledToFit()
                .frame(width: 44, height: 44)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

            VStack(alignment: .leading, spacing: 3) {
                Text("HTVANTIX")
                    .font(.system(size: 26, weight: .black, design: .rounded))
                Text("GAME ENHANCER • SECURE CLIENT")
                    .font(.system(size: 10, weight: .bold))
                    .tracking(1.5)
                    .foregroundStyle(HTTheme.muted)
            }

            Spacer()

            NavigationLink {
                SettingsView()
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 17, weight: .bold))
                    .frame(width: 44, height: 44)
                    .background(HTTheme.surface2, in: RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(HTTheme.border))
            }
        }
    }

    private var deviceCard: some View {
        HTCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("DEVICE")
                            .font(.caption.weight(.black))
                            .tracking(1.4)
                            .foregroundStyle(HTTheme.muted)

                        Text(hardwareIdentifier)
                            .font(.system(size: 22, weight: .black, design: .rounded))
                    }

                    Spacer()

                    Text("iOS \(UIDevice.current.systemVersion)")
                        .font(.caption.weight(.bold))
                        .padding(.horizontal, 11)
                        .frame(height: 32)
                        .background(HTTheme.surface2, in: Capsule())
                        .overlay(Capsule().stroke(HTTheme.border))
                }

                Divider().overlay(HTTheme.border)

                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("COMPATIBILITY")
                            .font(.caption2.weight(.black))
                            .tracking(1.2)
                            .foregroundStyle(HTTheme.muted)
                        Text("Universal iOS")
                            .font(.system(size: 17, weight: .bold))
                    }

                    Spacer()

                    Label(compatibilityText, systemImage: compatibilityReady ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                        .font(.caption.weight(.black))
                        .foregroundStyle(compatibilityReady ? HTTheme.green : .orange)
                }

                HStack(spacing: 10) {
                    statusPill(icon: "iphone", title: UIDevice.current.model)
                    statusPill(icon: "number", title: "Build \(BuildIdentity.build)")
                    statusPill(icon: "shield.checkered", title: "Protected")
                }
            }
        }
    }

    private func gameCard(id: String, title: String, image: String) -> some View {
        let count = app.packages.filter { $0.game == id }.count

        return NavigationLink {
            GameHubView(gameID: id, gameTitle: title, gameImage: image)
        } label: {
            HTCard {
                HStack(spacing: 15) {
                    Image(image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 64, height: 64)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .stroke(Color.white.opacity(0.12))
                        )

                    VStack(alignment: .leading, spacing: 6) {
                        Text(title)
                            .font(.system(size: 20, weight: .bold))
                            .foregroundStyle(.white)

                        HStack(spacing: 6) {
                            Circle()
                                .fill(count > 0 ? HTTheme.green : .orange)
                                .frame(width: 7, height: 7)
                            Text(count > 0 ? "พร้อมใช้งาน • \(count) รายการ" : "กำลังรอรายการจากระบบ")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(count > 0 ? HTTheme.green : HTTheme.muted)
                        }
                    }

                    Spacer()

                    Image(systemName: "chevron.right")
                        .font(.system(size: 17, weight: .black))
                        .foregroundStyle(HTTheme.accent)
                }
            }
        }
        .buttonStyle(.plain)
    }

    private var licenseCard: some View {
        HTCard {
            HStack(spacing: 14) {
                ZStack {
                    Circle()
                        .fill(HTTheme.green.opacity(0.14))
                        .frame(width: 52, height: 52)
                    Circle()
                        .fill(HTTheme.green)
                        .frame(width: 13, height: 13)
                        .shadow(color: HTTheme.green.opacity(0.7), radius: 9)
                }

                VStack(alignment: .leading, spacing: 5) {
                    Text("License Active")
                        .font(.system(size: 19, weight: .bold))
                    Text(licenseExpiryText)
                        .font(.caption)
                        .foregroundStyle(HTTheme.muted)
                    Text("ใช้งานได้ต่อเนื่อง")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(HTTheme.green)
                }

                Spacer()

                Image(systemName: "checkmark.shield.fill")
                    .font(.system(size: 29))
                    .foregroundStyle(HTTheme.green)
            }
        }
    }

    private var updateCard: some View {
        HTCard {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(HTTheme.accent.opacity(0.12))
                        .frame(width: 48, height: 48)
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundStyle(HTTheme.accent)
                }

                VStack(alignment: .leading, spacing: 5) {
                    Text("HTVANTIX UPDATE")
                        .font(.caption.weight(.black))
                        .tracking(1.2)
                    Text(updateHeadline)
                        .font(.system(size: 16, weight: .bold))
                    Text(updateDetail)
                        .font(.caption)
                        .foregroundStyle(HTTheme.muted)
                        .lineLimit(2)
                }

                Spacer()

                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 27))
                    .foregroundStyle(HTTheme.green)
            }
        }
    }

    private var compatibilityReady: Bool {
        ProcessInfo.processInfo.operatingSystemVersion.majorVersion >= 16
    }

    private var compatibilityText: String {
        compatibilityReady ? "รองรับ" : "ไม่รองรับ"
    }

    private var hardwareIdentifier: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machine = withUnsafePointer(to: &systemInfo.machine) {
            $0.withMemoryRebound(to: CChar.self, capacity: 1) {
                String(cString: $0)
            }
        }
        return machine.isEmpty ? UIDevice.current.model : machine
    }

    private var licenseExpiryText: String {
        guard let expiry = app.licenseInfo?.expiresAt, !expiry.isEmpty else {
            return "License พร้อมใช้งาน"
        }
        return "หมดอายุ \(expiry)"
    }

    private var updateHeadline: String {
        let current = app.config?.version.currentVersion ?? BuildIdentity.version
        if current == BuildIdentity.version {
            return "เวอร์ชันล่าสุดพร้อมใช้งาน"
        }
        return "Server version \(current)"
    }

    private var updateDetail: String {
        if let notes = app.config?.version.releaseNotes, !notes.isEmpty {
            return notes
        }
        return "Build \(BuildIdentity.build) • \(BuildIdentity.buildID)"
    }

    private func statusPill(icon: String, title: String) -> some View {
        HStack(spacing: 5) {
            Image(systemName: icon)
            Text(title)
        }
        .font(.system(size: 10, weight: .bold))
        .foregroundStyle(HTTheme.muted)
        .padding(.horizontal, 9)
        .frame(height: 28)
        .background(Color.white.opacity(0.035), in: Capsule())
        .overlay(Capsule().stroke(HTTheme.border))
    }
}
