import SwiftUI
import UIKit

@MainActor
final class PrivacyShieldState: ObservableObject {
    @Published private(set) var screenCaptured = UIScreen.main.isCaptured
    @Published private(set) var appInactive = false

    private var observers: [NSObjectProtocol] = []

    init() {
        observers.append(NotificationCenter.default.addObserver(
            forName: UIScreen.capturedDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.screenCaptured = UIScreen.main.isCaptured
        })

        observers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.willResignActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.appInactive = true
        })

        observers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.appInactive = false
            self?.screenCaptured = UIScreen.main.isCaptured
        })
    }

    deinit {
        observers.forEach(NotificationCenter.default.removeObserver)
    }

    var shouldCover: Bool { screenCaptured || appInactive }
}

struct PrivacyShieldModifier: ViewModifier {
    @StateObject private var state = PrivacyShieldState()

    func body(content: Content) -> some View {
        ZStack {
            content
                .allowsHitTesting(!state.shouldCover)
                .accessibilityHidden(state.shouldCover)

            if state.shouldCover {
                Color.black
                    .ignoresSafeArea()
                    .zIndex(999_999)
            }
        }
    }
}

extension View {
    func htvantixPrivacyShield() -> some View {
        modifier(PrivacyShieldModifier())
    }
}
