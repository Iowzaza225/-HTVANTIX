import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator

    var body: some View {
        HTVANTIXHomeView()
            .preferredColorScheme(.dark)
            .tint(AppTheme.accent)
    }
}

private struct HTVANTIXHomeView: View {
    @EnvironmentObject private var appState: AppState
    @Environment(\.appLanguage) private var language
    @State private var showSettings = false
    @StateObject private var homeCatalog = PatchServerCatalog()
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var revealContent = false
    @State private var ambientMotion = false

    var body: some View {
        NavigationStack {
            ZStack {
                premiumBackground

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        header
                            .motionEntrance(active: revealContent, delay: 0.02)
                        deviceCard
                            .motionEntrance(active: revealContent, delay: 0.08)

                        Text("YOUR GAMES")
                            .premiumSectionLabel()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.top, 2)
                            .motionEntrance(active: revealContent, delay: 0.13)

                        NavigationLink {
                            PatchProjectsView(gameFilter: "ff", gameTitle: "Free Fire")
                        } label: {
                            gameCard(game: "ff", title: "Free Fire", imageName: "FreeFireIcon")
                        }
                        .buttonStyle(MotionPressButtonStyle())
                        .motionEntrance(active: revealContent, delay: 0.18)

                        NavigationLink {
                            PatchProjectsView(gameFilter: "ffmax", gameTitle: "Free Fire MAX")
                        } label: {
                            gameCard(game: "ffmax", title: "Free Fire MAX", imageName: "FreeFireMaxIcon")
                        }
                        .buttonStyle(MotionPressButtonStyle())
                        .motionEntrance(active: revealContent, delay: 0.24)

                        licenseStatusCard
                            .motionEntrance(active: revealContent, delay: 0.30)
                        systemCard
                            .motionEntrance(active: revealContent, delay: 0.36)
                        footer
                            .motionEntrance(active: revealContent, delay: 0.42)
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 8)
                    .padding(.bottom, 28)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSettings) {
                SettingsView()
                    .preferredColorScheme(.dark)
            }
            .onAppear {
                revealContent = true
                guard !reduceMotion else { return }
                withAnimation(.easeInOut(duration: 5.5).repeatForever(autoreverses: true)) {
                    ambientMotion = true
                }
            }
            .task {
                guard homeCatalog.items.isEmpty, !homeCatalog.isLoading else { return }
                do {
                    _ = try await homeCatalog.load()
                    homeCatalog.finishSync()
                } catch {
                    homeCatalog.fail(error)
                }
            }
        }
    }

    private var premiumBackground: some View {
        ZStack {
            Color(red: 0.006, green: 0.013, blue: 0.020).ignoresSafeArea()

            LinearGradient(
                colors: [
                    Color.cyan.opacity(0.055),
                    Color.blue.opacity(0.018),
                    Color.clear
                ],
                startPoint: .topLeading,
                endPoint: .center
            )
            .scaleEffect(ambientMotion && !reduceMotion ? 1.08 : 1.0, anchor: .topLeading)
            .offset(x: ambientMotion && !reduceMotion ? 14 : -6, y: ambientMotion && !reduceMotion ? 8 : -4)
            .ignoresSafeArea()

            Circle()
                .fill(Color.cyan.opacity(0.035))
                .frame(width: 240, height: 240)
                .blur(radius: 55)
                .offset(x: ambientMotion && !reduceMotion ? 150 : 110, y: ambientMotion && !reduceMotion ? -250 : -210)
                .allowsHitTesting(false)
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image("HTVLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 46, height: 46)
                .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 13, style: .continuous)
                        .stroke(Color.cyan.opacity(0.28), lineWidth: 1)
                )
                .shadow(color: Color.cyan.opacity(ambientMotion && !reduceMotion ? 0.20 : 0.08), radius: ambientMotion && !reduceMotion ? 13 : 7)
                .offset(y: ambientMotion && !reduceMotion ? -1.5 : 1.0)

            VStack(alignment: .leading, spacing: 2) {
                Text("HTVANTIX")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .foregroundStyle(.white)

                Text("GAME ENHANCER")
                    .font(.caption2.weight(.bold))
                    .tracking(2.2)
                    .foregroundStyle(Color.cyan.opacity(0.92))
            }

            Spacer()

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(Color.white.opacity(0.055), in: Circle())
                    .overlay(Circle().stroke(Color.cyan.opacity(0.22), lineWidth: 1))
            }
            .buttonStyle(MotionPressButtonStyle())
        }
    }

    private var deviceCard: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.cyan.opacity(0.09))
                    .frame(width: 48, height: 48)

                Image(systemName: "iphone.gen3")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(Color.cyan)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text(AppInfo.displayMachineName)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                Text("iOS \(AppInfo.osVersion)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Label(
                appState.isSupported ? "รองรับ" : "ไม่รองรับ",
                systemImage: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill"
            )
            .font(.caption.weight(.bold))
            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
        }
        .premiumCard()
    }

    private func items(for game: String) -> [PatchServerCatalog.RemoteItem] {
        homeCatalog.items.filter { $0.game == game }
    }

    private func gameCard(game: String, title: String, imageName: String) -> some View {
        let gameItems = items(for: game)
        let ready = !gameItems.isEmpty

        return HStack(spacing: 15) {
            Image(imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 74, height: 74)
                .clipShape(RoundedRectangle(cornerRadius: 19, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 19, style: .continuous)
                        .stroke(Color.cyan.opacity(0.26), lineWidth: 1)
                )
                .shadow(color: Color.cyan.opacity(0.11), radius: 12)

            VStack(alignment: .leading, spacing: 7) {
                Text(title)
                    .font(.title3.weight(.black))
                    .foregroundStyle(.white)

                HStack(spacing: 6) {
                    MotionStatusDot(color: ready ? .green : .secondary, size: 7)
                        .frame(width: 10, height: 10)
                    Text(ready ? "\(gameItems.count) ฟังก์ชันพร้อมใช้งาน" : "ยังไม่มีฟังก์ชัน")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(ready ? Color.green : Color.secondary)
                }

                Text(homeCatalog.isLoading ? "กำลังโหลดข้อมูล…" : "แตะเพื่อดูรายการ Patch")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(Color.cyan)
        }
        .premiumCard()
    }

    private var licenseStatusCard: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color.green.opacity(0.12))
                    .frame(width: 48, height: 48)
                MotionStatusDot(color: .green, size: 12)
                    .frame(width: 24, height: 24)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("LICENSE ACTIVE")
                    .font(.headline.weight(.black))
                    .foregroundStyle(.white)
                Text("Secure Session พร้อมใช้งาน")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "checkmark.shield.fill")
                .font(.title2)
                .foregroundStyle(Color.green)
        }
        .premiumCard()
    }

    private var systemCard: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.cyan.opacity(0.09))
                    .frame(width: 48, height: 48)

                Image(systemName: "arrow.triangle.2.circlepath")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(Color.cyan)
                    .rotationEffect(.degrees(homeCatalog.isLoading && !reduceMotion ? 360 : 0))
                    .animation(homeCatalog.isLoading && !reduceMotion ? .linear(duration: 1.0).repeatForever(autoreverses: false) : .easeOut(duration: 0.25), value: homeCatalog.isLoading)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("HTVANTIX SYSTEM")
                    .font(.caption.weight(.black))
                    .tracking(1.3)
                    .foregroundStyle(.white)

                Text(systemStatusText)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "checkmark.circle.fill")
                .font(.title2)
                .foregroundStyle(Color.green)
        }
        .premiumCard()
    }

    private var systemStatusText: String {
        if homeCatalog.isLoading { return "กำลังเชื่อมต่อระบบไฟล์…" }
        if homeCatalog.errorMessage != nil { return "Secure Session • รอการเชื่อมต่อ" }
        return "API Online • \(homeCatalog.items.count) ฟังก์ชัน • Latest"
    }

    private var footer: some View {
        HStack(spacing: 8) {
            MotionStatusDot(color: .cyan, size: 6)
                .frame(width: 9, height: 9)
            Text("HTVANTIX • Secure Session")
                .font(.caption2.weight(.bold))
                .tracking(0.8)
                .foregroundStyle(.secondary)
        }
        .padding(.top, 2)
    }
}

private extension View {
    func premiumCard() -> some View {
        self
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(Color(red: 0.025, green: 0.040, blue: 0.055))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(Color.cyan.opacity(0.14), lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.24), radius: 14, y: 8)
    }

    func premiumSectionLabel() -> some View {
        self
            .font(.caption2.weight(.black))
            .tracking(1.9)
            .foregroundStyle(.secondary)
    }
}
