HTVANTIX - License Session + Remote Control

การเปลี่ยนแปลง:
- Client ไม่ต้องส่ง X-App-Token / HTVANTIX_APP_TOKEN อีกต่อไป
- /api/v4/license/redeem ใช้ License Key + rate limit
- /api/v4/session ใช้ Bearer License Token
- /api/v4/packages และ download ใช้ Bearer Client Session
- ปุ่ม Maintenance ในหลังบ้าน = Remote App OFF
- /api/v4/status ส่ง appEnabled/message ให้ Client

Environment ที่ยังต้องมีฝั่ง Server:
HIGHT_LICENSE_SECRET
HIGHT_CLIENT_SESSION_SECRET หรือ HIGHT_SESSION_SECRET
และ secrets อื่นตามระบบ admin เดิม

HIGHT_APP_TOKEN ไม่จำเป็นกับ Client flow ใหม่นี้
