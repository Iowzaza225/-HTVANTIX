const expired=new URLSearchParams(location.search).get("expired")==="1";
(() => {
  "use strict";
  const form = document.querySelector("#adminLogin");
  const button = document.querySelector("#loginButton");
  const message = document.querySelector("#loginMessage");
  const passwordStage = document.querySelector("#passwordStage");
  const otpStage = document.querySelector("#otpStage");
  const otpSetupBox = document.querySelector("#otpSetupBox");
  const otpSecret = document.querySelector("#otpSecret");
  const otpCode = document.querySelector("#otpCode");
  const copySecret = document.querySelector("#copySecret");

  let stage = "password";
  let isSetup = false;

  function text(value, ok = false) {
    message.textContent = value || "";
    message.className = "message " + (ok ? "ok" : "error");
  }

  function showOtp(setup) {
    stage = "otp";
    isSetup = Boolean(setup);
    passwordStage.classList.add("hidden");
    otpStage.classList.remove("hidden");
    otpSetupBox.classList.toggle("hidden", !isSetup);
    button.textContent = isSetup ? "ยืนยันและเปิด OTP" : "ยืนยัน OTP";
    otpCode.required = true;
    setTimeout(() => otpCode.focus(), 50);
  }

  async function startOtpSetup() {
    const response = await fetch("/admin/api/otp-setup", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: "{}",
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error("เริ่มตั้งค่า OTP ไม่สำเร็จ");
    otpSecret.textContent = data.secret || "";
  }

  copySecret?.addEventListener("click", async () => {
    const value = otpSecret.textContent.trim();
    if (!value || value === "-") return;
    try {
      await navigator.clipboard.writeText(value);
      text("คัดลอก Setup Key แล้ว", true);
    } catch {
      text("กดค้างที่ Setup Key เพื่อคัดลอก");
    }
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    button.disabled = true;

    try {
      if (stage === "password") {
        text("กำลังตรวจสอบรหัสผ่าน...");
        const response = await fetch("/admin/api/login", {
          method: "POST",
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            username: document.querySelector("#username").value.trim(),
            password: document.querySelector("#password").value,
          }),
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          if (response.status === 429) throw new Error("พยายามเข้าสู่ระบบหลายครั้งเกินไป กรุณารอสักครู่");
          if (response.status === 503) throw new Error("ระบบแอดมินยังตั้งค่าไม่ครบ");
          throw new Error("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง");
        }

        showOtp(data.otpSetup);
        if (data.otpSetup) {
          text("ตั้งค่า Authenticator แล้วกรอกรหัส 6 หลัก");
          await startOtpSetup();
        } else {
          text("กรอกรหัส 6 หลักจาก Authenticator");
        }
        button.disabled = false;
        return;
      }

      const code = otpCode.value.replace(/\D/g, "");
      if (code.length !== 6) throw new Error("กรุณากรอก OTP ให้ครบ 6 หลัก");
      text("กำลังตรวจสอบ OTP...");
      const endpoint = isSetup ? "/admin/api/otp-confirm" : "/admin/api/otp";
      const response = await fetch(endpoint, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        if (response.status === 429) throw new Error("กรอก OTP ผิดหลายครั้งเกินไป กรุณารอสักครู่");
        if (data.error === "OTP_REUSED") throw new Error("OTP นี้ใช้ไปแล้ว รอรหัสชุดใหม่แล้วลองอีกครั้ง");
        if (data.error === "SETUP_EXPIRED") throw new Error("เวลาตั้งค่า OTP หมดแล้ว กรุณาเริ่ม Login ใหม่");
        throw new Error("OTP ไม่ถูกต้อง");
      }

      text("ยืนยัน 2FA สำเร็จ", true);
      location.replace("/admin/");
    } catch (error) {
      text(error?.message || "เข้าสู่ระบบไม่สำเร็จ");
      button.disabled = false;
    }
  });
})();

if(expired){const el=document.querySelector("#msg")||document.querySelector(".message")||document.querySelector("[data-message]");if(el)el.textContent="Session หมดอายุ กรุณาเข้าสู่ระบบใหม่";}
