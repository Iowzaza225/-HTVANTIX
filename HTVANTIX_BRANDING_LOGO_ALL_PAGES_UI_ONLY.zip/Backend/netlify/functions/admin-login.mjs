import {
  json, adminConfigReady, sameOrigin, verifyAdminCredentials,
  makePreAuthSession, preAuthCookie, checkLoginRate,
  recordLoginFailure, clearLoginFailures, audit, isAdminOtpEnabled
} from "./_lib.mjs";

export default async (req, context) => {
  if (req.method !== "POST") return json({ error: "NOT_FOUND" }, 404);
  if (!sameOrigin(req)) return json({ error: "NOT_FOUND" }, 404);
  if (!adminConfigReady()) return json({ error: "ADMIN_NOT_CONFIGURED" }, 503);

  const rate = await checkLoginRate(req, context);
  if (!rate.allowed) {
    return json({ error: "LOCKED", retryAfter: rate.retryAfter }, 429, {
      "Retry-After": String(rate.retryAfter)
    });
  }

  let body;
  try { body = await req.json(); } catch { return json({ error: "BAD_REQUEST" }, 400); }
  const ok = verifyAdminCredentials(body?.username || "", body?.password || "");
  if (!ok) {
    await recordLoginFailure(rate);
    await audit("login_password_failed");
    return json({ error: "INVALID_LOGIN" }, 401);
  }

  await clearLoginFailures(rate.key);
  const otpEnabled = await isAdminOtpEnabled();
  const { token, payload } = makePreAuthSession();
  await audit("login_password_success", { sid: payload.sid, otpEnabled });

  return json({
    ok: true,
    otpRequired: true,
    otpSetup: !otpEnabled
  }, 200, {
    "Set-Cookie": preAuthCookie(token),
  });
};
