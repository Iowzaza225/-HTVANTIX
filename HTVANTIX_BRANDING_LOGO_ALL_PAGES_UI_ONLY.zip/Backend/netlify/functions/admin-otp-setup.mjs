import {
  json, sameOrigin, verifyPreAuth, isAdminOtpEnabled, getOrCreatePendingOtp, audit
} from "./_lib.mjs";

export default async (req) => {
  if (req.method !== "POST") return json({ error: "NOT_FOUND" }, 404);
  if (!sameOrigin(req)) return json({ error: "NOT_FOUND" }, 404);
  const pre = verifyPreAuth(req);
  if (!pre) return json({ error: "PREAUTH_REQUIRED" }, 401);
  if (await isAdminOtpEnabled()) return json({ error: "OTP_ALREADY_CONFIGURED" }, 409);

  const pending = await getOrCreatePendingOtp();
  const issuer = encodeURIComponent(String(process.env.HIGHT_ADMIN_OTP_ISSUER || "HIGHTBLACKSHOP"));
  const account = encodeURIComponent(String(process.env.HIGHT_ADMIN_USERNAME || "admin"));
  const otpauth = `otpauth://totp/${issuer}:${account}?secret=${encodeURIComponent(pending.secret)}&issuer=${issuer}&algorithm=SHA1&digits=6&period=30`;
  await audit("otp_setup_started", { sid: pre.sid });
  return json({ ok: true, secret: pending.secret, otpauth, expiresAt: pending.expiresAt });
};
