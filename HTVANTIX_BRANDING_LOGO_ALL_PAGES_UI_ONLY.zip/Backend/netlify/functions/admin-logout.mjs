import { json, requireAdmin, clearSessionCookie, audit } from "./_lib.mjs";

export default async (req) => {
  if (req.method !== "POST") return json({ error: "NOT_FOUND" }, 404);
  const auth = requireAdmin(req, true);
  if (!auth.ok) return auth.response;
  await audit("logout", { sid: auth.session.sid });
  return json({ ok: true }, 200, { "Set-Cookie": clearSessionCookie() });
};
