import { json, requireAdmin, getPatchIndex } from "./_lib.mjs";
export default async (req) => {
  const auth=requireAdmin(req,false); if(!auth.ok)return auth.response;
  if(req.method!=="GET")return json({error:"NOT_FOUND"},404);
  const items=await getPatchIndex();
  items.sort((a,b)=>String(b.createdAt||"").localeCompare(String(a.createdAt||"")));
  return json({packages:items});
};
