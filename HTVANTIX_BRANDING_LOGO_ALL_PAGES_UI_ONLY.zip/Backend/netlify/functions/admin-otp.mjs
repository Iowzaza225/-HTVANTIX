import {
  json, sameOrigin, verifyPreAuth, verifyAdminOtp,
  makeSession, sessionCookie, checkOtpRate, recordOtpFailure,
  clearOtpFailures, audit
} from "./_lib.mjs";

export default async (req, context) => {
  if (req.method !== "POST") return json({ error: "NOT_FOUND" }, 404);
  if (!sameOrigin(req)) return json({ error: "NOT_FOUND" }, 404);
  const pre = verifyPreAuth(req);
  if (!pre) return json({ error: "PREAUTH_REQUIRED" }, 401);

  const rate = await checkOtpRate(req, context);
  if (!rate.allowed) return json({ error: "OTP_LOCKED", retryAfter: rate.retryAfter }, 429, { "Retry-After": String(rate.retryAfter) });

  let body;
  try { body = await req.json(); } catch { return json({ error: "BAD_REQUEST" }, 400); }
  const checked = await verifyAdminOtp(body?.code || "");
  if (!checked.ok) {
    await recordOtpFailure(rate);
    await audit("otp_failed", { sid: pre.sid, reason: checked.reason });
    return json({ error: checked.reason || "INVALID_OTP" }, checked.reason === "OTP_NOT_CONFIGURED" ? 503 : 401);
  }

  await clearOtpFailures(rate.key);
  const { token, payload } = makeSession();
  await audit("login_success_2fa", { sid: payload.sid });
  return json({ ok: true, csrf: payload.csrf }, 200, { "Set-Cookie": sessionCookie(token) });
};
