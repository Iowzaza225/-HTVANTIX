import { json, requireClientSession, getPatchIndex, sanitizeText, logDownload } from "./_lib.mjs";
import { makeR2DownloadURL } from "./_r2.mjs";
export default async (req,context)=>{
  if(req.method!=="GET")return json({error:"NOT_FOUND"},404);
  const access=await requireClientSession(req,context,"download");if(!access.ok)return access.response;
  const url=new URL(req.url),id=sanitizeText(url.searchParams.get("id"),100);const item=(await getPatchIndex()).find(x=>x.id===id&&x.enabled!==false);
  if(!item||!item.r2Key){await logDownload(req,context,id||"unknown","not_found");return json({error:"NOT_FOUND"},404);}
  try{const signed=await makeR2DownloadURL(item.r2Key,item.fileName||"package.bin");await logDownload(req,context,id,"ok");return new Response(null,{status:302,headers:{Location:signed,"Cache-Control":"no-store","X-Content-SHA256":item.sha256||"","X-Content-Length":String(item.sizeBytes||0)}});}catch{await logDownload(req,context,id,"storage_error");return json({error:"STORAGE_ERROR"},502);}
};
