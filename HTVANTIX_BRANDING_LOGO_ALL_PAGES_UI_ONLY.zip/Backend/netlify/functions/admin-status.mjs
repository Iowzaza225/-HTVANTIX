import { json, adminConfigReady, verifySession, csrfForSession, licenseConfigReady, securityConfigReady, getSecurityState, getVersionState, clientSessionConfigReady } from "./_lib.mjs";
export default async (req) => {
  const session = verifySession(req);
  const out = { configured:adminConfigReady(), authenticated:Boolean(session), csrf:session ? csrfForSession(session) : null };
  if (session) {
    out.licenseConfigured = licenseConfigReady();
    out.securityConfigured = securityConfigReady();
    out.clientSessionConfigured = clientSessionConfigReady();
    out.security = await getSecurityState();
    out.version = await getVersionState();
  }
  return json(out);
};
