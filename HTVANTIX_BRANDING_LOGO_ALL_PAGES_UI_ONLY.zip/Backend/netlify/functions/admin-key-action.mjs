import {
  json, requireAdmin, getLicense, saveLicense, deleteLicenseRecord,
  publicLicense, sanitizeText, audit
} from "./_lib.mjs";

export default async (req) => {
  const auth = requireAdmin(req, true);
  if (!auth.ok) return auth.response;
  if (req.method !== "POST") return json({ error: "NOT_FOUND" }, 404);

  let body;
  try { body = await req.json(); } catch { return json({ error: "BAD_REQUEST" }, 400); }
  const id = sanitizeText(body?.id, 100);
  const action = sanitizeText(body?.action, 40);
  if (!id || !action) return json({ error: "BAD_REQUEST" }, 400);

  const rec = await getLicense(id);
  if (!rec) return json({ error: "NOT_FOUND" }, 404);

  if (action === "delete") {
    await deleteLicenseRecord(rec);
    await audit("license_deleted", { id });
    return json({ ok: true, action });
  }

  const now = Date.now();
  if (action === "disable") {
    rec.status = "disabled";
  } else if (action === "enable") {
    rec.status = "active";
  } else if (action === "reset_device") {
    rec.deviceHash = null;
    rec.deviceBoundAt = null;
    rec.lastVerifiedAt = null;
    rec.lastAppVersion = null;
  } else if (action === "extend") {
    const days = Math.max(1, Math.min(3650, Number(body?.days) || 30));
    if (!rec.activatedAt && rec.activationMode === "first_use" && !rec.expiresAt) {
      rec.durationMinutes = null;
      rec.durationDays = Math.min(3650, Number(rec.durationDays || 0) + days);
    } else {
      const current = rec.expiresAt ? Date.parse(rec.expiresAt) : now;
      const base = Math.max(Number.isFinite(current) ? current : now, now);
      rec.expiresAt = new Date(base + days * 86400000).toISOString();
    }
  } else {
    return json({ error: "INVALID_ACTION" }, 400);
  }

  rec.updatedAt = new Date().toISOString();
  await saveLicense(rec);
  await audit("license_updated", { id, action, days: body?.days || null });
  return json({ ok: true, action, license: publicLicense(rec, { includeKey: true }) });
};
