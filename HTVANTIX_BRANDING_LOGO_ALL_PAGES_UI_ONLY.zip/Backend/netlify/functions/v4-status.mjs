import { json, getVersionState } from "./_lib.mjs";

export default async (req)=>{
  if(req.method!=="GET") return json({error:"NOT_FOUND"},404);
  const version = await getVersionState();
  return json({
    ok: true,
    service: "HIGHT API",
    appEnabled: !version.maintenance,
    maintenance: Boolean(version.maintenance),
    message: version.message || (version.maintenance ? "ระบบถูกปิดใช้งานชั่วคราว" : ""),
    currentVersion: version.currentVersion,
    minimumVersion: version.minimumVersion,
    updateURL: version.updateURL || "",
    updatedAt: version.updatedAt || null
  }, 200, { "Cache-Control":"no-store" });
};
