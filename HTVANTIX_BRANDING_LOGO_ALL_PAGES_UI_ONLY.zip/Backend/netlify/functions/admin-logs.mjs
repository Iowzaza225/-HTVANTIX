import { json, requireAdmin, logStore } from "./_lib.mjs";
export default async (req)=>{
  const auth=requireAdmin(req,false); if(!auth.ok)return auth.response;
  if(req.method!=="GET")return json({error:"NOT_FOUND"},404);
  const {blobs}=await logStore().list({prefix:"download/"}); const rows=[];
  for(const b of blobs.slice(-250)){ const x=await logStore().get(b.key,{type:"json",consistency:"strong"}); if(x)rows.push(x); }
  rows.sort((a,b)=>String(b.at).localeCompare(String(a.at))); return json({logs:rows.slice(0,200)});
};
