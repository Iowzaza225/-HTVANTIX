import { json, requireAdmin, getPatchIndex, setPatchIndex, sanitizeText, audit } from "./_lib.mjs";
import { deleteR2Object } from "./_r2.mjs";
export default async (req) => {
  const auth=requireAdmin(req,true); if(!auth.ok)return auth.response;
  if(req.method!=="POST")return json({error:"NOT_FOUND"},404);
  let body; try{body=await req.json();}catch{return json({error:"BAD_REQUEST"},400);}
  const id=sanitizeText(body?.id,100), action=sanitizeText(body?.action,30); const index=await getPatchIndex(); const pos=index.findIndex(x=>x.id===id);
  if(pos<0)return json({error:"NOT_FOUND"},404); const item=index[pos];
  if(action==="enable") item.enabled=true; else if(action==="disable") item.enabled=false; else if(action==="delete") { index.splice(pos,1); await setPatchIndex(index); if(item.r2Key){try{await deleteR2Object(item.r2Key);}catch{}} await audit("package_deleted_v4",{id}); return json({ok:true}); } else return json({error:"INVALID_ACTION"},400);
  item.updatedAt=new Date().toISOString(); index[pos]=item; await setPatchIndex(index); await audit("package_updated_v4",{id,action}); return json({ok:true,package:item});
};
