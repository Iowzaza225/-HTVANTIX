import {
  json, requireAdmin, getLicenseIndex, getLicense, createLicenseRecord,
  publicLicense, audit, licenseConfigReady
} from "./_lib.mjs";

export default async (req) => {
  const mutating = req.method !== "GET";
  const auth = requireAdmin(req, mutating);
  if (!auth.ok) return auth.response;
  if (!licenseConfigReady()) return json({ error: "LICENSE_CONFIG_MISSING" }, 503);

  if (req.method === "GET") {
    const ids = await getLicenseIndex();
    const rows = [];
    for (const id of ids) {
      const rec = await getLicense(id);
      if (rec) rows.push(publicLicense(rec, { includeKey: true }));
    }
    rows.sort((a,b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    return json({ licenses: rows });
  }

  if (req.method !== "POST") return json({ error: "NOT_FOUND" }, 404);

  let body;
  try { body = await req.json(); } catch { return json({ error: "BAD_REQUEST" }, 400); }
  const requestedMinutes = Number(body?.minutes);
  const minutes = Number.isFinite(requestedMinutes) && requestedMinutes > 0 ? Math.max(1, Math.min(1440, Math.floor(requestedMinutes))) : null;
  const days = minutes ? null : Math.max(1, Math.min(3650, Number(body?.days) || 30));
  const quantity = Math.max(1, Math.min(50, Number(body?.quantity) || 1));
  const activationMode = body?.activationMode === "immediate" ? "immediate" : "first_use";

  const created = [];
  for (let i = 0; i < quantity; i++) {
    const { record, key } = await createLicenseRecord({ durationDays: days, durationMinutes: minutes, activationMode });
    created.push({ ...publicLicense(record), key });
    await audit("license_created", { id: record.id, days, minutes, activationMode });
  }
  return json({ ok: true, licenses: created }, 201);
};
