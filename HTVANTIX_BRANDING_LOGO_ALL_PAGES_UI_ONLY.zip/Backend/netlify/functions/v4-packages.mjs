import { json, requireClientSession, getPatchIndex } from "./_lib.mjs";
export default async (req,context)=>{
  if(req.method!=="GET")return json({error:"NOT_FOUND"},404);
  const access=await requireClientSession(req,context,"metadata");if(!access.ok)return access.response;
  const items=(await getPatchIndex()).filter(x=>x.enabled!==false).map(x=>({id:x.id,name:x.name,description:x.description||"",version:x.version||"1.0",game:x.game||null,category:x.category||"other",fileName:x.fileName,sizeBytes:x.sizeBytes,sha256:x.sha256,createdAt:x.createdAt}));
  return json({ok:true,packages:items});
};
