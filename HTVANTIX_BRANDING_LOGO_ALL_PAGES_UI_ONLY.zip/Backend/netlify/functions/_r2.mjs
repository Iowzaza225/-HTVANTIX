import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  HeadObjectCommand,
  DeleteObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

export const R2_MAX_UPLOAD_BYTES = 150 * 1024 * 1024;
export const R2_UPLOAD_URL_TTL = 10 * 60;
export const R2_DOWNLOAD_URL_TTL = 60;

function env(name) {
  return String(process.env[name] || "").trim();
}

export function r2Ready() {
  return Boolean(
    env("HIGHT_R2_ACCOUNT_ID") &&
    env("HIGHT_R2_ACCESS_KEY_ID") &&
    env("HIGHT_R2_SECRET_ACCESS_KEY") &&
    env("HIGHT_R2_BUCKET")
  );
}

export function r2Bucket() {
  return env("HIGHT_R2_BUCKET");
}

let cachedClient = null;
export function r2Client() {
  if (!r2Ready()) throw new Error("R2_NOT_CONFIGURED");
  if (cachedClient) return cachedClient;
  const accountId = env("HIGHT_R2_ACCOUNT_ID");
  cachedClient = new S3Client({
    region: "auto",
    endpoint: `https://${accountId}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: env("HIGHT_R2_ACCESS_KEY_ID"),
      secretAccessKey: env("HIGHT_R2_SECRET_ACCESS_KEY"),
    },
  });
  return cachedClient;
}

export async function makeR2UploadURL(objectKey) {
  return getSignedUrl(
    r2Client(),
    new PutObjectCommand({
      Bucket: r2Bucket(),
      Key: objectKey,
      ContentType: "application/octet-stream",
    }),
    { expiresIn: R2_UPLOAD_URL_TTL },
  );
}

export async function makeR2DownloadURL(objectKey, fileName = "patch.3105") {
  const safeName = String(fileName || "patch.3105").replace(/[\r\n"]/g, "_");
  return getSignedUrl(
    r2Client(),
    new GetObjectCommand({
      Bucket: r2Bucket(),
      Key: objectKey,
      ResponseContentType: "application/octet-stream",
      ResponseContentDisposition: `attachment; filename="${safeName.replace(/[^\x20-\x7E]/g, "_")}"`,
    }),
    { expiresIn: R2_DOWNLOAD_URL_TTL },
  );
}

export async function headR2Object(objectKey) {
  return r2Client().send(new HeadObjectCommand({ Bucket: r2Bucket(), Key: objectKey }));
}

export async function readR2HeadBytes(objectKey, maxBytes = 4096) {
  const result = await r2Client().send(new GetObjectCommand({
    Bucket: r2Bucket(),
    Key: objectKey,
    Range: `bytes=0-${Math.max(0, maxBytes - 1)}`,
  }));
  if (!result.Body) return Buffer.alloc(0);
  if (typeof result.Body.transformToByteArray === "function") {
    return Buffer.from(await result.Body.transformToByteArray());
  }
  const chunks = [];
  for await (const chunk of result.Body) chunks.push(Buffer.from(chunk));
  return Buffer.concat(chunks);
}

export async function deleteR2Object(objectKey) {
  return r2Client().send(new DeleteObjectCommand({ Bucket: r2Bucket(), Key: objectKey }));
}


export async function sha256R2Object(objectKey) {
  const cryptoMod = await import("node:crypto");
  const result = await r2Client().send(new GetObjectCommand({ Bucket: r2Bucket(), Key: objectKey }));
  if (!result.Body) throw new Error("R2_EMPTY_BODY");
  const hash = cryptoMod.createHash("sha256");
  let size = 0;
  for await (const chunk of result.Body) {
    const b = Buffer.from(chunk);
    size += b.length;
    if (size > R2_MAX_UPLOAD_BYTES) throw new Error("R2_TOO_LARGE");
    hash.update(b);
  }
  return { sha256: hash.digest("hex"), sizeBytes:size };
}
