import { json, requireAdmin, getSecurityState, saveSecurityState, audit, sanitizeText } from "./_lib.mjs";

export default async (req) => {
  const auth = requireAdmin(req, req.method !== "GET");
  if (!auth.ok) return auth.response;

  if (req.method === "GET") {
    return json({ security: await getSecurityState() });
  }
  if (req.method !== "PATCH") return json({ error: "NOT_FOUND" }, 404);

  let body;
  try { body = await req.json(); } catch { return json({ error: "BAD_REQUEST" }, 400); }
  const current = await getSecurityState();
  const next = await saveSecurityState({
    emergencyLock: typeof body?.emergencyLock === "boolean" ? body.emergencyLock : current.emergencyLock,
    metadataEnabled: typeof body?.metadataEnabled === "boolean" ? body.metadataEnabled : current.metadataEnabled,
    downloadsEnabled: typeof body?.downloadsEnabled === "boolean" ? body.downloadsEnabled : current.downloadsEnabled,
    sessionsEnabled: typeof body?.sessionsEnabled === "boolean" ? body.sessionsEnabled : current.sessionsEnabled,
    reason: sanitizeText(body?.reason ?? current.reason, 120),
  });
  await audit("security_state_updated", {
    sid: auth.session?.sid || null,
    emergencyLock: next.emergencyLock,
    metadataEnabled: next.metadataEnabled,
    downloadsEnabled: next.downloadsEnabled,
    sessionsEnabled: next.sessionsEnabled,
    reason: next.reason || null,
  });
  return json({ ok: true, security: next });
};
