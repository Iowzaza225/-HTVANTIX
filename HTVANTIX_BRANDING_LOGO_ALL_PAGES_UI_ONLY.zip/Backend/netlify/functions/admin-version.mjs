import { json, requireAdmin, getVersionState, saveVersionState, sanitizeText, audit } from "./_lib.mjs";
export default async (req)=>{
  const auth=requireAdmin(req,req.method!=="GET"); if(!auth.ok)return auth.response;
  if(req.method==="GET")return json({version:await getVersionState()});
  if(req.method!=="PATCH")return json({error:"NOT_FOUND"},404);
  let body;try{body=await req.json();}catch{return json({error:"BAD_REQUEST"},400);}
  const allowedBuilds=Array.isArray(body?.allowedBuilds)?body.allowedBuilds:String(body?.allowedBuilds||"").split(/[,\n]/).map(x=>x.trim()).filter(Boolean);
  const next=await saveVersionState({currentVersion:body?.currentVersion,minimumVersion:body?.minimumVersion,updateURL:body?.updateURL,message:body?.message,releaseNotes:body?.releaseNotes,maintenance:body?.maintenance,allowedBuilds});
  await audit("version_state_updated",{sid:auth.session?.sid||null,currentVersion:next.currentVersion,minimumVersion:next.minimumVersion,maintenance:next.maintenance,allowedBuildCount:next.allowedBuilds.length});
  return json({ok:true,version:next});
};
