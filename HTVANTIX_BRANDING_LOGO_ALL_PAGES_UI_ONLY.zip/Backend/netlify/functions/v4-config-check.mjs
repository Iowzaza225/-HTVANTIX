import { json } from "./_lib.mjs";
export default async (req) => {
  if (req.method !== "GET") return json({ error: "NOT_FOUND" }, 404);
  return json({
    ok: true,
    config: {
      appToken: Boolean(process.env.HIGHT_APP_TOKEN),
      licenseSecret: Boolean(process.env.HIGHT_LICENSE_SECRET),
      clientSessionSecret: Boolean(process.env.HIGHT_CLIENT_SESSION_SECRET),
      fallbackSessionSecret: Boolean(process.env.HIGHT_SESSION_SECRET)
    }
  }, 200, { "Cache-Control": "no-store" });
};
