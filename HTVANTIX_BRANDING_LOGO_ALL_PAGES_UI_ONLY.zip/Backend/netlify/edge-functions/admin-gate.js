const encoder = new TextEncoder();
const decoder = new TextDecoder();

function parseCookies(header) {
  const out = {};
  for (const part of String(header || "").split(";")) {
    const i = part.indexOf("=");
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    const v = part.slice(i + 1).trim();
    if (!k) continue;
    try { out[k] = decodeURIComponent(v); } catch { out[k] = v; }
  }
  return out;
}

function decodeBase64Url(value) {
  let s = String(value || "").replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  const raw = atob(s);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}

async function verifyAdminSession(request) {
  const secret = Netlify.env.get("HIGHT_SESSION_SECRET");
  if (!secret) return null;

  const cookies = parseCookies(request.headers.get("cookie"));
  const token = cookies["__Host-hight_admin_v4"] || "";
  const parts = token.split(".");
  if (parts.length !== 2) return null;

  const [body, signature] = parts;
  if (!body || !signature) return null;

  try {
    const key = await crypto.subtle.importKey(
      "raw",
      encoder.encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"],
    );

    const valid = await crypto.subtle.verify(
      "HMAC",
      key,
      decodeBase64Url(signature),
      encoder.encode(body),
    );
    if (!valid) return null;

    const payload = JSON.parse(decoder.decode(decodeBase64Url(body)));
    const now = Math.floor(Date.now() / 1000);

    if (payload?.sub !== "admin") return null;
    if (payload?.adminSessionVersion !== 4) return null;
    if (!Number(payload?.exp) || Number(payload.exp) < now) return null;

    return payload;
  } catch {
    return null;
  }
}

function securityHeaders(extra = {}) {
  return {
    "Cache-Control": "no-store, max-age=0",
    "Pragma": "no-cache",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "X-Robots-Tag": "noindex, nofollow, noarchive",
    "Content-Security-Policy":
      "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; form-action 'self'; base-uri 'none'; frame-ancestors 'none'; object-src 'none'",
    ...extra,
  };
}

function loginPage() {
  const html = `<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="robots" content="noindex,nofollow,noarchive">
  <title>HIGHT Admin • Login</title>
  <link rel="stylesheet" href="/auth/admin-login.css?v=400">
</head>
<body>
  <main class="login-shell">
    <section class="login-card">
      <div class="brand">HIGHT<span>BLACKSHOP</span></div>
      <div class="version">HIGHT API V4.0.1 • ADMIN OTP</div>
      <h1>Admin Login</h1>
      <p class="hint">พื้นที่สำหรับผู้ดูแลระบบเท่านั้น</p>
      <form id="adminLogin" autocomplete="on">
        <div id="passwordStage">
          <label for="username">ชื่อผู้ใช้</label>
          <input id="username" name="username" type="text" value="admin"
                 autocomplete="username" autocapitalize="none" spellcheck="false" required>
          <label for="password">รหัสผ่าน</label>
          <input id="password" name="password" type="password"
                 autocomplete="current-password" required>
        </div>

        <div id="otpStage" class="hidden">
          <div id="otpSetupBox" class="setup-box hidden">
            <div class="setup-title">ตั้งค่า OTP ครั้งแรก</div>
            <p>เปิด Google Authenticator หรือ Microsoft Authenticator แล้วเลือกเพิ่มบัญชีด้วย Setup Key</p>
            <div class="secret-row">
              <code id="otpSecret">-</code>
              <button id="copySecret" class="secondary" type="button">คัดลอก</button>
            </div>
            <small>ประเภท: Time based • 6 digits • 30 seconds</small>
          </div>
          <label for="otpCode">รหัส OTP 6 หลัก</label>
          <input id="otpCode" name="otpCode" type="text" inputmode="numeric"
                 pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" placeholder="000000">
        </div>

        <button id="loginButton" type="submit">เข้าสู่ระบบ</button>
        <p id="loginMessage" class="message" aria-live="polite"></p>
      </form>
    </section>
  </main>
  <script src="/auth/admin-login.js?v=400" defer></script>
</body>
</html>`;

  return new Response(html, {
    status: 200,
    headers: securityHeaders({
      "Content-Type": "text/html; charset=utf-8",
    }),
  });
}

function unauthorizedApi() {
  return Response.json(
    { error: "UNAUTHORIZED" },
    {
      status: 401,
      headers: securityHeaders({
        "Content-Type": "application/json; charset=utf-8",
      }),
    },
  );
}

export default async (request, context) => {
  const url = new URL(request.url);
  const path = url.pathname;

  // Login is intentionally the only unauthenticated admin endpoint.
  // Credential checking, lockout and same-origin checks remain in the
  // existing serverless function.
  if ([
    "/admin/api/login",
    "/admin/api/otp",
    "/admin/api/otp-setup",
    "/admin/api/otp-confirm"
  ].includes(path)) {
    return context.next();
  }

  const session = await verifyAdminSession(request);

  // Never send the real admin UI/assets without a valid signed session.
  if (!session) {
    if (path.startsWith("/admin/api/")) return unauthorizedApi();
    return loginPage();
  }

  // Valid session: continue to the existing static admin UI or serverless API.
  return context.next();
};

export const config = {
  path: ["/admin", "/admin/*"],
};
