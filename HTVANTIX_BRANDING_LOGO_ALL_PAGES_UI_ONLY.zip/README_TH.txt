HTVANTIX License Session + Remote Control

Client:
- ไม่มี HTVANTIX_APP_TOKEN / HTVANTIXAppToken ใน IPA
- Settings: ใส่ License Key, ดูสถานะ/วันหมดอายุ, Screen Protection toggle
- License Key -> License Token -> Client Session
- หน้า Patch ใช้ Client Session สำหรับ packages/download

Backend:
- License redeem และ Client session ไม่ต้องใช้ X-App-Token
- packages/download ยังต้องมี Client Session
- ใช้ Maintenance ในหน้า Version/Control เป็น Remote App OFF
- /api/v4/status ส่ง appEnabled + message ให้ Client

ลำดับติดตั้ง:
1) Deploy โฟลเดอร์ Backend ไป Netlify ก่อน
2) Build โฟลเดอร์ Client เป็น IPA
3) สร้าง License Key จากหลังบ้าน แล้ว Activate ใน Settings
4) ทดสอบ packages/download
5) ทดสอบ Maintenance ON/OFF
