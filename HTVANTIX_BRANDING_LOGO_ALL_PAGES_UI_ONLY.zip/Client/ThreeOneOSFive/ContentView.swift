import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator

    var body: some View {
        HTVANTIXHomeView()
            .preferredColorScheme(.dark)
            .tint(AppTheme.accent)
    }
}

private struct HTVANTIXHomeView: View {
    @EnvironmentObject private var appState: AppState
    @Environment(\.appLanguage) private var language
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.pageBackground.ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 14) {
                        header
                        deviceCard

                        NavigationLink {
                            PatchProjectsView(gameFilter: "ff", gameTitle: "Free Fire")
                        } label: {
                            gameCard(title: "Free Fire", subtitle: "พร้อมใช้งาน", badge: "FF")
                        }
                        .buttonStyle(.plain)

                        NavigationLink {
                            PatchProjectsView(gameFilter: "ffmax", gameTitle: "Free Fire MAX")
                        } label: {
                            gameCard(title: "Free Fire MAX", subtitle: "พร้อมใช้งาน", badge: "MAX")
                        }
                        .buttonStyle(.plain)

                        statusCard
                        updateCard
                    }
                    .padding(.horizontal, 18)
                    .padding(.bottom, 28)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSettings) {
                SettingsView()
                    .preferredColorScheme(.dark)
            }
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("HTVANTIX")
                    .font(.system(size: 23, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("GAME ENHANCER")
                    .font(.caption2.weight(.semibold))
                    .tracking(2.0)
                    .foregroundStyle(AppTheme.accent)
            }

            Spacer()

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(AppTheme.cardBackground, in: Circle())
                    .overlay(Circle().stroke(AppTheme.border, lineWidth: 1))
            }
            .accessibilityLabel(language.text("settings.title"))
        }
        .padding(.top, 10)
        .padding(.bottom, 2)
    }

    private var deviceCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("DEVICE")
                        .htSectionLabel()
                    Text(AppInfo.displayMachineName)
                        .font(.title2.weight(.bold))
                        .foregroundStyle(.white)
                }

                Spacer()

                Text("iOS \(AppInfo.osVersion)")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.84))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color.white.opacity(0.055), in: Capsule())
            }

            Divider().overlay(AppTheme.border)

            HStack {
                VStack(alignment: .leading, spacing: 6) {
                    Text("COMPATIBILITY")
                        .htSectionLabel()
                    Text("Universal iOS")
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.white)
                }

                Spacer()

                Label(appState.isSupported ? "รองรับ" : "ไม่รองรับ",
                      systemImage: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(appState.isSupported ? .green : .red)
            }
        }
        .htCard()
    }

    private func gameCard(title: String, subtitle: String, badge: String) -> some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [AppTheme.accent.opacity(0.30), Color.blue.opacity(0.13)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 58, height: 58)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(AppTheme.accent.opacity(0.35), lineWidth: 1)
                    )

                Text(badge)
                    .font(.system(size: badge == "MAX" ? 12 : 16, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
            }

            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)

                HStack(spacing: 6) {
                    Circle().fill(Color.green).frame(width: 7, height: 7)
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(Color.green)
                }
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(AppTheme.accent)
        }
        .htCard(padding: 14)
    }

    private var statusCard: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color.green.opacity(0.14))
                    .frame(width: 50, height: 50)
                Circle()
                    .fill(Color.green)
                    .frame(width: 13, height: 13)
                    .shadow(color: .green.opacity(0.9), radius: 8)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("HTVANTIX STATUS")
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                Text(appState.isSupported ? "ระบบพร้อมใช้งาน" : "อุปกรณ์ไม่รองรับ")
                    .font(.caption)
                    .foregroundStyle(appState.isSupported ? Color.green : Color.red)
            }

            Spacer()

            Image(systemName: "checkmark.shield.fill")
                .font(.title2)
                .foregroundStyle(appState.isSupported ? Color.green : Color.secondary)
        }
        .htCard(padding: 14)
    }

    private var updateCard: some View {
        HStack(spacing: 14) {
            AppRowIcon(systemName: "arrow.triangle.2.circlepath", tint: AppTheme.accent, symbolSize: 20, frameSize: 48)

            VStack(alignment: .leading, spacing: 4) {
                Text("HTVANTIX UPDATE")
                    .font(.caption.weight(.black))
                    .tracking(1.4)
                    .foregroundStyle(.white)
                Text("เวอร์ชันล่าสุดพร้อมใช้งาน")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "checkmark.circle.fill")
                .font(.title2)
                .foregroundStyle(Color.green)
        }
        .htCard(padding: 14)
    }
}

private extension View {
    func htCard(padding: CGFloat = 18) -> some View {
        self
            .padding(padding)
            .background(
                RoundedRectangle(cornerRadius: 19, style: .continuous)
                    .fill(AppTheme.cardBackground)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 19, style: .continuous)
                    .stroke(AppTheme.border, lineWidth: 1)
            )
    }

    func htSectionLabel() -> some View {
        self
            .font(.caption2.weight(.bold))
            .tracking(1.8)
            .foregroundStyle(.secondary)
    }
}
