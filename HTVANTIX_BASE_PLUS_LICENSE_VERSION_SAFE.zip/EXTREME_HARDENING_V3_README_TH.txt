HTVANTIX EXTREME HARDENING V3 (EXPERIMENTAL)

เพิ่ม:
- Release -O + whole module
- strip symbols / postprocess / dead code stripping
- ลด Swift reflection metadata และ debug serialization
- anti-debug sysctl
- ตรวจ DYLD / Frida / Substrate / Substitute / ElleKit / libhooker / FLEX / Reveal
- endpoint/network path สำคัญถูก XOR encode ไม่เก็บเป็น plain text ตรง ๆ
- แก้ duplicate App init ใน source แล้ว

ไม่แตะ:
- Apply/Restore/PatchTransaction/DevicePatchService
- Backend API logic
- Bundle Identifier

หมายเหตุ: ตัวนี้ aggressive กว่า V2 ควรทดสอบบนเครื่องจริงก่อนใช้เป็นฐานหลัก
