import SwiftUI
import UIKit
import UniformTypeIdentifiers

private enum PatchPackagePickerPolicy {
    static let packageType = UTType(filenameExtension: "3105") ?? .data
    static let allowedContentTypes: [UTType] = [packageType, .data]
    static let copiesSelectedDocument = true
}

private enum WallpaperPackagePickerPolicy {
    static let packageType = UTType(filenameExtension: "tendies") ?? .data
    static let allowedContentTypes: [UTType] = [packageType, .data]
}

struct PatchProjectsView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var draftCoordinator: PatchDraftCoordinator
    @EnvironmentObject private var store: PatchProjectStore
    @EnvironmentObject private var licenseManager: HTVLicenseManager
    @StateObject private var serverCatalog = PatchServerCatalog()
    @State private var activeProjectIDs: Set<UUID> = []
    @State private var workingProjectIDs: Set<UUID> = []
    @State private var needsRefilingProjectIDs: Set<UUID> = []
    @State private var userDisabledProjectIDs: Set<UUID> = Self.loadUserDisabledProjectIDs()
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @State private var showCreate = false
    @State private var showImporter = false
    @State private var showWallpaperImporter = false
    @State private var showCleaner = false
    @State private var searchText = ""
    @State private var wallpaperPackages: [WallpaperStagedPackage] = []
    @State private var wallpaperImportFeedback: WallpaperImportFeedback?
    @State private var wallpaperPendingDeletion: WallpaperStagedPackage?
    @State private var isImportingWallpapers = false
    @State private var showSimulatedWallpaperDetail = false
    @State private var simulatedWallpaperDetailGate = OneShotPresentationGate()
    let gameFilter: String?
    let screenTitle: String?
    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    private var localOnlyItems: [PatchLibraryItem] {
        store.items.filter { !serverCatalog.mappedLocalPackageIDs.contains($0.id) }
    }

    private var filteredItems: [PatchLibraryItem] {
        guard gameFilter == nil else { return [] }
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return localOnlyItems }
        return localOnlyItems.filter { item in
            if item.packageURL.lastPathComponent.localizedCaseInsensitiveContains(query) {
                return true
            }
            guard let project = item.project else { return false }
            if project.name.localizedCaseInsensitiveContains(query)
                || project.author.localizedCaseInsensitiveContains(query) {
                return true
            }
            guard item.canInspectContents else { return false }
            return project.allBundleIdentifiers.contains {
                    $0.localizedCaseInsensitiveContains(query)
                }
                || project.directories.contains {
                    $0.relativePath.localizedCaseInsensitiveContains(query)
                }
                || project.rules.contains {
                    $0.relativePath.localizedCaseInsensitiveContains(query)
                        || $0.replacementFilename.localizedCaseInsensitiveContains(query)
                }
        }
    }

    private var filteredRemoteItems: [PatchServerCatalog.RemoteItem] {
        let scoped = serverCatalog.items.filter { remote in
            guard let gameFilter else { return true }
            return remote.game == gameFilter
        }
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return scoped }
        return scoped.filter { remote in
            remote.name.localizedCaseInsensitiveContains(query)
                || remote.description.localizedCaseInsensitiveContains(query)
                || remote.version.localizedCaseInsensitiveContains(query)
                || serverCatalog.gameTitle(remote.game).localizedCaseInsensitiveContains(query)
                || serverCatalog.categoryTitle(remote.category).localizedCaseInsensitiveContains(query)
        }
    }

    private var filteredWallpaperPackages: [WallpaperStagedPackage] {
        guard gameFilter == nil else { return [] }
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return wallpaperPackages }
        return wallpaperPackages.filter {
            $0.displayName.localizedCaseInsensitiveContains(query)
        }
    }

    private var hasLocalContent: Bool {
        if gameFilter != nil { return !filteredRemoteItems.isEmpty }
        return !serverCatalog.items.isEmpty || !localOnlyItems.isEmpty || !wallpaperPackages.isEmpty
    }

    private var hasSearchResults: Bool {
        !filteredRemoteItems.isEmpty || !filteredItems.isEmpty || !filteredWallpaperPackages.isEmpty
    }

    init(
        gameFilter: String? = nil,
        screenTitle: String? = nil,
        onOpenSettings: @escaping () -> Void = {},
        onOpenLogs: @escaping () -> Void = {}
    ) {
        self.gameFilter = gameFilter
        self.screenTitle = screenTitle
        self.onOpenSettings = onOpenSettings
        self.onOpenLogs = onOpenLogs
#if targetEnvironment(simulator)
        _showCreate = State(
            initialValue: ProcessInfo.processInfo.arguments.contains("--simulate-patch-editor")
        )
#endif
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                List {
                    if serverCatalog.isLoading && serverCatalog.items.isEmpty {
                        HStack(spacing: 10) {
                            ProgressView()
                            Text("กำลังเตรียมรายการไฟล์ VIPERX…")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .listRowSeparator(.hidden)
                    }

                    if let message = serverCatalog.errorMessage, serverCatalog.items.isEmpty {
                        VStack(spacing: 8) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundStyle(.orange)
                            Text("เชื่อมต่อ VIPERX ไม่สำเร็จ")
                                .font(.headline)
                            Text(message)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                            Button("ลองใหม่") {
                                Task { await refreshServerCatalog() }
                            }
                            .buttonStyle(.bordered)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 22)
                        .listRowSeparator(.hidden)
                    }

                    if !hasLocalContent && (store.isBusy || isImportingWallpapers || serverCatalog.isLoading) {
                        loadingState
                            .listRowSeparator(.hidden)
                    } else if !hasLocalContent {
                        emptyState
                            .listRowSeparator(.hidden)
                    } else if !hasSearchResults && !store.isBusy {
                        searchEmptyState
                            .listRowSeparator(.hidden)
                    } else {
                        if !filteredRemoteItems.isEmpty {
                            Section {
                                ForEach(filteredRemoteItems) { remote in
                                    if let item = localItem(for: remote) {
                                        serverPatchRow(item, remote: remote)
                                    } else {
                                        serverPendingRow(remote)
                                    }
                                }
                            } header: {
                                HStack {
                                    Text("รายการแพตช์")
                                    Spacer()
                                    if serverCatalog.isLoading { ProgressView().controlSize(.mini) }
                                }
                            }
                        }

                        if !filteredItems.isEmpty {
                            Section("ไฟล์ในเครื่อง") {
                                ForEach(filteredItems) { item in
                                    itemRow(item)
                                }
                                .onDelete { offsets in
                                    offsets.map { filteredItems[$0] }.forEach(store.delete)
                                }
                            }
                        }
                        if !filteredWallpaperPackages.isEmpty {
                            Section(language.text("tab.wallpapers")) {
                                ForEach(filteredWallpaperPackages) { package in
                                    NavigationLink {
                                        InstalledWallpaperPackageDetailView(
                                            package: package,
                                            onApplied: reloadWallpaperPackages
                                        )
                                    } label: {
                                        wallpaperRow(package)
                                    }
                                    .swipeActions(
                                        edge: .trailing,
                                        allowsFullSwipe: false
                                    ) {
                                        Button(role: .destructive) {
                                            wallpaperPendingDeletion = package
                                        } label: {
                                            Label(
                                                language.text("common.delete"),
                                                systemImage: "trash"
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .background(AppTheme.canvas)
                .refreshable {
                    await refreshServerCatalog()
                }
            }
            .navigationTitle(screenTitle ?? language.text("tab.installed"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(AppTheme.canvas.opacity(0.96), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar(.hidden, for: .tabBar)
            .toolbar {
                // Production UI intentionally exposes Settings only. The former
                // manual add/import and Logs flows remain in source but are hidden.
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: onOpenSettings) {
                        Image(systemName: "gearshape")
                    }
                    .accessibilityLabel(language.text("accessibility.open_settings"))
                }
            }
            .sheet(isPresented: $showImporter) {
                FileDocumentPicker(
                    allowedContentTypes: PatchPackagePickerPolicy.allowedContentTypes,
                    copiesSelectedDocument: PatchPackagePickerPolicy.copiesSelectedDocument,
                    allowsMultipleSelection: false,
                    onSelection: { result in
                        showImporter = false
                        if case .success(let urls) = result, let url = urls.first {
                            store.importPackage(at: url)
                        }
                    },
                    onCancel: {
                        showImporter = false
                    }
                )
                .ignoresSafeArea()
            }
            .sheet(isPresented: $showCreate) {
                PatchProjectEditorView(
                    existingProject: nil,
                    passwordIsProtected: false
                ) { project, password in
                    store.create(project: project, password: password)
                }
            }
            .sheet(isPresented: $showCleaner) {
                CleanerView()
            }
            .sheet(item: $draftCoordinator.request) { request in
                PatchProjectEditorView(
                    existingProject: nil,
                    passwordIsProtected: false,
                    initialDraft: request.draft
                ) { project, password in
                    store.create(project: project, password: password)
                    draftCoordinator.clear()
                }
            }
            .sheet(isPresented: $showWallpaperImporter) {
                FileDocumentPicker(
                    allowedContentTypes: WallpaperPackagePickerPolicy.allowedContentTypes,
                    copiesSelectedDocument: true,
                    allowsMultipleSelection: true,
                    onSelection: { result in
                        showWallpaperImporter = false
                        if case .success(let urls) = result, !urls.isEmpty {
                            importWallpaperPackages(urls)
                        }
                    },
                    onCancel: {
                        showWallpaperImporter = false
                    }
                )
                .ignoresSafeArea()
            }
            .alert(item: $wallpaperImportFeedback) { feedback in
                Alert(
                    title: Text(language.text(feedback.titleKey)),
                    message: Text(feedback.message),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
            .alert(item: $store.alert) { alert in
                Alert(
                    title: Text(language.text(alert.titleKey)),
                    message: Text(alert.message(language: language)),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
            .alert(item: $wallpaperPendingDeletion) { package in
                Alert(
                    title: Text(language.text("wallpaper.delete_title")),
                    message: Text(language.text(
                        "wallpaper.delete_message",
                        package.displayName
                    )),
                    primaryButton: .destructive(
                        Text(language.text("common.delete"))
                    ) {
                        deleteWallpaperPackage(package)
                    },
                    secondaryButton: .cancel(Text(language.text("common.cancel")))
                )
            }
            .onAppear {
                reloadWallpaperPackages()
                refreshPatchHealth()
                consumeExternalImport()
                syncActiveStates()
                if serverCatalog.items.isEmpty, !serverCatalog.isLoading {
                    Task { await refreshServerCatalog() }
                }
#if targetEnvironment(simulator)
                if ProcessInfo.processInfo.arguments.contains(
                    "--simulate-wallpaper-detail"
                ), !wallpaperPackages.isEmpty,
                   simulatedWallpaperDetailGate.claim() {
                    DispatchQueue.main.async {
                        showSimulatedWallpaperDetail = true
                    }
                }
#endif
            }
            .navigationDestination(isPresented: $showSimulatedWallpaperDetail) {
                if let package = wallpaperPackages.first {
                    InstalledWallpaperPackageDetailView(
                        package: package,
                        onApplied: reloadWallpaperPackages
                    )
                }
            }
            .onChange(of: draftCoordinator.importRequest?.id) { _ in
                consumeExternalImport()
            }
            .onChange(of: scenePhase) { phase in
                if phase == .active { refreshPatchHealth() }
            }
        }
    }

    @MainActor
    private func refreshServerCatalog() async {
        do {
            // Server metadata/download endpoints use a short-lived client session.
            // Renew it before every explicit catalog sync so Installed keeps working
            // even after the app has been open longer than the session TTL.
            await licenseManager.bootstrap(forceSessionRefresh: true)
            guard licenseManager.isAuthorized else {
                throw PatchServerError.sessionRequired
            }

            let remoteItems = try await serverCatalog.load()
            var warnings: [String] = []
            let activeRemoteIDs = Set(remoteItems.map(\.id))

            // If an admin disables/removes a server package, restore any active
            // patch first and remove its cached local copy. This prevents a
            // server-hidden package from remaining active on the device.
            for stale in serverCatalog.staleBindings(activeRemoteIDs: activeRemoteIDs) {
                do {
                    try removeServerManagedPackage(localID: stale.localID)
                    serverCatalog.unbind(remoteID: stale.remoteID)
                } catch {
                    warnings.append("ล้างไฟล์เก่าไม่สำเร็จ: \(error.localizedDescription)")
                }
            }

            for remote in remoteItems where serverCatalog.needsDownload(remote, localItems: store.items)
                || serverCatalog.hasSharedLocalBinding(forRemoteID: remote.id) {
                do {
                    let previousLocalID = serverCatalog.localPackageID(forRemoteID: remote.id)
                    let origin = PatchPackageOrigin(
                        repositoryName: "VIPERX",
                        repositoryURL: serverCatalog.baseURL,
                        packageIdentifier: remote.id
                    )
                    let sharedBinding = previousLocalID.map {
                        serverCatalog.isLocalPackageIDShared($0)
                    } ?? false
                    let desiredLocalID = sharedBinding ? UUID() : (previousLocalID ?? UUID())
                    let packageID = try await store.importRemotePackageSilently(
                        from: serverCatalog.downloadURL(for: remote),
                        headers: serverCatalog.requestHeaders,
                        expectedSHA256: remote.sha256,
                        origin: origin,
                        forcedPackageID: desiredLocalID
                    )

                    serverCatalog.bind(
                        remoteID: remote.id,
                        to: packageID,
                        fingerprint: remote.fingerprint
                    )

                    if let previousLocalID,
                       previousLocalID != packageID,
                       !serverCatalog.isLocalPackageIDMapped(previousLocalID) {
                        try removeServerManagedPackage(localID: previousLocalID)
                    }
                } catch {
                    warnings.append("\(remote.name): \(error.localizedDescription)")
                }
            }

            store.reload()
            serverCatalog.finishSync(warning: warnings.first)
            syncActiveStates()
            refreshPatchHealth()
        } catch {
            serverCatalog.fail(error)
        }
    }

    @MainActor
    private func removeServerManagedPackage(localID: UUID) throws {
        if let receipt = DevicePatchService.latestReceipt(projectID: localID) {
            try DevicePatchService.restore(receipt: receipt)
        }
        if let item = store.items.first(where: { $0.id == localID }) {
            store.delete(item)
        }
        userDisabledProjectIDs.remove(localID)
        saveUserDisabledProjectIDs()
    }

    private func localItem(for remote: PatchServerCatalog.RemoteItem) -> PatchLibraryItem? {
        guard let localID = serverCatalog.localPackageID(forRemoteID: remote.id) else { return nil }
        return store.items.first(where: { $0.id == localID })
    }

    @ViewBuilder
    private func serverGameIcon(_ game: String, frameSize: CGFloat = 44) -> some View {
        let assetName = game == "ffmax" ? "FreeFireMaxIcon" : "FreeFireIcon"
        Image(assetName)
            .resizable()
            .scaledToFill()
            .frame(width: frameSize, height: frameSize)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.accent.opacity(0.28), lineWidth: 1))
    }

    @ViewBuilder
    private func serverPendingRow(_ remote: PatchServerCatalog.RemoteItem) -> some View {
        HStack(spacing: 12) {
            serverGameIcon(remote.game ?? "ff", frameSize: 42)
            VStack(alignment: .leading, spacing: 4) {
                Text(remote.name)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text("\(serverCatalog.gameTitle(remote.game)) • \(serverCatalog.categoryTitle(remote.category))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text("กำลังเตรียมไฟล์…")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(AppTheme.accent)
            }
            Spacer()
            ProgressView().controlSize(.small)
        }
        .htvCard(padding: 14)
        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
        .listRowBackground(Color.clear)
        .listRowSeparator(.hidden)
    }

    @ViewBuilder
    private func serverPatchRow(_ item: PatchLibraryItem, remote: PatchServerCatalog.RemoteItem) -> some View {
        let isActive = activeProjectIDs.contains(item.id)
        let isWorking = workingProjectIDs.contains(item.id)

        VStack(alignment: .leading, spacing: 13) {
            HStack(spacing: 12) {
                serverGameIcon(remote.game ?? "ff", frameSize: 44)

                VStack(alignment: .leading, spacing: 4) {
                    Text(remote.name)
                        .font(.headline.weight(.black))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                    Text("\(serverCatalog.gameTitle(remote.game)) • \(serverCatalog.categoryTitle(remote.category)) • v\(remote.version)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }

                Spacer(minLength: 8)

                HTVStatusPill(
                    title: isWorking ? "กำลังทำงาน" : (isActive ? "ใช้งานอยู่" : "พร้อมใช้"),
                    systemImage: isWorking ? "clock.fill" : (isActive ? "checkmark.circle.fill" : "circle.fill"),
                    tint: isWorking ? .orange : (isActive ? .green : AppTheme.accent)
                )
            }

            if !remote.description.isEmpty {
                Text(remote.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }

            HStack(spacing: 10) {
                if isWorking {
                    HStack(spacing: 8) {
                        ProgressView().controlSize(.small)
                        Text("กำลังทำงาน")
                            .font(.caption.weight(.bold))
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 42)
                    .background(AppTheme.surfaceRaised, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                } else if item.isLocked {
                    Button { store.requestUnlock(for: item) } label: {
                        patchActionPill(title: "ปลดล็อก", systemImage: "lock.fill", tint: AppTheme.accent)
                    }
                    .buttonStyle(.plain)
                } else if isActive && needsRefilingProjectIDs.contains(item.id) {
                    Button { refileServerPatch(item) } label: {
                        patchActionPill(title: "รีไฟล์อีกครั้ง", systemImage: "arrow.clockwise.circle.fill", tint: .orange)
                    }
                    .buttonStyle(.plain)
                } else if isActive {
                    Button { restoreServerPatch(item) } label: {
                        patchActionPill(title: "คืนค่า", systemImage: "arrow.uturn.backward.circle.fill", tint: .red)
                    }
                    .buttonStyle(.plain)
                } else {
                    Button { setServerPatchEnabled(true, for: item) } label: {
                        patchActionPill(title: "เปิดใช้", systemImage: "bolt.fill", tint: AppTheme.accent)
                    }
                    .buttonStyle(.plain)
                    .disabled(store.isBusy || !workingProjectIDs.isEmpty)
                }
            }
        }
        .htvCard(padding: 14, accent: isActive ? .green : AppTheme.accent)
        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
        .listRowBackground(Color.clear)
        .listRowSeparator(.hidden)
    }

    private func setServerPatchEnabled(_ enabled: Bool, for item: PatchLibraryItem) {
        guard workingProjectIDs.isEmpty, !item.isLocked else { return }
        workingProjectIDs.insert(item.id)

        Task.detached(priority: .userInitiated) {
            do {
                if enabled {
                    guard let baseProject = item.project else {
                        throw PatchPackageError.invalidProject
                    }
                    let project = item.summary.schemaVersion >= 2 && item.canInspectContents
                        ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                        : baseProject
                    _ = try DevicePatchService.apply(project: project)
                    await MainActor.run {
                        userDisabledProjectIDs.remove(item.id)
                        saveUserDisabledProjectIDs()
                    }
                } else {
                    if let receipt = DevicePatchService.latestReceipt(projectID: item.id) {
                        try DevicePatchService.restore(receipt: receipt, allowChangedTargets: true)
                    }
                }

                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    store.reload()
                    syncActiveStates()
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    if !enabled {
                        userDisabledProjectIDs.insert(item.id)
                        saveUserDisabledProjectIDs()
                    }
                    syncActiveStates()
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    if !enabled {
                        userDisabledProjectIDs.insert(item.id)
                        saveUserDisabledProjectIDs()
                    }
                    syncActiveStates()
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: enabled ? "patch.error.apply" : "patch.error.restore"
                    )
                }
            }
        }
    }

    @ViewBuilder
    private func patchActionPill(title: String, systemImage: String, tint: Color) -> some View {
        HStack(spacing: 8) {
            Image(systemName: systemImage)
                .font(.system(size: 13, weight: .black))
            Text(title)
                .font(.caption.weight(.black))
                .lineLimit(1)
            Spacer(minLength: 0)
            Image(systemName: "chevron.right")
                .font(.system(size: 10, weight: .black))
        }
        .foregroundStyle(tint)
        .padding(.horizontal, 13)
        .frame(maxWidth: .infinity)
        .frame(height: 42)
        .background(tint.opacity(0.10), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 13, style: .continuous).stroke(tint.opacity(0.28), lineWidth: 1))
        .contentShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
    }

    private func restoreServerPatch(_ item: PatchLibraryItem) {
        guard workingProjectIDs.isEmpty, !item.isLocked else { return }
        guard let receipt = DevicePatchService.latestReceipt(projectID: item.id) else {
            syncActiveStates()
            return
        }
        workingProjectIDs.insert(item.id)
        Task.detached(priority: .userInitiated) {
            do {
                // "คืนค่า" is the user's explicit confirmation. Restore the saved
                // pre-patch backup even when the target app changed the file later.
                try DevicePatchService.restore(
                    receipt: receipt,
                    allowChangedTargets: true
                )
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    needsRefilingProjectIDs.remove(item.id)
                    store.reload()
                    syncActiveStates()
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    syncActiveStates()
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    syncActiveStates()
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.restore"
                    )
                }
            }
        }
    }

    private func refileServerPatch(_ item: PatchLibraryItem) {
        guard workingProjectIDs.isEmpty, !item.isLocked else { return }
        guard let receipt = DevicePatchService.latestReceipt(projectID: item.id),
              let baseProject = item.project else {
            syncActiveStates()
            return
        }
        workingProjectIDs.insert(item.id)
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2 && item.canInspectContents
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                try DevicePatchService.resetToAppliedState(receipt: receipt, project: project)
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    needsRefilingProjectIDs.remove(item.id)
                    store.reload()
                    syncActiveStates()
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    needsRefilingProjectIDs.insert(item.id)
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    needsRefilingProjectIDs.insert(item.id)
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.reset"
                    )
                }
            }
        }
    }

    private func refreshPatchHealth() {
        let activeItems = store.items.filter {
            DevicePatchService.latestReceipt(projectID: $0.id) != nil
        }
        Task.detached(priority: .utility) {
            var needsRepair = Set<UUID>()
            for item in activeItems {
                guard let receipt = DevicePatchService.latestReceipt(projectID: item.id) else { continue }
                do {
                    let inspection = try DevicePatchService.inspectRestore(receipt: receipt)
                    if !inspection.changedTargets.isEmpty {
                        needsRepair.insert(item.id)
                    }
                } catch {
                    // If the active transaction cannot be inspected, surface a
                    // repair action on the list instead of forcing entry into Detail.
                    needsRepair.insert(item.id)
                }
            }
            await MainActor.run {
                needsRefilingProjectIDs = needsRepair
                syncActiveStates()
            }
        }
    }

    private func syncActiveStates() {
        activeProjectIDs = Set(
            store.items.compactMap { item in
                DevicePatchService.latestReceipt(projectID: item.id) == nil ? nil : item.id
            }
        )
    }

    private static let userDisabledProjectsKey = "htvintex.patch.userDisabledProjectIDs.v2"

    private static func loadUserDisabledProjectIDs() -> Set<UUID> {
        let defaults = UserDefaults.standard
        let values = defaults.stringArray(forKey: userDisabledProjectsKey)
            ?? defaults.stringArray(forKey: "htvantix.patch.userDisabledProjectIDs.v1")
            ?? []
        return Set(values.compactMap(UUID.init(uuidString:)))
    }

    private func saveUserDisabledProjectIDs() {
        UserDefaults.standard.set(
            userDisabledProjectIDs.map(\.uuidString).sorted(),
            forKey: Self.userDisabledProjectsKey
        )
    }

    private func consumeExternalImport() {
        guard let request = draftCoordinator.importRequest else { return }
        draftCoordinator.clearImport()
        store.importPackage(from: request.source)
    }

    private func wallpaperRow(_ package: WallpaperStagedPackage) -> some View {
        HStack(spacing: 12) {
            AppRowIcon(systemName: wallpaperSymbol)
            VStack(alignment: .leading, spacing: 3) {
                Text(package.displayName)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                InstalledContentKindBadge(kind: .wallpaper, language: language)
                Text(language.text(
                    "wallpaper.package_summary",
                    Int64(package.payload.descriptors.count),
                    ByteCountFormatter.string(
                        fromByteCount: package.payload.totalBytes,
                        countStyle: .file
                    )
                ))
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }

    private var cleanerRow: some View {
        Button {
            showCleaner = true
        } label: {
            HStack(spacing: 12) {
                AppRowIcon(systemName: "sparkles")
                VStack(alignment: .leading, spacing: 3) {
                    Text(language.text("tab.cleaner"))
                        .font(.body.weight(.semibold))
                        .foregroundStyle(.primary)
                    Text(language.text("repository.cleaner_subtitle"))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.tertiary)
                    .accessibilityHidden(true)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var wallpaperSymbol: String {
        if #available(iOS 18.0, *) {
            return "photo.on.rectangle.angled.fill"
        }
        return "photo.fill.on.rectangle.fill"
    }

    private func reloadWallpaperPackages() {
        wallpaperPackages = WallpaperPackageStore.packages()
    }

    private func deleteWallpaperPackage(_ package: WallpaperStagedPackage) {
        do {
            try WallpaperPackageStore.delete(package)
            reloadWallpaperPackages()
        } catch {
            wallpaperImportFeedback = WallpaperImportFeedback(
                titleKey: "wallpaper.operation_failed",
                message: wallpaperErrorMessage(error)
            )
        }
    }

    private func importWallpaperPackages(_ urls: [URL]) {
        guard !isImportingWallpapers else { return }
        isImportingWallpapers = true
        DispatchQueue.global(qos: .userInitiated).async {
            var imported = 0
            var failures: [String] = []
            for url in urls {
                do {
                    _ = try WallpaperPackageStore.importPackage(from: url)
                    imported += 1
                    log("wallpaper: staged \(url.lastPathComponent)")
                } catch {
                    failures.append(
                        "\(url.lastPathComponent): \(wallpaperErrorMessage(error))"
                    )
                    log("wallpaper: import rejected \(url.lastPathComponent)")
                }
            }
            DispatchQueue.main.async {
                isImportingWallpapers = false
                reloadWallpaperPackages()
                wallpaperImportFeedback = WallpaperImportFeedback(
                    titleKey: failures.isEmpty
                        ? "wallpaper.import_done_title"
                        : "wallpaper.import_result_title",
                    message: failures.isEmpty
                        ? language.text(
                            "wallpaper.import_done_message",
                            Int64(imported)
                        )
                        : failures.joined(separator: "\n")
                )
            }
        }
    }

    private func wallpaperErrorMessage(_ error: Error) -> String {
        if let wallpaperError = error as? WallpaperLabError {
            return language.text(wallpaperError.localizationKey)
        }
        return language.text("wallpaper.error.unknown")
    }

    @ViewBuilder
    private func itemRow(_ item: PatchLibraryItem) -> some View {
        if item.isLocked {
            Button { store.requestUnlock(for: item) } label: {
                PatchProjectRow(item: item, language: language)
            }
            .buttonStyle(.plain)
        } else {
            NavigationLink {
                PatchProjectDetailView(store: store, projectID: item.id)
            } label: {
                PatchProjectRow(item: item, language: language)
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "shippingbox")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(AppTheme.accent)
            Text(language.text("installed.empty_title"))
                .font(.headline)
            Text(language.text("installed.empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Text("ไฟล์ที่เปิดใช้งานจากหน้าเว็บจะปรากฏที่นี่อัตโนมัติ")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var loadingState: some View {
        VStack(spacing: 12) {
            ProgressView()
            Text(language.text("installed.loading"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var searchEmptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(.secondary)
            Text(language.text("patch.search_empty"))
                .font(.headline)
            Text(language.text("patch.search_empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }
}

// MARK: - VIPERX server catalog

@MainActor
final class PatchServerCatalog: ObservableObject {
    struct RemoteItem: Identifiable, Hashable {
        let id: String
        let name: String
        let description: String
        let version: String
        let game: String?
        let category: String
        let fileName: String
        let sizeBytes: Int?
        let sha256: String?

        var fingerprint: String {
            if let sha256, !sha256.isEmpty { return "sha256:\(sha256.lowercased())" }
            return "\(version)|\(fileName)|\(sizeBytes ?? -1)"
        }
    }

    @Published private(set) var items: [RemoteItem] = []
    @Published private(set) var isLoading = false
    @Published private(set) var errorMessage: String?

    private let mappingKey = "htvintex.patch.server.remoteToLocal.v2"
    private let fingerprintKey = "htvintex.patch.server.fingerprints.v2"
    private var remoteToLocal: [String: String]
    private var fingerprints: [String: String]

    init() {
        let defaults = UserDefaults.standard
        remoteToLocal = defaults.dictionary(forKey: mappingKey) as? [String: String]
            ?? defaults.dictionary(forKey: "patch.server.remoteToLocal.v1") as? [String: String]
            ?? [:]
        fingerprints = defaults.dictionary(forKey: fingerprintKey) as? [String: String] ?? [:]
        defaults.set(remoteToLocal, forKey: mappingKey)
    }

    var mappedLocalPackageIDs: Set<UUID> {
        Set(remoteToLocal.values.compactMap(UUID.init(uuidString:)))
    }

    var requestHeaders: [String: String] {
        var headers = ["Accept": "application/json"]
        if let bearer = UserDefaults.standard.string(forKey: "htvantix.client.sessionToken"),
           !bearer.isEmpty {
            headers["Authorization"] = "Bearer \(bearer)"
        }
        return headers
    }

    var baseURL: URL {
        if let raw = Bundle.main.object(forInfoDictionaryKey: "PatchServerBaseURL") as? String,
           let url = URL(string: raw),
           url.scheme?.lowercased() == "https" {
            return url
        }
        return URL(string: "https://hightapi.netlify.app")!
    }

    func localPackageID(forRemoteID id: String) -> UUID? {
        guard let raw = remoteToLocal[id] else { return nil }
        return UUID(uuidString: raw)
    }

    func hasSharedLocalBinding(forRemoteID id: String) -> Bool {
        guard let raw = remoteToLocal[id] else { return false }
        return remoteToLocal.values.filter { $0 == raw }.count > 1
    }

    func isLocalPackageIDShared(_ id: UUID) -> Bool {
        let raw = id.uuidString
        return remoteToLocal.values.filter { $0 == raw }.count > 1
    }

    func isLocalPackageIDMapped(_ id: UUID) -> Bool {
        remoteToLocal.values.contains(id.uuidString)
    }

    func staleBindings(activeRemoteIDs: Set<String>) -> [(remoteID: String, localID: UUID)] {
        remoteToLocal.compactMap { remoteID, localID in
            guard !activeRemoteIDs.contains(remoteID),
                  let uuid = UUID(uuidString: localID) else { return nil }
            return (remoteID, uuid)
        }
    }

    func unbind(remoteID: String) {
        remoteToLocal.removeValue(forKey: remoteID)
        fingerprints.removeValue(forKey: remoteID)
        let defaults = UserDefaults.standard
        defaults.set(remoteToLocal, forKey: mappingKey)
        defaults.set(fingerprints, forKey: fingerprintKey)
        objectWillChange.send()
    }

    func needsDownload(_ item: RemoteItem, localItems: [PatchLibraryItem]) -> Bool {
        guard let localID = localPackageID(forRemoteID: item.id),
              localItems.contains(where: { $0.id == localID }) else {
            return true
        }
        return fingerprints[item.id] != item.fingerprint
    }

    func bind(remoteID: String, to packageID: UUID, fingerprint: String) {
        remoteToLocal[remoteID] = packageID.uuidString
        fingerprints[remoteID] = fingerprint
        let defaults = UserDefaults.standard
        defaults.set(remoteToLocal, forKey: mappingKey)
        defaults.set(fingerprints, forKey: fingerprintKey)
        objectWillChange.send()
    }

    func load() async throws -> [RemoteItem] {
        isLoading = true
        errorMessage = nil

        var request = URLRequest(url: catalogURL)
        request.httpMethod = "GET"
        for (name, value) in requestHeaders {
            request.setValue(value, forHTTPHeaderField: name)
        }

        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 25
        configuration.timeoutIntervalForResource = 60
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw PatchServerError.invalidResponse
        }
        guard (200..<300).contains(http.statusCode) else {
            if http.statusCode == 401 || http.statusCode == 403 {
                throw PatchServerError.sessionRequired
            }
            throw PatchServerError.http(http.statusCode)
        }

        let parsed = try Self.parseCatalog(data)
        items = parsed
        return parsed
    }

    func finishSync(warning: String? = nil) {
        isLoading = false
        errorMessage = warning
    }

    func fail(_ error: Error) {
        isLoading = false
        errorMessage = error.localizedDescription
    }

    func downloadURL(for item: RemoteItem) -> URL {
        baseURL
            .appendingPathComponent("api/v4/packages")
            .appendingPathComponent(item.id)
            .appendingPathComponent("download")
    }

    func categoryTitle(_ category: String) -> String {
        switch category {
        case "shoot": return "ไฟล์ยิง"
        case "visual": return "ไฟล์มอง"
        case "skin_free": return "มอดสกิน"
        default: return "อื่น ๆ"
        }
    }

    func gameTitle(_ game: String?) -> String {
        switch game {
        case "ff": return "Free Fire"
        case "ffmax": return "Free Fire MAX"
        default: return "ทั่วไป"
        }
    }

    private var catalogURL: URL {
        if let raw = Bundle.main.object(forInfoDictionaryKey: "PatchCatalogURL") as? String,
           let url = URL(string: raw),
           url.scheme?.lowercased() == "https" {
            return url
        }
        return baseURL.appendingPathComponent("api/v4/packages")
    }

    private static func parseCatalog(_ data: Data) throws -> [RemoteItem] {
        let root = try JSONSerialization.jsonObject(with: data)
        let rawItems: [[String: Any]]
        if let array = root as? [[String: Any]] {
            rawItems = array
        } else if let object = root as? [String: Any],
                  let array = (object["packages"] ?? object["patches"] ?? object["files"]) as? [[String: Any]] {
            rawItems = array
        } else {
            throw PatchServerError.malformed
        }

        return rawItems.compactMap { object in
            let enabled = (object["enabled"] as? Bool) ?? (object["active"] as? Bool) ?? true
            guard enabled else { return nil }
            guard let id = stringValue(object["id"] ?? object["packageId"] ?? object["_id"]),
                  !id.isEmpty else { return nil }

            return RemoteItem(
                id: id,
                name: stringValue(object["name"] ?? object["title"]) ?? "Patch",
                description: stringValue(object["description"]) ?? "",
                version: stringValue(object["version"]) ?? "1.0",
                game: stringValue(object["game"]),
                category: stringValue(object["category"]) ?? "other",
                fileName: stringValue(object["fileName"] ?? object["filename"]) ?? "\(id).3105",
                sizeBytes: intValue(object["sizeBytes"]),
                sha256: stringValue(object["sha256"])
            )
        }
    }

    private static func stringValue(_ value: Any?) -> String? {
        if let string = value as? String { return string }
        if let number = value as? NSNumber { return number.stringValue }
        return nil
    }

    private static func intValue(_ value: Any?) -> Int? {
        if let value = value as? Int { return value }
        if let value = value as? NSNumber { return value.intValue }
        if let value = value as? String { return Int(value) }
        return nil
    }
}

private enum PatchServerError: LocalizedError {
    case http(Int)
    case malformed
    case invalidResponse
    case sessionRequired

    var errorDescription: String? {
        switch self {
        case .http(let status): return "HTTP \(status)"
        case .malformed: return "ข้อมูลรายการไฟล์ VIPERX ไม่ถูกต้อง"
        case .invalidResponse: return "ไม่ได้รับคำตอบที่ถูกต้องจาก VIPERX"
        case .sessionRequired: return "Session หมดอายุ กรุณาเปิดแอปใหม่หรือเข้าสู่ License อีกครั้ง"
        }
    }
}

private struct WallpaperImportFeedback: Identifiable {
    let id = UUID()
    let titleKey: String
    let message: String
}

private struct PatchProjectRow: View {
    let item: PatchLibraryItem
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 12) {
            AppRowIcon(systemName: item.isLocked ? "lock.doc.fill" : "shippingbox.fill")
            VStack(alignment: .leading, spacing: 3) {
                Text(item.project?.name ?? language.text("patch.locked_project"))
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                InstalledContentKindBadge(kind: .patch, language: language)
                if let author = item.project?.author, !author.isEmpty {
                    Text(language.text("patch.by_author", author))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Text(rowDetail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if item.summary.isPasswordProtected {
                Image(systemName: "key.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .accessibilityLabel(language.text("patch.password_protected"))
            }
            if item.project?.isPrivate == true {
                Image(systemName: "eye.slash.fill")
                    .font(.caption)
                    .foregroundStyle(AppTheme.accent)
                    .accessibilityLabel(language.text("patch.private"))
            }
        }
        .padding(.vertical, 4)
    }

    private var rowDetail: String {
        if item.isLocked {
            return language.text("patch.tap_to_unlock")
        }
        if item.project?.isPrivate == true, !item.isAuthorCopy {
            return language.text("patch.private_received")
        }
        return language.text(
            item.summary.schemaVersion >= 2
                ? "patch.workspace_items_count"
                : "patch.rules_count",
            Int64((item.project?.rules.count ?? 0) + (item.project?.directories.count ?? 0))
        )
    }
}

private enum InstalledContentKind {
    case patch
    case wallpaper

    var localizationKey: String {
        switch self {
        case .patch: return "installed.kind.patch"
        case .wallpaper: return "installed.kind.wallpaper"
        }
    }

    var systemImage: String {
        switch self {
        case .patch: return "shippingbox.fill"
        case .wallpaper: return "photo.fill"
        }
    }
}

private struct InstalledContentKindBadge: View {
    let kind: InstalledContentKind
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: kind.systemImage)
                .accessibilityHidden(true)
            Text(language.text(kind.localizationKey))
        }
            .font(.caption2.weight(.semibold))
            .foregroundStyle(AppTheme.accent)
            .padding(.horizontal, 8)
            .frame(height: 24)
            .background(AppTheme.accent.opacity(0.12), in: Capsule())
            .fixedSize()
            .accessibilityElement(children: .combine)
    }
}

struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    let request: PatchPasswordRequest
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in
                            store.clearUnlockError()
                        }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    if let origin = request.origin {
                        Text(language.text(
                            "patch.password_repo_contact",
                            origin.repositoryName
                        ))
                    } else {
                        Text(language.text("patch.password_once_message"))
                    }
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchStorePresentationModifier: ViewModifier {
    @ObservedObject var store: PatchProjectStore

    func body(content: Content) -> some View {
        content
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { request in
                PatchUnlockView(store: store, request: request)
            }
    }
}

extension View {
    func patchStorePresentation(_ store: PatchProjectStore) -> some View {
        modifier(PatchStorePresentationModifier(store: store))
    }
}

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showEditor = false
    @State private var editingRule: PatchRule?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var showChangedRestoreConfirmation = false
    @State private var showResetConfirmation = false
    @State private var restoreChangedPaths: [String] = []
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?
    @State private var shareRequest: PatchShareRequest?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    var body: some View {
        List {
            if let item, let project = item.project {
                Section(language.text("patch.information")) {
                    if !project.author.isEmpty {
                        patchInfoRow(
                            label: language.text("patch.author"),
                            value: project.author
                        )
                    }
                    patchInfoRow(label: language.text("patch.privacy")) {
                        Label(
                            language.text(project.isPrivate
                                ? "patch.private"
                                : "patch.public"),
                            systemImage: project.isPrivate
                                ? "eye.slash.fill"
                                : "eye"
                        )
                        .foregroundStyle(project.isPrivate ? AppTheme.accent : Color.secondary)
                    }
                    if let origin = item.origin {
                        patchInfoRow(
                            label: language.text("repository.source"),
                            value: origin.repositoryName
                        )
                    }
                }

                if project.isPrivate && !item.canInspectContents {
                    Section {
                        VStack(spacing: 10) {
                            Image(systemName: "lock.shield.fill")
                                .font(.system(size: 30, weight: .medium))
                                .foregroundStyle(AppTheme.accent)
                            Text(language.text("patch.private_hidden_title"))
                                .font(.headline)
                            Text(language.text("patch.private_hidden_message"))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 20)
                    }
                } else if !isWorkspaceProject {
                    Section {
                        ForEach(project.rules) { rule in
                            Button {
                                editingRule = rule
                            } label: {
                                HStack(spacing: 10) {
                                    ruleSummary(rule)
                                    Spacer(minLength: 8)
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityHint(language.text("patch.edit_rule_hint"))
                        }
                    } header: {
                        Text(language.text("patch.rules"))
                    } footer: {
                        Text(language.text("patch.legacy_footer"))
                    }
                }

                Section(language.text("patch.password")) {
                    HStack(spacing: 12) {
                        Image(systemName: item.summary.isPasswordProtected ? "lock.fill" : "lock.open")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)
                        Text(language.text(item.summary.isPasswordProtected
                            ? "patch.password_locked"
                            : "patch.no_password"))
                            .font(.subheadline)
                    }
                }

                Section {
                    Button {
                        showApplyConfirmation = true
                    } label: {
                        actionLabel("patch.apply", systemImage: "checkmark.shield.fill")
                    }
                    .disabled(isWorking || receipt != nil)

                    if receipt != nil {
                        Button {
                            showResetConfirmation = true
                        } label: {
                            Label("รีไฟล์อีกครั้ง", systemImage: "arrow.counterclockwise.circle")
                        }
                        .disabled(isWorking)

                        Button(role: .destructive) {
                            showRestoreConfirmation = true
                        } label: {
                            Label("คืนค่าไฟล์เดิม", systemImage: "arrow.uturn.backward.circle")
                        }
                        .disabled(isWorking)
                    }

                } footer: {
                    Text(language.text("patch.apply_footer"))
                }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(AppTheme.canvas)
        .navigationTitle(item?.project?.name ?? language.text("patch.title"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                } else if !isWorkspaceProject, item?.canInspectContents == true {
                    Button(language.text("patch.edit")) { showEditor = true }
                        .disabled(item?.project == nil)
                }
            }
        }
        .sheet(isPresented: $showEditor) {
            if let item, let project = item.project {
                PatchProjectEditorView(
                    existingProject: project,
                    passwordIsProtected: item.summary.isPasswordProtected
                ) { updatedProject, _ in
                    store.update(project: updatedProject)
                }
            }
        }
        .sheet(item: $editingRule) { rule in
            PatchRuleEditorView(rule: rule) { updatedRule in
                updateRule(updatedRule)
            }
        }
        .confirmationDialog(
            language.text("patch.apply_confirm_title"),
            isPresented: $showApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.apply")) { apply() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.apply_confirm_message"))
        }
        .confirmationDialog(
            language.text("patch.restore_confirm_title"),
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button("คืนค่าไฟล์เดิม", role: .destructive) { prepareRestore() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.restore_confirm_message"))
        }
        .confirmationDialog(
            language.text("patch.restore_changed_title"),
            isPresented: $showChangedRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button("คืนค่าต่อ", role: .destructive) {
                restore(allowChangedTargets: true)
            }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(changedRestoreMessage)
        }
        .confirmationDialog(
            language.text("patch.reset_confirm_title"),
            isPresented: $showResetConfirmation,
            titleVisibility: .visible
        ) {
            Button("รีไฟล์อีกครั้ง", role: .destructive) { resetToAppliedState() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.reset_confirm_message"))
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .sheet(item: $shareRequest) { request in
            PatchActivityView(items: [request.url])
                .ignoresSafeArea()
        }
    }

    private func actionLabel(_ key: String, systemImage: String) -> some View {
        Label(language.text(key), systemImage: systemImage)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func patchInfoRow(
        label: String,
        value: String
    ) -> some View {
        patchInfoRow(label: label) {
            Text(value)
                .foregroundStyle(.primary)
        }
    }

    private func patchInfoRow<Content: View>(
        label: String,
        @ViewBuilder value: () -> Content
    ) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            Text(label)
                .foregroundStyle(.secondary)
            Spacer(minLength: 16)
            value()
                .multilineTextAlignment(.trailing)
                .fixedSize(horizontal: false, vertical: true)
        }
        .font(.subheadline)
        .padding(.vertical, 5)
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func updateRule(_ updatedRule: PatchRule) {
        guard var project = item?.project,
              let index = project.rules.firstIndex(where: { $0.id == updatedRule.id }) else {
            return
        }
        project.rules[index] = updatedRule
        project.updatedAt = Date()
        do {
            try PatchPackageCodec.validate(project)
            store.update(project: project)
        } catch let error as PatchPackageError {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: error.localizationKey,
                messageArgument: error.localizationArgument
            )
        } catch {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2 && item.canInspectContents
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func prepareExport() {
        guard let item else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                if item.summary.schemaVersion >= 2, item.canInspectContents {
                    _ = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                }
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    shareRequest = PatchShareRequest(url: item.packageURL)
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.invalid_project"
                    )
                }
            }
        }
    }

    private var changedRestoreMessage: String {
        guard item?.project?.isPrivate != true || item?.isAuthorCopy == true else {
            return language.text(
                "patch.restore_changed_private_message",
                Int64(restoreChangedPaths.count)
            )
        }
        var visiblePaths = restoreChangedPaths.prefix(5).joined(separator: "\n")
        if restoreChangedPaths.count > 5 {
            visiblePaths += "\n…"
        }
        return language.text(
            "patch.restore_changed_message",
            Int64(restoreChangedPaths.count),
            visiblePaths
        )
    }

    private func prepareRestore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let inspection = try DevicePatchService.inspectRestore(receipt: receipt)
                if inspection.changedTargets.isEmpty {
                    try DevicePatchService.restore(receipt: receipt)
                    await MainActor.run {
                        isWorking = false
                        actionAlert = PatchStoreAlert(
                            titleKey: "common.done",
                            messageKey: "patch.restored_message"
                        )
                    }
                } else {
                    await MainActor.run {
                        isWorking = false
                        restoreChangedPaths = inspection.changedTargets.map(\.displayPath)
                        showChangedRestoreConfirmation = true
                    }
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.restore"
                    )
                }
            }
        }
    }

    private func restore(allowChangedTargets: Bool) {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(
                    receipt: receipt,
                    allowChangedTargets: allowChangedTargets
                )
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }

    private func resetToAppliedState() {
        guard let receipt, let project = item?.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.resetToAppliedState(
                    receipt: receipt,
                    project: project
                )
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.done",
                        messageKey: "patch.reset_message"
                    )
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.reset"
                    )
                }
            }
        }
    }

    private func privateErrorKey(for error: PatchPackageError) -> String {
        guard item?.project?.isPrivate == true,
              item?.isAuthorCopy == false else {
            return error.localizationKey
        }
        return "patch.error.private_operation"
    }

    private func privateErrorArgument(for error: PatchPackageError) -> String? {
        guard item?.project?.isPrivate == true,
              item?.isAuthorCopy == false else {
            return error.localizationArgument
        }
        return nil
    }
}

private struct PatchShareRequest: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PatchActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(
        _ uiViewController: UIActivityViewController,
        context: Context
    ) {}
}
