import SwiftUI
import UIKit

// MARK: - HTVANTIX Capture Protection
//
// Goal:
// - The owner keeps seeing/using HTVANTIX normally on the device.
// - Screen recording / mirroring / screen-share output should not receive the
//   protected hierarchy when UIKit's secure rendering container is available.
// - App-switcher snapshots are always covered locally.
// - If a future iOS version prevents creation of the secure container, an
//   active capture fails closed with a local black cover instead of exposing UI.
//
// Apple does not publish an API that guarantees screenshot exclusion for an
// arbitrary UIView hierarchy. The secure UITextField rendering path used here
// is therefore best-effort and intentionally isolated in this file.

private struct CaptureProtectedContainer<Content: View>: UIViewControllerRepresentable {
    let content: Content
    let captureState: PrivacyShieldState

    init(captureState: PrivacyShieldState, @ViewBuilder content: () -> Content) {
        self.captureState = captureState
        self.content = content()
    }

    func makeUIViewController(context: Context) -> ProtectedHostingController<Content> {
        ProtectedHostingController(rootView: content, captureState: captureState)
    }

    func updateUIViewController(
        _ uiViewController: ProtectedHostingController<Content>,
        context: Context
    ) {
        uiViewController.update(rootView: content)
    }
}

private final class ProtectedHostingController<Content: View>: UIViewController {
    private let hostingController: UIHostingController<Content>
    private let secureTextField = UITextField(frame: .zero)
    private let fallbackContainer = UIView(frame: .zero)
    private let captureState: PrivacyShieldState

    private weak var secureCanvas: UIView?
    private weak var mountedContainer: UIView?
    private var secureMountAttempts = 0
    private let maxSecureMountAttempts = 8

    init(rootView: Content, captureState: PrivacyShieldState) {
        self.hostingController = UIHostingController(rootView: rootView)
        self.captureState = captureState
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .black
        configureContainers()
        mountHostingView(in: fallbackContainer)
        attemptSecureMount()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if secureCanvas == nil {
            attemptSecureMount()
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if secureCanvas == nil && secureMountAttempts < maxSecureMountAttempts {
            attemptSecureMount()
        }
    }

    func update(rootView: Content) {
        hostingController.rootView = rootView
    }

    private func configureContainers() {
        secureTextField.translatesAutoresizingMaskIntoConstraints = false
        secureTextField.backgroundColor = .clear
        secureTextField.borderStyle = .none
        secureTextField.textColor = .clear
        secureTextField.tintColor = .clear
        secureTextField.autocorrectionType = .no
        secureTextField.spellCheckingType = .no
        secureTextField.isSecureTextEntry = true
        secureTextField.text = "HTVANTIX"
        secureTextField.clipsToBounds = true

        fallbackContainer.translatesAutoresizingMaskIntoConstraints = false
        fallbackContainer.backgroundColor = .clear

        // The normal container stays visible until UIKit exposes its secure
        // rendering canvas. Once ready, the hosted SwiftUI hierarchy is moved
        // into that secure canvas and this fallback is hidden.
        view.addSubview(secureTextField)
        view.addSubview(fallbackContainer)

        NSLayoutConstraint.activate([
            secureTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            secureTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            secureTextField.topAnchor.constraint(equalTo: view.topAnchor),
            secureTextField.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            fallbackContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            fallbackContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            fallbackContainer.topAnchor.constraint(equalTo: view.topAnchor),
            fallbackContainer.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        view.layoutIfNeeded()
        secureTextField.layoutIfNeeded()
    }

    private func attemptSecureMount() {
        guard secureCanvas == nil else { return }
        guard secureMountAttempts < maxSecureMountAttempts else {
            captureState.secureContainerReady = false
            return
        }

        secureMountAttempts += 1
        view.layoutIfNeeded()
        secureTextField.layoutIfNeeded()

        if let canvas = findSecureCanvas(in: secureTextField) {
            secureCanvas = canvas
            canvas.clipsToBounds = true
            canvas.backgroundColor = .clear
            mountHostingView(in: canvas)
            fallbackContainer.isHidden = true
            captureState.secureContainerReady = true
            return
        }

        // UIKit sometimes creates the secure canvas one or two run-loop turns
        // after isSecureTextEntry becomes active, especially after restoration.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) { [weak self] in
            self?.attemptSecureMount()
        }
    }

    private func findSecureCanvas(in root: UIView) -> UIView? {
        // Prefer UIKit's secure canvas when its internal class name is visible.
        // No private selector/API is called; this only identifies a subview that
        // UIKit itself created for the secure text field.
        for child in root.subviews {
            let className = NSStringFromClass(type(of: child)).lowercased()
            if className.contains("canvas") || className.contains("secure") {
                return child
            }
            if let nested = findSecureCanvas(in: child) {
                return nested
            }
        }

        // Fallback for iOS versions where the internal class name changes but
        // the secure field still exposes a single rendering child.
        if root === secureTextField, root.subviews.count == 1 {
            return root.subviews[0]
        }

        return nil
    }

    private func mountHostingView(in container: UIView) {
        let needsChildAttach = hostingController.parent == nil
        if needsChildAttach {
            addChild(hostingController)
        }

        let hostedView = hostingController.view!
        if mountedContainer !== container {
            hostedView.removeFromSuperview()
            hostedView.translatesAutoresizingMaskIntoConstraints = false
            hostedView.backgroundColor = .clear
            container.addSubview(hostedView)

            NSLayoutConstraint.activate([
                hostedView.leadingAnchor.constraint(equalTo: container.leadingAnchor),
                hostedView.trailingAnchor.constraint(equalTo: container.trailingAnchor),
                hostedView.topAnchor.constraint(equalTo: container.topAnchor),
                hostedView.bottomAnchor.constraint(equalTo: container.bottomAnchor)
            ])

            mountedContainer = container
        }

        if needsChildAttach {
            hostingController.didMove(toParent: self)
        }
    }
}

// MARK: - Privacy state

@MainActor
final class PrivacyShieldState: ObservableObject {
    @Published private(set) var screenCaptured = UIScreen.main.isCaptured
    @Published private(set) var appInactive = false
    @Published fileprivate var secureContainerReady = false

    private var observers: [NSObjectProtocol] = []

    init() {
        observers.append(NotificationCenter.default.addObserver(
            forName: UIScreen.capturedDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.screenCaptured = UIScreen.main.isCaptured
        })

        observers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.willResignActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.appInactive = true
        })

        observers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.appInactive = false
            self?.screenCaptured = UIScreen.main.isCaptured
        })
    }

    deinit {
        observers.forEach(NotificationCenter.default.removeObserver)
    }

    // App-switcher snapshots must always be black locally. During a live
    // capture, keep the owner's display usable when secure rendering is ready.
    // If secure rendering is unavailable, fail closed and cover locally.
    var shouldCoverLocally: Bool {
        appInactive || (screenCaptured && !secureContainerReady)
    }
}

// MARK: - SwiftUI modifier

struct PrivacyShieldModifier: ViewModifier {
    @StateObject private var state = PrivacyShieldState()

    func body(content: Content) -> some View {
        ZStack {
            CaptureProtectedContainer(captureState: state) {
                content
            }
            .ignoresSafeArea()

            if state.shouldCoverLocally {
                Color.black
                    .ignoresSafeArea()
                    .zIndex(999_999)
                    .accessibilityHidden(true)
            }
        }
        .background(Color.black)
    }
}

extension View {
    func htvantixPrivacyShield() -> some View {
        modifier(PrivacyShieldModifier())
    }
}
