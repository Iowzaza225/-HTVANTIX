import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var appState: AppState

    var body: some View {
        NavigationStack {
            ZStack {
                HTCyberBackground()

                ScrollView {
                    VStack(spacing: 18) {
                        appCard
                        deviceCard
                    }
                    .padding(18)
                }
            }
            .navigationTitle("ตั้งค่า")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(HTCyberTheme.background.opacity(0.95), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("เสร็จสิ้น") { dismiss() }
                        .fontWeight(.semibold)
                        .foregroundStyle(HTCyberTheme.cyan)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var appCard: some View {
        HStack(spacing: 14) {
            AppLogo(size: 54)
            VStack(alignment: .leading, spacing: 4) {
                Text("HTVANTIX")
                    .font(.title3.bold())
                    .foregroundStyle(.white)
                Text("เวอร์ชัน \(appVersion)")
                    .font(.subheadline)
                    .foregroundStyle(HTCyberTheme.muted)
            }
            Spacer()
        }
        .padding(18)
        .background(HTCyberTheme.panel.opacity(0.95), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(HTCyberTheme.cyan.opacity(0.28), lineWidth: 1)
        }
    }

    private var deviceCard: some View {
        VStack(spacing: 0) {
            settingsRow("รุ่นอุปกรณ์", AppInfo.displayMachineName)
            Divider().overlay(Color.white.opacity(0.08))
            settingsRow("เวอร์ชัน iOS", "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
            Divider().overlay(Color.white.opacity(0.08))
            settingsRow("รองรับ iOS", supportedVersions)
            Divider().overlay(Color.white.opacity(0.08))

            HStack {
                Text("สถานะ")
                    .foregroundStyle(.white.opacity(0.72))
                Spacer()
                Text(appState.isSupported ? "รองรับ" : "ไม่รองรับ")
                    .fontWeight(.bold)
                    .foregroundStyle(appState.isSupported ? Color.green : Color.orange)
            }
            .padding(.vertical, 15)
        }
        .padding(.horizontal, 18)
        .background(HTCyberTheme.panel.opacity(0.95), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(HTCyberTheme.cyan.opacity(0.28), lineWidth: 1)
        }
    }

    private func settingsRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 14) {
            Text(title)
                .foregroundStyle(.white.opacity(0.72))
            Spacer(minLength: 10)
            Text(value)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white)
                .multilineTextAlignment(.trailing)
        }
        .padding(.vertical, 15)
    }

    private var supportedVersions: String {
        "iOS 17 • 18 • 26 • 27 Beta"
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }
}
