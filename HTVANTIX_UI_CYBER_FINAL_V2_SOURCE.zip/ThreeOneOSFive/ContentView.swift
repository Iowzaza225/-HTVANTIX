import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var tabNavigation: AppTabNavigationState

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab = arguments.contains("--simulate-patch-tab")
            ? AppSection.patches.rawValue
            : AppSection.home.rawValue
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularLayout
            } else {
                compactLayout
            }
        }
        .tint(HTCyberTheme.cyan)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onAppear {
            if tabNavigation.selectedTab != AppSection.home.rawValue &&
                tabNavigation.selectedTab != AppSection.patches.rawValue {
                tabNavigation.select(AppSection.home.rawValue)
            }
        }
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            DashboardView {
                tabNavigation.select(AppSection.patches.rawValue)
            }
            .tabItem {
                Label("หน้าหลัก", systemImage: "house.fill")
            }
            .tag(AppSection.home.rawValue)

            PatchProjectsView()
                .tabItem {
                    Label("ไฟล์", systemImage: "folder.fill")
                }
                .tag(AppSection.patches.rawValue)
        }
        .toolbarBackground(HTCyberTheme.panel, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                Button {
                    tabNavigation.select(AppSection.home.rawValue)
                } label: {
                    Label("หน้าหลัก", systemImage: "house.fill")
                }
                Button {
                    tabNavigation.select(AppSection.patches.rawValue)
                } label: {
                    Label("ไฟล์", systemImage: "folder.fill")
                }
            }
            .navigationTitle("HTVANTIX")
        } detail: {
            if tabNavigation.selectedTab == AppSection.patches.rawValue {
                PatchProjectsView()
            } else {
                DashboardView {
                    tabNavigation.select(AppSection.patches.rawValue)
                }
            }
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }
}

enum HTCyberTheme {
    static let background = Color(red: 0.015, green: 0.035, blue: 0.085)
    static let panel = Color(red: 0.035, green: 0.075, blue: 0.13)
    static let panel2 = Color(red: 0.055, green: 0.095, blue: 0.16)
    static let cyan = Color(red: 0.14, green: 0.82, blue: 1.0)
    static let blue = Color(red: 0.15, green: 0.46, blue: 1.0)
    static let muted = Color.white.opacity(0.58)
    static let line = Color(red: 0.14, green: 0.82, blue: 1.0).opacity(0.42)
}

struct HTCyberBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.015, green: 0.035, blue: 0.085),
                    Color(red: 0.02, green: 0.07, blue: 0.13),
                    Color.black
                ],
                startPoint: .top,
                endPoint: .bottom
            )

            Canvas { context, size in
                var path = Path()
                let spacing: CGFloat = 28
                var x: CGFloat = 0
                while x <= size.width {
                    path.move(to: CGPoint(x: x, y: 0))
                    path.addLine(to: CGPoint(x: x, y: size.height))
                    x += spacing
                }
                var y: CGFloat = 0
                while y <= size.height {
                    path.move(to: CGPoint(x: 0, y: y))
                    path.addLine(to: CGPoint(x: size.width, y: y))
                    y += spacing
                }
                context.stroke(path, with: .color(HTCyberTheme.cyan.opacity(0.07)), lineWidth: 0.7)
            }
        }
        .ignoresSafeArea()
    }
}

private struct DashboardView: View {
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @AppStorage("htvantix.selectedGame") private var selectedGame = "freefire"
    let openFiles: () -> Void

    var body: some View {
        NavigationStack {
            ZStack {
                HTCyberBackground()

                ScrollView {
                    VStack(spacing: 20) {
                        devicePanel
                        gameCard(
                            title: "Free Fire",
                            subtitle: "com.dts.freefireth",
                            symbol: "flame.fill",
                            gameKey: "freefire"
                        )
                        gameCard(
                            title: "Free Fire Max",
                            subtitle: "com.dts.freefiremax",
                            symbol: "bolt.fill",
                            gameKey: "freefiremax"
                        )
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 14)
                    .padding(.bottom, 34)
                }
            }
            .navigationTitle("HTVANTIX")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(HTCyberTheme.background.opacity(0.95), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showSettings = true } label: {
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundStyle(HTCyberTheme.cyan)
                            .padding(10)
                            .background(HTCyberTheme.panel2, in: Circle())
                            .overlay {
                                Circle().stroke(HTCyberTheme.cyan.opacity(0.45), lineWidth: 1)
                            }
                    }
                    .accessibilityLabel("ตั้งค่า")
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
        }
        .preferredColorScheme(.dark)
    }

    private var devicePanel: some View {
        VStack(spacing: 16) {
            HStack {
                Label("HT OPTIONS", systemImage: "apple.logo")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(HTCyberTheme.muted)
                Spacer()
                Text("iOS \(AppInfo.osVersion)")
                    .font(.caption.weight(.bold).monospaced())
                    .foregroundStyle(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.white.opacity(0.06), in: Capsule())
            }

            Text(AppInfo.displayMachineName)
                .font(.system(size: 28, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, alignment: .center)

            HStack(spacing: 10) {
                Label("Universal iOS", systemImage: "apple.logo")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.82))

                Spacer()

                Label(
                    appState.isSupported ? "รองรับ" : "ไม่รองรับ",
                    systemImage: appState.isSupported ? "checkmark.shield.fill" : "exclamationmark.triangle.fill"
                )
                .font(.subheadline.weight(.bold))
                .foregroundStyle(appState.isSupported ? Color.green : Color.orange)
            }
        }
        .padding(20)
        .background(
            LinearGradient(
                colors: [HTCyberTheme.panel2.opacity(0.95), HTCyberTheme.panel.opacity(0.92)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 24, style: .continuous)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(HTCyberTheme.cyan.opacity(0.72), lineWidth: 1.4)
                .shadow(color: HTCyberTheme.cyan.opacity(0.35), radius: 8)
        }
    }

    private func gameCard(
        title: String,
        subtitle: String,
        symbol: String,
        gameKey: String
    ) -> some View {
        Button {
            selectedGame = gameKey
            openFiles()
        } label: {
            HStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .fill(
                            LinearGradient(
                                colors: [HTCyberTheme.blue.opacity(0.75), HTCyberTheme.cyan.opacity(0.28)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                    Image(systemName: symbol)
                        .font(.system(size: 30, weight: .black))
                        .foregroundStyle(.white)
                }
                .frame(width: 78, height: 78)

                VStack(alignment: .leading, spacing: 7) {
                    Text(title)
                        .font(.title3.bold())
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.caption.monospaced())
                        .foregroundStyle(HTCyberTheme.muted)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.title3.bold())
                    .foregroundStyle(HTCyberTheme.cyan)
            }
            .padding(18)
            .background(HTCyberTheme.panel.opacity(0.94), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .stroke(HTCyberTheme.cyan.opacity(0.42), lineWidth: 1.1)
            }
        }
        .buttonStyle(.plain)
    }
}
