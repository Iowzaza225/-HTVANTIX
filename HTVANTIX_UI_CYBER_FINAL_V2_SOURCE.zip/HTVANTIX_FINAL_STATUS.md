# HTVANTIX Ready API/Patch Build

- HTVANTIX UI
- Free Fire focused
- Home + Patches visible
- Files/Cleaner/Wallpapers hidden from primary navigation; file logic retained
- Existing API base: https://hightapi.netlify.app
- Patch list: /cv/sp
- Patch download: /cv/sp/{id}/download
- Existing X-App-Token header support reads HTVANTIX_APP_TOKEN from Info.plist when configured
- Downloaded package imports through PatchProjectStore
- Toggle ON uses DevicePatchService.apply
- Toggle OFF uses DevicePatchService.restore
- Backup/receipt/rollback remain handled by PatchTransaction
- License/key UI not enabled in this build
- No server secrets should be embedded in the app.
