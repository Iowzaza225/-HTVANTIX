import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var tabNavigation: AppTabNavigationState

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab = arguments.contains("--simulate-patch-tab")
            ? AppSection.patches.rawValue
            : AppSection.home.rawValue
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularLayout
            } else {
                compactLayout
            }
        }
        .tint(PremiumTheme.accent)
        .preferredColorScheme(.dark)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onAppear {
            if tabNavigation.selectedTab != AppSection.home.rawValue &&
                tabNavigation.selectedTab != AppSection.patches.rawValue {
                tabNavigation.select(AppSection.home.rawValue)
            }
        }
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            PremiumHomeView {
                tabNavigation.select(AppSection.patches.rawValue)
            }
            .tabItem { Label("หน้าหลัก", systemImage: "house.fill") }
            .tag(AppSection.home.rawValue)

            PatchProjectsView()
                .tabItem { Label("ไฟล์", systemImage: "folder.fill") }
                .tag(AppSection.patches.rawValue)
        }
        .toolbarBackground(PremiumTheme.tabBar, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                Button { tabNavigation.select(AppSection.home.rawValue) } label: {
                    Label("หน้าหลัก", systemImage: "house.fill")
                }
                Button { tabNavigation.select(AppSection.patches.rawValue) } label: {
                    Label("ไฟล์", systemImage: "folder.fill")
                }
            }
            .scrollContentBackground(.hidden)
            .background(PremiumTheme.background)
            .navigationTitle("HTVANTIX")
        } detail: {
            if tabNavigation.selectedTab == AppSection.patches.rawValue {
                PatchProjectsView()
            } else {
                PremiumHomeView {
                    tabNavigation.select(AppSection.patches.rawValue)
                }
            }
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }
}

enum PremiumTheme {
    static let background = Color.black
    static let surface = Color(red: 0.045, green: 0.05, blue: 0.065)
    static let surface2 = Color(red: 0.075, green: 0.082, blue: 0.105)
    static let border = Color.white.opacity(0.10)
    static let accent = Color(red: 0.16, green: 0.72, blue: 1.0)
    static let accentSoft = Color(red: 0.16, green: 0.72, blue: 1.0).opacity(0.14)
    static let textSecondary = Color.white.opacity(0.52)
    static let textTertiary = Color.white.opacity(0.34)
    static let tabBar = Color(red: 0.025, green: 0.028, blue: 0.036)
}

struct PremiumBackground: View {
    var body: some View {
        ZStack {
            Color.black
            RadialGradient(
                colors: [PremiumTheme.accent.opacity(0.10), Color.clear],
                center: .topTrailing,
                startRadius: 10,
                endRadius: 340
            )
            RadialGradient(
                colors: [Color.white.opacity(0.035), Color.clear],
                center: .bottomLeading,
                startRadius: 20,
                endRadius: 420
            )
        }
        .ignoresSafeArea()
    }
}

private struct PremiumHomeView: View {
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @AppStorage("htvantix.selectedGame") private var selectedGame = "freefire"
    let openFiles: () -> Void

    var body: some View {
        NavigationStack {
            ZStack {
                PremiumBackground()

                ScrollView {
                    VStack(spacing: 16) {
                        heroPanel
                        gameCard(title: "Free Fire", subtitle: "com.dts.freefireth", symbol: "flame.fill", gameKey: "freefire")
                        gameCard(title: "Free Fire Max", subtitle: "com.dts.freefiremax", symbol: "bolt.fill", gameKey: "freefiremax")
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 12)
                    .padding(.bottom, 34)
                }
            }
            .navigationTitle("HTVANTIX")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(Color.black.opacity(0.96), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showSettings = true } label: {
                        ZStack {
                            Circle().fill(PremiumTheme.surface2)
                            Image(systemName: "gearshape.fill")
                                .font(.system(size: 17, weight: .bold))
                                .foregroundStyle(.white)
                        }
                        .frame(width: 40, height: 40)
                        .overlay(Circle().stroke(PremiumTheme.border, lineWidth: 1))
                    }
                    .accessibilityLabel("ตั้งค่า")
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
        }
    }

    private var heroPanel: some View {
        VStack(spacing: 18) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("DEVICE")
                        .font(.caption2.weight(.bold))
                        .tracking(1.4)
                        .foregroundStyle(PremiumTheme.textTertiary)
                    Text(AppInfo.displayMachineName)
                        .font(.system(size: 25, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                }
                Spacer()
                Text("iOS \(AppInfo.osVersion)")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.82))
                    .padding(.horizontal, 11)
                    .padding(.vertical, 7)
                    .background(PremiumTheme.surface2, in: Capsule())
            }

            Rectangle()
                .fill(PremiumTheme.border)
                .frame(height: 1)

            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("COMPATIBILITY")
                        .font(.caption2.weight(.bold))
                        .tracking(1.4)
                        .foregroundStyle(PremiumTheme.textTertiary)
                    Text("Universal iOS")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.78))
                }

                Spacer()

                HStack(spacing: 7) {
                    Image(systemName: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill")
                    Text(appState.isSupported ? "รองรับ" : "ไม่รองรับ")
                }
                .font(.subheadline.weight(.bold))
                .foregroundStyle(appState.isSupported ? Color.green : Color.orange)
            }
        }
        .padding(20)
        .background(PremiumTheme.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(PremiumTheme.border, lineWidth: 1))
        .shadow(color: Color.black.opacity(0.35), radius: 18, y: 10)
    }

    private func gameCard(title: String, subtitle: String, symbol: String, gameKey: String) -> some View {
        Button {
            selectedGame = gameKey
            openFiles()
        } label: {
            HStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .fill(PremiumTheme.accentSoft)
                    Image(systemName: symbol)
                        .font(.system(size: 27, weight: .bold))
                        .foregroundStyle(PremiumTheme.accent)
                }
                .frame(width: 66, height: 66)

                VStack(alignment: .leading, spacing: 5) {
                    Text(title)
                        .font(.title3.weight(.bold))
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.caption.monospaced())
                        .foregroundStyle(PremiumTheme.textSecondary)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(PremiumTheme.accent)
            }
            .padding(18)
            .background(PremiumTheme.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(PremiumTheme.border, lineWidth: 1))
            .shadow(color: Color.black.opacity(0.30), radius: 14, y: 8)
        }
        .buttonStyle(.plain)
    }
}
