import SwiftUI
import UIKit

struct ContentView: View {
    var body: some View {
        PUBGControlHomeView()
            .preferredColorScheme(.dark)
            .tint(AppTheme.accent)
    }
}

private struct PUBGControlHomeView: View {
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @StateObject private var homeCatalog = PatchServerCatalog()

    var body: some View {
        NavigationStack {
            ZStack {
                tacticalBackground
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 18) {
                        header
                        statusStrip
                        NavigationLink {
                            // Do not filter or remap server IDs. This preserves the entire
                            // existing package/download/patch connection behind the new UI.
                            PatchProjectsView(gameFilter: nil, gameTitle: "PUBG CONTROL")
                        } label: { pubgHeroCard }
                            .buttonStyle(.plain)
                        connectionCard
                        footer
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 10)
                    .padding(.bottom, 30)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSettings) {
                SettingsView().preferredColorScheme(.dark)
            }
            .task {
                guard homeCatalog.items.isEmpty, !homeCatalog.isLoading else { return }
                do {
                    _ = try await homeCatalog.load()
                    homeCatalog.finishSync()
                } catch { homeCatalog.fail(error) }
            }
        }
    }

    private var tacticalBackground: some View {
        ZStack {
            Color(red: 0.025, green: 0.026, blue: 0.024).ignoresSafeArea()
            LinearGradient(
                colors: [AppTheme.accent.opacity(0.14), .clear, Color.black.opacity(0.35)],
                startPoint: .topTrailing,
                endPoint: .bottomLeading
            ).ignoresSafeArea()
            Canvas { context, size in
                var path = Path()
                stride(from: CGFloat.zero, through: size.width, by: 38).forEach { x in
                    path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height))
                }
                stride(from: CGFloat.zero, through: size.height, by: 38).forEach { y in
                    path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
                }
                context.stroke(path, with: .color(.white.opacity(0.018)), lineWidth: 0.5)
            }.ignoresSafeArea()
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image("PUBGControlLogo")
                .resizable()
                .scaledToFill()
            .frame(width: 48, height: 48)
            .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 13, style: .continuous).stroke(AppTheme.accent.opacity(0.45), lineWidth: 1))
            .shadow(color: AppTheme.accent.opacity(0.28), radius: 14)
            VStack(alignment: .leading, spacing: 2) {
                Text("PUBG CONTROL").font(.system(size: 22, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text("TACTICAL DEPLOYMENT SYSTEM")
                    .font(.system(size: 9, weight: .bold, design: .rounded)).tracking(1.65).foregroundStyle(AppTheme.accent)
            }
            Spacer()
            Button { showSettings = true } label: {
                Image(systemName: "gearshape.fill").font(.system(size: 17, weight: .bold)).foregroundStyle(.white)
                    .frame(width: 44, height: 44).background(Color.white.opacity(0.065), in: Circle())
                    .overlay(Circle().stroke(Color.white.opacity(0.10), lineWidth: 1))
            }
        }
    }

    private var statusStrip: some View {
        HStack(spacing: 10) {
            statusPill(icon: "iphone.gen3", title: "DEVICE", value: appState.isSupported ? "READY" : "CHECK", color: appState.isSupported ? .green : .orange)
            statusPill(icon: "network", title: "NETWORK", value: homeCatalog.errorMessage == nil ? "ONLINE" : "WAIT", color: homeCatalog.errorMessage == nil ? .green : .orange)
        }
    }

    private func statusPill(icon: String, title: String, value: String, color: Color) -> some View {
        HStack(spacing: 9) {
            Image(systemName: icon).font(.system(size: 15, weight: .bold)).foregroundStyle(AppTheme.accent)
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.system(size: 8, weight: .bold)).tracking(1).foregroundStyle(.secondary)
                Text(value).font(.caption.weight(.black)).foregroundStyle(color)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 13).frame(maxWidth: .infinity, minHeight: 58)
        .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(AppTheme.border, lineWidth: 1))
    }

    private var pubgHeroCard: some View {
        ZStack(alignment: .bottomLeading) {
            Image("PUBGHero")
                .resizable()
                .scaledToFill()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            LinearGradient(
                colors: [Color.black.opacity(0.82), Color.black.opacity(0.32), Color.black.opacity(0.12)],
                startPoint: .leading,
                endPoint: .trailing
            )
            LinearGradient(colors: [.clear, Color.black.opacity(0.70)], startPoint: .center, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 7) {
                        Text("BATTLEGROUNDS").font(.system(size: 10, weight: .black)).tracking(2.2).foregroundStyle(AppTheme.accent)
                        Text("PUBG").font(.system(size: 48, weight: .black, design: .rounded)).tracking(-2).foregroundStyle(.white)
                        Text("CONTROL CENTER").font(.system(size: 14, weight: .heavy)).tracking(2.4).foregroundStyle(.white.opacity(0.72))
                    }
                    Spacer()
                    Image("PUBGControlLogo")
                        .resizable().scaledToFill()
                        .frame(width: 66, height: 66)
                        .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(AppTheme.accent.opacity(0.45), lineWidth: 1))
                        .padding(.top, 8)
                }
                Spacer()
                HStack {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack(spacing: 7) {
                            Circle().fill(packageCount > 0 ? Color.green : Color.secondary).frame(width: 7, height: 7)
                            Text(packageCount > 0 ? "\(packageCount) PACKAGE READY" : "AWAITING PACKAGE")
                                .font(.caption2.weight(.black)).foregroundStyle(packageCount > 0 ? Color.green : .secondary)
                        }
                        Text(homeCatalog.isLoading ? "กำลังซิงก์ข้อมูล…" : "แตะเพื่อเข้าสู่ระบบจัดการ")
                            .font(.caption).foregroundStyle(.white.opacity(0.58))
                    }
                    Spacer()
                    Image(systemName: "arrow.up.right").font(.system(size: 17, weight: .black)).foregroundStyle(.black)
                        .frame(width: 44, height: 44).background(AppTheme.accent, in: Circle())
                }
            }.padding(22)
        }
        .frame(height: 285)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(AppTheme.accent.opacity(0.32), lineWidth: 1))
        .shadow(color: .black.opacity(0.38), radius: 24, y: 14)
    }

    private var packageCount: Int { homeCatalog.items.count }

    private var connectionCard: some View {
        HStack(spacing: 13) {
            Image(systemName: homeCatalog.errorMessage == nil ? "checkmark.shield.fill" : "exclamationmark.shield.fill")
                .font(.system(size: 24, weight: .bold)).foregroundStyle(homeCatalog.errorMessage == nil ? Color.green : Color.orange)
                .frame(width: 48, height: 48).background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            VStack(alignment: .leading, spacing: 4) {
                Text("SYSTEM STATUS").font(.caption.weight(.black)).tracking(1.3).foregroundStyle(.white)
                Text(systemStatusText).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(16).background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(AppTheme.border, lineWidth: 1))
    }

    private var systemStatusText: String {
        if homeCatalog.isLoading { return "กำลังเชื่อมต่อระบบไฟล์เดิม…" }
        if homeCatalog.errorMessage != nil { return "รอการเชื่อมต่อ • แตะ PUBG เพื่อลองใหม่" }
        return "CONNECTED • \(packageCount) PACKAGES • LATEST"
    }

    private var footer: some View {
        Text("PUBG CONTROL • TACTICAL SYSTEM").font(.system(size: 9, weight: .bold)).tracking(1.4).foregroundStyle(.secondary).padding(.top, 2)
    }
}
