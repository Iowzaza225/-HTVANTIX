import SwiftUI
import UIKit

struct ContentView: View {
    var body: some View {
        PUBGStableHomeView()
            .preferredColorScheme(.dark)
            .tint(AppTheme.accent)
    }
}

// Stable PUBG shell based on the original HTVANTIX home structure.
// The existing package/download/patch destination is unchanged.
private struct PUBGStableHomeView: View {
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @StateObject private var homeCatalog = PatchServerCatalog()

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.018, green: 0.020, blue: 0.018).ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        header
                        deviceCard

                        Text("PUBG SYSTEM")
                            .font(.caption.weight(.black))
                            .tracking(1.8)
                            .foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)

                        NavigationLink {
                            PatchProjectsView(gameFilter: nil, gameTitle: "PUBG CONTROL")
                        } label: {
                            pubgCard
                        }
                        .buttonStyle(.plain)

                        systemCard
                        footer
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 8)
                    .padding(.bottom, 28)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSettings) {
                SettingsView().preferredColorScheme(.dark)
            }
            .task {
                guard homeCatalog.items.isEmpty, !homeCatalog.isLoading else { return }
                do {
                    _ = try await homeCatalog.load()
                    homeCatalog.finishSync()
                } catch {
                    homeCatalog.fail(error)
                }
            }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .fill(Color.orange.opacity(0.13))
                    .frame(width: 46, height: 46)
                Image(systemName: "scope")
                    .font(.system(size: 23, weight: .black))
                    .foregroundStyle(Color.orange)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text("PUBG CONTROL")
                    .font(.system(size: 23, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("TACTICAL DEPLOYMENT SYSTEM")
                    .font(.system(size: 9, weight: .bold))
                    .tracking(1.5)
                    .foregroundStyle(Color.orange)
            }

            Spacer()

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(Color.white.opacity(0.055), in: Circle())
            }
        }
    }

    private var deviceCard: some View {
        HStack(spacing: 14) {
            Image(systemName: "iphone.gen3")
                .font(.system(size: 21, weight: .semibold))
                .foregroundStyle(Color.orange)
                .frame(width: 48, height: 48)
                .background(Color.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

            VStack(alignment: .leading, spacing: 3) {
                Text(AppInfo.displayMachineName)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                Text("iOS \(AppInfo.osVersion)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Text(appState.isSupported ? "READY" : "CHECK")
                .font(.caption.weight(.black))
                .foregroundStyle(appState.isSupported ? Color.green : Color.orange)
        }
        .stableCard()
    }

    private var pubgCard: some View {
        HStack(spacing: 15) {
            Image(systemName: "shield.lefthalf.filled")
                .font(.system(size: 31, weight: .black))
                .foregroundStyle(Color.orange)
                .frame(width: 72, height: 72)
                .background(Color.orange.opacity(0.11), in: RoundedRectangle(cornerRadius: 18, style: .continuous))

            VStack(alignment: .leading, spacing: 7) {
                Text("PUBG")
                    .font(.title2.weight(.black))
                    .foregroundStyle(.white)
                Text(packageText)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(homeCatalog.items.isEmpty ? Color.secondary : Color.green)
                Text(homeCatalog.isLoading ? "กำลังเชื่อมต่อ…" : "แตะเพื่อเข้าสู่ระบบแพตช์")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(Color.orange)
        }
        .stableCard()
    }

    private var packageText: String {
        homeCatalog.items.isEmpty ? "AWAITING PACKAGE" : "\(homeCatalog.items.count) PACKAGE READY"
    }

    private var systemCard: some View {
        HStack(spacing: 14) {
            Image(systemName: homeCatalog.errorMessage == nil ? "checkmark.shield.fill" : "exclamationmark.shield.fill")
                .font(.system(size: 23, weight: .bold))
                .foregroundStyle(homeCatalog.errorMessage == nil ? Color.green : Color.orange)
                .frame(width: 48, height: 48)
                .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

            VStack(alignment: .leading, spacing: 4) {
                Text("SYSTEM STATUS")
                    .font(.caption.weight(.black))
                    .tracking(1.2)
                    .foregroundStyle(.white)
                Text(homeCatalog.errorMessage == nil ? "CONNECTED • SERVER READY" : "WAITING FOR SERVER")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
        .stableCard()
    }

    private var footer: some View {
        Text("PUBG CONTROL • SAFE BUILD 9")
            .font(.system(size: 9, weight: .bold))
            .tracking(1.3)
            .foregroundStyle(.secondary)
            .padding(.top, 2)
    }
}

private extension View {
    func stableCard() -> some View {
        padding(16)
            .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.white.opacity(0.085), lineWidth: 1)
            )
    }
}
