import crypto from "node:crypto";
import { json, requireAdmin, sanitizeText, audit, requestAppId, requireEnabledApp } from "./_lib.mjs";
import { r2Ready, makeR2UploadURL, R2_MAX_UPLOAD_BYTES, R2_UPLOAD_URL_TTL } from "./_r2.mjs";
export default async (req) => {
  const auth = requireAdmin(req, true); if (!auth.ok) return auth.response;
  if (req.method !== "POST") return json({error:"NOT_FOUND"},404);
  if (!r2Ready()) return json({error:"STORAGE_NOT_CONFIGURED"},503);
  let body; try { body=await req.json(); } catch { return json({error:"BAD_REQUEST"},400); }
  const appId=requestAppId(req,body); const app=await requireEnabledApp(appId); if(!app)return json({error:"APP_DISABLED"},403);
  const fileName=sanitizeText(body?.fileName,140); const sizeBytes=Number(body?.sizeBytes||0);
  if (!fileName || !Number.isSafeInteger(sizeBytes) || sizeBytes<=0 || sizeBytes>R2_MAX_UPLOAD_BYTES) return json({error:"FILE_SIZE",maxBytes:R2_MAX_UPLOAD_BYTES},413);
  const ext = (fileName.match(/\.[a-zA-Z0-9]{1,12}$/)?.[0] || ".bin").toLowerCase();
  const objectKey=`v4/packages/${appId}/${Date.now()}-${crypto.randomUUID()}${ext}`;
  const uploadURL=await makeR2UploadURL(objectKey);
  await audit("package_upload_url_v4",{sid:auth.session?.sid||null,appId,fileName,sizeBytes,objectKey});
  return json({ok:true,appId,objectKey,uploadURL,contentType:"application/octet-stream",maxBytes:R2_MAX_UPLOAD_BYTES,expiresIn:R2_UPLOAD_URL_TTL});
};
