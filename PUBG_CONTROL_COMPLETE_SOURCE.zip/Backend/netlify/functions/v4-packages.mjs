import { json, requireClientSession, getPatchIndex, sha256Hex, audit, packageHasApp } from "./_lib.mjs";

export default async (req, context) => {
  if (req.method !== "GET") return json({ error: "NOT_FOUND" }, 404);
  const access = await requireClientSession(req, context, "metadata");
  if (!access.ok) return access.response;
  const appId = access.session.app;
  const index = await getPatchIndex();
  const allowedCategories = new Set(["shoot", "visual", "skin_free", "other"]);
  const normalizeCategory = (value) => {
    const raw = String(value ?? "").trim().toLowerCase();
    return allowedCategories.has(raw) ? raw : "other";
  };

  const appIndex = index.filter((x) => packageHasApp(x, appId));
  const items = appIndex
    .filter((x) => x?.enabled !== false)
    .map((x) => ({
      id: x.id,
      name: x.name,
      description: x.description || "",
      version: x.version || "1.0",
      game: x.game || null,
      category: normalizeCategory(x.category),
      fileName: x.fileName,
      sizeBytes: x.sizeBytes,
      sha256: x.sha256,
      createdAt: x.createdAt,
    }));

  const catalogRevision = sha256Hex(JSON.stringify({ appId, items })).slice(0, 24);
  const generatedAt = new Date().toISOString();
  const auditTask = audit("packages_catalog_read_v4", {
    appId,
    indexCount: appIndex.length,
    globalIndexCount: index.length,
    enabledCount: items.length,
    catalogRevision,
    packages: items.map((x) => ({ id: x.id, category: x.category, game: x.game })),
  });
  if (typeof context?.waitUntil === "function") context.waitUntil(auditTask);
  else auditTask.catch(() => {});

  return json({ok:true,appId,packages:items,catalogRevision,generatedAt,packageCount:items.length},200,{
    "Cache-Control":"no-store, no-cache, must-revalidate, max-age=0, s-maxage=0, no-transform",
    "CDN-Cache-Control":"no-store","Netlify-CDN-Cache-Control":"no-store","Pragma":"no-cache","Expires":"0",
    "Vary":"Authorization, X-App-Id","X-App-Id":appId,"X-Catalog-Revision":catalogRevision,"X-Catalog-Count":String(items.length),
  });
};
