import { json, requireClientSession, getPatchIndex, sanitizeText, logDownload, packageHasApp } from "./_lib.mjs";
import { makeR2DownloadURL, getR2DownloadObject, R2_RELAY_MAX_BYTES } from "./_r2.mjs";

function background(context, task) {
  if (typeof context?.waitUntil === "function") context.waitUntil(task);
  else task.catch(() => {});
}

function toWebStream(body) {
  if (!body) return null;
  if (typeof body.transformToWebStream === "function") return body.transformToWebStream();
  if (typeof ReadableStream !== "undefined" && body instanceof ReadableStream) return body;
  return body;
}

export default async (req, context) => {
  if (req.method !== "GET") return json({ error: "NOT_FOUND" }, 404);

  const access = await requireClientSession(req, context, "download");
  if (!access.ok) return access.response;

  const url = new URL(req.url);
  const pathMatch = url.pathname.match(/\/api\/v4\/packages\/([^/]+)\/download\/?$/i);
  const rawId = url.searchParams.get("id") || (pathMatch ? decodeURIComponent(pathMatch[1]) : "");
  const id = sanitizeText(rawId, 100);
  const item = (await getPatchIndex()).find(
    (x) => x.id === id && x.enabled !== false && packageHasApp(x, access.session.app),
  );

  if (!item || !item.r2Key) {
    background(context, logDownload(req, context, id || "unknown", "not_found"));
    return json({ error: "NOT_FOUND" }, 404);
  }

  try {
    const declaredSize = Number(item.sizeBytes || 0);
    const canRelay = declaredSize > 0 && declaredSize <= R2_RELAY_MAX_BYTES;

    // v4.2.6: for normal patch files, return the R2 object directly as a streamed
    // 200/206 response. This removes the 302 hop for clients that don't reliably
    // follow signed redirects. Large files keep the old signed-URL fallback.
    if (canRelay) {
      const range = req.headers.get("range") || "";
      const obj = await getR2DownloadObject(item.r2Key, item.fileName || "package.bin", range);
      const body = toWebStream(obj.Body);
      if (!body) throw new Error("R2_EMPTY_BODY");

      const headers = new Headers({
        "Content-Type": obj.ContentType || "application/octet-stream",
        "Content-Disposition": obj.ContentDisposition || `attachment; filename="package.bin"`,
        "Cache-Control": "private, no-store",
        "Accept-Ranges": obj.AcceptRanges || "bytes",
        "X-App-Id": access.session.app,
        "X-Content-SHA256": item.sha256 || "",
        "X-Content-Length": String(item.sizeBytes || obj.ContentLength || 0),
        "X-Download-Mode": "relay",
      });
      if (obj.ContentLength != null) headers.set("Content-Length", String(obj.ContentLength));
      if (obj.ContentRange) headers.set("Content-Range", String(obj.ContentRange));
      if (obj.ETag) headers.set("ETag", String(obj.ETag));

      background(context, logDownload(req, context, id, "ok_relay"));
      return new Response(body, { status: obj.ContentRange ? 206 : 200, headers });
    }

    const signed = await makeR2DownloadURL(item.r2Key, item.fileName || "package.bin");
    background(context, logDownload(req, context, id, "ok_redirect"));
    return new Response(null, {
      status: 302,
      headers: {
        Location: signed,
        "Cache-Control": "no-store",
        "X-App-Id": access.session.app,
        "X-Content-SHA256": item.sha256 || "",
        "X-Content-Length": String(item.sizeBytes || 0),
        "X-Download-Mode": "redirect",
      },
    });
  } catch (error) {
    background(context, logDownload(req, context, id, "storage_error"));
    return json({ error: "STORAGE_ERROR" }, 502);
  }
};
