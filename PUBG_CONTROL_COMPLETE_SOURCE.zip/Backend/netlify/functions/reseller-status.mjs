import { json, requireReseller, publicReseller, resellerCsrfForSession, getApps } from "./_lib.mjs";
export default async (req)=>{
  const a=await requireReseller(req,false); if(!a.ok)return a.response;
  const me=publicReseller(a.reseller); const allowed=new Set(me.allowedApps||[]);
  const apps=(await getApps()).filter(x=>x.enabled!==false&&allowed.has(x.appId));
  return json({authenticated:true,reseller:me,apps,csrf:resellerCsrfForSession(a.session)});
};
