import { json, checkLicenseRate, normalizeLicenseKey, validDeviceId, findLicenseByKey, licenseState, deviceHash, saveLicense, sanitizeText, publicLicense, makeLicenseToken, evaluateClientVersion, privacyHash, clientIP, audit, requestAppId, recordAppId, requireEnabledApp } from "./_lib.mjs";
export default async (req,context)=>{
  if(req.method!=="POST")return json({error:"NOT_FOUND"},404);
  const rate=await checkLicenseRate(req,context,"activate"); if(!rate.allowed)return json({error:"RATE_LIMIT"},429,{"Retry-After":String(rate.retryAfter)});
  let body;try{body=await req.json();}catch{return json({error:"BAD_REQUEST"},400);}
  const appId=requestAppId(req,body);
  const app=await requireEnabledApp(appId); if(!app)return json({error:"APP_DISABLED"},403);
  const key=normalizeLicenseKey(body?.key), deviceId=String(body?.deviceId||"").trim(), appVersion=sanitizeText(body?.appVersion,24), buildId=sanitizeText(body?.buildId,80), deviceModel=sanitizeText(body?.deviceModel,100);
  if(!key||!validDeviceId(deviceId)||!appVersion)return json({error:"BAD_REQUEST"},400);
  const rec=await findLicenseByKey(key); const state=licenseState(rec); if(!state.ok)return json({error:state.code},403);
  if(recordAppId(rec)!==appId){await audit("license_wrong_app_v4",{id:rec?.id||null,requestedAppId:appId,licenseAppId:recordAppId(rec)});return json({error:"KEY_NOT_FOR_THIS_APP"},403);}
  const vg=await evaluateClientVersion(appVersion,buildId,appId); if(!vg.ok)return json({error:vg.code,client:vg.state},426);
  const devHash=deviceHash(deviceId); if(rec.deviceHash&&rec.deviceHash!==devHash)return json({error:"DEVICE_MISMATCH"},403);
  const now=Date.now(); const firstBind=!rec.deviceHash;
  if(!rec.deviceHash){rec.deviceHash=devHash;rec.deviceBoundAt=new Date(now).toISOString();}
  if(!rec.activatedAt){rec.activatedAt=new Date(now).toISOString(); if(rec.activationMode==="first_use"&&!rec.expiresAt){const ms=Number(rec.durationMinutes||0)>0?Number(rec.durationMinutes)*60000:Number(rec.durationDays||30)*86400000;rec.expiresAt=new Date(now+ms).toISOString();}}
  const after=licenseState(rec,now); if(!after.ok)return json({error:after.code},403);
  rec.appId=appId;rec.lastVerifiedAt=new Date(now).toISOString();rec.lastAppVersion=appVersion;rec.lastBuildId=buildId||null;rec.lastDeviceModel=deviceModel||null;rec.lastClientHash=privacyHash(clientIP(req,context)); await saveLicense(rec);
  const token=makeLicenseToken(rec,devHash); await audit("license_redeemed_v4",{id:rec.id,appId,firstBind,appVersion,buildId});
  return json({ok:true,app:{appId:app.appId,name:app.name},licenseToken:token,license:publicLicense(rec),client:vg.state});
};
