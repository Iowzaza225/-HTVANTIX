import { json, requireReseller, getLicense, saveLicense, deleteLicenseRecord, publicLicense, sanitizeText, audit } from "./_lib.mjs";
export default async(req)=>{const a=await requireReseller(req,true);if(!a.ok)return a.response;if(req.method!=="POST")return json({error:"NOT_FOUND"},404);let b={};try{b=await req.json()}catch{return json({error:"BAD_REQUEST"},400)}
 const id=sanitizeText(b.id,100),action=sanitizeText(b.action,40);const rec=await getLicense(id);if(!rec||rec.resellerId!==a.reseller.id)return json({error:"NOT_FOUND"},404);
 if(action==="delete"){await deleteLicenseRecord(rec);await audit("reseller_license_deleted",{resellerId:a.reseller.id,id});return json({ok:true,action});}
 if(action==="reset_device"){rec.deviceHash=null;rec.deviceBoundAt=null;rec.lastVerifiedAt=null;rec.lastAppVersion=null;rec.updatedAt=new Date().toISOString();await saveLicense(rec);await audit("reseller_device_reset",{resellerId:a.reseller.id,id});return json({ok:true,action,license:publicLicense(rec,{includeKey:true})});}
 return json({error:"INVALID_ACTION"},400);
};
