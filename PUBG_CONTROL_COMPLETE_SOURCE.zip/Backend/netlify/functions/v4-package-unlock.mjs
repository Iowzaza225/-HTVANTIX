import { json, requireClientSession, getPatchIndex, sanitizeText, packageHasApp, decryptPackagePassword, audit } from "./_lib.mjs";

function background(context, task) {
  if (typeof context?.waitUntil === "function") context.waitUntil(task);
  else task.catch(() => {});
}

export default async (req, context) => {
  if (req.method !== "GET") return json({ error: "NOT_FOUND" }, 404);
  const access = await requireClientSession(req, context, "download");
  if (!access.ok) return access.response;

  const url = new URL(req.url);
  const pathMatch = url.pathname.match(/\/api\/v4\/packages\/([^/]+)\/unlock\/?$/i);
  const rawId = url.searchParams.get("id") || (pathMatch ? decodeURIComponent(pathMatch[1]) : "");
  const id = sanitizeText(rawId, 100);
  const item = (await getPatchIndex()).find(
    x => x.id === id && x.enabled !== false && packageHasApp(x, access.session.app),
  );
  if (!item) return json({ error: "NOT_FOUND" }, 404);

  const password = decryptPackagePassword(item.passwordEnvelope);
  if (!password) return json({ error: "UNLOCK_NOT_AVAILABLE" }, 404);

  background(context, audit("package_unlock_issued_v4", {
    appId: access.session.app,
    packageId: id,
    licenseId: access.session.sub,
    deviceHash: access.session.dev,
  }));
  return json({ ok: true, password });
};
