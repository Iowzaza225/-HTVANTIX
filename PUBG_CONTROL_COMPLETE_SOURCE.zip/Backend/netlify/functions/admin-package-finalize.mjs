import crypto from "node:crypto";
import { json, requireAdmin, getPatchIndex, appendPatchIndexItem, sanitizeText, audit, requestAppId, requireEnabledApp, packageHasApp, encryptPackagePassword } from "./_lib.mjs";
import { r2Ready, headR2Object, deleteR2Object, sha256R2Object, R2_MAX_UPLOAD_BYTES } from "./_r2.mjs";
export default async (req) => {
  const auth=requireAdmin(req,true); if(!auth.ok)return auth.response;
  if(req.method!=="POST")return json({error:"NOT_FOUND"},404);
  if(!r2Ready())return json({error:"STORAGE_NOT_CONFIGURED"},503);
  let body; try{body=await req.json();}catch{return json({error:"BAD_REQUEST"},400);}
  const appId=requestAppId(req,body); const app=await requireEnabledApp(appId); if(!app)return json({error:"APP_DISABLED"},403);
  const objectKey=sanitizeText(body?.objectKey,260), name=sanitizeText(body?.name,100), version=sanitizeText(body?.version||"1.0",30), game=sanitizeText(body?.game,20), category=sanitizeText(body?.category,40), description=sanitizeText(body?.description||"",200), fileName=sanitizeText(body?.fileName,140), packageID=sanitizeText(body?.packageID,100), packagePassword=String(body?.packagePassword||"");
  const claimed=String(body?.sha256||"").trim().toLowerCase();
  if(!objectKey.startsWith(`v4/packages/${appId}/`)||objectKey.includes("..")||!name||!fileName||!packageID)return json({error:"INVALID_METADATA",message:"Package ID is required."},400);
  if(!["ff","ffmax","pubg"].includes(game)) return json({error:"INVALID_GAME"},400);
  if(Buffer.byteLength(packagePassword,"utf8")>256)return json({error:"PASSWORD_TOO_LONG"},400);
  if(!["shoot","visual","skin_free","other"].includes(category)) return json({error:"INVALID_CATEGORY"},400);
  if(claimed && !/^[a-f0-9]{64}$/.test(claimed))return json({error:"INVALID_SHA256"},400);
  const existingIndex=await getPatchIndex();
  const duplicate=existingIndex.find(x=>packageHasApp(x,appId)&&String(x?.packageID||"").trim().toLowerCase()===packageID.toLowerCase());
  if(duplicate){
    try{await deleteR2Object(objectKey);}catch{}
    await audit("package_id_duplicate_v4",{sid:auth.session?.sid||null,appId,packageID,existingId:duplicate.id||null,existingName:duplicate.name||null,name});
    return json({error:"PACKAGE_ID_DUPLICATE",appId,packageID,existingPackage:{id:duplicate.id||null,name:duplicate.name||null}},409);
  }
  let head; try{head=await headR2Object(objectKey);}catch{return json({error:"UPLOAD_NOT_FOUND"},404);}
  const headSize=Number(head.ContentLength||0); if(!headSize||headSize>R2_MAX_UPLOAD_BYTES){try{await deleteR2Object(objectKey);}catch{} return json({error:"FILE_SIZE",maxBytes:R2_MAX_UPLOAD_BYTES},413);}
  let verified; try{verified=await sha256R2Object(objectKey);}catch(e){return json({error:"VERIFY_FAILED"},502);}
  if(verified.sizeBytes!==headSize){try{await deleteR2Object(objectKey);}catch{} return json({error:"SIZE_MISMATCH"},409);}
  if(claimed && claimed!==verified.sha256){try{await deleteR2Object(objectKey);}catch{} return json({error:"HASH_MISMATCH",serverSHA256:verified.sha256},409);}
  let passwordEnvelope=null;
  try{passwordEnvelope=encryptPackagePassword(packagePassword);}catch{return json({error:"PACKAGE_UNLOCK_NOT_CONFIGURED"},503);}
  const item={id:crypto.randomUUID().toUpperCase(),appId,appIds:[appId],packageID,name,description,version,game,category,fileName,sizeBytes:verified.sizeBytes,sha256:verified.sha256,createdAt:new Date().toISOString(),enabled:true,storageProvider:"r2",r2Key:objectKey,passwordEnvelope};
  let finalIndex;
  try { finalIndex = await appendPatchIndexItem(item); }
  catch (e) { await audit("package_index_conflict_v4",{sid:auth.session?.sid||null,appId,id:item.id,name,error:String(e?.message||e)}); return json({error:"PACKAGE_INDEX_CONFLICT",message:"Please retry finalize."},409); }
  await audit("package_uploaded_v4",{sid:auth.session?.sid||null,appId,id:item.id,packageID,name,sizeBytes:item.sizeBytes,sha256:item.sha256,game,category,r2Key:item.r2Key,fileName:item.fileName,indexCount:finalIndex.length});
  const {passwordEnvelope:_,...safeItem}=item;
  return json({ok:true,app,package:{...safeItem,hasPackagePassword:Boolean(passwordEnvelope)},indexCount:finalIndex.length},201);
};
