import { json, requireReseller, clearResellerSessionCookie } from "./_lib.mjs";
export default async(req)=>{const a=await requireReseller(req,true);if(!a.ok)return a.response;return json({ok:true},200,{"Set-Cookie":clearResellerSessionCookie()});};
