import crypto from "node:crypto";
import {
  json, requireAdmin, sanitizeText, getResellerIndex, setResellerIndex, getReseller, saveReseller,
  findResellerByUsername, publicReseller, hashResellerPassword, deleteReseller, audit, getApps, normalizeAppId, DEFAULT_APP_ID
} from "./_lib.mjs";

function parseAllowedApps(body, available) {
  const raw = Array.isArray(body?.allowedApps) ? body.allowedApps : (body?.appId ? [body.appId] : [DEFAULT_APP_ID]);
  const allowedSet = new Set(available.filter(x=>x.enabled!==false).map(x=>x.appId));
  return [...new Set(raw.map(x=>normalizeAppId(x)).filter(x=>allowedSet.has(x)))];
}

export default async (req) => {
  const auth = requireAdmin(req, req.method !== "GET");
  if (!auth.ok) return auth.response;

  if (req.method === "GET") {
    const ids = await getResellerIndex();
    const rows=[];
    for (const id of ids) { const r=await getReseller(id); if (r) rows.push(publicReseller(r)); }
    rows.sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
    return json({ resellers: rows, apps: await getApps() });
  }
  let body={}; try { body=await req.json(); } catch { return json({error:"BAD_REQUEST"},400); }
  const apps=await getApps();

  if (req.method === "POST") {
    const username=sanitizeText(body.username,80).toLowerCase();
    const displayName=sanitizeText(body.displayName,100) || username;
    const password=String(body.password||"");
    const rawLimit=body.planLimit;
    const planLimit=(rawLimit===null || rawLimit==="unlimited" || rawLimit==="") ? null : Math.max(1, Math.min(1000000, Number(rawLimit)||1500));
    const days=Math.max(1,Math.min(3650,Number(body.planDays)||30));
    const allowedApps=parseAllowedApps(body,apps);
    if (!/^[a-z0-9._-]{3,40}$/.test(username) || password.length < 6) return json({error:"INVALID_ACCOUNT"},400);
    if (!allowedApps.length) return json({error:"APP_REQUIRED"},400);
    if (await findResellerByUsername(username)) return json({error:"USERNAME_EXISTS"},409);
    const now=new Date();
    const r={
      id:crypto.randomUUID().toUpperCase(), username, displayName,
      passwordHash:hashResellerPassword(password), status:"active", planLimit, usedCount:0, allowedApps,
      planStartedAt:now.toISOString(), planExpiresAt:new Date(now.getTime()+days*86400000).toISOString(),
      createdAt:now.toISOString(), updatedAt:now.toISOString()
    };
    await saveReseller(r); const ids=await getResellerIndex(); ids.push(r.id); await setResellerIndex(ids);
    await audit("reseller_created",{resellerId:r.id,username:r.username,planLimit,days,allowedApps});
    return json({ok:true,reseller:publicReseller(r)},201);
  }

  if (req.method === "PATCH") {
    const id=sanitizeText(body.id,100); const r=await getReseller(id); if(!r)return json({error:"NOT_FOUND"},404);
    if (body.displayName !== undefined) r.displayName=sanitizeText(body.displayName,100)||r.username;
    if (body.status === "active" || body.status === "disabled") r.status=body.status;
    if (body.password) { if(String(body.password).length<6)return json({error:"PASSWORD_TOO_SHORT"},400); r.passwordHash=hashResellerPassword(body.password); }
    if (body.planLimit !== undefined) r.planLimit=(body.planLimit===null || body.planLimit==="unlimited" || body.planLimit==="")?null:Math.max(1,Math.min(1000000,Number(body.planLimit)||1500));
    if (body.allowedApps !== undefined || body.appId !== undefined) { const next=parseAllowedApps(body,apps); if(!next.length)return json({error:"APP_REQUIRED"},400); r.allowedApps=next; }
    if (body.resetPlan === true || body.planDays) {
      const days=Math.max(1,Math.min(3650,Number(body.planDays)||30)); const now=new Date();
      r.planStartedAt=now.toISOString(); r.planExpiresAt=new Date(now.getTime()+days*86400000).toISOString();
      if (body.resetUsage === true) r.usedCount=0;
    }
    r.updatedAt=new Date().toISOString(); await saveReseller(r); await audit("reseller_updated",{resellerId:r.id,status:r.status,allowedApps:publicReseller(r).allowedApps});
    return json({ok:true,reseller:publicReseller(r)});
  }

  if (req.method === "DELETE") {
    const id=sanitizeText(body.id,100); const r=await getReseller(id); if(!r)return json({error:"NOT_FOUND"},404);
    await deleteReseller(id); const ids=(await getResellerIndex()).filter(x=>x!==id); await setResellerIndex(ids);
    await audit("reseller_deleted",{resellerId:r.id,username:r.username});
    return json({ok:true,deleted:true,id:r.id});
  }
  return json({error:"NOT_FOUND"},404);
};
