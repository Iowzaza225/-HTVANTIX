import { json, requireAdmin, getVersionState, saveVersionState, audit, requestAppId, requireEnabledApp } from "./_lib.mjs";
export default async (req)=>{
  const auth=requireAdmin(req,req.method!=="GET"); if(!auth.ok)return auth.response;
  if(req.method==="GET"){
    const appId=requestAppId(req,null); const app=await requireEnabledApp(appId); if(!app)return json({error:"APP_DISABLED"},403);
    return json({app,version:await getVersionState(appId)});
  }
  if(req.method!=="PATCH")return json({error:"NOT_FOUND"},404);
  let body;try{body=await req.json();}catch{return json({error:"BAD_REQUEST"},400);}
  const appId=requestAppId(req,body); const app=await requireEnabledApp(appId); if(!app)return json({error:"APP_DISABLED"},403);
  const allowedBuilds=Array.isArray(body?.allowedBuilds)?body.allowedBuilds:String(body?.allowedBuilds||"").split(/[,\n]/).map(x=>x.trim()).filter(Boolean);
  const next=await saveVersionState({currentVersion:body?.currentVersion,minimumVersion:body?.minimumVersion,updateURL:body?.updateURL,message:body?.message,releaseNotes:body?.releaseNotes,maintenance:body?.maintenance,allowedBuilds},appId);
  await audit("version_state_updated",{sid:auth.session?.sid||null,appId,currentVersion:next.currentVersion,minimumVersion:next.minimumVersion,maintenance:next.maintenance,allowedBuildCount:next.allowedBuilds.length});
  return json({ok:true,app,version:next});
};
