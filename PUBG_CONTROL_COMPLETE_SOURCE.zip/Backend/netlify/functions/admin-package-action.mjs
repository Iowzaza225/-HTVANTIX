import { json, requireAdmin, getPatchIndex, setPatchIndex, sanitizeText, audit, getApps, normalizeAppId, packageAppIds, packageHasApp } from "./_lib.mjs";
import { deleteR2Object } from "./_r2.mjs";

const safePackage = (item) => {
  const { passwordEnvelope, ...safe } = item;
  return { ...safe, hasPackagePassword: Boolean(passwordEnvelope) };
};

export default async (req) => {
  const auth=requireAdmin(req,true); if(!auth.ok)return auth.response;
  if(req.method!=="POST")return json({error:"NOT_FOUND"},404);
  let body; try{body=await req.json();}catch{return json({error:"BAD_REQUEST"},400);}
  const id=sanitizeText(body?.id,100), action=sanitizeText(body?.action,30);
  const index=await getPatchIndex();
  const pos=index.findIndex(x=>x.id===id);
  if(pos<0)return json({error:"NOT_FOUND"},404);
  const item=index[pos];

  if(action==="set_apps") {
    const enabledApps=(await getApps()).filter(x=>x.enabled!==false);
    const enabledIds=new Set(enabledApps.map(x=>x.appId));
    const requested=Array.isArray(body?.appIds)?body.appIds:[];
    const appIds=[]; const seen=new Set();
    for(const raw of requested){
      const appId=normalizeAppId(raw,"");
      if(!appId||seen.has(appId))continue;
      if(!enabledIds.has(appId))return json({error:"APP_DISABLED",appId},403);
      seen.add(appId); appIds.push(appId);
    }
    if(!appIds.length)return json({error:"APP_REQUIRED"},400);

    const pid=String(item?.packageID||"").trim().toLowerCase();
    if(pid){
      for(const appId of appIds){
        const duplicate=index.find((x,i)=>i!==pos&&packageHasApp(x,appId)&&String(x?.packageID||"").trim().toLowerCase()===pid);
        if(duplicate)return json({error:"PACKAGE_ID_DUPLICATE",appId,packageID:item.packageID,existingPackage:{id:duplicate.id||null,name:duplicate.name||null}},409);
      }
    }

    const before=packageAppIds(item);
    item.appIds=appIds;
    // Keep a primary appId for older admin/diagnostic code and backward data compatibility.
    item.appId=appIds[0];
    item.updatedAt=new Date().toISOString();
    index[pos]=item;
    await setPatchIndex(index);
    await audit("package_apps_updated_v4",{sid:auth.session?.sid||null,id,before,after:appIds,packageID:item.packageID||null,name:item.name||null});
    return json({ok:true,package:safePackage(item),appIds});
  }

  if(action==="enable") item.enabled=true;
  else if(action==="disable") item.enabled=false;
  else if(action==="delete") {
    index.splice(pos,1); await setPatchIndex(index);
    if(item.r2Key){try{await deleteR2Object(item.r2Key);}catch{}}
    await audit("package_deleted_v4",{sid:auth.session?.sid||null,id,appIds:packageAppIds(item)});
    return json({ok:true});
  } else return json({error:"INVALID_ACTION"},400);

  item.updatedAt=new Date().toISOString(); index[pos]=item; await setPatchIndex(index);
  await audit("package_updated_v4",{sid:auth.session?.sid||null,id,action,appIds:packageAppIds(item)});
  return json({ok:true,package:safePackage(item)});
};
