import {
  json, requireAdmin, getLicenseIndex, getLicense, createLicenseRecord,
  publicLicense, audit, licenseConfigReady, requestAppId, requireEnabledApp, sanitizeText
} from "./_lib.mjs";

export default async (req) => {
  const mutating = req.method !== "GET";
  const auth = requireAdmin(req, mutating);
  if (!auth.ok) return auth.response;
  if (!licenseConfigReady()) return json({ error: "LICENSE_CONFIG_MISSING" }, 503);

  if (req.method === "GET") {
    const ids = await getLicenseIndex();
    const rows = [];
    for (const id of ids) {
      const rec = await getLicense(id);
      if (rec) rows.push(publicLicense(rec, { includeKey: true }));
    }
    rows.sort((a,b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    return json({ licenses: rows });
  }

  if (req.method !== "POST") return json({ error: "NOT_FOUND" }, 404);

  let body;
  try { body = await req.json(); } catch { return json({ error: "BAD_REQUEST" }, 400); }
  const appId = requestAppId(req, body);
  const app = await requireEnabledApp(appId);
  if (!app) return json({ error: "APP_DISABLED" }, 403);
  const requestedMinutes = Number(body?.minutes);
  const minutes = Number.isFinite(requestedMinutes) && requestedMinutes > 0 ? Math.max(1, Math.min(1440, Math.floor(requestedMinutes))) : null;
  const days = minutes ? null : Math.max(1, Math.min(3650, Number(body?.days) || 30));
  const quantity = Math.max(1, Math.min(50, Number(body?.quantity) || 1));
  const activationMode = body?.activationMode === "immediate" ? "immediate" : "first_use";
  const baseLabel = sanitizeText(body?.label || "", 80);

  const created = [];
  for (let i = 0; i < quantity; i++) {
    const label = baseLabel && quantity > 1 ? `${baseLabel} ${String(i + 1).padStart(2, "0")}`.slice(0, 80) : baseLabel;
    const { record, key } = await createLicenseRecord({ durationDays: days, durationMinutes: minutes, activationMode, appId, label });
    created.push({ ...publicLicense(record), key });
    await audit("license_created", { id: record.id, appId, days, minutes, activationMode, hasLabel: Boolean(label) });
  }
  return json({ ok: true, app, licenses: created }, 201);
};
