import { json, requireClientSession } from "./_lib.mjs";
export default async (req,context)=>{
  if(req.method!=="GET")return json({error:"NOT_FOUND"},404);
  const access=await requireClientSession(req,context,"metadata");
  if(!access.ok)return access.response;
  return json({
    ok:true,
    appId:access.session.app,
    version:access.version,
    games:[{id:"ff",title:"Free Fire"},{id:"ffmax",title:"Free Fire MAX"}],
    categories:[{id:"shoot",title:"ไฟล์ยิง"},{id:"visual",title:"ไฟล์มอง"},{id:"skin_free",title:"มอดสกิน ฟรี"},{id:"other",title:"อื่น ๆ"}],
    clientPolicy:{privacyShield:true,screenCaptureCover:"black",appSwitcherCover:"black"},
    session:{appId:access.session.app,appVersion:access.session.ver,buildId:access.session.bld}
  },200,{"Cache-Control":"no-store","X-App-Id":access.session.app});
};
