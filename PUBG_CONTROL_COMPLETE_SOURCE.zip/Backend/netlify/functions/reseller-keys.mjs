import {
  json, requireReseller, getLicense, createLicenseRecord, publicLicense,
  saveReseller, publicReseller, audit, getApps, normalizeAppId, sanitizeText,
  DEFAULT_APP_ID, getOrRepairResellerLicenseIndex, setResellerLicenseIndex
} from "./_lib.mjs";

export default async(req)=>{
 const a=await requireReseller(req,req.method!=="GET");
 if(!a.ok)return a.response;
 const r=a.reseller;
 const me=publicReseller(r);
 const allowed=new Set(me.allowedApps||[DEFAULT_APP_ID]);
 const appRows=(await getApps()).filter(x=>x.enabled!==false&&allowed.has(x.appId));

 if(req.method==="GET"){
   // v4.2.2: reseller keys use their own persistent index. On the first GET
   // after upgrading, old reseller-created licenses are recovered by scanning
   // license/* once if that index does not exist yet.
   const ids=await getOrRepairResellerLicenseIndex(r.id);
   const rows=[];
   const cleanIds=[];
   for(const id of ids){
     const x=await getLicense(id);
     if(x&&String(x.resellerId||"")===String(r.id)){
       rows.push(publicLicense(x,{includeKey:true}));
       cleanIds.push(x.id);
     }
   }
   if(cleanIds.length!==ids.length) await setResellerLicenseIndex(r.id,cleanIds);
   rows.sort((x,y)=>String(y.createdAt).localeCompare(String(x.createdAt)));
   return json({reseller:me,apps:appRows,licenses:rows});
 }

 if(req.method!=="POST")return json({error:"NOT_FOUND"},404);
 let b={};try{b=await req.json()}catch{return json({error:"BAD_REQUEST"},400)}
 const appId=normalizeAppId(b?.appId||me.allowedApps?.[0]||DEFAULT_APP_ID);
 if(!allowed.has(appId)||!appRows.some(x=>x.appId===appId))return json({error:"APP_NOT_ALLOWED"},403);
 const baseLabel=sanitizeText(b?.label||"",80);
 const requestedMinutes=Number(b.minutes);
 const minutes=Number.isFinite(requestedMinutes)&&requestedMinutes>0?Math.max(1,Math.min(1440,Math.floor(requestedMinutes))):null;
 const days=minutes?null:Math.max(1,Math.min(3650,Number(b.days)||30));
 const qty=Math.max(1,Math.min(50,Number(b.quantity)||1));
 const mode=b.activationMode==="immediate"?"immediate":"first_use";
 const used=Number(r.usedCount||0);
 if(r.planLimit!=null&&used+qty>Number(r.planLimit))return json({error:"QUOTA_EXCEEDED",remaining:Math.max(0,Number(r.planLimit)-used)},409);

 const created=[];
 for(let i=0;i<qty;i++){
   const label=baseLabel&&qty>1?`${baseLabel} ${String(i+1).padStart(2,"0")}`.slice(0,80):baseLabel;
   const {record,key}=await createLicenseRecord({
     durationDays:days,
     durationMinutes:minutes,
     activationMode:mode,
     appId,
     label,
     resellerId:r.id,
     resellerUsername:r.username
   });
   created.push({...publicLicense(record),key});
 }
 r.usedCount=used+created.length;
 r.updatedAt=new Date().toISOString();
 await saveReseller(r);
 await audit("reseller_license_created",{resellerId:r.id,appId,quantity:created.length,days,minutes,hasLabel:Boolean(baseLabel),licenseIds:created.map(x=>x.id)});
 return json({ok:true,reseller:publicReseller(r),apps:appRows,licenses:created},201);
};
