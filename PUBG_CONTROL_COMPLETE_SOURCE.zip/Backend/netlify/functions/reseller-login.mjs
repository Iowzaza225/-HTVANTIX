import {
  json, sameOrigin, findResellerByUsername, verifyResellerPassword,
  makeResellerSession, resellerSessionCookie, publicReseller, audit,
  checkResellerLoginRate, recordResellerLoginFailure, clearResellerLoginFailures
} from "./_lib.mjs";

export default async (req, context) => {
  if (req.method !== "POST") return json({ error: "NOT_FOUND" }, 404);
  if (!sameOrigin(req)) return json({ error: "CROSS_ORIGIN_BLOCKED" }, 403);

  // Check the IP bucket before any reseller lookup / scrypt work. Once an IP
  // is locked, repeated bot requests are answered cheaply with 429.
  const rate = await checkResellerLoginRate(req, context);
  if (!rate.allowed) {
    return json({ error: "LOCKED", retryAfter: rate.retryAfter }, 429, {
      "Retry-After": String(rate.retryAfter)
    });
  }

  // Cheap abuse guards before any reseller lookup / password hashing.
  // The normal reseller panel sends a tiny JSON body, so these limits do not
  // affect legitimate logins but prevent oversized / malformed requests from
  // consuming unnecessary compute during an attack.
  const contentLength = Number(req.headers.get("content-length") || 0);
  if (Number.isFinite(contentLength) && contentLength > 4096) {
    return json({ error: "PAYLOAD_TOO_LARGE" }, 413);
  }
  const contentType = String(req.headers.get("content-type") || "").toLowerCase();
  if (!contentType.includes("application/json")) {
    return json({ error: "UNSUPPORTED_MEDIA_TYPE" }, 415);
  }

  let body = {};
  try { body = await req.json(); } catch { return json({ error: "BAD_REQUEST" }, 400); }

  const username = typeof body?.username === "string" ? body.username.trim() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  const shapeOK = username.length >= 1 && username.length <= 80 && password.length >= 1 && password.length <= 256;

  const reseller = shapeOK ? await findResellerByUsername(username) : null;
  const valid = Boolean(
    reseller &&
    reseller.status === "active" &&
    verifyResellerPassword(password, reseller)
  );

  if (!valid) {
    const failed = await recordResellerLoginFailure(rate);
    // Only write an audit event when the limiter actually enters lock state,
    // avoiding one audit write for every bot request.
    if (failed.lockedNow) {
      await audit("reseller_login_rate_locked", { ip: rate.ipHash, attempts: failed.count });
    }
    return json({ error: "INVALID_LOGIN" }, 401);
  }

  const exp = reseller.planExpiresAt ? Date.parse(reseller.planExpiresAt) : 0;
  if (exp && exp <= Date.now()) return json({ error: "PLAN_EXPIRED" }, 403);

  await clearResellerLoginFailures(rate.key);
  const session = makeResellerSession(reseller);
  await audit("reseller_login", { resellerId: reseller.id });
  return json({ ok: true, reseller: publicReseller(reseller) }, 200, {
    "Set-Cookie": resellerSessionCookie(session.token)
  });
};
