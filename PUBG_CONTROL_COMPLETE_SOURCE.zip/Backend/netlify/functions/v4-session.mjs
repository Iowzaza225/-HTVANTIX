import { json, verifyLicenseToken, getLicense, licenseState, validDeviceId, deviceHash, evaluateClientVersion, makeClientSession, clientSessionConfigReady, sanitizeText, audit, requestAppId, recordAppId, requireEnabledApp } from "./_lib.mjs";
export default async (req)=>{
  if(req.method!=="POST")return json({error:"NOT_FOUND"},404);
  if(!clientSessionConfigReady())return json({error:"SERVER_NOT_CONFIGURED"},503);
  const auth=req.headers.get("authorization")||""; const m=auth.match(/^Bearer\s+(.+)$/i); const lic=m?verifyLicenseToken(m[1]):null; if(!lic)return json({error:"LICENSE_SESSION_REQUIRED"},401);
  let body;try{body=await req.json();}catch{return json({error:"BAD_REQUEST"},400);}
  const appId=requestAppId(req,body,lic.app); if(appId!==lic.app)return json({error:"APP_SESSION_MISMATCH"},403);
  const app=await requireEnabledApp(appId); if(!app)return json({error:"APP_DISABLED"},403);
  const appVersion=sanitizeText(body?.appVersion,24),buildId=sanitizeText(body?.buildId,80),deviceId=String(body?.deviceId||"").trim(); if(!appVersion||!validDeviceId(deviceId))return json({error:"BAD_REQUEST"},400);
  const dh=deviceHash(deviceId); if(dh!==lic.dev)return json({error:"DEVICE_MISMATCH"},403);
  const rec=await getLicense(lic.sub);const state=licenseState(rec);if(!state.ok)return json({error:state.code},403);if(rec.deviceHash!==dh)return json({error:"DEVICE_MISMATCH"},403);if(recordAppId(rec)!==appId)return json({error:"KEY_NOT_FOR_THIS_APP"},403);
  const vg=await evaluateClientVersion(appVersion,buildId,appId);if(!vg.ok)return json({error:vg.code,client:vg.state},426);
  const {token,payload}=makeClientSession({licenseId:rec.id,devHash:dh,appVersion,buildId,appId});await audit("client_session_v4",{id:rec.id,appId,appVersion,buildId,jti:payload.jti});
  return json({ok:true,app:{appId:app.appId,name:app.name},sessionToken:token,expiresAt:new Date(payload.exp*1000).toISOString(),client:vg.state});
};
