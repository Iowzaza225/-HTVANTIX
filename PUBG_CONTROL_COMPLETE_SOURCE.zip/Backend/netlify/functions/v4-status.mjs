import { json, getVersionState, requestAppId, requireEnabledApp } from "./_lib.mjs";

export default async (req)=>{
  if(req.method!=="GET") return json({error:"NOT_FOUND"},404);
  const appId=requestAppId(req,null);
  const app=await requireEnabledApp(appId);
  if(!app)return json({ok:false,appId,error:"APP_DISABLED"},403,{"Cache-Control":"no-store"});
  const version = await getVersionState(appId);
  return json({
    ok: true,
    app:{appId:app.appId,name:app.name},
    service: "HIGHT API",
    appEnabled: !version.maintenance,
    maintenance: Boolean(version.maintenance),
    message: version.message || (version.maintenance ? "ระบบถูกปิดใช้งานชั่วคราว" : ""),
    currentVersion: version.currentVersion,
    minimumVersion: version.minimumVersion,
    updateURL: version.updateURL || "",
    updatedAt: version.updatedAt || null
  }, 200, { "Cache-Control":"no-store", "X-App-Id":appId });
};
