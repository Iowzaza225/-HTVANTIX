import { json, requireAdmin, getPatchIndex, audit, recordAppId, packageAppIds } from "./_lib.mjs";
import { r2Ready, listR2PackageObjects, deleteR2Object } from "./_r2.mjs";

function summarize(index, objects) {
  const refs = new Map();
  for (const p of index) {
    const key = String(p?.r2Key || "");
    if (!key) continue;
    const arr = refs.get(key) || [];
    arr.push({ appId:recordAppId(p), appIds:packageAppIds(p), id:p.id||null, packageID:p.packageID||null, name:p.name||null, enabled:p.enabled!==false });
    refs.set(key, arr);
  }
  const objectMap = new Map(objects.map(o => [o.key, o]));
  const missing = [];
  const duplicateR2Keys = [];
  const duplicatePackageIDs = [];
  const packageIds = new Map();
  for (const p of index) {
    const appIds=packageAppIds(p);
    const pid = String(p?.packageID || "").trim().toLowerCase();
    if (pid) {
      for (const appId of appIds) {
        const scoped = `${appId}:${pid}`;
        const arr = packageIds.get(scoped) || [];
        arr.push({ appId,id:p.id||null,packageID:p.packageID||null,name:p.name||null });
        packageIds.set(scoped, arr);
      }
    }
    const key = String(p?.r2Key || "");
    if (key && !objectMap.has(key)) missing.push({ appId:recordAppId(p),appIds,id:p.id||null,packageID:p.packageID||null,name:p.name||null,r2Key:key });
  }
  for (const [key, arr] of refs) if (arr.length > 1) duplicateR2Keys.push({ r2Key:key, packages:arr });
  for (const [_, arr] of packageIds) if (arr.length > 1) duplicatePackageIDs.push(arr);
  const orphans = objects.filter(o => !refs.has(o.key));
  const rows = index.map(p => {
    const o = objectMap.get(String(p?.r2Key || ""));
    return {
      appId:recordAppId(p),appIds:packageAppIds(p),id:p.id||null,packageID:p.packageID||null,name:p.name||null,enabled:p.enabled!==false,
      fileName:p.fileName||null,r2Key:p.r2Key||null,catalogSizeBytes:Number(p.sizeBytes||0),r2Exists:!!o,
      r2SizeBytes:o?Number(o.sizeBytes||0):null,sizeMatch:!!o&&Number(o.sizeBytes||0)===Number(p.sizeBytes||0),createdAt:p.createdAt||null,
    };
  });
  const byApp={};
  for(const p of index){for(const id of packageAppIds(p)){byApp[id] ||= {catalogCount:0,enabledCount:0};byApp[id].catalogCount++;if(p?.enabled!==false)byApp[id].enabledCount++;}}
  return {catalogCount:index.length,enabledCount:index.filter(x=>x?.enabled!==false).length,r2ObjectCount:objects.length,linkedObjectCount:objects.filter(o=>refs.has(o.key)).length,orphanCount:orphans.length,missingCount:missing.length,duplicateR2KeyCount:duplicateR2Keys.length,duplicatePackageIDCount:duplicatePackageIDs.length,byApp,rows,orphans,missing,duplicateR2Keys,duplicatePackageIDs};
}

export default async (req) => {
  const auth = requireAdmin(req, true); if (!auth.ok) return auth.response;
  if (!r2Ready()) return json({error:"STORAGE_NOT_CONFIGURED"},503);
  if (req.method === "GET") {
    const index = await getPatchIndex(); const objects = await listR2PackageObjects(5000); const report = summarize(index, objects);
    await audit("storage_diagnostic_v4", {sid:auth.session?.sid||null,catalogCount:report.catalogCount,enabledCount:report.enabledCount,r2ObjectCount:report.r2ObjectCount,orphanCount:report.orphanCount,missingCount:report.missingCount,duplicateR2KeyCount:report.duplicateR2KeyCount,duplicatePackageIDCount:report.duplicatePackageIDCount,byApp:report.byApp});
    return json({ok:true,generatedAt:new Date().toISOString(),...report});
  }
  if (req.method === "POST") {
    let body; try { body = await req.json(); } catch { return json({error:"BAD_REQUEST"},400); }
    if (body?.action !== "delete_orphans" || body?.confirm !== "DELETE_ORPHANS") return json({error:"CONFIRM_REQUIRED"},400);
    const index = await getPatchIndex(); const objects = await listR2PackageObjects(5000); const report = summarize(index, objects);
    const deleted=[]; const failed=[];
    for (const o of report.orphans) { try { await deleteR2Object(o.key); deleted.push(o.key); } catch (e) { failed.push({key:o.key,error:String(e?.message||e)}); } }
    await audit("storage_orphans_deleted_v4", {sid:auth.session?.sid||null,deletedCount:deleted.length,failedCount:failed.length});
    return json({ok:failed.length===0,deletedCount:deleted.length,failedCount:failed.length,failed});
  }
  return json({error:"NOT_FOUND"},404);
};
