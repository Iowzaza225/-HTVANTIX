import { json, requireAdmin, getApps, saveApps, normalizeAppId, sanitizeText, audit } from "./_lib.mjs";

export default async (req) => {
  const auth = requireAdmin(req, req.method !== "GET");
  if (!auth.ok) return auth.response;

  if (req.method === "GET") {
    return json({ apps: await getApps() });
  }

  let body = {};
  try { body = await req.json(); } catch { return json({ error: "BAD_REQUEST" }, 400); }
  const rows = await getApps();

  if (req.method === "POST") {
    const raw = String(body?.appId || "").trim().toLowerCase();
    const appId = normalizeAppId(raw, "");
    const name = sanitizeText(body?.name || appId, 80);
    if (!appId || appId !== raw || !/^[a-z0-9][a-z0-9._-]{1,47}$/.test(appId) || !name) {
      return json({ error: "INVALID_APP" }, 400);
    }
    if (rows.some(x => x.appId === appId)) return json({ error: "APP_EXISTS" }, 409);
    const now = new Date().toISOString();
    const app = { appId, name, enabled: true, createdAt: now, updatedAt: now };
    rows.push(app);
    await saveApps(rows);
    await audit("app_created_v4", { appId, name });
    return json({ ok: true, app }, 201);
  }

  if (req.method === "PATCH") {
    const appId = normalizeAppId(body?.appId, "");
    const pos = rows.findIndex(x => x.appId === appId);
    if (!appId || pos < 0) return json({ error: "NOT_FOUND" }, 404);
    if (body?.name !== undefined) {
      const name = sanitizeText(body.name, 80);
      if (!name) return json({ error: "INVALID_APP" }, 400);
      rows[pos].name = name;
    }
    if (typeof body?.enabled === "boolean") rows[pos].enabled = body.enabled;
    rows[pos].updatedAt = new Date().toISOString();
    await saveApps(rows);
    await audit("app_updated_v4", { appId, enabled: rows[pos].enabled, name: rows[pos].name });
    return json({ ok: true, app: rows[pos] });
  }

  return json({ error: "NOT_FOUND" }, 404);
};
