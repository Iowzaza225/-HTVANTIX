import crypto from "node:crypto";
import { getStore } from "@netlify/blobs";

export const BUILD = "HIGHT-API-V4.2.5-DOWNLOAD-HOTPATH";
export const MAX_UPLOAD_BYTES = 150 * 1024 * 1024;

function packageUnlockCryptoKey() {
  const secret = String(process.env.HIGHT_PACKAGE_UNLOCK_SECRET || "");
  if (!secret) throw new Error("HIGHT_PACKAGE_UNLOCK_SECRET missing");
  return crypto.createHash("sha256").update(`hight-package-unlock:${secret}`).digest();
}

export function encryptPackagePassword(password) {
  const value = String(password || "");
  if (!value) return null;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", packageUnlockCryptoKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return {
    v: 1,
    iv: iv.toString("base64url"),
    ciphertext: ciphertext.toString("base64url"),
    tag: cipher.getAuthTag().toString("base64url"),
  };
}

export function decryptPackagePassword(record) {
  if (!record?.iv || !record?.ciphertext || !record?.tag) return null;
  try {
    const decipher = crypto.createDecipheriv(
      "aes-256-gcm",
      packageUnlockCryptoKey(),
      Buffer.from(record.iv, "base64url")
    );
    decipher.setAuthTag(Buffer.from(record.tag, "base64url"));
    return Buffer.concat([
      decipher.update(Buffer.from(record.ciphertext, "base64url")),
      decipher.final(),
    ]).toString("utf8");
  } catch {
    return null;
  }
}

// Multi-app / multi-IPA routing. Existing clients that do not send an appId
// remain attached to HTVANTIX for backwards compatibility. New IPA builds
// should send x-app-id (or body.appId where applicable).
export const DEFAULT_APP_ID = "htvantix";
const APP_INDEX_KEY = "app-index-v1";

// Short-lived warm-instance caches keep the IPA hot path off strong-consistency
// Blob reads on every request. Admin writes invalidate the matching cache, so
// control changes still propagate quickly while status/packages/download stay
// responsive during traffic spikes.
const HOT_CACHE_TTL_MS = 3000;
let appsCache = { at: 0, value: null };
let securityCache = { at: 0, value: null };
let patchIndexCache = { at: 0, value: null };
const versionCache = new Map();

function hotCacheFresh(entry) {
  return entry && entry.value != null && (Date.now() - entry.at) < HOT_CACHE_TTL_MS;
}

export function normalizeAppId(value, fallback = DEFAULT_APP_ID) {
  const raw = String(value ?? "").trim().toLowerCase();
  if (!raw) return fallback;
  const clean = raw.replace(/[^a-z0-9._-]/g, "").slice(0, 48);
  return clean || fallback;
}

export function recordAppId(record) {
  return normalizeAppId(record?.appId || DEFAULT_APP_ID);
}

// Package records can be shared by more than one IPA without duplicating the
// physical R2 object. Older records only have appId; treat those as a
// one-element appIds list so existing HTVANTIX data keeps working.
export function packageAppIds(record) {
  const raw = Array.isArray(record?.appIds) ? record.appIds : [];
  const out = [];
  const seen = new Set();
  for (const value of raw) {
    const id = normalizeAppId(value, "");
    if (!id || seen.has(id)) continue;
    seen.add(id);
    out.push(id);
  }
  if (!out.length) out.push(recordAppId(record));
  return out;
}

export function packageHasApp(record, appId) {
  const wanted = normalizeAppId(appId);
  return packageAppIds(record).includes(wanted);
}

export function requestAppId(req, body = null, fallback = DEFAULT_APP_ID) {
  let queryValue = "";
  try { queryValue = new URL(req.url).searchParams.get("appId") || ""; } catch {}
  return normalizeAppId(body?.appId || req.headers.get("x-app-id") || queryValue || fallback, fallback);
}

function defaultApps() {
  return [
    { appId: "htvantix", name: "HTVANTIX", enabled: true },
    { appId: "viperxmod", name: "Viperxmod", enabled: true },
    { appId: "pubgcontrol", name: "PUBG CONTROL", enabled: true },
  ];
}

export async function getApps() {
  if (hotCacheFresh(appsCache)) return appsCache.value;
  const raw = await metaStore().get(APP_INDEX_KEY, { type: "json", consistency: "strong" });
  const rows = Array.isArray(raw) ? raw : [];
  const byId = new Map();
  for (const x of [...defaultApps(), ...rows]) {
    const appId = normalizeAppId(x?.appId, "");
    if (!appId) continue;
    const prev = byId.get(appId) || {};
    byId.set(appId, {
      ...prev,
      ...x,
      appId,
      name: sanitizeText(x?.name || prev.name || appId, 80) || appId,
      enabled: x?.enabled !== false,
      createdAt: x?.createdAt || prev.createdAt || null,
      updatedAt: x?.updatedAt || prev.updatedAt || null,
    });
  }
  const value = [...byId.values()].sort((a,b) => a.appId.localeCompare(b.appId));
  appsCache = { at: Date.now(), value };
  return value;
}

export async function saveApps(rows) {
  const clean = [];
  const seen = new Set();
  for (const x of Array.isArray(rows) ? rows : []) {
    const appId = normalizeAppId(x?.appId, "");
    if (!appId || seen.has(appId)) continue;
    seen.add(appId);
    clean.push({
      appId,
      name: sanitizeText(x?.name || appId, 80) || appId,
      enabled: x?.enabled !== false,
      createdAt: x?.createdAt || new Date().toISOString(),
      updatedAt: x?.updatedAt || new Date().toISOString(),
    });
  }
  await metaStore().setJSON(APP_INDEX_KEY, clean);
  appsCache = { at: 0, value: null };
  return clean;
}

export async function getApp(appId) {
  const wanted = normalizeAppId(appId);
  return (await getApps()).find(x => x.appId === wanted) || null;
}

export async function requireEnabledApp(appId) {
  const app = await getApp(appId);
  return app && app.enabled !== false ? app : null;
}

export const metaStore = () => getStore({ name: "hight-v4-meta", consistency: "strong" });
export const fileStore = () => getStore({ name: "hight-v4-files", consistency: "strong" });
export const authStore = () => getStore({ name: "hight-v4-auth", consistency: "strong" });
export const logStore = () => getStore({ name: "hight-v4-logs", consistency: "strong" });
export const auditStore = () => getStore({ name: "hight-v4-audit", consistency: "strong" });
export const licenseStore = () => getStore({ name: "hight-v4-license", consistency: "strong" });

const baseSecurityHeaders = {
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "no-referrer",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
  "Cross-Origin-Opener-Policy": "same-origin",
  "Cross-Origin-Resource-Policy": "same-origin",
  "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
  "X-HIGHT-Build": BUILD,
};

export const json = (data, status = 200, extra = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...baseSecurityHeaders,
      ...extra,
    },
  });

export const sha256Hex = (input) =>
  crypto.createHash("sha256").update(input).digest("hex");

export const safeEqual = (a, b) => {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
};

export function responseSignature(bytes) {
  const key = process.env.HIGHT_RESPONSE_HMAC;
  if (!key) throw new Error("HIGHT_RESPONSE_HMAC missing");
  return crypto.createHmac("sha256", String(key)).update(bytes).digest("hex");
}

export function signedResponse(bytes, contentType, extra = {}) {
  const raw = Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes);
  return new Response(raw, {
    status: 200,
    headers: {
      "Content-Type": contentType,
      "X-Response-Sig": responseSignature(raw),
      "Cache-Control": "no-store, no-cache, must-revalidate, no-transform",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
      "X-HIGHT-Build": BUILD,
      ...extra,
    },
  });
}

export function signedJSON(obj) {
  const raw = Buffer.from(JSON.stringify(obj));
  return signedResponse(raw, "application/json; charset=utf-8");
}

export function parseCookies(req) {
  const raw = req.headers.get("cookie") || "";
  const out = {};
  for (const part of raw.split(";")) {
    const i = part.indexOf("=");
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    const v = part.slice(i + 1).trim();
    try { out[k] = decodeURIComponent(v); } catch { out[k] = v; }
  }
  return out;
}

export function sameOrigin(req) {
  const u = new URL(req.url);
  const origin = req.headers.get("origin");
  if (origin && origin !== u.origin) return false;
  const site = req.headers.get("sec-fetch-site");
  if (site && site !== "same-origin" && site !== "none") return false;
  return true;
}

export function adminConfigReady() {
  return Boolean(
    (process.env.HIGHT_ADMIN_PASSWORD_SCRYPT || process.env.HIGHT_ADMIN_PASSWORD) &&
    process.env.HIGHT_SESSION_SECRET
  );
}

export function securityConfigReady() {
  return Boolean(
    (process.env.HIGHT_ADMIN_PASSWORD_SCRYPT || process.env.HIGHT_ADMIN_PASSWORD) &&
    process.env.HIGHT_SESSION_SECRET &&
    process.env.HIGHT_LOG_SALT &&
    process.env.HIGHT_RESPONSE_HMAC &&
    process.env.HIGHT_LICENSE_SECRET
  );
}

export function verifyAdminCredentials(username, password) {
  const expectedUser = String(process.env.HIGHT_ADMIN_USERNAME || "admin");
  if (!safeEqual(String(username || ""), expectedUser)) return false;

  // Prefer the scrypt record when configured. Plain HIGHT_ADMIN_PASSWORD is
  // supported only to make first-time Netlify setup simple; both remain server-side.
  const record = String(process.env.HIGHT_ADMIN_PASSWORD_SCRYPT || "");
  if (record) {
    const parts = record.split("$");
    if (parts.length !== 6 || parts[0] !== "scrypt") return false;
    const N = Number(parts[1]), r = Number(parts[2]), p = Number(parts[3]);
    const salt = Buffer.from(parts[4], "hex");
    const expected = Buffer.from(parts[5], "hex");
    if (!N || !r || !p || !salt.length || expected.length !== 64) return false;
    try {
      const actual = crypto.scryptSync(String(password || ""), salt, expected.length, {
        N, r, p, maxmem: 128 * 1024 * 1024
      });
      return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
    } catch {
      return false;
    }
  }

  const expectedPassword = String(process.env.HIGHT_ADMIN_PASSWORD || "");
  return Boolean(expectedPassword) && safeEqual(String(password || ""), expectedPassword);
}

// Backward-compatible helper for any older internal call.
export function verifyAdminPassword(password) {
  return verifyAdminCredentials(process.env.HIGHT_ADMIN_USERNAME || "admin", password);
}

function b64url(value) {
  return Buffer.from(value).toString("base64url");
}

export function csrfForSession(session) {
  const secret = process.env.HIGHT_SESSION_SECRET;
  const sid = String(session?.sid || "");
  if (!secret || !sid) return "";
  return crypto.createHmac("sha256", String(secret))
    .update(`admin-csrf:${sid}`)
    .digest("base64url");
}

export function makeSession() {
  const secret = process.env.HIGHT_SESSION_SECRET;
  if (!secret) throw new Error("HIGHT_SESSION_SECRET missing");
  const now = Math.floor(Date.now() / 1000);
  const payload = {
    sub: "admin",
    iat: now,
    exp: now + 8 * 60 * 60,
    sid: crypto.randomBytes(12).toString("hex"),
    adminSessionVersion: 4,
  };
  // CSRF is derived from the signed session id instead of being a second
  // independently-random value. This keeps status/read and mutation checks
  // synchronized even across Edge/Function routing and existing sessions.
  payload.csrf = csrfForSession(payload);
  const body = b64url(JSON.stringify(payload));
  const sig = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  return { token: `${body}.${sig}`, payload };
}

export function verifySession(req) {
  const secret = process.env.HIGHT_SESSION_SECRET;
  if (!secret) return null;
  const cookies = parseCookies(req);
  const token = cookies["__Host-hight_admin_v4"] || "";
  const [body, signature] = token.split(".");
  if (!body || !signature) return null;
  const expected = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  if (!safeEqual(signature, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    if (
      payload.sub !== "admin" ||
      payload.adminSessionVersion !== 4 ||
      !payload.exp ||
      payload.exp < Math.floor(Date.now()/1000)
    ) return null;
    return payload;
  } catch {
    return null;
  }
}

export function requireAdmin(req, requireCsrf = false) {
  if (!sameOrigin(req)) {
    return { ok: false, response: json({ error: "CROSS_ORIGIN_BLOCKED" }, 403) };
  }
  const session = verifySession(req);
  if (!session) {
    return { ok: false, response: json({ error: "UNAUTHORIZED" }, 401) };
  }
  if (requireCsrf) {
    const got = req.headers.get("x-hight-csrf") || "";
    const expected = csrfForSession(session);
    if (!got || !expected || !safeEqual(got, expected)) {
      return { ok: false, response: json({ error: "CSRF" }, 403) };
    }
  }
  return { ok: true, session };
}

export function sessionCookie(token, maxAge = 8 * 60 * 60) {
  return `__Host-hight_admin_v4=${encodeURIComponent(token)}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${maxAge}`;
}

export function clearSessionCookie() {
  return "__Host-hight_admin_v4=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0";
}


export function clearLegacySessionCookies() {
  return [
    "__Host-hight_admin=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0",
    "__Host-hight_pre=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0"
  ];
}

export function clientIP(req, context) {
  return context?.ip ||
    req.headers.get("x-nf-client-connection-ip") ||
    (req.headers.get("x-forwarded-for") || "").split(",")[0].trim() ||
    "unknown";
}

export function privacyHash(value) {
  const salt = process.env.HIGHT_LOG_SALT;
  if (!salt) return sha256Hex(`unconfigured:${value}`).slice(0, 24);
  return sha256Hex(`${salt}:${value}`).slice(0, 24);
}

export async function checkLoginRate(req, context) {
  const key = "login/" + privacyHash(clientIP(req, context));
  const store = authStore();
  const now = Date.now();
  const rec = await store.get(key, { type: "json", consistency: "strong" }) || {
    count: 0, windowStart: now, lockedUntil: 0
  };
  if (rec.lockedUntil > now) {
    return { allowed: false, key, rec, retryAfter: Math.ceil((rec.lockedUntil - now) / 1000) };
  }
  if (now - rec.windowStart > 10 * 60 * 1000) {
    rec.count = 0; rec.windowStart = now; rec.lockedUntil = 0;
  }
  return { allowed: true, key, rec };
}

export async function recordLoginFailure(rate) {
  const now = Date.now();
  rate.rec.count += 1;
  if (rate.rec.count >= 5) rate.rec.lockedUntil = now + 15 * 60 * 1000;
  await authStore().setJSON(rate.key, rate.rec);
}

export async function clearLoginFailures(key) {
  try { await authStore().delete(key); } catch {}
}

// Reseller login gets its own IP bucket so brute-force traffic cannot
// interfere with the Admin login rate limiter. Policy: 5 failed attempts
// inside 10 minutes => block that IP from reseller login for 30 minutes.
export async function checkResellerLoginRate(req, context) {
  const ipHash = privacyHash(clientIP(req, context));
  const key = "reseller-login/" + ipHash;
  const store = authStore();
  const now = Date.now();
  const rec = await store.get(key, { type: "json", consistency: "strong" }) || {
    count: 0, windowStart: now, lockedUntil: 0
  };
  if (rec.lockedUntil > now) {
    return { allowed: false, key, ipHash, rec, retryAfter: Math.ceil((rec.lockedUntil - now) / 1000) };
  }
  if (now - rec.windowStart > 10 * 60 * 1000) {
    rec.count = 0; rec.windowStart = now; rec.lockedUntil = 0;
  }
  return { allowed: true, key, ipHash, rec };
}

export async function recordResellerLoginFailure(rate) {
  const now = Date.now();
  rate.rec.count = Number(rate.rec.count || 0) + 1;
  const lockedNow = rate.rec.count >= 5;
  if (lockedNow) rate.rec.lockedUntil = now + 30 * 60 * 1000;
  await authStore().setJSON(rate.key, rate.rec);
  return { lockedNow, count: rate.rec.count, lockedUntil: rate.rec.lockedUntil || 0 };
}

export async function clearResellerLoginFailures(key) {
  try { await authStore().delete(key); } catch {}
}

export async function audit(action, data = {}) {
  try {
    const key = `audit/${Date.now()}-${crypto.randomUUID()}`;
    await auditStore().setJSON(key, {
      at: new Date().toISOString(),
      action,
      ...data,
    });
  } catch {}
}



// ===== Admin TOTP / pre-auth helpers (RFC 6238) =====
const OTP_CONFIG_KEY = "admin/totp-config";
const OTP_PENDING_KEY = "admin/totp-pending";

function otpCryptoKey() {
  const secret = String(process.env.HIGHT_SESSION_SECRET || "");
  if (!secret) throw new Error("HIGHT_SESSION_SECRET missing");
  return crypto.createHash("sha256").update(`hight-admin-totp:${secret}`).digest();
}

function encryptOtpSecret(secret) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", otpCryptoKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(String(secret), "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    v: 1,
    iv: iv.toString("base64url"),
    ciphertext: ciphertext.toString("base64url"),
    tag: tag.toString("base64url"),
  };
}

function decryptOtpSecret(record) {
  if (!record?.iv || !record?.ciphertext || !record?.tag) return null;
  try {
    const decipher = crypto.createDecipheriv(
      "aes-256-gcm",
      otpCryptoKey(),
      Buffer.from(record.iv, "base64url")
    );
    decipher.setAuthTag(Buffer.from(record.tag, "base64url"));
    const plain = Buffer.concat([
      decipher.update(Buffer.from(record.ciphertext, "base64url")),
      decipher.final(),
    ]);
    return plain.toString("utf8");
  } catch {
    return null;
  }
}

const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function base32Encode(buffer) {
  let bits = 0, value = 0, out = "";
  for (const byte of buffer) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

function base32Decode(input) {
  const clean = String(input || "").toUpperCase().replace(/[^A-Z2-7]/g, "");
  let bits = 0, value = 0;
  const bytes = [];
  for (const ch of clean) {
    const idx = B32.indexOf(ch);
    if (idx < 0) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(bytes);
}

function hotp(secretBase32, counter) {
  const key = base32Decode(secretBase32);
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter));
  const digest = crypto.createHmac("sha1", key).update(msg).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const binary =
    ((digest[offset] & 0x7f) << 24) |
    ((digest[offset + 1] & 0xff) << 16) |
    ((digest[offset + 2] & 0xff) << 8) |
    (digest[offset + 3] & 0xff);
  return String(binary % 1_000_000).padStart(6, "0");
}

export function verifyTotpCode(code, secretBase32, nowMs = Date.now(), window = 1) {
  const clean = String(code || "").replace(/\s+/g, "");
  if (!/^\d{6}$/.test(clean)) return { ok: false, counter: null };
  const current = Math.floor(nowMs / 1000 / 30);
  for (let delta = -window; delta <= window; delta++) {
    const counter = current + delta;
    if (counter < 0) continue;
    if (safeEqual(clean, hotp(secretBase32, counter))) return { ok: true, counter };
  }
  return { ok: false, counter: null };
}

export async function isAdminOtpEnabled() {
  const rec = await authStore().get(OTP_CONFIG_KEY, { type: "json", consistency: "strong" });
  return Boolean(rec?.enabled && decryptOtpSecret(rec));
}

export async function getOrCreatePendingOtp() {
  const store = authStore();
  const now = Date.now();
  let rec = await store.get(OTP_PENDING_KEY, { type: "json", consistency: "strong" });
  if (!rec || Number(rec.expiresAt || 0) <= now || !decryptOtpSecret(rec)) {
    const secret = base32Encode(crypto.randomBytes(20));
    rec = {
      ...encryptOtpSecret(secret),
      createdAt: new Date(now).toISOString(),
      expiresAt: now + 10 * 60 * 1000,
    };
    await store.setJSON(OTP_PENDING_KEY, rec);
  }
  const secret = decryptOtpSecret(rec);
  return { secret, expiresAt: rec.expiresAt };
}

export async function confirmPendingOtp(code) {
  const store = authStore();
  const rec = await store.get(OTP_PENDING_KEY, { type: "json", consistency: "strong" });
  if (!rec || Number(rec.expiresAt || 0) <= Date.now()) return { ok: false, reason: "SETUP_EXPIRED" };
  const secret = decryptOtpSecret(rec);
  if (!secret) return { ok: false, reason: "SETUP_EXPIRED" };
  const checked = verifyTotpCode(code, secret);
  if (!checked.ok) return { ok: false, reason: "INVALID_OTP" };
  await store.setJSON(OTP_CONFIG_KEY, {
    ...encryptOtpSecret(secret),
    enabled: true,
    createdAt: new Date().toISOString(),
    lastCounter: checked.counter,
  });
  try { await store.delete(OTP_PENDING_KEY); } catch {}
  return { ok: true, counter: checked.counter };
}

export async function verifyAdminOtp(code) {
  const store = authStore();
  const rec = await store.get(OTP_CONFIG_KEY, { type: "json", consistency: "strong" });
  if (!rec?.enabled) return { ok: false, reason: "OTP_NOT_CONFIGURED" };
  const secret = decryptOtpSecret(rec);
  if (!secret) return { ok: false, reason: "OTP_NOT_CONFIGURED" };
  const checked = verifyTotpCode(code, secret);
  if (!checked.ok) return { ok: false, reason: "INVALID_OTP" };
  // Reject reuse of the same/older 30-second code.
  const last = Number(rec.lastCounter ?? -1);
  if (checked.counter <= last) return { ok: false, reason: "OTP_REUSED" };
  rec.lastCounter = checked.counter;
  rec.lastUsedAt = new Date().toISOString();
  await store.setJSON(OTP_CONFIG_KEY, rec);
  return { ok: true, counter: checked.counter };
}

export function makePreAuthSession() {
  const secret = process.env.HIGHT_SESSION_SECRET;
  if (!secret) throw new Error("HIGHT_SESSION_SECRET missing");
  const now = Math.floor(Date.now() / 1000);
  const payload = {
    sub: "admin-preauth",
    iat: now,
    exp: now + 5 * 60,
    sid: crypto.randomBytes(12).toString("hex"),
    adminSessionVersion: 4,
  };
  const body = b64url(JSON.stringify(payload));
  const sig = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  return { token: `${body}.${sig}`, payload };
}

export function verifyPreAuth(req) {
  const secret = process.env.HIGHT_SESSION_SECRET;
  if (!secret) return null;
  const token = parseCookies(req)["__Host-hight_pre_v4"] || "";
  const [body, signature] = token.split(".");
  if (!body || !signature) return null;
  const expected = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  if (!safeEqual(signature, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    if (payload.sub !== "admin-preauth" || !payload.exp || payload.exp < Math.floor(Date.now()/1000)) return null;
    return payload;
  } catch { return null; }
}

export function preAuthCookie(token, maxAge = 300) {
  return `__Host-hight_pre_v4=${encodeURIComponent(token)}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${maxAge}`;
}

export async function checkOtpRate(req, context) {
  const key = "otp/" + privacyHash(clientIP(req, context));
  const store = authStore();
  const now = Date.now();
  const rec = await store.get(key, { type: "json", consistency: "strong" }) || {
    count: 0, windowStart: now, lockedUntil: 0
  };
  if (rec.lockedUntil > now) {
    return { allowed: false, key, rec, retryAfter: Math.ceil((rec.lockedUntil - now)/1000) };
  }
  if (now - rec.windowStart > 10 * 60 * 1000) {
    rec.count = 0; rec.windowStart = now; rec.lockedUntil = 0;
  }
  return { allowed: true, key, rec };
}

export async function recordOtpFailure(rate) {
  const now = Date.now();
  rate.rec.count += 1;
  if (rate.rec.count >= 5) rate.rec.lockedUntil = now + 15 * 60 * 1000;
  await authStore().setJSON(rate.key, rate.rec);
}

export async function clearOtpFailures(key) {
  try { await authStore().delete(key); } catch {}
}

export async function getPatchIndex() {
  if (hotCacheFresh(patchIndexCache)) return patchIndexCache.value;
  const index = await metaStore().get("patch-index", { type: "json", consistency: "strong" });
  const value = Array.isArray(index) ? index : [];
  patchIndexCache = { at: Date.now(), value };
  return value;
}

export async function setPatchIndex(index) {
  await metaStore().setJSON("patch-index", index);
  patchIndexCache = { at: 0, value: null };
}

// Append one package without letting a concurrent finalize silently replace
// packages that were written by another request between get() and setJSON().
// Netlify Blobs does not provide an atomic array-push primitive, so we use a
// short read/merge/write/verify loop. Each retry starts from the latest strong
// read and preserves every record currently present in the index.
export async function appendPatchIndexItem(item, maxAttempts = 6) {
  const id = String(item?.id || "");
  if (!id) throw new Error("PATCH_ID_REQUIRED");

  let last = [];
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    const current = await getPatchIndex();
    if (current.some((x) => x?.id === id)) return current;

    // Preserve the newest copy of every existing id, then append this item.
    const byId = new Map();
    for (const record of current) {
      if (record && record.id) byId.set(record.id, record);
    }
    byId.set(id, item);
    const merged = Array.from(byId.values());

    await setPatchIndex(merged);

    const verify = await getPatchIndex();
    const verifyIds = new Set(verify.map((x) => x?.id).filter(Boolean));
    const preserved = current.every((x) => !x?.id || verifyIds.has(x.id));
    if (verifyIds.has(id) && preserved) return verify;

    last = verify;
    // Small jitter helps two simultaneous finalize calls stop overwriting each
    // other on the exact same schedule.
    await new Promise((resolve) => setTimeout(resolve, 25 + Math.floor(Math.random() * 50)));
  }

  throw new Error(`PATCH_INDEX_CONFLICT:${last.length}`);
}

export async function ensureSeed() {
  const store = metaStore();
  const initialized = await store.get("initialized", { type: "text", consistency: "strong" });
  if (initialized !== "1") await store.set("initialized", "1");
}

export function publicPatch(p) {
  return {
    // The iOS client expects the remote patch id to match the package UUID
    // embedded inside the .3105 envelope. Keep the admin/internal record id
    // separate so existing uploaded records do not need to be re-uploaded.
    id: p.packageUUID || p.id,
    name: p.name,
    description: p.description || "",
    version: p.version || "1.0",
    fileName: p.fileName,
    sizeBytes: p.sizeBytes,
    sha256: p.sha256,
    createdAt: p.createdAt,
    gameId: p.gameId || null,
    containerId: p.containerId || null,
    password: null,
  };
}

export function requireAppToken(req) {
  const expected = String(process.env.HIGHT_APP_TOKEN || "");
  const got = String(req.headers.get("x-app-token") || "");

  // TEMP DIAGNOSTIC MODE: do not reveal either token value.
  // These explicit errors make it possible to distinguish a missing
  // Netlify environment variable, a missing IPA header, and a mismatch.
  if (!expected) {
    return json({
      error: "TOKEN_ENV_MISSING",
      detail: "HIGHT_APP_TOKEN is not available to this Netlify function"
    }, 460, { "X-HTV-Diag": "token-env-missing", "X-HTV-Build": "TOKEN-DIAG-V2" });
  }

  if (!got) {
    return json({
      error: "TOKEN_HEADER_MISSING",
      detail: "X-App-Token header was not received"
    }, 461, { "X-HTV-Diag": "token-header-missing", "X-HTV-Build": "TOKEN-DIAG-V2" });
  }

  if (!safeEqual(got, expected)) {
    const expectedFp = sha256Hex(expected).slice(0, 12);
    const receivedFp = sha256Hex(got).slice(0, 12);
    const code = `TOKEN_MISMATCH_E${expected.length}_R${got.length}_EF${expectedFp}_RF${receivedFp}`;
    return json({
      error: code,
      diagnostic: "TOKEN-DIAG-V3",
      expectedLength: expected.length,
      receivedLength: got.length,
      expectedFingerprint: expectedFp,
      receivedFingerprint: receivedFp
    }, 401, {
      "X-HTV-Diag": "token-mismatch",
      "X-HTV-Build": "TOKEN-DIAG-V3",
      "X-HTV-Expected-Len": String(expected.length),
      "X-HTV-Received-Len": String(got.length),
      "X-HTV-Expected-FP": expectedFp,
      "X-HTV-Received-FP": receivedFp
    });
  }

  return null;
}

export async function checkDownloadRate(req, context) {
  const ip = privacyHash(clientIP(req, context));
  const key = `dlrate/${ip}`;
  const store = authStore();
  const now = Date.now();
  const rec = await store.get(key, { type: "json", consistency: "strong" }) || {
    count: 0, windowStart: now
  };
  if (now - rec.windowStart > 10 * 60 * 1000) {
    rec.count = 0; rec.windowStart = now;
  }
  if (rec.count >= 30) {
    return { allowed: false, retryAfter: Math.ceil((rec.windowStart + 10*60*1000 - now)/1000) };
  }
  rec.count += 1;
  await store.setJSON(key, rec);
  return { allowed: true };
}

export async function logDownload(req, context, patchId, result) {
  try {
    const key = `download/${Date.now()}-${crypto.randomUUID()}`;
    await logStore().setJSON(key, {
      at: new Date().toISOString(),
      patchId,
      result,
      clientHash: privacyHash(clientIP(req, context)),
      ua: (req.headers.get("user-agent") || "").slice(0, 160),
    });
  } catch {}
}

export function sanitizeText(value, max = 120) {
  return String(value || "").trim().slice(0, max);
}

export function validGameId(v) {
  return ["freefire-th", "freefire-max"].includes(v);
}

export function validContainerId(v) {
  return ["main-file", "main-file-max"].includes(v);
}

export function findEmbeddedPackageUUID(bytes) {
  const head = Buffer.from(bytes).subarray(0, 4096).toString("latin1");
  const m = head.match(/[A-F0-9]{8}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{12}/);
  return m ? m[0] : null;
}


// =========================
// REMOTE SECURITY CONTROL
// =========================
const SECURITY_STATE_KEY = "security-state-v1";

export async function getSecurityState() {
  if (hotCacheFresh(securityCache)) return securityCache.value;
  const raw = await metaStore().get(SECURITY_STATE_KEY, { type: "json", consistency: "strong" }) || {};
  const value = {
    emergencyLock: Boolean(raw.emergencyLock),
    metadataEnabled: raw.metadataEnabled !== false,
    downloadsEnabled: raw.downloadsEnabled !== false,
    sessionsEnabled: raw.sessionsEnabled !== false,
    updatedAt: raw.updatedAt || null,
    reason: sanitizeText(raw.reason || "", 120),
  };
  securityCache = { at: Date.now(), value };
  return value;
}

export async function saveSecurityState(input = {}) {
  const current = await getSecurityState();
  const next = {
    emergencyLock: typeof input.emergencyLock === "boolean" ? input.emergencyLock : current.emergencyLock,
    metadataEnabled: typeof input.metadataEnabled === "boolean" ? input.metadataEnabled : current.metadataEnabled,
    downloadsEnabled: typeof input.downloadsEnabled === "boolean" ? input.downloadsEnabled : current.downloadsEnabled,
    sessionsEnabled: typeof input.sessionsEnabled === "boolean" ? input.sessionsEnabled : current.sessionsEnabled,
    reason: sanitizeText(input.reason ?? current.reason, 120),
    updatedAt: new Date().toISOString(),
  };
  await metaStore().setJSON(SECURITY_STATE_KEY, next);
  securityCache = { at: 0, value: null };
  return next;
}

export async function checkPublicRate(req, context, bucket = "meta") {
  const ip = privacyHash(clientIP(req, context));
  const key = `pubrate/${bucket}/${ip}`;
  const store = authStore();
  const now = Date.now();
  const rec = await store.get(key, { type: "json", consistency: "strong" }) || { count: 0, windowStart: now };
  if (now - rec.windowStart > 10 * 60 * 1000) {
    rec.count = 0;
    rec.windowStart = now;
  }
  const limit = bucket === "download" ? 3000 : 900;
  if (rec.count >= limit) {
    return { allowed: false, retryAfter: Math.max(1, Math.ceil((rec.windowStart + 10*60*1000 - now) / 1000)) };
  }
  rec.count += 1;
  await store.setJSON(key, rec);
  return { allowed: true };
}

export async function requireContentAccess(req, context, scope = "metadata") {
  const denied = requireAppToken(req);
  if (denied) return denied;
  const state = await getSecurityState();
  if (state.emergencyLock) return json({ error: "NOT_FOUND" }, 404);
  if (scope === "metadata" && !state.metadataEnabled) return json({ error: "NOT_FOUND" }, 404);
  if (scope === "download" && !state.downloadsEnabled) return json({ error: "NOT_FOUND" }, 404);
  const rate = await checkPublicRate(req, context, scope === "download" ? "download" : "meta");
  if (!rate.allowed) return json({ error: "NOT_FOUND" }, 404, { "Retry-After": String(rate.retryAfter) });
  return null;
}

// =========================
// LICENSE / DEVICE BINDING
// =========================
const LICENSE_INDEX_KEY = "license-index";
const LICENSE_KEY_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function licenseConfigReady() {
  return Boolean(process.env.HIGHT_LICENSE_SECRET);
}

function licenseSecret() {
  const secret = process.env.HIGHT_LICENSE_SECRET;
  if (!secret) throw new Error("HIGHT_LICENSE_SECRET missing");
  return String(secret);
}

export function normalizeLicenseKey(value) {
  return String(value || "").trim().toUpperCase();
}

export function generateLicenseKey() {
  const chunks = [];
  for (let c = 0; c < 4; c++) {
    let part = "";
    for (let i = 0; i < 4; i++) {
      const n = crypto.randomInt(0, LICENSE_KEY_ALPHABET.length);
      part += LICENSE_KEY_ALPHABET[n];
    }
    chunks.push(part);
  }
  return `HT-${chunks.join("-")}`;
}

export function licenseKeyHash(value) {
  const normalized = normalizeLicenseKey(value);
  return crypto.createHmac("sha256", licenseSecret()).update(normalized).digest("hex");
}

function licenseCryptoKey() {
  return crypto.createHash("sha256").update(`hight-license-key:${licenseSecret()}`).digest();
}

export function encryptLicenseKey(value) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", licenseCryptoKey(), iv);
  const enc = Buffer.concat([cipher.update(normalizeLicenseKey(value), "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv, tag, enc].map(x => x.toString("base64url")).join(".");
}

export function decryptLicenseKey(value) {
  try {
    const [ivS, tagS, encS] = String(value || "").split(".");
    if (!ivS || !tagS || !encS) return null;
    const decipher = crypto.createDecipheriv("aes-256-gcm", licenseCryptoKey(), Buffer.from(ivS, "base64url"));
    decipher.setAuthTag(Buffer.from(tagS, "base64url"));
    return Buffer.concat([
      decipher.update(Buffer.from(encS, "base64url")),
      decipher.final(),
    ]).toString("utf8");
  } catch {
    return null;
  }
}

export function deviceHash(deviceId) {
  return crypto.createHmac("sha256", licenseSecret())
    .update(`device:${String(deviceId || "")}`)
    .digest("hex");
}

export function validDeviceId(value) {
  const s = String(value || "").trim();
  return s.length >= 12 && s.length <= 180;
}

export async function getLicenseIndex() {
  const index = await licenseStore().get(LICENSE_INDEX_KEY, { type: "json", consistency: "strong" });
  return Array.isArray(index) ? index : [];
}

export async function setLicenseIndex(index) {
  await licenseStore().setJSON(LICENSE_INDEX_KEY, Array.from(new Set(index)));
}

// Keep license-index safe when Admin and multiple reseller panels create keys
// at the same time. A plain read/push/write can lose another request's ID.
export async function appendLicenseIndexId(id, maxAttempts = 6) {
  const wanted = String(id || "");
  if (!wanted) throw new Error("LICENSE_ID_REQUIRED");

  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    const current = await getLicenseIndex();
    if (current.includes(wanted)) return current;

    const merged = Array.from(new Set([...current, wanted]));
    await setLicenseIndex(merged);

    const verify = await getLicenseIndex();
    if (verify.includes(wanted)) return verify;
  }
  throw new Error("LICENSE_INDEX_UPDATE_FAILED");
}

const resellerLicenseIndexKey = resellerId => `reseller-license-index/${String(resellerId || "")}`;

export async function getResellerLicenseIndex(resellerId) {
  if (!resellerId) return null;
  const rows = await licenseStore().get(resellerLicenseIndexKey(resellerId), { type: "json", consistency: "strong" });
  return Array.isArray(rows) ? rows : null;
}

export async function setResellerLicenseIndex(resellerId, ids) {
  if (!resellerId) return [];
  const clean = Array.from(new Set((Array.isArray(ids) ? ids : []).map(x => String(x || "")).filter(Boolean)));
  await licenseStore().setJSON(resellerLicenseIndexKey(resellerId), clean);
  return clean;
}

export async function appendResellerLicenseIndexId(resellerId, id, maxAttempts = 6) {
  const rid = String(resellerId || "");
  const wanted = String(id || "");
  if (!rid || !wanted) return [];

  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    const current = (await getResellerLicenseIndex(rid)) || [];
    if (current.includes(wanted)) return current;
    const merged = Array.from(new Set([...current, wanted]));
    await setResellerLicenseIndex(rid, merged);
    const verify = (await getResellerLicenseIndex(rid)) || [];
    if (verify.includes(wanted)) return verify;
  }
  throw new Error("RESELLER_LICENSE_INDEX_UPDATE_FAILED");
}

export async function removeResellerLicenseIndexId(resellerId, id) {
  const rid = String(resellerId || "");
  if (!rid) return;
  const current = await getResellerLicenseIndex(rid);
  if (!Array.isArray(current)) return;
  await setResellerLicenseIndex(rid, current.filter(x => String(x) !== String(id)));
}

// Existing deployments did not have a per-reseller index. Rebuild it once by
// scanning the actual license blobs, so reseller-created keys that disappeared
// from the old global index can still be recovered and shown again.
export async function rebuildResellerLicenseIndex(resellerId) {
  const rid = String(resellerId || "");
  if (!rid) return [];
  const store = licenseStore();
  const listed = await store.list({ prefix: "license/" });
  const blobs = Array.isArray(listed?.blobs) ? listed.blobs : [];
  const ids = [];

  // Read in small batches so a larger catalog does not create an excessive
  // number of simultaneous Blob requests.
  for (let i = 0; i < blobs.length; i += 25) {
    const batch = blobs.slice(i, i + 25);
    const rows = await Promise.all(batch.map(async b => {
      const id = String(b?.key || "").replace(/^license\//, "");
      if (!id) return null;
      const rec = await getLicense(id);
      return rec && String(rec.resellerId || "") === rid ? rec.id : null;
    }));
    ids.push(...rows.filter(Boolean));
  }

  await setResellerLicenseIndex(rid, ids);
  return ids;
}

export async function getOrRepairResellerLicenseIndex(resellerId) {
  const current = await getResellerLicenseIndex(resellerId);
  if (current !== null) return current;
  return await rebuildResellerLicenseIndex(resellerId);
}

export async function getLicense(id) {
  if (!id) return null;
  return await licenseStore().get(`license/${id}`, { type: "json", consistency: "strong" }) || null;
}

export async function saveLicense(record) {
  await licenseStore().setJSON(`license/${record.id}`, record);
}

export async function deleteLicenseRecord(record) {
  if (!record) return;
  try { await licenseStore().delete(`lookup/${record.keyHash}`); } catch {}
  try { await licenseStore().delete(`license/${record.id}`); } catch {}
  const index = await getLicenseIndex();
  await setLicenseIndex(index.filter(x => x !== record.id));
  if (record.resellerId) {
    try { await removeResellerLicenseIndexId(record.resellerId, record.id); } catch {}
  }
}

export async function findLicenseByKey(key) {
  const keyHash = licenseKeyHash(key);
  const id = await licenseStore().get(`lookup/${keyHash}`, { type: "text", consistency: "strong" });
  if (!id) return null;
  return await getLicense(id);
}

export async function createLicenseRecord({ durationDays = 30, durationMinutes = null, activationMode = "first_use", appId = DEFAULT_APP_ID, label = "", resellerId = null, resellerUsername = null } = {}) {
  const minutesRaw = Number(durationMinutes);
  const minutes = Number.isFinite(minutesRaw) && minutesRaw > 0 ? Math.max(1, Math.min(1440, Math.floor(minutesRaw))) : null;
  const days = minutes ? null : Math.max(1, Math.min(3650, Number(durationDays) || 30));
  const mode = activationMode === "immediate" ? "immediate" : "first_use";
  const key = generateLicenseKey();
  const hash = licenseKeyHash(key);
  const now = new Date();
  const durationMs = minutes ? minutes * 60000 : days * 86400000;
  const record = {
    id: crypto.randomUUID().toUpperCase(),
    appId: normalizeAppId(appId),
    label: sanitizeText(label || "", 80),
    keyHash: hash,
    keyEnc: encryptLicenseKey(key),
    keyHint: `${key.slice(0, 7)}••••-${key.slice(-4)}`,
    durationDays: days,
    durationMinutes: minutes,
    activationMode: mode,
    status: "active",
    createdAt: now.toISOString(),
    activatedAt: null,
    expiresAt: mode === "immediate" ? new Date(now.getTime() + durationMs).toISOString() : null,
    deviceHash: null,
    deviceBoundAt: null,
    lastVerifiedAt: null,
    lastAppVersion: null,
    ...(resellerId ? { resellerId: String(resellerId) } : {}),
    ...(resellerUsername ? { resellerUsername: sanitizeText(resellerUsername, 80) } : {}),
  };
  await saveLicense(record);
  await licenseStore().set(`lookup/${hash}`, record.id);
  await appendLicenseIndexId(record.id);
  if (record.resellerId) await appendResellerLicenseIndexId(record.resellerId, record.id);
  return { record, key };
}

export function licenseState(record, nowMs = Date.now()) {
  if (!record) return { ok: false, code: "INVALID_KEY" };
  if (record.status !== "active") return { ok: false, code: "DISABLED" };
  if (record.expiresAt && Date.parse(record.expiresAt) <= nowMs) {
    return { ok: false, code: "EXPIRED" };
  }
  return { ok: true, code: "ACTIVE" };
}

export function publicLicense(record, { includeKey = false } = {}) {
  const state = licenseState(record);
  const expiresMs = record.expiresAt ? Date.parse(record.expiresAt) : null;
  const remainingSeconds = expiresMs ? Math.max(0, Math.floor((expiresMs - Date.now()) / 1000)) : null;
  const out = {
    id: record.id,
    appId: recordAppId(record),
    label: sanitizeText(record.label || "", 80),
    keyHint: record.keyHint,
    durationDays: record.durationDays,
    durationMinutes: record.durationMinutes || null,
    activationMode: record.activationMode,
    status: state.ok ? "active" : state.code.toLowerCase(),
    createdAt: record.createdAt,
    activatedAt: record.activatedAt,
    expiresAt: record.expiresAt,
    remainingSeconds,
    deviceBound: Boolean(record.deviceHash),
    deviceHint: record.deviceHash ? `${record.deviceHash.slice(0, 8)}…${record.deviceHash.slice(-6)}` : null,
    deviceBoundAt: record.deviceBoundAt,
    lastVerifiedAt: record.lastVerifiedAt,
    lastAppVersion: record.lastAppVersion,
  };
  if (includeKey) out.key = decryptLicenseKey(record.keyEnc) || record.keyHint;
  return out;
}

function licenseTokenSign(body) {
  return crypto.createHmac("sha256", licenseSecret()).update(body).digest("base64url");
}

export function makeLicenseToken(record, devHash) {
  const now = Math.floor(Date.now() / 1000);
  const hardExp = record.expiresAt ? Math.floor(Date.parse(record.expiresAt) / 1000) : now + 6 * 60 * 60;
  const exp = Math.min(now + 6 * 60 * 60, hardExp);
  const payload = {
    sub: record.id,
    dev: devHash,
    app: recordAppId(record),
    iat: now,
    exp,
    typ: "license",
    jti: crypto.randomBytes(8).toString("hex"),
  };
  const body = b64url(JSON.stringify(payload));
  return `${body}.${licenseTokenSign(body)}`;
}

export function verifyLicenseToken(token) {
  const [body, signature] = String(token || "").split(".");
  if (!body || !signature) return null;
  const expected = licenseTokenSign(body);
  if (!safeEqual(signature, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    const now = Math.floor(Date.now() / 1000);
    if (payload.typ !== "license" || !payload.sub || !payload.dev || !payload.exp || payload.exp <= now) return null;
    payload.app = normalizeAppId(payload.app || DEFAULT_APP_ID);
    return payload;
  } catch {
    return null;
  }
}

export async function checkLicenseRate(req, context, bucket = "verify") {
  const ip = privacyHash(clientIP(req, context));
  const key = `licrate/${bucket}/${ip}`;
  const store = authStore();
  const now = Date.now();
  const rec = await store.get(key, { type: "json", consistency: "strong" }) || { count: 0, windowStart: now };
  if (now - rec.windowStart > 10 * 60 * 1000) {
    rec.count = 0;
    rec.windowStart = now;
  }
  const limit = bucket === "activate" ? 10 : 60;
  if (rec.count >= limit) {
    return { allowed: false, retryAfter: Math.max(1, Math.ceil((rec.windowStart + 10*60*1000 - now) / 1000)) };
  }
  rec.count += 1;
  await store.setJSON(key, rec);
  return { allowed: true };
}


// =========================
// V4 VERSION / CLIENT SESSION
// =========================
const VERSION_STATE_KEY = "version-state-v4";

function versionStateKey(appId = DEFAULT_APP_ID) {
  const id = normalizeAppId(appId);
  return id === DEFAULT_APP_ID ? VERSION_STATE_KEY : `${VERSION_STATE_KEY}/${id}`;
}

function normalizeVersionState(raw = {}) {
  return {
    currentVersion: sanitizeText(raw.currentVersion || "8.12", 24),
    minimumVersion: sanitizeText(raw.minimumVersion || "8.12", 24),
    updateURL: sanitizeText(raw.updateURL || "", 300),
    message: sanitizeText(raw.message || "", 180),
    releaseNotes: sanitizeText(raw.releaseNotes || "", 500),
    maintenance: Boolean(raw.maintenance),
    allowedBuilds: Array.isArray(raw.allowedBuilds) ? raw.allowedBuilds.map(x => sanitizeText(x, 80)).filter(Boolean).slice(0, 100) : [],
    updatedAt: raw.updatedAt || null,
  };
}

export async function getVersionState(appId = DEFAULT_APP_ID) {
  const id = normalizeAppId(appId);
  const cached = versionCache.get(id);
  if (hotCacheFresh(cached)) return cached.value;
  let raw = await metaStore().get(versionStateKey(id), { type: "json", consistency: "strong" }) || null;
  // A new app inherits the current HTVANTIX gate until its own gate is saved.
  // This keeps same-version customer builds usable without touching the old app.
  if (!raw && id !== DEFAULT_APP_ID) {
    raw = await metaStore().get(VERSION_STATE_KEY, { type: "json", consistency: "strong" }) || {};
  }
  const value = normalizeVersionState(raw || {});
  versionCache.set(id, { at: Date.now(), value });
  return value;
}

export async function saveVersionState(input = {}, appId = DEFAULT_APP_ID) {
  const id = normalizeAppId(appId);
  const cur = await getVersionState(id);
  const allowedBuilds = Array.isArray(input.allowedBuilds)
    ? input.allowedBuilds.map(x => sanitizeText(x, 80)).filter(Boolean).slice(0, 100)
    : cur.allowedBuilds;
  const next = {
    currentVersion: sanitizeText(input.currentVersion ?? cur.currentVersion, 24) || cur.currentVersion,
    minimumVersion: sanitizeText(input.minimumVersion ?? cur.minimumVersion, 24) || cur.minimumVersion,
    updateURL: sanitizeText(input.updateURL ?? cur.updateURL, 300),
    message: sanitizeText(input.message ?? cur.message, 180),
    releaseNotes: sanitizeText(input.releaseNotes ?? cur.releaseNotes, 500),
    maintenance: typeof input.maintenance === "boolean" ? input.maintenance : cur.maintenance,
    allowedBuilds,
    updatedAt: new Date().toISOString(),
  };
  await metaStore().setJSON(versionStateKey(id), next);
  versionCache.delete(id);
  return next;
}

function numericVersion(v) {
  return String(v || "0").split(/[.+-]/).slice(0,4).map(x => Number.parseInt(x,10) || 0);
}
export function compareVersions(a, b) {
  const aa = numericVersion(a), bb = numericVersion(b);
  const n = Math.max(aa.length, bb.length);
  for (let i=0;i<n;i++) {
    const x = aa[i] || 0, y = bb[i] || 0;
    if (x < y) return -1;
    if (x > y) return 1;
  }
  return 0;
}

export async function evaluateClientVersion(appVersion, buildId = "", appId = DEFAULT_APP_ID) {
  const state = await getVersionState(appId);
  if (state.maintenance) return { ok:false, code:"MAINTENANCE", state };
  if (compareVersions(appVersion, state.minimumVersion) < 0) return { ok:false, code:"UPDATE_REQUIRED", state };
  if (state.allowedBuilds.length && !state.allowedBuilds.includes(String(buildId || ""))) {
    return { ok:false, code:"BUILD_BLOCKED", state };
  }
  return { ok:true, code:"OK", state };
}

function clientSessionSecret() {
  // Prefer a dedicated client-session secret. For backwards-compatible
  // deployments, fall back to the existing server session secret.
  const secret = process.env.HIGHT_CLIENT_SESSION_SECRET || process.env.HIGHT_SESSION_SECRET;
  if (!secret) throw new Error("Client session secret missing");
  return String(secret);
}
export function clientSessionConfigReady() {
  const sessionSecret = process.env.HIGHT_CLIENT_SESSION_SECRET || process.env.HIGHT_SESSION_SECRET;
  return Boolean(sessionSecret && process.env.HIGHT_LICENSE_SECRET);
}
function clientSessionSign(body) {
  return crypto.createHmac("sha256", clientSessionSecret()).update(body).digest("base64url");
}
export function makeClientSession({ licenseId, devHash, appVersion, buildId, appId = DEFAULT_APP_ID }) {
  const now = Math.floor(Date.now()/1000);
  const payload = {
    typ:"client-v4", sub:String(licenseId), dev:String(devHash), app:normalizeAppId(appId), ver:String(appVersion || ""),
    bld:String(buildId || ""), iat:now, exp:now + 15*60, jti:crypto.randomBytes(10).toString("hex")
  };
  const body = b64url(JSON.stringify(payload));
  return { token:`${body}.${clientSessionSign(body)}`, payload };
}
export function verifyClientSessionToken(token) {
  const [body, sig] = String(token || "").split(".");
  if (!body || !sig) return null;
  if (!safeEqual(sig, clientSessionSign(body))) return null;
  try {
    const p = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    const now = Math.floor(Date.now()/1000);
    if (p.typ !== "client-v4" || !p.sub || !p.dev || !p.exp || p.exp <= now) return null;
    p.app = normalizeAppId(p.app || DEFAULT_APP_ID);
    return p;
  } catch { return null; }
}
export async function requireClientSession(req, context, scope="metadata") {
  const sec = await getSecurityState();
  if (sec.emergencyLock || sec.sessionsEnabled === false) return { ok:false, response:json({error:"SERVICE_UNAVAILABLE"},503) };
  if (scope === "metadata" && sec.metadataEnabled === false) return { ok:false, response:json({error:"SERVICE_UNAVAILABLE"},503) };
  if (scope === "download" && sec.downloadsEnabled === false) return { ok:false, response:json({error:"SERVICE_UNAVAILABLE"},503) };
  const auth = req.headers.get("authorization") || "";
  const m = auth.match(/^Bearer\s+(.+)$/i);
  const session = m ? verifyClientSessionToken(m[1]) : null;
  if (!session) return { ok:false, response:json({error:"SESSION_REQUIRED"},401) };
  const app = await requireEnabledApp(session.app || DEFAULT_APP_ID);
  if (!app) return { ok:false, response:json({error:"APP_DISABLED"},403) };
  const version = await evaluateClientVersion(session.ver, session.bld, app.appId);
  if (!version.ok) return { ok:false, response:json({error:version.code, client:version.state},426) };
  // /api/v4/* is edge-rate-limited in netlify.toml. Do not perform a
  // strong Blob read+write for every authenticated metadata/download request;
  // that shared-store write was able to become a bottleneck during login floods.
  return { ok:true, session, security:sec, version:version.state };
}

// ===== Reseller accounts / sessions =====
const RESELLER_INDEX_KEY = "reseller-index";

export async function getResellerIndex() {
  const rows = await authStore().get(RESELLER_INDEX_KEY, { type: "json", consistency: "strong" });
  return Array.isArray(rows) ? rows : [];
}

export async function setResellerIndex(rows) {
  await authStore().setJSON(RESELLER_INDEX_KEY, Array.from(new Set(rows)));
}

export async function getReseller(id) {
  if (!id) return null;
  return await authStore().get(`reseller/${id}`, { type: "json", consistency: "strong" }) || null;
}

export async function saveReseller(record) {
  await authStore().setJSON(`reseller/${record.id}`, record);
}

export async function deleteReseller(id) {
  if (!id) return;
  await authStore().delete(`reseller/${id}`);
}

export function hashResellerPassword(password) {
  const salt = crypto.randomBytes(16);
  const N = 16384, r = 8, p = 1;
  const derived = crypto.scryptSync(String(password || ""), salt, 64, { N, r, p, maxmem: 128 * 1024 * 1024 });
  return `scrypt$${N}$${r}$${p}$${salt.toString("hex")}$${derived.toString("hex")}`;
}

export function verifyResellerPassword(password, record) {
  // record is the reseller object; the password verifier must read its stored hash.
  // Accept a raw hash too for backward compatibility with any internal callers.
  const storedHash = typeof record === "string" ? record : record?.passwordHash;
  const parts = String(storedHash || "").split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  try {
    const N = Number(parts[1]), r = Number(parts[2]), p = Number(parts[3]);
    const salt = Buffer.from(parts[4], "hex");
    const expected = Buffer.from(parts[5], "hex");
    const actual = crypto.scryptSync(String(password || ""), salt, expected.length, { N, r, p, maxmem: 128 * 1024 * 1024 });
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch { return false; }
}

export async function findResellerByUsername(username) {
  const wanted = sanitizeText(username, 80).toLowerCase();
  if (!wanted) return null;
  const ids = await getResellerIndex();
  for (const id of ids) {
    const r = await getReseller(id);
    if (r && String(r.username || "").toLowerCase() === wanted) return r;
  }
  return null;
}

export function publicReseller(r) {
  if (!r) return null;
  const now = Date.now();
  const exp = r.planExpiresAt ? Date.parse(r.planExpiresAt) : 0;
  const planActive = r.status === "active" && (!exp || exp > now);
  return {
    id: r.id,
    username: r.username,
    displayName: r.displayName || r.username,
    status: r.status || "active",
    planLimit: r.planLimit == null ? null : Number(r.planLimit),
    usedCount: Number(r.usedCount || 0),
    planStartedAt: r.planStartedAt || null,
    planExpiresAt: r.planExpiresAt || null,
    planActive,
    allowedApps: Array.isArray(r.allowedApps) && r.allowedApps.length ? r.allowedApps.map(x => normalizeAppId(x)) : [DEFAULT_APP_ID],
    createdAt: r.createdAt,
    updatedAt: r.updatedAt || r.createdAt,
  };
}

function resellerCsrf(session) {
  const secret = process.env.HIGHT_SESSION_SECRET;
  const sid = String(session?.sid || "");
  if (!secret || !sid) return "";
  return crypto.createHmac("sha256", String(secret)).update(`reseller-csrf:${sid}`).digest("base64url");
}

export function makeResellerSession(reseller) {
  const secret = process.env.HIGHT_SESSION_SECRET;
  if (!secret) throw new Error("HIGHT_SESSION_SECRET missing");
  const now = Math.floor(Date.now()/1000);
  const payload = {
    sub: "reseller",
    rid: reseller.id,
    iat: now,
    exp: now + 8 * 60 * 60,
    sid: crypto.randomBytes(12).toString("hex"),
    resellerSessionVersion: 1,
  };
  payload.csrf = resellerCsrf(payload);
  const body = b64url(JSON.stringify(payload));
  const sig = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  return { token: `${body}.${sig}`, payload };
}

export function verifyResellerSession(req) {
  const secret = process.env.HIGHT_SESSION_SECRET;
  if (!secret) return null;
  const token = parseCookies(req)["__Host-hight_reseller_v1"] || "";
  const [body, signature] = token.split(".");
  if (!body || !signature) return null;
  const expected = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  if (!safeEqual(signature, expected)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    if (p.sub !== "reseller" || p.resellerSessionVersion !== 1 || !p.rid || !p.exp || p.exp < Math.floor(Date.now()/1000)) return null;
    return p;
  } catch { return null; }
}

export async function requireReseller(req, requireCsrf = false) {
  if (!sameOrigin(req)) return { ok:false, response:json({ error:"CROSS_ORIGIN_BLOCKED" },403) };
  const session = verifyResellerSession(req);
  if (!session) return { ok:false, response:json({ error:"UNAUTHORIZED" },401) };
  const reseller = await getReseller(session.rid);
  if (!reseller || reseller.status !== "active") return { ok:false, response:json({ error:"RESELLER_DISABLED" },403) };
  const exp = reseller.planExpiresAt ? Date.parse(reseller.planExpiresAt) : 0;
  if (exp && exp <= Date.now()) return { ok:false, response:json({ error:"PLAN_EXPIRED" },403) };
  if (requireCsrf) {
    const got = req.headers.get("x-hight-csrf") || "";
    const expected = resellerCsrf(session);
    if (!got || !expected || !safeEqual(got, expected)) return { ok:false, response:json({ error:"CSRF" },403) };
  }
  return { ok:true, session, reseller };
}

export function resellerSessionCookie(token, maxAge = 8 * 60 * 60) {
  return `__Host-hight_reseller_v1=${encodeURIComponent(token)}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${maxAge}`;
}
export function clearResellerSessionCookie() {
  return "__Host-hight_reseller_v1=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0";
}
export function resellerCsrfForSession(session) { return resellerCsrf(session); }
