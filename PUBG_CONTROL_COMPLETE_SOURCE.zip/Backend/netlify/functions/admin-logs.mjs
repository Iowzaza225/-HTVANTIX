import { json, requireAdmin, logStore, auditStore } from "./_lib.mjs";
async function readRecent(store, blobs, limit = 80) {
  const selected=[...(blobs||[])].sort((a,b)=>String(b.key||"").localeCompare(String(a.key||""))).slice(0,limit);const out=[];const batchSize=10;
  for(let i=0;i<selected.length;i+=batchSize){const batch=selected.slice(i,i+batchSize);const vals=await Promise.all(batch.map(async b=>{try{return await store.get(b.key,{type:"json",consistency:"strong"});}catch{return null;}}));out.push(...vals.filter(Boolean));}
  return out;
}
export default async (req) => {
  const auth=requireAdmin(req,false);if(!auth.ok)return auth.response;if(req.method!=="GET")return json({error:"NOT_FOUND"},404);
  const [downloadList,auditList]=await Promise.all([logStore().list({prefix:"download/"}),auditStore().list({prefix:"audit/"})]);
  const [downloadRows,auditRows]=await Promise.all([readRecent(logStore(),downloadList.blobs,80),readRecent(auditStore(),auditList.blobs,120)]);
  const logs=downloadRows.sort((a,b)=>String(b.at||"").localeCompare(String(a.at||""))).slice(0,80);
  const catalogLogs=auditRows.filter(x=>x?.action==="packages_catalog_read_v4").sort((a,b)=>String(b.at||"").localeCompare(String(a.at||""))).slice(0,80).map(x=>({
    at:x.at||null,action:"packages_catalog_read_v4",appId:String(x.appId||"htvantix"),indexCount:Number(x.indexCount||0),globalIndexCount:Number(x.globalIndexCount||x.indexCount||0),enabledCount:Number(x.enabledCount||0),catalogRevision:String(x.catalogRevision||""),
    packages:Array.isArray(x.packages)?x.packages.slice(0,200).map(p=>({id:String(p?.id||""),category:String(p?.category||"other"),game:p?.game==null?null:String(p.game)})):[]
  }));
  return json({logs,catalogLogs},200,{"Cache-Control":"no-store, max-age=0","Pragma":"no-cache"});
};
