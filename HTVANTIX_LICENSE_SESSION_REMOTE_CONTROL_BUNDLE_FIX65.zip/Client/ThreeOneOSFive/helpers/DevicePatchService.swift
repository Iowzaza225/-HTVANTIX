import Foundation

/// Safe patch runtime for 3105 packages.
///
/// Patch payloads are materialized only inside 3105's own Application Support
/// container. A package bundle identifier is treated as a namespace, never as
/// permission to resolve or write another application's private data container.
enum DevicePatchService {
    static func apply(project: PatchProject) throws -> PatchTransactionReceipt {
        let roots = try managedRoots(for: project.allBundleIdentifiers)
        return try PatchTransaction.apply(
            project: project,
            backupRoot: try PatchProjectLibrary.backupRootURL(),
            containerResolver: { bundleID in
                guard let root = roots[bundleID] else {
                    throw PatchPackageError.targetAppUnavailable(bundleID)
                }
                return root
            }
        )
    }

    static func restore(receipt: PatchTransactionReceipt) throws {
        let bundleIDs = try PatchTransaction.requiredBundleIdentifiers(for: receipt)
        let roots = try managedRoots(for: bundleIDs)
        try PatchTransaction.restore(
            receipt: receipt,
            containerResolver: { bundleID in
                guard let root = roots[bundleID] else {
                    throw PatchPackageError.targetAppUnavailable(bundleID)
                }
                return root
            }
        )
    }

    static func latestReceipt(projectID: UUID) -> PatchTransactionReceipt? {
        guard let backupRoot = try? PatchProjectLibrary.backupRootURL() else { return nil }
        return PatchTransaction.latestReceipt(projectID: projectID, backupRoot: backupRoot)
    }

    /// Location where enabled patch files are materialized.
    /// This always lives in 3105's own sandbox.
    static func managedPatchRootURL(fileManager: FileManager = .default) throws -> URL {
        let base = try fileManager.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let root = base.appendingPathComponent("Active3105Patches", isDirectory: true)
        try fileManager.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }

    private static func managedRoots(
        for bundleIDs: [String],
        fileManager: FileManager = .default
    ) throws -> [String: URL] {
        let root = try managedPatchRootURL(fileManager: fileManager)
        var result: [String: URL] = [:]
        for rawBundleID in bundleIDs {
            let bundleID = try PatchPathValidator.canonicalBundleIdentifier(rawBundleID)
            guard bundleID == rawBundleID else { throw PatchPackageError.invalidBundleIdentifier }

            // Bundle IDs are already validated to exclude path separators. They
            // are used only to separate package namespaces under our own root.
            let namespace = root.appendingPathComponent(bundleID, isDirectory: true)
            try fileManager.createDirectory(at: namespace, withIntermediateDirectories: true)
            result[bundleID] = namespace.standardizedFileURL
        }
        return result
    }
}
