import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @AppStorage("htvantix.screenPrivacyEnabled") private var screenPrivacyEnabled = false
    @AppStorage("htvantix.license.key") private var storedLicenseKey = ""
    @AppStorage("htvantix.license.expiresAt") private var storedLicenseExpiresAt = ""
    @AppStorage("htvantix.license.status") private var storedLicenseStatus = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(Color.cyan.opacity(0.14))
                                .frame(width: 58, height: 58)
                            Image(systemName: "shield.lefthalf.filled")
                                .font(.system(size: 26, weight: .semibold))
                                .foregroundStyle(AppTheme.accent)
                        }

                        VStack(alignment: .leading, spacing: 3) {
                            Text("HTVANTIX")
                                .font(.headline.weight(.bold))
                            Text("Version \(appVersion)")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section("License") {
                    LabeledContent("License Key") {
                        Text(maskedLicenseKey)
                            .font(.system(.body, design: .monospaced))
                            .foregroundStyle(storedLicenseKey.isEmpty ? .secondary : .primary)
                    }

                    LabeledContent("Status") {
                        HStack(spacing: 6) {
                            Circle()
                                .fill(licenseStatusColor)
                                .frame(width: 8, height: 8)
                            Text(licenseStatusText)
                                .foregroundStyle(licenseStatusColor)
                        }
                    }

                    LabeledContent("Expires") {
                        Text(licenseExpiryText)
                            .foregroundStyle(storedLicenseExpiresAt.isEmpty ? .secondary : .primary)
                    }
                } footer: {
                    Text("ข้อมูลคีย์และวันหมดอายุจะแสดงจาก License Session ของ HTVANTIX เมื่อเปิดใช้งานคีย์สำเร็จ")
                }

                Section("Privacy") {
                    Toggle(isOn: $screenPrivacyEnabled) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Screen Protection")
                            Text(screenPrivacyEnabled ? "เปิดการป้องกันหน้าจอ" : "ปิดการป้องกันหน้าจอ")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .tint(AppTheme.accent)
                } footer: {
                    Text("เมื่อเปิด ระบบจะปิดบังหน้าจอระหว่างการบันทึก/แชร์หน้าจอที่ iOS ตรวจพบ และตอนแอปไม่อยู่ด้านหน้า")
                }

                Section(language.text("settings.language")) {
                    Picker(language.text("settings.language"), selection: $languageCode) {
                        ForEach(AppLanguage.allCases) { option in
                            Text(option.displayName).tag(option.rawValue)
                        }
                    }
                    .pickerStyle(.segmented)
                    .labelsHidden()
                }

                Section(language.text("common.device")) {
                    LabeledContent(language.text("dashboard.hardware_model"), value: AppInfo.displayMachineName)
                    LabeledContent(language.text("settings.ios_version"), value: "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                }

                Section {
                    HStack {
                        Text(language.text("settings.current_version"))
                        Spacer()
                        Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                    LabeledContent("iOS 17", value: ExploitSupportPolicy.verifiedIOS17Range)
                    LabeledContent("iOS 18", value: ExploitSupportPolicy.verifiedIOS18Range)
                    LabeledContent("iOS 26", value: ExploitSupportPolicy.verifiedIOS26Range)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("iOS 27.0")
                        ForEach(ExploitSupportPolicy.verifiedIOS27Builds, id: \.build) { version in
                            Text(versionLabel(version))
                                .font(.caption.monospaced())
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 2)
                } header: {
                    Text(language.text("settings.verified_versions"))
                }
            }
            .tint(AppTheme.accent)
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(language.text("common.done")) { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private var maskedLicenseKey: String {
        let key = storedLicenseKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return "Not activated" }
        if key.count <= 10 { return key }
        return "\(key.prefix(5))••••\(key.suffix(5))"
    }

    private var licenseStatusText: String {
        let value = storedLicenseStatus.lowercased()
        if value == "active" { return "Active" }
        if value == "expired" { return "Expired" }
        if value == "disabled" { return "Disabled" }
        return storedLicenseKey.isEmpty ? "Not activated" : "Unknown"
    }

    private var licenseStatusColor: Color {
        switch storedLicenseStatus.lowercased() {
        case "active": return .green
        case "expired", "disabled": return .red
        default: return .secondary
        }
    }

    private var licenseExpiryText: String {
        let raw = storedLicenseExpiresAt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return "—" }
        let formatter = ISO8601DateFormatter()
        guard let date = formatter.date(from: raw) else { return raw }
        return date.formatted(date: .abbreviated, time: .shortened)
    }

    private func versionLabel(_ version: (beta: Int, publicBeta: Int?, build: String)) -> String {
        if let publicBeta = version.publicBeta {
            return language.text(
                "settings.developer_public_beta_build",
                Int64(version.beta),
                Int64(publicBeta),
                version.build
            )
        }
        return language.text(
            "settings.developer_beta_build",
            Int64(version.beta),
            version.build
        )
    }
}
