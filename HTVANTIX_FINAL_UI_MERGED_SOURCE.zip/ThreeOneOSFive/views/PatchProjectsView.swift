import SwiftUI
import UIKit
import UniformTypeIdentifiers

private enum HTVANTIXPatchAPI {
    static let baseURL = URL(string: "https://hightapi.netlify.app")!
    static let collectionPath = "cv/sp"

    static func fetch() async throws -> [HTRemotePatch] {
        var request = URLRequest(url: baseURL.appendingPathComponent(collectionPath))
        request.httpMethod = "GET"
        request.timeoutInterval = 15
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let token = appToken {
            request.setValue(token, forHTTPHeaderField: "X-App-Token")
        }
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response)
        let decoder = JSONDecoder()
        if let direct = try? decoder.decode([HTRemotePatch].self, from: data) { return direct }
        if let envelope = try? decoder.decode(HTPatchEnvelope.self, from: data) { return envelope.patches ?? [] }
        throw HTPatchAPIError.invalidResponse
    }

    static func download(_ patch: HTRemotePatch) async throws -> URL {
        let url = baseURL
            .appendingPathComponent(collectionPath)
            .appendingPathComponent(patch.id)
            .appendingPathComponent("download")
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 60
        if let token = appToken {
            request.setValue(token, forHTTPHeaderField: "X-App-Token")
        }
        let (temporaryURL, response) = try await URLSession.shared.download(for: request)
        try validate(response)
        let fileName = (patch.fileName?.isEmpty == false ? patch.fileName! : "\(patch.id).3105")
        let destination = FileManager.default.temporaryDirectory
            .appendingPathComponent("HTVANTIX-Remote", isDirectory: true)
            .appendingPathComponent(fileName)
        try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
        try FileManager.default.moveItem(at: temporaryURL, to: destination)
        return destination
    }

    private static var appToken: String? {
        let candidates: [String?] = [
            Bundle.main.object(forInfoDictionaryKey: "HTVANTIX_APP_TOKEN") as? String,
            Bundle.main.object(forInfoDictionaryKey: "HIGHT_APP_TOKEN") as? String,
            UserDefaults.standard.string(forKey: "HTVANTIX_APP_TOKEN")
        ]

        return candidates
            .compactMap { $0?.trimmingCharacters(in: .whitespacesAndNewlines) }
            .first(where: { !$0.isEmpty })
    }

    private static func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { return }
        guard (200..<300).contains(http.statusCode) else { throw HTPatchAPIError.http(http.statusCode) }
    }
}

private enum HTPatchAPIError: LocalizedError {
    case invalidResponse
    case http(Int)

    var errorDescription: String? { userFacingMessage }

    var userFacingMessage: String {
        switch self {
        case .invalidResponse:
            return "รูปแบบข้อมูลไม่ถูกต้อง"
        case .http(let code):
            if code == 401 || code == 403 {
                return "การเชื่อมต่อยังไม่ได้รับอนุญาต"
            }
            if code == 404 {
                return "ไม่พบรายการที่ร้องขอ"
            }
            return "เชื่อมต่อไม่สำเร็จ (\(code))"
        }
    }
}

private struct HTPatchEnvelope: Decodable { let patches: [HTRemotePatch]? }

private struct HTRemotePatch: Identifiable, Decodable, Hashable {
    let id: String
    let gameId: String?
    let title: String
    let detail: String?
    let version: String?
    let fileName: String?
    let sizeBytes: Int64?
    let active: Bool

    enum CodingKeys: String, CodingKey {
        case id, gameId, game_id, title, name, detail, description, version, fileName, file_name, sizeBytes, size_bytes, active, enabled
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? c.decode(String.self, forKey: .id)) ?? UUID().uuidString
        gameId = (try? c.decodeIfPresent(String.self, forKey: .gameId)) ?? (try? c.decodeIfPresent(String.self, forKey: .game_id)) ?? nil
        title = (try? c.decode(String.self, forKey: .title)) ?? (try? c.decode(String.self, forKey: .name)) ?? "Free Fire Patch"
        detail = (try? c.decodeIfPresent(String.self, forKey: .detail)) ?? (try? c.decodeIfPresent(String.self, forKey: .description)) ?? nil
        version = try? c.decodeIfPresent(String.self, forKey: .version)
        fileName = (try? c.decodeIfPresent(String.self, forKey: .fileName)) ?? (try? c.decodeIfPresent(String.self, forKey: .file_name)) ?? nil
        sizeBytes = (try? c.decodeIfPresent(Int64.self, forKey: .sizeBytes)) ?? (try? c.decodeIfPresent(Int64.self, forKey: .size_bytes)) ?? nil
        active = (try? c.decode(Bool.self, forKey: .active)) ?? (try? c.decode(Bool.self, forKey: .enabled)) ?? true
    }
}

struct PatchProjectsView: View {
    @StateObject private var store = PatchProjectStore()
    @AppStorage("htvantix.selectedGame") private var selectedGame = "freefire"
    @State private var remotePatches: [HTRemotePatch] = []
    @State private var isLoadingRemote = false
    @State private var alertText: String?

    private var filteredRemote: [HTRemotePatch] {
        let selectedID = selectedGame.lowercased().contains("max")
            ? "freefire-max"
            : "freefire-th"

        return remotePatches.filter { patch in
            guard let game = patch.gameId?.lowercased(), !game.isEmpty else { return true }
            return game == selectedID
        }
    }

    var body: some View {
        ZStack {
            PremiumBackground()

                ScrollView {
                    LazyVStack(spacing: 12) {
                        gameHeader
                            .padding(.bottom, 4)

                        if isLoadingRemote {
                            HStack(spacing: 10) {
                                ProgressView().tint(PremiumTheme.accent)
                                Text("กำลังโหลด...")
                                    .foregroundStyle(PremiumTheme.textSecondary)
                            }
                            .padding(.top, 40)
                        } else if filteredRemote.isEmpty {
                            VStack(spacing: 12) {
                                Image(systemName: "folder")
                                    .font(.system(size: 34, weight: .semibold))
                                    .foregroundStyle(Color.white.opacity(0.78))
                                Text("ยังไม่มีฟังก์ชัน")
                                    .font(.headline)
                                    .foregroundStyle(.white)
                            }
                            .padding(.top, 48)
                        } else {
                            ForEach(filteredRemote) { patch in
                                HTVANTIXRemoteToggleRow(
                                    patch: patch,
                                    store: store,
                                    alertText: $alertText
                                )
                            }
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 14)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle(selectedGame.lowercased().contains("max") ? "Free Fire Max" : "Free Fire")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(PremiumTheme.background.opacity(0.95), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .refreshable { await loadRemote() }
            .task { await loadRemote() }
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { _ in
                PatchUnlockView(store: store)
            }
            .alert("HTVANTIX", isPresented: alertPresented) {
                Button("ตกลง", role: .cancel) { alertText = nil }
            } message: {
                Text(alertText ?? "")
            }
        .preferredColorScheme(.dark)
    }

    private var selectedGameTitle: String {
        selectedGame.lowercased().contains("max") ? "Free Fire Max" : "Free Fire"
    }

    private var selectedGameImage: String {
        selectedGame.lowercased().contains("max") ? "FreeFireMaxIcon" : "FreeFireIcon"
    }

    private var gameHeader: some View {
        HStack(spacing: 14) {
            Image(selectedGameImage)
                .resizable()
                .scaledToFill()
                .frame(width: 58, height: 58)
                .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 15, style: .continuous)
                        .stroke(Color.white.opacity(0.08), lineWidth: 1)
                }
                .shadow(color: PremiumTheme.accent.opacity(0.10), radius: 8, y: 3)

            VStack(alignment: .leading, spacing: 5) {
                Text(selectedGameTitle)
                    .font(.title3.weight(.bold))
                    .foregroundStyle(.white)

                Text("เลือกฟังก์ชันที่ต้องการ")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(PremiumTheme.textSecondary)
            }

            Spacer()

            HStack(spacing: 6) {
                Circle()
                    .fill(Color.green)
                    .frame(width: 7, height: 7)

                Text("พร้อม")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(Color.green)
            }
        }
        .padding(16)
        .background(
            LinearGradient(
                colors: [
                    PremiumTheme.surface2.opacity(0.92),
                    PremiumTheme.surface.opacity(0.98)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 20, style: .continuous)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.09), lineWidth: 1)
        }
    }

    private var alertPresented: Binding<Bool> {
        Binding(
            get: { alertText != nil },
            set: { value in if !value { alertText = nil } }
        )
    }

    @MainActor
    private func loadRemote() async {
        isLoadingRemote = true
        defer { isLoadingRemote = false }

        do {
            remotePatches = try await HTVANTIXPatchAPI.fetch()
        } catch let apiError as HTPatchAPIError {
            remotePatches = []
            alertText = apiError.userFacingMessage
        } catch {
            remotePatches = []
            alertText = "ไม่สามารถโหลดรายการได้ กรุณาลองใหม่"
        }
    }
}

private struct HTVANTIXRemoteToggleRow: View {
    let patch: HTRemotePatch
    @ObservedObject var store: PatchProjectStore
    @Binding var alertText: String?

    @State private var isOn = false
    @State private var isWorking = false

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.white.opacity(0.055))
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 21, weight: .bold))
                    .foregroundStyle(PremiumTheme.accent)
            }
            .frame(width: 48, height: 48)

            VStack(alignment: .leading, spacing: 4) {
                Text(patch.title)
                    .font(.headline)
                    .foregroundStyle(.white)

                Text(isOn ? "เปิดใช้งาน" : "ปิดอยู่")
                    .font(.caption)
                    .foregroundStyle(isOn ? Color.green : PremiumTheme.textSecondary)
            }

            Spacer()

            if isWorking {
                ProgressView()
                    .tint(PremiumTheme.accent)
            } else {
                Toggle("", isOn: Binding(
                    get: { isOn },
                    set: { newValue in
                        if newValue {
                            enable()
                        } else {
                            disable()
                        }
                    }
                ))
                .labelsHidden()
                .tint(PremiumTheme.accent)
            }
        }
        .padding(16)
        .background(PremiumTheme.surface.opacity(0.95), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(
                    isOn ? PremiumTheme.accent.opacity(0.42) : Color.white.opacity(0.08),
                    lineWidth: 1
                )
        }
        .onAppear { refreshState() }
    }

    private var mappingKey: String {
        "htvantix.remote.project.\(patch.id)"
    }

    private func mappedItem() -> PatchLibraryItem? {
        guard let raw = UserDefaults.standard.string(forKey: mappingKey),
              let id = UUID(uuidString: raw) else {
            return nil
        }
        return store.items.first(where: { $0.id == id })
    }

    private func saveMapping(_ item: PatchLibraryItem) {
        UserDefaults.standard.set(item.id.uuidString, forKey: mappingKey)
    }

    private func refreshState() {
        store.reload()
        guard let item = mappedItem() else {
            isOn = false
            return
        }
        isOn = DevicePatchService.latestReceipt(projectID: item.id) != nil
    }

    private func enable() {
        guard !isWorking else { return }
        isWorking = true

        Task {
            do {
                var item = await MainActor.run { mappedItem() }

                if item == nil {
                    let existingIDs = await MainActor.run {
                        Set(store.items.map(\.id))
                    }

                    let url = try await HTVANTIXPatchAPI.download(patch)

                    await MainActor.run {
                        store.importPackage(at: url)
                    }

                    for _ in 0..<24 {
                        try? await Task.sleep(nanoseconds: 250_000_000)

                        let found = await MainActor.run { () -> PatchLibraryItem? in
                            store.reload()
                            return store.items.first(where: { !existingIDs.contains($0.id) })
                        }

                        if let found {
                            item = found
                            await MainActor.run {
                                saveMapping(found)
                            }
                            break
                        }
                    }
                }

                guard let readyItem = item,
                      let baseProject = readyItem.project,
                      !readyItem.isLocked else {
                    await MainActor.run {
                        isWorking = false
                        isOn = false
                        alertText = "ไม่สามารถเปิดใช้งานรายการนี้ได้"
                    }
                    return
                }

                let projectToApply: PatchProject
                if readyItem.summary.schemaVersion >= 2 {
                    projectToApply = try PatchProjectLibrary.synchronizeWorkspace(item: readyItem)
                } else {
                    projectToApply = baseProject
                }

                _ = try DevicePatchService.apply(project: projectToApply)

                await MainActor.run {
                    store.reload()
                    saveMapping(readyItem)
                    isWorking = false
                    isOn = true
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    refreshState()
                    alertText = "เปิดใช้งานไม่สำเร็จ"
                }
            }
        }
    }

    private func disable() {
        guard !isWorking else { return }

        guard let item = mappedItem(),
              let receipt = DevicePatchService.latestReceipt(projectID: item.id) else {
            isOn = false
            return
        }

        isWorking = true

        Task {
            do {
                do {
                    try DevicePatchService.restore(receipt: receipt)
                } catch {
                    // If the target changed after Apply, restore the verified
                    // backup anyway. Container, path and backup digest checks
                    // are still enforced by PatchTransaction.
                    try DevicePatchService.restore(receipt: receipt, force: true)
                }

                await MainActor.run {
                    store.reload()
                    isWorking = false
                    isOn = false
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    refreshState()
                    alertText = "ปิดใช้งานไม่สำเร็จ"
                }
            }
        }
    }
}

private struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in
                            store.clearUnlockError()
                        }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text(language.text("patch.password_once_message"))
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showEditor = false
    @State private var editingRule: PatchRule?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?
    @State private var shareRequest: PatchShareRequest?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    var body: some View {
        List {
            if let item, let project = item.project {
                if isWorkspaceProject {
                    Section {
                        ForEach(project.allBundleIdentifiers, id: \.self) { bundleID in
                            Label {
                                Text(bundleID)
                                    .font(.subheadline.monospaced())
                            } icon: {
                                Image(systemName: "app.dashed")
                                    .foregroundStyle(AppTheme.accent)
                            }
                        }
                        LabeledContent(language.text("patch.files")) {
                            Text("\(project.rules.count)")
                        }
                        LabeledContent(language.text("patch.folders")) {
                            Text("\(project.directories.count)")
                        }
                        if let workspaceURL = item.workspaceURL {
                            NavigationLink {
                                FileBrowserView(
                                    containerPath: workspaceURL.path,
                                    title: project.name,
                                    bundleID: nil
                                )
                            } label: {
                                Label(
                                    language.text("patch.open_workspace"),
                                    systemImage: "folder"
                                )
                            }
                        }
                    } header: {
                        Text(language.text("patch.workspace"))
                    } footer: {
                        Text(language.text("patch.workspace_detail_footer"))
                    }
                } else {
                    Section {
                        ForEach(project.rules) { rule in
                            Button {
                                editingRule = rule
                            } label: {
                                HStack(spacing: 10) {
                                    ruleSummary(rule)
                                    Spacer(minLength: 8)
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityHint(language.text("patch.edit_rule_hint"))
                        }
                    } header: {
                        Text(language.text("patch.rules"))
                    } footer: {
                        Text(language.text("patch.legacy_footer"))
                    }
                }

                Section(language.text("patch.password")) {
                    HStack(spacing: 12) {
                        Image(systemName: item.summary.isPasswordProtected ? "lock.fill" : "lock.open")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)
                        Text(language.text(item.summary.isPasswordProtected
                            ? "patch.password_locked"
                            : "patch.no_password"))
                            .font(.subheadline)
                    }
                }

                Section {
                    Button {
                        showApplyConfirmation = true
                    } label: {
                        actionLabel("patch.apply", systemImage: "checkmark.shield.fill")
                    }
                    .disabled(isWorking)

                    if receipt != nil {
                        Button(role: .destructive) {
                            showRestoreConfirmation = true
                        } label: {
                            actionLabel("patch.restore", systemImage: "arrow.uturn.backward.circle")
                        }
                        .disabled(isWorking)
                    }

                    Button(action: prepareExport) {
                        actionLabel("patch.export", systemImage: "square.and.arrow.up")
                    }
                    .disabled(isWorking)
                } footer: {
                    Text(language.text("patch.apply_footer"))
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(item?.project?.name ?? language.text("patch.title"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                } else if !isWorkspaceProject {
                    Button(language.text("patch.edit")) { showEditor = true }
                        .disabled(item?.project == nil)
                }
            }
        }
        .sheet(isPresented: $showEditor) {
            if let item, let project = item.project {
                PatchProjectEditorView(
                    existingProject: project,
                    passwordIsProtected: item.summary.isPasswordProtected
                ) { updatedProject, _ in
                    store.update(project: updatedProject)
                }
            }
        }
        .sheet(item: $editingRule) { rule in
            PatchRuleEditorView(rule: rule) { updatedRule in
                updateRule(updatedRule)
            }
        }
        .confirmationDialog(
            language.text("patch.apply_confirm_title"),
            isPresented: $showApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.apply")) { apply() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.apply_confirm_message"))
        }
        .confirmationDialog(
            language.text("patch.restore_confirm_title"),
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.restore"), role: .destructive) { restore() }
            Button(language.text("common.cancel"), role: .cancel) {}
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .sheet(item: $shareRequest) { request in
            PatchActivityView(items: [request.url])
                .ignoresSafeArea()
        }
    }

    private func actionLabel(_ key: String, systemImage: String) -> some View {
        Label(language.text(key), systemImage: systemImage)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func updateRule(_ updatedRule: PatchRule) {
        guard var project = item?.project,
              let index = project.rules.firstIndex(where: { $0.id == updatedRule.id }) else {
            return
        }
        project.rules[index] = updatedRule
        project.updatedAt = Date()
        do {
            try PatchPackageCodec.validate(project)
            store.update(project: project)
        } catch let error as PatchPackageError {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: error.localizationKey,
                messageArgument: error.localizationArgument
            )
        } catch {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func prepareExport() {
        guard let item else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                if item.summary.schemaVersion >= 2 {
                    _ = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                }
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    shareRequest = PatchShareRequest(url: item.packageURL)
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.invalid_project"
                    )
                }
            }
        }
    }

    private func restore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}

private struct PatchShareRequest: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PatchActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(
        _ uiViewController: UIActivityViewController,
        context: Context
    ) {}
}
