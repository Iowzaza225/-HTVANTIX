import SwiftUI
import UIKit

struct ContentView: View {
    @StateObject private var license = HTLicenseSession()

    var body: some View {
        Group {
            switch license.state {
            case .checking:
                HTLicenseCheckingView()
            case .locked, .error:
                HTLicenseAccessView(session: license)
            case .unlocked:
                PremiumHomeRoot(session: license)
            }
        }
        .preferredColorScheme(.dark)
        .task {
            await license.bootstrap()
        }
    }
}

// MARK: - Premium Theme

enum PremiumTheme {
    static let background = Color.black
    static let surface = Color(red: 0.045, green: 0.05, blue: 0.065)
    static let surface2 = Color(red: 0.075, green: 0.082, blue: 0.105)
    static let border = Color.white.opacity(0.10)
    static let accent = Color(red: 0.16, green: 0.72, blue: 1.0)
    static let accentSoft = Color(red: 0.16, green: 0.72, blue: 1.0).opacity(0.14)
    static let textSecondary = Color.white.opacity(0.52)
    static let textTertiary = Color.white.opacity(0.34)
}

struct PremiumBackground: View {
    var body: some View {
        ZStack {
            Color.black
            RadialGradient(
                colors: [PremiumTheme.accent.opacity(0.09), Color.clear],
                center: .topTrailing,
                startRadius: 10,
                endRadius: 340
            )
            RadialGradient(
                colors: [Color.white.opacity(0.025), Color.clear],
                center: .bottomLeading,
                startRadius: 20,
                endRadius: 430
            )
        }
        .ignoresSafeArea()
    }
}

// MARK: - License Session

@MainActor
final class HTLicenseSession: ObservableObject {
    enum State: Equatable {
        case checking
        case locked
        case unlocked
        case error(String)
    }

    @Published var state: State = .checking
    @Published var expiresAt: String?
    @Published var isSubmitting = false

    private let sessionTokenKey = "com.htblackshop.license-session"
    private let deviceIDKey = "com.htblackshop.device-id"
    private let baseURL = URL(string: "https://hightapi.netlify.app")!

    var errorMessage: String? {
        if case .error(let message) = state { return message }
        return nil
    }

    var deviceID: String {
        if let existing = UserDefaults.standard.string(forKey: deviceIDKey),
           !existing.isEmpty {
            return existing
        }
        let value = UUID().uuidString
        UserDefaults.standard.set(value, forKey: deviceIDKey)
        return value
    }

    func bootstrap() async {
        guard let token = UserDefaults.standard.string(forKey: sessionTokenKey),
              !token.isEmpty else {
            state = .locked
            return
        }

        state = .checking

        do {
            let response = try await verify(token: token)
            UserDefaults.standard.set(response.token, forKey: sessionTokenKey)
            expiresAt = response.license?.expiresAt
            state = .unlocked
        } catch {
            UserDefaults.standard.removeObject(forKey: sessionTokenKey)
            state = .locked
        }
    }

    func activate(key: String) async {
        let value = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else {
            state = .error("กรุณากรอก License Key")
            return
        }

        isSubmitting = true
        defer { isSubmitting = false }

        do {
            let response = try await activateRequest(key: value)
            UserDefaults.standard.set(response.token, forKey: sessionTokenKey)
            expiresAt = response.license?.expiresAt
            state = .unlocked
        } catch {
            state = .error(Self.userMessage(for: error))
        }
    }

    func resetError() {
        if case .error = state {
            state = .locked
        }
    }

    func signOut() {
        UserDefaults.standard.removeObject(forKey: sessionTokenKey)
        expiresAt = nil
        state = .locked
    }

    private func activateRequest(key: String) async throws -> HTLicenseResponse {
        let url = baseURL.appendingPathComponent("license").appendingPathComponent("activate")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 15
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        try applyAppToken(to: &request)

        let payload = HTLicenseActivatePayload(
            key: key,
            deviceId: deviceID,
            appVersion: appVersion
        )
        request.httpBody = try JSONEncoder().encode(payload)

        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response: response, data: data)
        return try JSONDecoder().decode(HTLicenseResponse.self, from: data)
    }

    private func verify(token: String) async throws -> HTLicenseResponse {
        let url = baseURL.appendingPathComponent("license").appendingPathComponent("verify")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 15
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        try applyAppToken(to: &request)

        let payload = HTLicenseVerifyPayload(
            token: token,
            deviceId: deviceID,
            appVersion: appVersion
        )
        request.httpBody = try JSONEncoder().encode(payload)

        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response: response, data: data)
        return try JSONDecoder().decode(HTLicenseResponse.self, from: data)
    }

    private func applyAppToken(to request: inout URLRequest) throws {
        guard let token = appToken else {
            throw HTLicenseError.configuration
        }
        request.setValue(token, forHTTPHeaderField: "X-App-Token")
    }

    private var appToken: String? {
        let candidates: [String?] = [
            Bundle.main.object(forInfoDictionaryKey: "HTVANTIX_APP_TOKEN") as? String,
            Bundle.main.object(forInfoDictionaryKey: "HIGHT_APP_TOKEN") as? String
        ]
        return candidates
            .compactMap { $0?.trimmingCharacters(in: .whitespacesAndNewlines) }
            .first(where: { !$0.isEmpty })
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "8.11"
    }

    private func validate(response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else { return }
        guard (200..<300).contains(http.statusCode) else {
            let serverError = try? JSONDecoder().decode(HTLicenseServerError.self, from: data)
            throw HTLicenseError.http(http.statusCode, serverError?.error)
        }
    }

    private static func userMessage(for error: Error) -> String {
        if let licenseError = error as? HTLicenseError {
            switch licenseError {
            case .configuration:
                return "ระบบยังไม่พร้อมใช้งาน"
            case .http(_, let code):
                switch code {
                case "INVALID_KEY": return "ไม่พบ License Key นี้"
                case "DISABLED": return "License Key ถูกปิดใช้งาน"
                case "EXPIRED": return "License Key หมดอายุแล้ว"
                case "DEVICE_MISMATCH": return "License Key ถูกผูกกับอุปกรณ์อื่นแล้ว"
                case "RATE_LIMITED": return "ลองใหม่อีกครั้งในภายหลัง"
                default: return "ไม่สามารถยืนยัน License Key ได้"
                }
            }
        }

        if let urlError = error as? URLError {
            switch urlError.code {
            case .notConnectedToInternet, .networkConnectionLost, .timedOut:
                return "ไม่สามารถเชื่อมต่ออินเทอร์เน็ตได้"
            default:
                break
            }
        }

        return "ไม่สามารถยืนยัน License Key ได้"
    }
}

private enum HTLicenseError: Error {
    case configuration
    case http(Int, String?)
}

private struct HTLicenseActivatePayload: Encodable {
    let key: String
    let deviceId: String
    let appVersion: String
}

private struct HTLicenseVerifyPayload: Encodable {
    let token: String
    let deviceId: String
    let appVersion: String
}

private struct HTLicenseResponse: Decodable {
    let ok: Bool
    let token: String
    let license: HTLicensePublicInfo?
    let serverTime: String?
}

private struct HTLicensePublicInfo: Decodable {
    let status: String?
    let expiresAt: String?
    let remainingSeconds: Int?
    let deviceBound: Bool?
}

private struct HTLicenseServerError: Decodable {
    let error: String?
}

// MARK: - License UI

private struct HTLicenseCheckingView: View {
    var body: some View {
        ZStack {
            PremiumBackground()
            VStack(spacing: 16) {
                AppLogo(size: 74)
                Text("HTVANTIX")
                    .font(.system(size: 28, weight: .black))
                    .foregroundStyle(.white)
                ProgressView()
                    .tint(PremiumTheme.accent)
                    .padding(.top, 4)
            }
        }
    }
}

private struct HTLicenseAccessView: View {
    @ObservedObject var session: HTLicenseSession
    @State private var key = ""
    @State private var reveal = false

    var body: some View {
        ZStack {
            PremiumBackground()

            ScrollView {
                VStack(spacing: 24) {
                    Spacer(minLength: 46)

                    AppLogo(size: 84)

                    VStack(spacing: 7) {
                        Text("HTVANTIX")
                            .font(.system(size: 30, weight: .black))
                            .foregroundStyle(.white)
                        Text("ยืนยันสิทธิ์การใช้งาน")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(PremiumTheme.textSecondary)
                    }

                    VStack(alignment: .leading, spacing: 14) {
                        Text("LICENSE KEY")
                            .font(.caption2.weight(.bold))
                            .tracking(1.4)
                            .foregroundStyle(PremiumTheme.textTertiary)

                        HStack(spacing: 10) {
                            Group {
                                if reveal {
                                    TextField("กรอก License Key", text: $key)
                                } else {
                                    SecureField("กรอก License Key", text: $key)
                                }
                            }
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .foregroundStyle(.white)

                            Button { reveal.toggle() } label: {
                                Image(systemName: reveal ? "eye.slash.fill" : "eye.fill")
                                    .foregroundStyle(PremiumTheme.textSecondary)
                            }
                        }
                        .padding(.horizontal, 16)
                        .frame(height: 58)
                        .background(PremiumTheme.surface2, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 15, style: .continuous)
                                .stroke(PremiumTheme.border, lineWidth: 1)
                        }

                        if let message = session.errorMessage {
                            Text(message)
                                .font(.caption)
                                .foregroundStyle(Color.red.opacity(0.92))
                        }

                        Button {
                            session.resetError()
                            Task { await session.activate(key: key) }
                        } label: {
                            HStack {
                                Spacer()
                                if session.isSubmitting {
                                    ProgressView().tint(.black)
                                } else {
                                    Text("ACTIVATE")
                                        .font(.headline.weight(.black))
                                }
                                Spacer()
                            }
                            .frame(height: 56)
                            .foregroundStyle(.black)
                            .background(PremiumTheme.accent, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                        }
                        .disabled(session.isSubmitting)
                    }
                    .padding(20)
                    .background(PremiumTheme.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .stroke(PremiumTheme.border, lineWidth: 1)
                    }

                    Text("License จะผูกกับอุปกรณ์เครื่องนี้")
                        .font(.caption)
                        .foregroundStyle(PremiumTheme.textTertiary)

                    Spacer(minLength: 40)
                }
                .padding(.horizontal, 22)
            }
        }
    }
}

// MARK: - Home only

private struct PremiumHomeRoot: View {
    @ObservedObject var session: HTLicenseSession
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var appeared = false
    @AppStorage("htvantix.selectedGame") private var selectedGame = "freefire"

    var body: some View {
        NavigationStack {
            ZStack {
                PremiumBackground()

                ScrollView {
                    VStack(spacing: 16) {
                        deviceCard
                            .premiumEntrance(index: 0, appeared: appeared)

                        NavigationLink {
                            PatchProjectsView()
                                .onAppear { selectedGame = "freefire" }
                        } label: {
                            gameCard(
                                title: "Free Fire",
                                status: "พร้อมใช้งาน",
                                imageName: "FreeFireIcon"
                            )
                        }
                        .buttonStyle(PremiumPressButtonStyle())
                        .premiumEntrance(index: 1, appeared: appeared)

                        NavigationLink {
                            PatchProjectsView()
                                .onAppear { selectedGame = "freefiremax" }
                        } label: {
                            gameCard(
                                title: "Free Fire Max",
                                status: "พร้อมใช้งาน",
                                imageName: "FreeFireMaxIcon"
                            )
                        }
                        .buttonStyle(PremiumPressButtonStyle())
                        .premiumEntrance(index: 2, appeared: appeared)

                        licenseCard
                            .premiumEntrance(index: 3, appeared: appeared)

                        updateCard
                            .premiumEntrance(index: 4, appeared: appeared)

                        footerView
                            .premiumEntrance(index: 5, appeared: appeared)
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 12)
                    .padding(.bottom, 34)
                }
            }
            .navigationTitle("HTVANTIX")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(Color.black.opacity(0.96), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showSettings = true } label: {
                        ZStack {
                            Circle().fill(PremiumTheme.surface2)
                            Image(systemName: "gearshape.fill")
                                .font(.system(size: 17, weight: .bold))
                                .foregroundStyle(.white)
                        }
                        .frame(width: 40, height: 40)
                        .overlay(Circle().stroke(PremiumTheme.border, lineWidth: 1))
                    }
                    .accessibilityLabel("ตั้งค่า")
                }
            }
            .sheet(isPresented: $showSettings) {
                SettingsView()
                    .environmentObject(appState)
                    .environmentObject(session)
            }
            .onAppear {
                withAnimation(.easeOut(duration: 0.30)) {
                    appeared = true
                }
            }
        }
    }

    private var deviceCard: some View {
        VStack(spacing: 18) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("DEVICE")
                        .font(.caption2.weight(.bold))
                        .tracking(1.4)
                        .foregroundStyle(PremiumTheme.textTertiary)

                    Text(AppInfo.displayMachineName)
                        .font(.system(size: 25, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                }

                Spacer()

                Text("iOS \(AppInfo.osVersion)")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.82))
                    .padding(.horizontal, 11)
                    .padding(.vertical, 7)
                    .background(PremiumTheme.surface2, in: Capsule())
            }

            Rectangle()
                .fill(PremiumTheme.border)
                .frame(height: 1)

            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("COMPATIBILITY")
                        .font(.caption2.weight(.bold))
                        .tracking(1.4)
                        .foregroundStyle(PremiumTheme.textTertiary)

                    Text("Universal iOS")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.78))
                }

                Spacer()

                HStack(spacing: 7) {
                    Image(systemName: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill")
                    Text(appState.isSupported ? "รองรับ" : "ไม่รองรับ")
                }
                .font(.subheadline.weight(.bold))
                .foregroundStyle(appState.isSupported ? Color.green : Color.orange)
            }
        }
        .padding(20)
        .background(PremiumTheme.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(PremiumTheme.border, lineWidth: 1)
        }
    }

    private func gameCard(title: String, status: String, imageName: String) -> some View {
        HStack(spacing: 16) {
            Image(imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 66, height: 66)
                .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 17, style: .continuous)
                        .stroke(Color.white.opacity(0.08), lineWidth: 1)
                }
                .shadow(color: PremiumTheme.accent.opacity(0.12), radius: 10, y: 4)

            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.title3.weight(.bold))
                    .foregroundStyle(.white)

                HStack(spacing: 6) {
                    Circle()
                        .fill(Color.green)
                        .frame(width: 6, height: 6)

                    Text(status)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(PremiumTheme.textSecondary)
                }
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(PremiumTheme.accent)
        }
        .padding(18)
        .background(PremiumTheme.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(PremiumTheme.border, lineWidth: 1)
        }
    }

    private var licenseCard: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color.green.opacity(0.14))

                Circle()
                    .fill(Color.green)
                    .frame(width: 10, height: 10)
                    .shadow(color: Color.green.opacity(0.65), radius: 7)
            }
            .frame(width: 42, height: 42)

            VStack(alignment: .leading, spacing: 4) {
                Text("License Active")
                    .font(.headline)
                    .foregroundStyle(.white)

                Text(licenseExpiryText)
                    .font(.caption)
                    .foregroundStyle(PremiumTheme.textSecondary)
            }

            Spacer()

            Button {
                showSettings = true
            } label: {
                Text("จัดการคีย์")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(PremiumTheme.surface2, in: Capsule())
                    .overlay {
                        Capsule()
                            .stroke(PremiumTheme.border, lineWidth: 1)
                    }
            }
            .buttonStyle(.plain)
        }
        .padding(18)
        .background(PremiumTheme.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(PremiumTheme.border, lineWidth: 1)
        }
    }

    private var updateCard: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 15, style: .continuous)
                    .fill(PremiumTheme.accentSoft)

                Image(systemName: "arrow.triangle.2.circlepath")
                    .font(.system(size: 19, weight: .bold))
                    .foregroundStyle(PremiumTheme.accent)
            }
            .frame(width: 48, height: 48)

            VStack(alignment: .leading, spacing: 4) {
                Text("HTVANTIX UPDATE")
                    .font(.caption.weight(.black))
                    .tracking(0.8)
                    .foregroundStyle(.white)

                Text("เวอร์ชันล่าสุดพร้อมใช้งาน")
                    .font(.subheadline)
                    .foregroundStyle(PremiumTheme.textSecondary)
            }

            Spacer()

            Image(systemName: "checkmark.circle.fill")
                .font(.title3)
                .foregroundStyle(Color.green)
        }
        .padding(18)
        .background(PremiumTheme.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(PremiumTheme.border, lineWidth: 1)
        }
    }

    private var footerView: some View {
        HStack(spacing: 7) {
            Circle()
                .fill(PremiumTheme.accent)
                .frame(width: 5, height: 5)

            Text("HTVANTIX")
                .font(.caption2.weight(.bold))

            Text("•")
                .font(.caption2)

            Text("v8.11")
                .font(.caption2.weight(.semibold))

            Text("•")
                .font(.caption2)

            Text("Secure Session")
                .font(.caption2.weight(.medium))
        }
        .foregroundStyle(PremiumTheme.textTertiary)
        .frame(maxWidth: .infinity)
        .padding(.top, 8)
        .padding(.bottom, 6)
    }

    private var licenseExpiryText: String {
        guard let expires = session.expiresAt,
              !expires.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return "สิทธิ์การใช้งานเปิดอยู่"
        }
        return "หมดอายุ \(expires)"
    }
}

private struct PremiumPressButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.985 : 1.0)
            .opacity(configuration.isPressed ? 0.92 : 1.0)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

private extension View {
    func premiumEntrance(index: Int, appeared: Bool) -> some View {
        self
            .opacity(appeared ? 1 : 0)
            .offset(y: appeared ? 0 : 10)
            .animation(
                .easeOut(duration: 0.30)
                    .delay(Double(index) * 0.045),
                value: appeared
            )
    }
}
