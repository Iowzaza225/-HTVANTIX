import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var appState: AppState

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        AppLogo(size: 50)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("HTVANTIX").font(.headline)
                            Text("เวอร์ชัน \(appVersion)")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 5)
                }

                Section("อุปกรณ์") {
                    LabeledContent("รุ่นอุปกรณ์", value: AppInfo.displayMachineName)
                    LabeledContent("เวอร์ชัน iOS", value: "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                    HStack {
                        Text("สถานะรองรับ")
                        Spacer()
                        Text(appState.isSupported ? "รองรับ" : "ไม่รองรับ")
                            .fontWeight(.semibold)
                            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                }

                Section("ระบบ") {
                    LabeledContent("เกม", value: "Free Fire")
                    LabeledContent("เซิร์ฟเวอร์", value: "hightapi.netlify.app")
                    LabeledContent("ระบบแพตช์", value: "HTVANTIX Core")
                } footer: {
                    Text("ระบบไฟล์และแพตช์ภายในยังใช้HTVANTIX Core สำหรับจัดการไฟล์ สำรอง และคืนค่า")
                }
            }
            .tint(AppTheme.accent)
            .navigationTitle("ตั้งค่า")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("เสร็จสิ้น") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }
}
