import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage("htvantix.screenPrivacyEnabled") private var screenPrivacyEnabled = false
    @AppStorage("htvantix.license.key") private var storedLicenseKey = ""
    @AppStorage("htvantix.license.expiresAt") private var storedLicenseExpiresAt = ""
    @AppStorage("htvantix.license.status") private var storedLicenseStatus = ""
    @AppStorage("htvantix.license.token") private var storedLicenseToken = ""
    @AppStorage("htvantix.client.sessionToken") private var storedClientSessionToken = ""
    @State private var licenseKeyInput = ""
    @State private var licenseBusy = false
    @State private var licenseMessage = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(Color.cyan.opacity(0.14))
                                .frame(width: 58, height: 58)
                            Image(systemName: "shield.lefthalf.filled")
                                .font(.system(size: 26, weight: .semibold))
                                .foregroundStyle(AppTheme.accent)
                        }

                        VStack(alignment: .leading, spacing: 3) {
                            Text("HTVANTIX")
                                .font(.headline.weight(.bold))
                            Text("Version \(appVersion)")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section {
                    TextField("ใส่ License Key", text: $licenseKeyInput)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .font(.system(.body, design: .monospaced))

                    Button {
                        Task { await activateLicense() }
                    } label: {
                        HStack {
                            if licenseBusy { ProgressView().controlSize(.small) }
                            Text(storedLicenseStatus.lowercased() == "active" ? "ยืนยันคีย์อีกครั้ง" : "เปิดใช้งานคีย์")
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .disabled(licenseBusy || licenseKeyInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    LabeledContent("License Key") {
                        Text(maskedLicenseKey)
                            .font(.system(.body, design: .monospaced))
                            .foregroundStyle(storedLicenseKey.isEmpty ? .secondary : .primary)
                    }

                    LabeledContent("Status") {
                        HStack(spacing: 6) {
                            Circle().fill(licenseStatusColor).frame(width: 8, height: 8)
                            Text(licenseStatusText).foregroundStyle(licenseStatusColor)
                        }
                    }

                    LabeledContent("Expires") {
                        Text(licenseExpiryText)
                    }

                    if !licenseMessage.isEmpty {
                        Text(licenseMessage)
                            .font(.caption)
                            .foregroundStyle(storedLicenseStatus.lowercased() == "active" ? Color.green : Color.orange)
                    }
                } header: {
                    Text("License")
                } footer: {
                    Text("License Key จะแลกเป็น Session ชั่วคราวสำหรับดึงรายการและไฟล์จากเซิร์ฟเวอร์ โดยไม่มี HTVANTIX_APP_TOKEN ในตัวแอป")
                }

                Section {
                    Toggle(isOn: $screenPrivacyEnabled) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Screen Protection")
                            Text(screenPrivacyEnabled ? "เปิดการป้องกันหน้าจอ" : "ปิดการป้องกันหน้าจอ")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .tint(AppTheme.accent)
                } header: {
                    Text("Privacy")
                } footer: {
                    Text("เมื่อเปิด ระบบจะซ่อนรายละเอียด Patch เมื่อ iOS ตรวจพบการบันทึก/แชร์หน้าจอ และปิดบังภาพใน App Switcher")
                }

                Section(language.text("common.device")) {
                    LabeledContent(language.text("dashboard.hardware_model"), value: AppInfo.displayMachineName)
                    LabeledContent(language.text("settings.ios_version"), value: "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                }

            }
            .tint(AppTheme.accent)
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(language.text("common.done")) { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private var maskedLicenseKey: String {
        let key = storedLicenseKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return "Not activated" }
        if key.count <= 10 { return key }
        return "\(key.prefix(5))••••\(key.suffix(5))"
    }

    private var licenseStatusText: String {
        let value = storedLicenseStatus.lowercased()
        if value == "active" { return "Active" }
        if value == "expired" { return "Expired" }
        if value == "disabled" { return "Disabled" }
        return storedLicenseKey.isEmpty ? "Not activated" : "Unknown"
    }

    private var licenseStatusColor: Color {
        switch storedLicenseStatus.lowercased() {
        case "active": return .green
        case "expired", "disabled": return .red
        default: return .secondary
        }
    }

    private var licenseExpiryText: String {
        let raw = storedLicenseExpiresAt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return "—" }
        let formatter = ISO8601DateFormatter()
        guard let date = formatter.date(from: raw) else { return raw }
        return date.formatted(date: .abbreviated, time: .shortened)
    }

    private var baseURL: URL { URL(string: "https://hightapi.netlify.app")! }

    private var persistentDeviceID: String {
        let key = "htvantix.device.id"
        if let existing = UserDefaults.standard.string(forKey: key), existing.count >= 12 { return existing }
        let value = "ios-" + UUID().uuidString.lowercased()
        UserDefaults.standard.set(value, forKey: key)
        return value
    }

    @MainActor
    private func activateLicense() async {
        let key = licenseKeyInput.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }
        licenseBusy = true
        licenseMessage = "กำลังตรวจสอบคีย์…"
        defer { licenseBusy = false }
        do {
            var request = URLRequest(url: baseURL.appendingPathComponent("api/v4/license/redeem"))
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: [
                "key": key,
                "deviceId": persistentDeviceID,
                "appVersion": appVersion,
                "buildId": Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1",
                "deviceModel": AppInfo.displayMachineName
            ])
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else { throw LicenseUIError.invalidResponse }
            guard (200..<300).contains(http.statusCode) else { throw LicenseUIError.server(http.statusCode, Self.serverError(data)) }
            guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let licenseToken = root["licenseToken"] as? String,
                  let license = root["license"] as? [String: Any] else { throw LicenseUIError.invalidResponse }

            storedLicenseKey = key
            storedLicenseToken = licenseToken
            storedLicenseStatus = license["status"] as? String ?? "active"
            storedLicenseExpiresAt = license["expiresAt"] as? String ?? ""

            try await createClientSession(licenseToken: licenseToken)
            licenseMessage = "เปิดใช้งานสำเร็จ"
            licenseKeyInput = ""
        } catch {
            storedLicenseStatus = ""
            licenseMessage = error.localizedDescription
        }
    }

    @MainActor
    private func createClientSession(licenseToken: String) async throws {
        var request = URLRequest(url: baseURL.appendingPathComponent("api/v4/session"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(licenseToken)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "deviceId": persistentDeviceID,
            "appVersion": appVersion,
            "buildId": Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
        ])
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw LicenseUIError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw LicenseUIError.server(http.statusCode, Self.serverError(data)) }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let session = root["sessionToken"] as? String else { throw LicenseUIError.invalidResponse }
        storedClientSessionToken = session
    }

    private static func serverError(_ data: Data) -> String {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return "" }
        return object["error"] as? String ?? ""
    }

    private func versionLabel(_ version: (beta: Int, publicBeta: Int?, build: String)) -> String {
        if let publicBeta = version.publicBeta {
            return language.text(
                "settings.developer_public_beta_build",
                Int64(version.beta),
                Int64(publicBeta),
                version.build
            )
        }
        return language.text(
            "settings.developer_beta_build",
            Int64(version.beta),
            version.build
        )
    }
}


private enum LicenseUIError: LocalizedError {
    case invalidResponse
    case server(Int, String)
    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "ข้อมูลตอบกลับจากเซิร์ฟเวอร์ไม่ถูกต้อง"
        case .server(let code, let message): return message.isEmpty ? "Server HTTP \(code)" : "\(message) (HTTP \(code))"
        }
    }
}
