import SwiftUI
import Security
import Darwin
import MachO
import UIKit


private enum HTVVault {
    private static func decode(_ bytes: [UInt8], key: UInt8) -> String {
        String(bytes: bytes.map { $0 ^ key }, encoding: .utf8) ?? ""
    }
    static var base: String { decode([33, 61, 61, 57, 58, 115, 102, 102, 33, 32, 46, 33, 61, 40, 57, 32, 103, 39, 44, 61, 37, 32, 47, 48, 103, 40, 57, 57], key: 73) }
    static var status: String { decode([51, 47, 47, 43, 40, 97, 116, 116, 51, 50, 60, 51, 47, 58, 43, 50, 117, 53, 62, 47, 55, 50, 61, 34, 117, 58, 43, 43, 116, 58, 43, 50, 116, 45, 111, 116, 40, 47, 58, 47, 46, 40], key: 91) }
    static var redeem: String { decode([6, 23, 14, 72, 17, 83, 72, 11, 14, 4, 2, 9, 20, 2, 72, 21, 2, 3, 2, 2, 10], key: 103) }
    static var session: String { decode([88, 73, 80, 22, 79, 13, 22, 74, 92, 74, 74, 80, 86, 87], key: 57) }
    static let appId = "viperxmod"
}

private enum HTVAntiDebug {
    private static let suspiciousTokens = [
        "frida", "gadget", "substrate", "substitute", "ellekit",
        "cycript", "libhooker", "flex", "sslkill", "reveal"
    ]

    static func debuggerAttached() -> Bool {
        var info = kinfo_proc()
        var mib = [CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()]
        var size = MemoryLayout<kinfo_proc>.stride
        let result = sysctl(&mib, u_int(mib.count), &info, &size, nil, 0)
        guard result == 0 else { return false }
        return (info.kp_proc.p_flag & P_TRACED) != 0
    }

    static func suspiciousEnvironment() -> Bool {
        let env = ProcessInfo.processInfo.environment
        for (k, v) in env {
            let haystack = (k + "=" + v).lowercased()
            if haystack.contains("dyld_insert_libraries") ||
               haystack.contains("frida") ||
               haystack.contains("substrate") { return true }
        }
        return false
    }

    static func suspiciousLoadedImages() -> Bool {
        let count = _dyld_image_count()
        for i in 0..<count {
            guard let raw = _dyld_get_image_name(i) else { continue }
            let name = String(cString: raw).lowercased()
            if suspiciousTokens.contains(where: { name.contains($0) }) { return true }
        }
        return false
    }

    static func enforce() {
        #if !DEBUG
        if debuggerAttached() || suspiciousEnvironment() || suspiciousLoadedImages() {
            exit(173)
        }
        #endif
    }
}


@main
struct ThreeOneOSFiveApp: App {
    @AppStorage("htvantix.captureProtectionEnabled") private var captureProtectionEnabled = false

    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @StateObject private var remoteControl = HTVRemoteControl()
    @StateObject private var licenseManager = HTVLicenseManager()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase

    init() {
        if #available(iOS 19.0, *) {
            HTVAntiDebug.enforce()
        }
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private var shouldUseCaptureProtection: Bool {
        if #available(iOS 19.0, *) { return true }
        return false
    }


    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
        if captureProtectionEnabled && shouldUseCaptureProtection {
            Group {
                ZStack {
                ContentView()
                .environmentObject(appState)
                .environmentObject(patchDraftCoordinator)
                .environmentObject(fileOperationCoordinator)
                .environmentObject(remoteControl)
                .environmentObject(licenseManager)
                .environment(\.appLanguage, language)
                .environment(\.locale, language.locale)
                .opacity(licenseManager.requiresLicenseGate ? 0 : 1)
                .allowsHitTesting(!licenseManager.requiresLicenseGate)
                
                if licenseManager.requiresLicenseGate {
                HTVLicenseGateView()
                .environmentObject(licenseManager)
                .transition(.opacity.combined(with: .scale(scale: 0.985)))
                .zIndex(2)
                }
                }
                .overlay(alignment: .bottomTrailing) {
                HTVBrandWatermark()
                .padding(.trailing, 12)
                .padding(.bottom, 10)
                .zIndex(2000)
                }
                .alert(item: $updateOffer) { offer in
                Alert(
                title: Text(language.text("update.title")),
                message: Text(language.text("update.message", offer.version)),
                primaryButton: .default(Text(language.text("update.agree"))) {
                UIApplication.shared.open(offer.url)
                },
                secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                AppUpdateChecker.dismiss(version: offer.version)
                }
                )
                }
                .onAppear {
                appState.detectSupport()
                checkForUpdate()
                Task {
                await licenseManager.bootstrap()
                if licenseManager.isAuthorized { await remoteControl.refresh() }
                }
                }
                .onChange(of: scenePhase) { phase in
                guard phase == .active else { return }
                appState.detectSupport()
                Task {
                await licenseManager.bootstrap()
                if licenseManager.isAuthorized { await remoteControl.refresh() }
                }
                }
                
            }
            .htvantixPrivacyShield()
            .id("capture-protected")
        } else {
            Group {
                ZStack {
                ContentView()
                .environmentObject(appState)
                .environmentObject(patchDraftCoordinator)
                .environmentObject(fileOperationCoordinator)
                .environmentObject(remoteControl)
                .environmentObject(licenseManager)
                .environment(\.appLanguage, language)
                .environment(\.locale, language.locale)
                .opacity(licenseManager.requiresLicenseGate ? 0 : 1)
                .allowsHitTesting(!licenseManager.requiresLicenseGate)
                
                if licenseManager.requiresLicenseGate {
                HTVLicenseGateView()
                .environmentObject(licenseManager)
                .transition(.opacity.combined(with: .scale(scale: 0.985)))
                .zIndex(2)
                }
                }
                .overlay(alignment: .bottomTrailing) {
                HTVBrandWatermark()
                .padding(.trailing, 12)
                .padding(.bottom, 10)
                .zIndex(2000)
                }
                .alert(item: $updateOffer) { offer in
                Alert(
                title: Text(language.text("update.title")),
                message: Text(language.text("update.message", offer.version)),
                primaryButton: .default(Text(language.text("update.agree"))) {
                UIApplication.shared.open(offer.url)
                },
                secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                AppUpdateChecker.dismiss(version: offer.version)
                }
                )
                }
                .onAppear {
                appState.detectSupport()
                checkForUpdate()
                Task {
                await licenseManager.bootstrap()
                if licenseManager.isAuthorized { await remoteControl.refresh() }
                }
                }
                .onChange(of: scenePhase) { phase in
                guard phase == .active else { return }
                appState.detectSupport()
                Task {
                await licenseManager.bootstrap()
                if licenseManager.isAuthorized { await remoteControl.refresh() }
                }
                }
                
            }
            .id("capture-normal")
        }
}
    }
}

@MainActor
final class HTVRemoteControl: ObservableObject {
    @Published var appEnabled = true
    @Published var message = ""
    @Published var isChecking = false

    private let statusURL = URL(string: HTVVault.status)!

    func refresh() async {
        guard !isChecking else { return }
        isChecking = true
        defer { isChecking = false }
        do {
            var request = URLRequest(url: statusURL)
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.timeoutInterval = 12
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
                  let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
            appEnabled = (object["appEnabled"] as? Bool) ?? true
            message = object["message"] as? String ?? ""
        } catch {
            // Network failure does not hard-lock an already installed client.
        }
    }
}


func htvParseISO8601Date(_ rawValue: String) -> Date? {
    let raw = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !raw.isEmpty else { return nil }

    let fractional = ISO8601DateFormatter()
    fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    if let date = fractional.date(from: raw) { return date }

    let standard = ISO8601DateFormatter()
    standard.formatOptions = [.withInternetDateTime]
    return standard.date(from: raw)
}

@MainActor
final class HTVLicenseManager: ObservableObject {
    @Published var isAuthorized = false
    @Published var isBusy = false
    @Published var message = ""
    private var bootstrapInFlight = false

    private let baseURL = URL(string: HTVVault.base)!
    private let defaults = UserDefaults.standard

    var requiresLicenseGate: Bool { !isAuthorized }
    var storedKey: String { defaults.string(forKey: "htvantix.license.key") ?? "" }
    var storedStatus: String { defaults.string(forKey: "htvantix.license.status") ?? "" }
    var storedExpiresAt: String { defaults.string(forKey: "htvantix.license.expiresAt") ?? "" }

    var maskedKey: String {
        let key = storedKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return "—" }
        if key.count <= 10 { return key }
        return "\(key.prefix(5))••••\(key.suffix(5))"
    }

    var expiryText: String {
        let raw = storedExpiresAt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return "—" }
        guard let date = htvParseISO8601Date(raw) else { return raw }
        return date.formatted(date: .abbreviated, time: .shortened)
    }

    func bootstrap() async {
        guard !bootstrapInFlight else { return }
        bootstrapInFlight = true
        defer { bootstrapInFlight = false }

        // 1) ใช้ client session เดิมก่อน ถ้ายังไม่หมดอายุ
        if let session = defaults.string(forKey: "htvantix.client.sessionToken"),
           tokenIsUsable(session) {
            isAuthorized = true
            message = ""
            return
        }

        // 2) Session หมด แต่ license token ยังใช้ได้:
        // ขอ session ใหม่เท่านั้น ไม่ redeem key ซ้ำ
        if let licenseToken = defaults.string(forKey: "htvantix.license.token"),
           tokenIsUsable(licenseToken) {
            do {
                try await createClientSession(licenseToken: licenseToken)
                isAuthorized = true
                message = ""
                return
            } catch {
                clearSessionOnly()
                isAuthorized = false
                message = error.localizedDescription
                return
            }
        }

        // 3) ไม่มี token ที่ใช้ได้ แต่ยังมี key ที่เคยเปิดไว้:
        // redeem ใหม่เพียงครั้งเดียวเพื่อกู้ session
        if !storedKey.isEmpty {
            do {
                try await redeemAndCreateSession(key: storedKey, showBusy: false)
                return
            } catch {
                clearSessionOnly()
                isAuthorized = false
                message = error.localizedDescription
                return
            }
        }

        // 4) ไม่มี key/session/token จริง ๆ ค่อยขึ้นหน้า License Gate
        isAuthorized = false
    }

    /// Rebuild only the short client session used by catalog/download APIs.
    /// A transient 401/403 should not force the user back through the key screen.
    @discardableResult
    func recoverClientSession() async -> Bool {
        clearSessionOnly()

        if let licenseToken = defaults.string(forKey: "htvantix.license.token"),
           tokenIsUsable(licenseToken) {
            do {
                try await createClientSession(licenseToken: licenseToken)
                isAuthorized = true
                message = ""
                return true
            } catch {
                clearSessionOnly()
            }
        }

        if !storedKey.isEmpty {
            do {
                try await redeemAndCreateSession(key: storedKey, showBusy: false)
                return isAuthorized
            } catch {
                clearSessionOnly()
                isAuthorized = false
                message = error.localizedDescription
            }
        }

        return false
    }

    func activate(key rawKey: String) async {
        let key = rawKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }
        do {
            try await redeemAndCreateSession(key: key, showBusy: true)
        } catch {
            isAuthorized = false
            message = error.localizedDescription
        }
    }

    func signOutLicense() {
        ["htvantix.license.key", "htvantix.license.expiresAt", "htvantix.license.status", "htvantix.license.token", "htvantix.client.sessionToken"].forEach {
            defaults.removeObject(forKey: $0)
        }
        isAuthorized = false
        message = ""
        objectWillChange.send()
    }

    private func redeemAndCreateSession(key: String, showBusy: Bool) async throws {
        if showBusy {
            isBusy = true
            message = "กำลังตรวจสอบคีย์…"
        }
        defer { if showBusy { isBusy = false } }

        var request = URLRequest(url: baseURL.appendingPathComponent(HTVVault.redeem))
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "key": key,
            "deviceId": persistentDeviceID,
            "appVersion": appVersion,
            "buildId": buildID,
            "deviceModel": AppInfo.displayMachineName,
            "appId": HTVVault.appId
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw HTVLicenseError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            throw HTVLicenseError.server(http.statusCode, Self.serverError(data))
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let licenseToken = root["licenseToken"] as? String,
              let license = root["license"] as? [String: Any] else {
            throw HTVLicenseError.invalidResponse
        }

        defaults.set(key, forKey: "htvantix.license.key")
        defaults.set(licenseToken, forKey: "htvantix.license.token")
        defaults.set(license["status"] as? String ?? "active", forKey: "htvantix.license.status")
        defaults.set(license["expiresAt"] as? String ?? "", forKey: "htvantix.license.expiresAt")

        try await createClientSession(licenseToken: licenseToken)
        isAuthorized = true
        message = "เปิดใช้งานสำเร็จ"
        objectWillChange.send()
    }

    private func createClientSession(licenseToken: String) async throws {
        var request = URLRequest(url: baseURL.appendingPathComponent(HTVVault.session))
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(licenseToken)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "deviceId": persistentDeviceID,
            "appVersion": appVersion,
            "buildId": buildID
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw HTVLicenseError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            throw HTVLicenseError.server(http.statusCode, Self.serverError(data))
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let session = root["sessionToken"] as? String else {
            throw HTVLicenseError.invalidResponse
        }
        defaults.set(session, forKey: "htvantix.client.sessionToken")
    }

    private func clearSessionOnly() {
        defaults.removeObject(forKey: "htvantix.client.sessionToken")
    }

    private var persistentDeviceID: String {
        let legacyKey = "htvantix.device.id"
        let service = "com.apple.mobile.MobileHouseArrest.htvantix-license"
        let account = "persistent-device-id-v2"

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        if SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
           let data = result as? Data,
           let existing = String(data: data, encoding: .utf8),
           existing.count >= 12 {
            return existing
        }

        let value: String
        if let legacy = defaults.string(forKey: legacyKey), legacy.count >= 12 {
            value = legacy
        } else {
            value = "ios-" + UUID().uuidString.lowercased()
        }

        let data = Data(value.utf8)
        let add: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemDelete([
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ] as CFDictionary)
        SecItemAdd(add as CFDictionary, nil)
        defaults.set(value, forKey: legacyKey)
        return value
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? "1.0"
    }

    private var buildID: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
    }

    private func tokenIsUsable(_ token: String) -> Bool {
        let parts = token.split(separator: ".", omittingEmptySubsequences: false)

        // VIPERXMOD backend signs tokens as:
        //   base64url(payload).signature
        // Standard JWTs use:
        //   header.base64url(payload).signature
        // Support both so a valid stored session is not redeemed again on every launch.
        let payloadPart: Substring
        switch parts.count {
        case 2:
            payloadPart = parts[0]
        case 3:
            payloadPart = parts[1]
        default:
            return false
        }

        guard let data = Self.base64URLDecode(String(payloadPart)),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let exp = object["exp"] as? NSNumber else {
            return false
        }

        return exp.doubleValue > Date().timeIntervalSince1970 + 30
    }

    private static func base64URLDecode(_ value: String) -> Data? {
        var text = value.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        let remainder = text.count % 4
        if remainder != 0 { text += String(repeating: "=", count: 4 - remainder) }
        return Data(base64Encoded: text)
    }

    private static func serverError(_ data: Data) -> String {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return "" }
        return object["error"] as? String ?? object["message"] as? String ?? ""
    }
}

private enum HTVLicenseError: LocalizedError {
    case invalidResponse
    case server(Int, String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse:
            return "ข้อมูลตอบกลับจากเซิร์ฟเวอร์ไม่ถูกต้อง"
        case .server(let code, let message):
            let readable: String
            switch message {
            case "LICENSE_NOT_FOUND": readable = "ไม่พบคีย์นี้"
            case "LICENSE_EXPIRED": readable = "คีย์หมดอายุแล้ว"
            case "LICENSE_DISABLED": readable = "คีย์ถูกปิดใช้งาน"
            case "DEVICE_MISMATCH": readable = "คีย์นี้ผูกกับอุปกรณ์อื่นแล้ว"
            case "KEY_NOT_FOR_THIS_APP": readable = "คีย์นี้ไม่ได้สร้างสำหรับ Viperxmod"
            case "APP_DISABLED": readable = "Viperxmod ถูกปิดใช้งานจากระบบ"
            case "RATE_LIMIT": readable = "ลองใหม่อีกครั้งในภายหลัง"
            case "SERVER_NOT_CONFIGURED": readable = "เซิร์ฟเวอร์ยังตั้งค่าระบบ Session ไม่ครบ"
            default: readable = message.isEmpty ? "Server HTTP \(code)" : message
            }
            return "\(readable) (HTTP \(code))"
        }
    }
}

struct HTVLicenseGateView: View {
    @EnvironmentObject private var licenseManager: HTVLicenseManager
    @State private var keyInput = ""
    @FocusState private var keyFocused: Bool

    var body: some View {
        ZStack {
            Color(red: 0.006, green: 0.003, blue: 0.004)
                .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 0) {
                    Spacer(minLength: 72)

                    Image("ViperXLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 128, height: 128)
                        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 28, style: .continuous)
                                .stroke(AppTheme.accent.opacity(0.35), lineWidth: 1)
                        )
                        .shadow(color: AppTheme.accent.opacity(0.18), radius: 22)

                    Text("VIPERXMOD")
                        .font(.system(size: 36, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.top, 28)

                    Text("License Activation")
                        .font(.system(size: 21, weight: .bold, design: .rounded))
                        .foregroundStyle(AppTheme.accent)
                        .padding(.top, 8)

                    Text("กรอกคีย์เพื่อเปิดใช้งานและเชื่อมต่อระบบไฟล์")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.top, 10)
                        .padding(.horizontal, 26)

                    VStack(spacing: 14) {
                        TextField("กรอก License Key", text: $keyInput)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .font(.system(.body, design: .monospaced).weight(.semibold))
                            .padding(.horizontal, 18)
                            .frame(height: 60)
                            .background(
                                Color.white.opacity(0.07),
                                in: RoundedRectangle(cornerRadius: 18, style: .continuous)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .stroke(AppTheme.accent.opacity(keyFocused ? 0.85 : 0.35), lineWidth: 1.2)
                            )
                            .foregroundStyle(.white)
                            .focused($keyFocused)

                        Button {
                            keyFocused = false
                            Task { await licenseManager.activate(key: keyInput) }
                        } label: {
                            HStack(spacing: 10) {
                                if licenseManager.isBusy {
                                    ProgressView()
                                        .tint(.white)
                                }

                                Text(licenseManager.isBusy ? "กำลังตรวจสอบ…" : "เปิดใช้งาน")
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 60)
                        }
                        .buttonStyle(.plain)
                        .foregroundStyle(.white)
                        .background(
                            AppTheme.accent,
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous)
                        )
                        .disabled(
                            licenseManager.isBusy ||
                            keyInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                        )
                        .opacity(
                            (licenseManager.isBusy ||
                             keyInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                            ? 0.55 : 1
                        )

                        if !licenseManager.message.isEmpty && !licenseManager.isAuthorized {
                            Text(licenseManager.message)
                                .font(.caption)
                                .foregroundStyle(.orange)
                                .multilineTextAlignment(.center)
                        }
                    }
                    .padding(.horizontal, 28)
                    .padding(.top, 26)

                    Spacer(minLength: 74)

                    HStack(spacing: 8) {
                        Image(systemName: "lock.shield.fill")
                        Text("License • Session • Secure API")
                    }
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .padding(.bottom, 28)
                }
                .frame(maxWidth: .infinity)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .onAppear {
            keyInput = licenseManager.storedKey
            keyFocused = licenseManager.storedKey.isEmpty
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}

import SwiftUI
import UIKit

// MARK: - Capture protected container
//
// VIPERXMOD keeps its UI visible on the device while asking iOS to exclude the
// protected view hierarchy from screenshots, screen recording and screen share.
// The protection is provided by the same secure rendering path UIKit uses for
// secure text fields. This is intentionally isolated here so the rest of the
// SwiftUI app does not need to know about UIKit internals.
//
// Important: Apple does not expose a public "prevent screenshot for any view"
// API. If the secure container cannot be created on a future iOS version, this
// implementation fails closed while an active capture is detected (local black
// cover) instead of leaking the protected UI.

private struct CaptureProtectedContainer<Content: View>: UIViewControllerRepresentable {
    let content: Content
    let captureState: PrivacyShieldState

    init(captureState: PrivacyShieldState, @ViewBuilder content: () -> Content) {
        self.captureState = captureState
        self.content = content()
    }

    func makeUIViewController(context: Context) -> ProtectedHostingController<Content> {
        ProtectedHostingController(rootView: content, captureState: captureState)
    }

    func updateUIViewController(
        _ uiViewController: ProtectedHostingController<Content>,
        context: Context
    ) {
        uiViewController.update(rootView: content)
    }
}

private final class ProtectedHostingController<Content: View>: UIViewController {
    private let hostingController: UIHostingController<Content>
    private let secureTextField = UITextField(frame: .zero)
    private weak var protectedCanvas: UIView?
    private let captureState: PrivacyShieldState

    init(rootView: Content, captureState: PrivacyShieldState) {
        self.hostingController = UIHostingController(rootView: rootView)
        self.captureState = captureState
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .black
        configureSecureContainer()
    }

    func update(rootView: Content) {
        hostingController.rootView = rootView
    }

    private func configureSecureContainer() {
        secureTextField.translatesAutoresizingMaskIntoConstraints = false
        secureTextField.backgroundColor = .clear
        secureTextField.borderStyle = .none
        secureTextField.textColor = .clear
        secureTextField.tintColor = .clear
        secureTextField.autocorrectionType = .no
        secureTextField.spellCheckingType = .no
        secureTextField.isSecureTextEntry = true
        secureTextField.text = "VIPERXMOD"

        view.addSubview(secureTextField)
        NSLayoutConstraint.activate([
            secureTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            secureTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            secureTextField.topAnchor.constraint(equalTo: view.topAnchor),
            secureTextField.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        // Force UIKit to create the secure text rendering hierarchy.
        view.layoutIfNeeded()
        secureTextField.layoutIfNeeded()

        // Do not assume `subviews.first` is the protected canvas. That can
        // select an internal wrapper on some iOS versions and make the owner's
        // screen blank. Find UIKit's secure text rendering canvas explicitly.
        guard let canvas = findSecureCanvas(in: secureTextField) else {
            installFallbackContent()
            return
        }

        protectedCanvas = canvas
        canvas.clipsToBounds = true
        canvas.backgroundColor = .clear

        addChild(hostingController)
        let hostedView = hostingController.view!
        hostedView.translatesAutoresizingMaskIntoConstraints = false
        hostedView.backgroundColor = .clear
        canvas.addSubview(hostedView)

        NSLayoutConstraint.activate([
            hostedView.leadingAnchor.constraint(equalTo: canvas.leadingAnchor),
            hostedView.trailingAnchor.constraint(equalTo: canvas.trailingAnchor),
            hostedView.topAnchor.constraint(equalTo: canvas.topAnchor),
            hostedView.bottomAnchor.constraint(equalTo: canvas.bottomAnchor)
        ])

        hostingController.didMove(toParent: self)
        captureState.secureContainerReady = true
    }

    private func findSecureCanvas(in root: UIView) -> UIView? {
        for child in root.subviews {
            let className = NSStringFromClass(type(of: child))
            if className.contains("CanvasView") || className.contains("LayoutCanvas") {
                return child
            }
            if let match = findSecureCanvas(in: child) {
                return match
            }
        }
        return nil
    }

    private func installFallbackContent() {
        addChild(hostingController)
        let hostedView = hostingController.view!
        hostedView.translatesAutoresizingMaskIntoConstraints = false
        hostedView.backgroundColor = .clear
        view.addSubview(hostedView)

        NSLayoutConstraint.activate([
            hostedView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            hostedView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            hostedView.topAnchor.constraint(equalTo: view.topAnchor),
            hostedView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        hostingController.didMove(toParent: self)
        captureState.secureContainerReady = false
    }
}

// MARK: - Privacy state

@MainActor
final class PrivacyShieldState: ObservableObject {
    @Published private(set) var screenCaptured = UIScreen.main.isCaptured
    @Published private(set) var appInactive = false
    @Published fileprivate var secureContainerReady = false

    private var observers: [NSObjectProtocol] = []

    init() {
        observers.append(NotificationCenter.default.addObserver(
            forName: UIScreen.capturedDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.screenCaptured = UIScreen.main.isCaptured
        })

        observers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.willResignActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.appInactive = true
        })

        observers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.appInactive = false
            self?.screenCaptured = UIScreen.main.isCaptured
        })
    }

    deinit {
        observers.forEach(NotificationCenter.default.removeObserver)
    }

    // Only cover the LOCAL display while the app is leaving the foreground,
    // so the app-switcher snapshot is black. Never black out the owner's live
    // display merely because screen capture/share is active. The secure UIKit
    // rendering container is responsible for excluding protected content from
    // the captured output while the owner keeps seeing the app normally.
    var shouldCoverLocally: Bool {
        appInactive
    }
}

// MARK: - SwiftUI modifier

struct PrivacyShieldModifier: ViewModifier {
    @StateObject private var state = PrivacyShieldState()

    func body(content: Content) -> some View {
        ZStack {
            CaptureProtectedContainer(captureState: state) {
                content
            }
            .ignoresSafeArea()

            if state.shouldCoverLocally {
                Color.black
                    .ignoresSafeArea()
                    .zIndex(999_999)
                    .accessibilityHidden(true)
            }
        }
    }
}

extension View {
    func htvantixPrivacyShield() -> some View {
        modifier(PrivacyShieldModifier())
    }
}
