import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var license: HTLicenseSession

    var body: some View {
        NavigationStack {
            ZStack {
                PremiumBackground()

                ScrollView {
                    VStack(spacing: 16) {
                        appCard
                        infoCard
                        licenseCard
                    }
                    .padding(18)
                }
            }
            .navigationTitle("ตั้งค่า")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(Color.black.opacity(0.96), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("เสร็จสิ้น") { dismiss() }
                        .fontWeight(.semibold)
                        .foregroundStyle(PremiumTheme.accent)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var appCard: some View {
        HStack(spacing: 14) {
            AppLogo(size: 52)
            VStack(alignment: .leading, spacing: 3) {
                Text("HTVANTIX")
                    .font(.title3.weight(.bold))
                    .foregroundStyle(.white)
                Text("เวอร์ชัน \(appVersion)")
                    .font(.subheadline)
                    .foregroundStyle(PremiumTheme.textSecondary)
            }
            Spacer()
        }
        .padding(18)
        .background(PremiumTheme.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(PremiumTheme.border, lineWidth: 1)
        }
    }

    private var infoCard: some View {
        VStack(spacing: 0) {
            row("รุ่นอุปกรณ์", AppInfo.displayMachineName)
            separator
            row("เวอร์ชัน iOS", "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
            separator
            row("รองรับ iOS", "17 • 18 • 26 • 27 Beta")
            separator
            HStack {
                Text("สถานะ")
                    .foregroundStyle(PremiumTheme.textSecondary)
                Spacer()
                Text(appState.isSupported ? "รองรับ" : "ไม่รองรับ")
                    .fontWeight(.bold)
                    .foregroundStyle(appState.isSupported ? Color.green : Color.orange)
            }
            .padding(.vertical, 15)
        }
        .padding(.horizontal, 18)
        .background(PremiumTheme.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(PremiumTheme.border, lineWidth: 1)
        }
    }

    private var licenseCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("LICENSE")
                .font(.caption2.weight(.bold))
                .tracking(1.4)
                .foregroundStyle(PremiumTheme.textTertiary)

            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("License Active")
                        .font(.headline)
                        .foregroundStyle(.white)
                    if let expiresAt = license.expiresAt, !expiresAt.isEmpty {
                        Text("หมดอายุ \(expiresAt)")
                            .font(.caption)
                            .foregroundStyle(PremiumTheme.textSecondary)
                    } else {
                        Text("สิทธิ์การใช้งานเปิดอยู่")
                            .font(.caption)
                            .foregroundStyle(PremiumTheme.textSecondary)
                    }
                }

                Spacer()

                Circle()
                    .fill(Color.green)
                    .frame(width: 9, height: 9)
                    .shadow(color: Color.green.opacity(0.65), radius: 7)
            }

            Button(role: .destructive) {
                dismiss()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                    license.signOut()
                }
            } label: {
                Text("เปลี่ยน License Key")
                    .font(.subheadline.weight(.bold))
                    .frame(maxWidth: .infinity)
                    .frame(height: 48)
            }
            .buttonStyle(.bordered)
            .tint(.red)
        }
        .padding(18)
        .background(PremiumTheme.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(PremiumTheme.border, lineWidth: 1)
        }
    }

    private var separator: some View {
        Rectangle()
            .fill(PremiumTheme.border)
            .frame(height: 1)
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            Text(title)
                .foregroundStyle(PremiumTheme.textSecondary)
            Spacer(minLength: 10)
            Text(value)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white)
                .multilineTextAlignment(.trailing)
        }
        .padding(.vertical, 15)
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "8.11"
    }
}
