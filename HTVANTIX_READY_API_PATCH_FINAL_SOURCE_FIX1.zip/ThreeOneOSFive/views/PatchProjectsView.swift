import SwiftUI
import UIKit
import UniformTypeIdentifiers

private enum HTVANTIXPatchAPI {
    static let baseURL = URL(string: "https://hightapi.netlify.app")!
    static let collectionPath = "cv/sp"

    static func fetch() async throws -> [HTRemotePatch] {
        var request = URLRequest(url: baseURL.appendingPathComponent(collectionPath))
        request.httpMethod = "GET"
        request.timeoutInterval = 15
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let token = Bundle.main.object(forInfoDictionaryKey: "HTVANTIX_APP_TOKEN") as? String,
           !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            request.setValue(token, forHTTPHeaderField: "X-App-Token")
        }
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response)
        let decoder = JSONDecoder()
        if let direct = try? decoder.decode([HTRemotePatch].self, from: data) { return direct }
        if let envelope = try? decoder.decode(HTPatchEnvelope.self, from: data) { return envelope.patches ?? [] }
        throw HTPatchAPIError.invalidResponse
    }

    static func download(_ patch: HTRemotePatch) async throws -> URL {
        let url = baseURL
            .appendingPathComponent(collectionPath)
            .appendingPathComponent(patch.id)
            .appendingPathComponent("download")
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 60
        if let token = Bundle.main.object(forInfoDictionaryKey: "HTVANTIX_APP_TOKEN") as? String,
           !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            request.setValue(token, forHTTPHeaderField: "X-App-Token")
        }
        let (temporaryURL, response) = try await URLSession.shared.download(for: request)
        try validate(response)
        let fileName = (patch.fileName?.isEmpty == false ? patch.fileName! : "\(patch.id).3105")
        let destination = FileManager.default.temporaryDirectory
            .appendingPathComponent("HTVANTIX-Remote", isDirectory: true)
            .appendingPathComponent(fileName)
        try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
        try FileManager.default.moveItem(at: temporaryURL, to: destination)
        return destination
    }

    private static func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { return }
        guard (200..<300).contains(http.statusCode) else { throw HTPatchAPIError.http(http.statusCode) }
    }
}

private enum HTPatchAPIError: LocalizedError {
    case invalidResponse
    case http(Int)
    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "ข้อมูลแพตช์จากเซิร์ฟเวอร์ไม่ตรงรูปแบบ"
        case .http(let code): return "เซิร์ฟเวอร์ตอบกลับ HTTP \(code)"
        }
    }
}

private struct HTPatchEnvelope: Decodable { let patches: [HTRemotePatch]? }

private struct HTRemotePatch: Identifiable, Decodable, Hashable {
    let id: String
    let gameId: String?
    let title: String
    let detail: String?
    let version: String?
    let fileName: String?
    let sizeBytes: Int64?
    let active: Bool

    enum CodingKeys: String, CodingKey {
        case id, gameId, game_id, title, name, detail, description, version, fileName, file_name, sizeBytes, size_bytes, active, enabled
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? c.decode(String.self, forKey: .id)) ?? UUID().uuidString
        gameId = (try? c.decodeIfPresent(String.self, forKey: .gameId)) ?? (try? c.decodeIfPresent(String.self, forKey: .game_id)) ?? nil
        title = (try? c.decode(String.self, forKey: .title)) ?? (try? c.decode(String.self, forKey: .name)) ?? "Free Fire Patch"
        detail = (try? c.decodeIfPresent(String.self, forKey: .detail)) ?? (try? c.decodeIfPresent(String.self, forKey: .description)) ?? nil
        version = try? c.decodeIfPresent(String.self, forKey: .version)
        fileName = (try? c.decodeIfPresent(String.self, forKey: .fileName)) ?? (try? c.decodeIfPresent(String.self, forKey: .file_name)) ?? nil
        sizeBytes = (try? c.decodeIfPresent(Int64.self, forKey: .sizeBytes)) ?? (try? c.decodeIfPresent(Int64.self, forKey: .size_bytes)) ?? nil
        active = (try? c.decode(Bool.self, forKey: .active)) ?? (try? c.decode(Bool.self, forKey: .enabled)) ?? true
    }
}

struct PatchProjectsView: View {
    @StateObject private var store = PatchProjectStore()
    @State private var remotePatches: [HTRemotePatch] = []
    @State private var isLoadingRemote = false
    @State private var downloadingID: String?
    @State private var searchText = ""
    @State private var alertText: String?

    private var filteredRemote: [HTRemotePatch] {
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        let source = remotePatches.filter { patch in
            guard let game = patch.gameId?.lowercased(), !game.isEmpty else { return true }
            return game.contains("free") || game.contains("ff") || game.contains("garena")
        }
        guard !q.isEmpty else { return source }
        return source.filter { patch in
            if patch.title.localizedCaseInsensitiveContains(q) { return true }
            if let detail = patch.detail, detail.localizedCaseInsensitiveContains(q) { return true }
            return false
        }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    headerCard
                        .listRowInsets(EdgeInsets())
                        .listRowBackground(Color.clear)
                }

                Section("ฟังก์ชันจากเซิร์ฟเวอร์") {
                    if isLoadingRemote {
                        HStack(spacing: 10) {
                            ProgressView()
                            Text("กำลังโหลดรายการแพตช์…").foregroundStyle(.secondary)
                        }
                    } else if filteredRemote.isEmpty {
                        VStack(spacing: 8) {
                            Image(systemName: "shippingbox")
                                .font(.system(size: 28))
                                .foregroundStyle(AppTheme.accent)
                            Text("ยังไม่มีฟังก์ชัน").font(.headline)
                            Text("ดึงรายการจาก hightapi.netlify.app/cv/sp")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 18)
                    } else {
                        ForEach(filteredRemote) { patch in remoteRow(patch) }
                    }
                }

                if !store.items.isEmpty {
                    Section("แพตช์ที่พร้อมใช้งาน") {
                        ForEach(store.items) { item in
                            if item.isLocked {
                                Button { store.requestUnlock(for: item) } label: {
                                    HStack(spacing: 12) {
                                        Image(systemName: "lock.fill")
                                            .foregroundStyle(AppTheme.accent)
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(item.project?.name ?? "HTVANTIX Patch")
                                                .font(.headline)
                                                .foregroundStyle(.primary)
                                            Text("แตะเพื่อปลดล็อกแพ็กเกจ")
                                                .font(.caption)
                                                .foregroundStyle(.secondary)
                                        }
                                        Spacer()
                                        Image(systemName: "chevron.right")
                                            .foregroundStyle(.tertiary)
                                    }
                                    .contentShape(Rectangle())
                                }
                                .buttonStyle(.plain)
                            } else {
                                HTVANTIXPatchToggleRow(store: store, item: item)
                            }
                        }
                    } footer: {
                        Text("เปิดสวิตช์เพื่อ Apply ไฟล์แพตช์ ปิดสวิตช์เพื่อ Restore ไฟล์ต้นฉบับจาก Backup เดิมของ Patch Engine")
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("แพตช์ Free Fire")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $searchText, prompt: "ค้นหาฟังก์ชัน")
            .refreshable { await loadRemote() }
            .task { await loadRemote() }
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { _ in
                PatchUnlockView(store: store)
            }
            .alert("HTVANTIX", isPresented: alertPresented) {
                Button("ตกลง", role: .cancel) { alertText = nil }
            } message: { Text(alertText ?? "") }
        }
    }

    private var alertPresented: Binding<Bool> {
        Binding(
            get: { alertText != nil },
            set: { isPresented in
                if !isPresented { alertText = nil }
            }
        )
    }

    private var headerCard: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(Color.black.gradient)
                Image(systemName: "scope")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundStyle(.white)
            }
            .frame(width: 66, height: 66)
            VStack(alignment: .leading, spacing: 5) {
                Text("FREE FIRE").font(.title3.bold())
                Text("HTVANTIX PATCH CENTER")
                    .font(.caption2.weight(.bold).monospaced())
                    .foregroundStyle(AppTheme.accent)
                Text("รายการด้านล่างอัปเดตจาก API ของคุณ")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .padding(.vertical, 4)
    }

    private func remoteRow(_ patch: HTRemotePatch) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(patch.title).font(.headline)
                    if let detail = patch.detail, !detail.isEmpty {
                        Text(detail).font(.caption).foregroundStyle(.secondary).lineLimit(3)
                    }
                }
                Spacer()
                Text(patch.active ? "พร้อม" : "ปิด")
                    .font(.caption2.bold())
                    .foregroundStyle(patch.active ? Color.green : Color.secondary)
                    .padding(.horizontal, 9).padding(.vertical, 5)
                    .background((patch.active ? Color.green : Color.gray).opacity(0.12), in: Capsule())
            }
            HStack(spacing: 12) {
                if let version = patch.version { Label(version, systemImage: "number") }
                if let bytes = patch.sizeBytes { Label(ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file), systemImage: "internaldrive") }
            }
            .font(.caption2).foregroundStyle(.secondary)

            Button {
                Task { await installRemote(patch) }
            } label: {
                HStack {
                    if downloadingID == patch.id { ProgressView().tint(.white) }
                    else { Image(systemName: "arrow.down.circle.fill") }
                    Text(downloadingID == patch.id ? "กำลังดาวน์โหลด…" : "ดาวน์โหลดและเพิ่มแพตช์")
                    Spacer()
                }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white)
                .padding(.horizontal, 14).frame(height: 42)
                .background(AppTheme.accent.gradient, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(!patch.active || downloadingID != nil)
        }
        .padding(.vertical, 6)
    }

    @MainActor
    private func loadRemote() async {
        isLoadingRemote = true
        defer { isLoadingRemote = false }
        do { remotePatches = try await HTVANTIXPatchAPI.fetch() }
        catch { remotePatches = []; alertText = error.localizedDescription }
    }

    @MainActor
    private func installRemote(_ patch: HTRemotePatch) async {
        downloadingID = patch.id
        defer { downloadingID = nil }
        do {
            let url = try await HTVANTIXPatchAPI.download(patch)
            store.importPackage(at: url)
            alertText = "ดาวน์โหลดสำเร็จ ระบบกำลังเพิ่มแพ็กเกจเข้าสู่ HTVANTIX Core"
        } catch { alertText = error.localizedDescription }
    }
}


private struct HTVANTIXPatchToggleRow: View {
    @ObservedObject var store: PatchProjectStore
    let item: PatchLibraryItem

    @State private var isApplied = false
    @State private var isWorking = false
    @State private var message: String?

    private var project: PatchProject? { item.project }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(project?.name ?? "HTVANTIX Patch")
                        .font(.headline)
                    Text(isApplied ? "กำลังใช้งานแพตช์" : "ไฟล์ปกติ")
                        .font(.caption)
                        .foregroundStyle(isApplied ? Color.green : Color.secondary)
                }
                Spacer()
                if isWorking {
                    ProgressView()
                } else {
                    Toggle("", isOn: Binding(
                        get: { isApplied },
                        set: { newValue in
                            guard newValue != isApplied else { return }
                            if newValue { applyPatch() } else { restoreOriginal() }
                        }
                    ))
                    .labelsHidden()
                    .tint(AppTheme.accent)
                }
            }

            HStack(spacing: 10) {
                Label("\(project?.rules.count ?? 0) ไฟล์", systemImage: "doc.on.doc")
                if let project {
                    Label("\(project.allBundleIdentifiers.count) แอป", systemImage: "app.dashed")
                }
                Spacer()
                NavigationLink {
                    PatchProjectDetailView(store: store, projectID: item.id)
                } label: {
                    Label("รายละเอียด", systemImage: "chevron.right")
                        .labelStyle(.titleAndIcon)
                }
                .font(.caption.weight(.semibold))
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding(.vertical, 6)
        .onAppear { refreshAppliedState() }
        .alert("HTVANTIX", isPresented: Binding(
            get: { message != nil },
            set: { if !$0 { message = nil } }
        )) {
            Button("ตกลง", role: .cancel) { message = nil }
        } message: {
            Text(message ?? "")
        }
    }

    private func refreshAppliedState() {
        isApplied = DevicePatchService.latestReceipt(projectID: item.id) != nil
    }

    private func applyPatch() {
        guard let baseProject = project, !isWorking else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let projectToApply = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: projectToApply)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    isApplied = true
                    message = "เปิดใช้งานแพตช์แล้ว ระบบสำรองไฟล์ต้นฉบับไว้สำหรับ Restore เรียบร้อย"
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    refreshAppliedState()
                    message = error.localizedDescription
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    refreshAppliedState()
                    message = "ไม่สามารถเปิดใช้งานแพตช์ได้"
                }
            }
        }
    }

    private func restoreOriginal() {
        guard !isWorking,
              let receipt = DevicePatchService.latestReceipt(projectID: item.id) else {
            refreshAppliedState()
            return
        }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    isApplied = false
                    message = "ปิดแพตช์แล้ว และคืนไฟล์ต้นฉบับจาก Backup เรียบร้อย"
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    refreshAppliedState()
                    message = error.localizedDescription
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    refreshAppliedState()
                    message = "ไม่สามารถคืนไฟล์ต้นฉบับได้อย่างปลอดภัย"
                }
            }
        }
    }
}

private struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in
                            store.clearUnlockError()
                        }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text(language.text("patch.password_once_message"))
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showEditor = false
    @State private var editingRule: PatchRule?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?
    @State private var shareRequest: PatchShareRequest?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    var body: some View {
        List {
            if let item, let project = item.project {
                if isWorkspaceProject {
                    Section {
                        ForEach(project.allBundleIdentifiers, id: \.self) { bundleID in
                            Label {
                                Text(bundleID)
                                    .font(.subheadline.monospaced())
                            } icon: {
                                Image(systemName: "app.dashed")
                                    .foregroundStyle(AppTheme.accent)
                            }
                        }
                        LabeledContent(language.text("patch.files")) {
                            Text("\(project.rules.count)")
                        }
                        LabeledContent(language.text("patch.folders")) {
                            Text("\(project.directories.count)")
                        }
                        if let workspaceURL = item.workspaceURL {
                            NavigationLink {
                                FileBrowserView(
                                    containerPath: workspaceURL.path,
                                    title: project.name,
                                    bundleID: nil
                                )
                            } label: {
                                Label(
                                    language.text("patch.open_workspace"),
                                    systemImage: "folder"
                                )
                            }
                        }
                    } header: {
                        Text(language.text("patch.workspace"))
                    } footer: {
                        Text(language.text("patch.workspace_detail_footer"))
                    }
                } else {
                    Section {
                        ForEach(project.rules) { rule in
                            Button {
                                editingRule = rule
                            } label: {
                                HStack(spacing: 10) {
                                    ruleSummary(rule)
                                    Spacer(minLength: 8)
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityHint(language.text("patch.edit_rule_hint"))
                        }
                    } header: {
                        Text(language.text("patch.rules"))
                    } footer: {
                        Text(language.text("patch.legacy_footer"))
                    }
                }

                Section(language.text("patch.password")) {
                    HStack(spacing: 12) {
                        Image(systemName: item.summary.isPasswordProtected ? "lock.fill" : "lock.open")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)
                        Text(language.text(item.summary.isPasswordProtected
                            ? "patch.password_locked"
                            : "patch.no_password"))
                            .font(.subheadline)
                    }
                }

                Section {
                    Button {
                        showApplyConfirmation = true
                    } label: {
                        actionLabel("patch.apply", systemImage: "checkmark.shield.fill")
                    }
                    .disabled(isWorking)

                    if receipt != nil {
                        Button(role: .destructive) {
                            showRestoreConfirmation = true
                        } label: {
                            actionLabel("patch.restore", systemImage: "arrow.uturn.backward.circle")
                        }
                        .disabled(isWorking)
                    }

                    Button(action: prepareExport) {
                        actionLabel("patch.export", systemImage: "square.and.arrow.up")
                    }
                    .disabled(isWorking)
                } footer: {
                    Text(language.text("patch.apply_footer"))
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(item?.project?.name ?? language.text("patch.title"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                } else if !isWorkspaceProject {
                    Button(language.text("patch.edit")) { showEditor = true }
                        .disabled(item?.project == nil)
                }
            }
        }
        .sheet(isPresented: $showEditor) {
            if let item, let project = item.project {
                PatchProjectEditorView(
                    existingProject: project,
                    passwordIsProtected: item.summary.isPasswordProtected
                ) { updatedProject, _ in
                    store.update(project: updatedProject)
                }
            }
        }
        .sheet(item: $editingRule) { rule in
            PatchRuleEditorView(rule: rule) { updatedRule in
                updateRule(updatedRule)
            }
        }
        .confirmationDialog(
            language.text("patch.apply_confirm_title"),
            isPresented: $showApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.apply")) { apply() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.apply_confirm_message"))
        }
        .confirmationDialog(
            language.text("patch.restore_confirm_title"),
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.restore"), role: .destructive) { restore() }
            Button(language.text("common.cancel"), role: .cancel) {}
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .sheet(item: $shareRequest) { request in
            PatchActivityView(items: [request.url])
                .ignoresSafeArea()
        }
    }

    private func actionLabel(_ key: String, systemImage: String) -> some View {
        Label(language.text(key), systemImage: systemImage)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func updateRule(_ updatedRule: PatchRule) {
        guard var project = item?.project,
              let index = project.rules.firstIndex(where: { $0.id == updatedRule.id }) else {
            return
        }
        project.rules[index] = updatedRule
        project.updatedAt = Date()
        do {
            try PatchPackageCodec.validate(project)
            store.update(project: project)
        } catch let error as PatchPackageError {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: error.localizationKey,
                messageArgument: error.localizationArgument
            )
        } catch {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func prepareExport() {
        guard let item else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                if item.summary.schemaVersion >= 2 {
                    _ = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                }
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    shareRequest = PatchShareRequest(url: item.packageURL)
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.invalid_project"
                    )
                }
            }
        }
    }

    private func restore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}

private struct PatchShareRequest: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PatchActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(
        _ uiViewController: UIActivityViewController,
        context: Context
    ) {}
}
