import SwiftUI
import CryptoKit

struct GameHubView: View {
    @EnvironmentObject private var app: AppCoordinator
    let gameID: String
    let gameTitle: String
    let gameImage: String

    @State private var selectedCategory = "shoot"

    private var categories: [V4ClientConfig.Item] {
        app.config?.categories ?? [
            .init(id: "shoot", title: "ไฟล์ยิง"),
            .init(id: "visual", title: "ไฟล์มอง"),
            .init(id: "skin_free", title: "มอดสกิน ฟรี"),
            .init(id: "other", title: "อื่นๆ")
        ]
    }

    private var filtered: [RemotePackage] {
        app.packages.filter {
            $0.game == gameID && $0.category == selectedCategory
        }
    }

    var body: some View {
        ZStack {
            HTBackground()

            ScrollView {
                VStack(spacing: 14) {
                    categoryTabs

                    if filtered.isEmpty {
                        HTCard {
                            VStack(spacing: 10) {
                                Image(systemName: "tray")
                                    .font(.system(size: 30))
                                    .foregroundStyle(HTTheme.muted)
                                Text("ยังไม่มีรายการในหมวดนี้")
                                    .foregroundStyle(HTTheme.muted)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 20)
                        }
                    } else {
                        ForEach(filtered) { item in
                            FeatureToggleRow(package: item)
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 24)
            }
            .refreshable { await app.refreshPackages() }
        }
        .navigationTitle(gameTitle)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var categoryTabs: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 9) {
                ForEach(categories.filter { ["shoot", "visual", "skin_free", "other"].contains($0.id) }) { item in
                    Button {
                        selectedCategory = item.id
                    } label: {
                        Text(item.title)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(selectedCategory == item.id ? .black : .white)
                            .padding(.horizontal, 15)
                            .frame(height: 40)
                            .background(
                                selectedCategory == item.id ? HTTheme.accent : HTTheme.surface2,
                                in: Capsule()
                            )
                            .overlay(
                                Capsule().stroke(selectedCategory == item.id ? Color.clear : HTTheme.border)
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.vertical, 2)
        }
    }
}

private struct FeatureToggleRow: View {
    @EnvironmentObject private var app: AppCoordinator
    let package: RemotePackage

    @State private var isEnabled = false
    @State private var isWorking = false
    @State private var workingText = ""
    @State private var inlineStatus = ""

    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.white.opacity(0.045))
                    .frame(width: 58, height: 58)

                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundStyle(HTTheme.accent)
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(package.name)
                    .font(.system(size: 19, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(2)

                Text(statusText)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(isEnabled ? HTTheme.green : HTTheme.muted)
            }

            Spacer(minLength: 10)

            if isWorking {
                ProgressView()
                    .controlSize(.regular)
                    .tint(HTTheme.accent)
                    .frame(width: 52, height: 44)
            } else {
                Toggle("", isOn: toggleBinding)
                    .labelsHidden()
                    .tint(HTTheme.accent)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 15)
        .frame(maxWidth: .infinity, minHeight: 92)
        .background(
            Color(red: 0.035, green: 0.045, blue: 0.06),
            in: RoundedRectangle(cornerRadius: 22, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
        .onAppear {
            isEnabled = SafeDevicePatchService.isApplied(remotePackageID: package.id)
            inlineStatus = ""
        }
    }

    private var statusText: String {
        if isWorking { return workingText.isEmpty ? "กำลังดำเนินการ..." : workingText }
        if !inlineStatus.isEmpty { return inlineStatus }
        return isEnabled ? "เปิดอยู่" : "ปิดอยู่"
    }

    private var toggleBinding: Binding<Bool> {
        Binding(
            get: { isEnabled },
            set: { newValue in
                guard !isWorking else { return }
                if newValue {
                    enablePackage()
                } else {
                    disablePackage()
                }
            }
        )
    }

    private func enablePackage() {
        isWorking = true
        workingText = "กำลังเปิด..."

        Task {
            do {
                // API client checks SHA-256 and file size before returning this URL.
                let downloadedURL = try await app.download(package)

                await MainActor.run {
                    workingText = "กำลังเปิด..."
                }

                try PackageIntegrityVerifier.verify(downloadedURL, package: package)
                let stagedURL = try SafeDevicePatchService.stageVerifiedDownload(downloadedURL, package: package)
                let data = try Data(contentsOf: stagedURL, options: .mappedIfSafe)
                _ = try SafeDevicePatchService.apply(packageData: data, remotePackageID: package.id)

                await MainActor.run {
                    isEnabled = true
                    isWorking = false
                    workingText = ""
                    inlineStatus = "เปิดอยู่"
                }
            } catch {
                await MainActor.run {
                    isEnabled = SafeDevicePatchService.isApplied(remotePackageID: package.id)
                    isWorking = false
                    workingText = ""
                    inlineStatus = "ดำเนินการไม่สำเร็จ"
                }
            }
        }
    }

    private func disablePackage() {
        isWorking = true
        workingText = "กำลังปิด..."

        Task {
            do {
                try SafeDevicePatchService.restore(remotePackageID: package.id)
                try SafeDevicePatchService.removeDownloadedPackage(package)

                await MainActor.run {
                    isEnabled = false
                    isWorking = false
                    workingText = ""
                    inlineStatus = "ปิดอยู่"
                }
            } catch {
                await MainActor.run {
                    isEnabled = SafeDevicePatchService.isApplied(remotePackageID: package.id)
                    isWorking = false
                    workingText = ""
                    inlineStatus = "ดำเนินการไม่สำเร็จ"
                }
            }
        }
    }
}

/// Manages the package apply/restore lifecycle inside HTVANTIX's own iOS sandbox.
/// File metadata stays internal; the UI only exposes the feature name and on/off state.
private enum PackageIntegrityVerifier {
    static func verify(_ url: URL, package: RemotePackage) throws {
        let data = try Data(contentsOf: url)

        if package.sizeBytes > 0, data.count != package.sizeBytes {
            throw APIError.integrityFailed
        }

        let hash = SHA256.hash(data: data)
            .map { String(format: "%02x", $0) }
            .joined()

        guard hash.caseInsensitiveCompare(package.sha256) == .orderedSame else {
            throw APIError.integrityFailed
        }
    }
}
