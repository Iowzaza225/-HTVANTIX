import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var appState: AppState

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        AppLogo(size: 50)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("HTVANTIX").font(.headline)
                            Text("เวอร์ชัน \(appVersion)")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 5)
                }

                Section {
                    settingsRow("รุ่นอุปกรณ์", AppInfo.displayMachineName)
                    settingsRow("เวอร์ชัน iOS", "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                    HStack {
                        Text("สถานะรองรับ")
                        Spacer()
                        Text(appState.isSupported ? "รองรับ" : "ไม่รองรับ")
                            .fontWeight(.semibold)
                            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                } header: {
                    Text("อุปกรณ์")
                }

                Section {
                    settingsRow("เกม", "Free Fire")
                    settingsRow("เซิร์ฟเวอร์", "hightapi.netlify.app")
                    settingsRow("ระบบแพตช์", "HTVANTIX Core")
                } header: {
                    Text("ระบบ")
                } footer: {
                    Text("ระบบไฟล์และแพตช์ภายในยังใช้HTVANTIX Core สำหรับจัดการไฟล์ สำรอง และคืนค่า")
                }
            }
            .tint(AppTheme.accent)
            .navigationTitle("ตั้งค่า")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("เสร็จสิ้น") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }

    @ViewBuilder
    private func settingsRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title)
            Spacer(minLength: 12)
            Text(value)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.trailing)
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }
}
