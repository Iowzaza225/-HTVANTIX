import SwiftUI
import UIKit

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @StateObject private var remoteControl = HTVRemoteControl()
    @StateObject private var licenseManager = HTVLicenseManager()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("htvantix.screenPrivacyEnabled") private var screenPrivacyEnabled = false
    @State private var screenIsCaptured = UIScreen.main.isCaptured

    init() {
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environmentObject(remoteControl)
                    .environmentObject(licenseManager)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .opacity(licenseManager.requiresLicenseGate ? 0 : 1)
                    .allowsHitTesting(!licenseManager.requiresLicenseGate)

                if licenseManager.requiresLicenseGate {
                    HTVLicenseGateView()
                        .environmentObject(licenseManager)
                        .transition(.opacity.combined(with: .scale(scale: 0.985)))
                        .zIndex(2)
                }
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        UIApplication.shared.open(offer.url)
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .onAppear {
                appState.detectSupport()
                checkForUpdate()
                Task {
                    await licenseManager.bootstrap()
                    if licenseManager.isAuthorized { await remoteControl.refresh() }
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active else { return }
                appState.detectSupport()
                Task {
                    await licenseManager.bootstrap()
                    if licenseManager.isAuthorized { await remoteControl.refresh() }
                }
            }
            .overlay {
                if licenseManager.isAuthorized && !remoteControl.appEnabled {
                    ZStack {
                        Color.black.ignoresSafeArea()
                        VStack(spacing: 14) {
                            Image(systemName: "lock.shield.fill")
                                .font(.system(size: 42, weight: .bold))
                                .foregroundStyle(.cyan)
                            Text("HTVANTIX")
                                .font(.title2.weight(.black))
                                .foregroundStyle(.white)
                            Text("ระบบถูกปิดใช้งานชั่วคราว")
                                .font(.headline)
                                .foregroundStyle(.white)
                            if !remoteControl.message.isEmpty {
                                Text(remoteControl.message)
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                            }
                            Button("ตรวจสอบอีกครั้ง") {
                                Task { await remoteControl.refresh() }
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.cyan)
                        }
                        .padding(28)
                    }
                    .zIndex(1000)
                } else if screenPrivacyEnabled && (screenIsCaptured || scenePhase != .active) {
                    ZStack {
                        Color.black.ignoresSafeArea()
                        VStack(spacing: 12) {
                            Image(systemName: "shield.fill")
                                .font(.system(size: 34, weight: .semibold))
                                .foregroundStyle(.cyan)
                            Text("HTVANTIX")
                                .font(.headline.weight(.bold))
                                .foregroundStyle(.white)
                            Text("Screen Protection")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .transition(.opacity)
                    .zIndex(999)
                }
            }
            .onReceive(NotificationCenter.default.publisher(for: UIScreen.capturedDidChangeNotification)) { _ in
                screenIsCaptured = UIScreen.main.isCaptured
            }
            .onOpenURL { url in
                patchDraftCoordinator.presentImport(url)
            }
        }
    }
}

@MainActor
final class HTVRemoteControl: ObservableObject {
    @Published var appEnabled = true
    @Published var message = ""
    @Published var isChecking = false

    private let statusURL = URL(string: "https://hightapi.netlify.app/api/v4/status")!

    func refresh() async {
        guard !isChecking else { return }
        isChecking = true
        defer { isChecking = false }
        do {
            var request = URLRequest(url: statusURL)
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.timeoutInterval = 12
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
                  let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
            appEnabled = (object["appEnabled"] as? Bool) ?? true
            message = object["message"] as? String ?? ""
        } catch {
            // Network failure does not hard-lock an already installed client.
        }
    }
}


@MainActor
final class HTVLicenseManager: ObservableObject {
    @Published var isAuthorized = false
    @Published var isBusy = false
    @Published var message = ""

    private let baseURL = URL(string: "https://hightapi.netlify.app")!
    private let defaults = UserDefaults.standard

    var requiresLicenseGate: Bool { !isAuthorized }
    var storedKey: String { defaults.string(forKey: "htvantix.license.key") ?? "" }
    var storedStatus: String { defaults.string(forKey: "htvantix.license.status") ?? "" }
    var storedExpiresAt: String { defaults.string(forKey: "htvantix.license.expiresAt") ?? "" }

    var maskedKey: String {
        let key = storedKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return "—" }
        if key.count <= 10 { return key }
        return "\(key.prefix(5))••••\(key.suffix(5))"
    }

    var expiryText: String {
        let raw = storedExpiresAt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return "—" }
        let formatter = ISO8601DateFormatter()
        guard let date = formatter.date(from: raw) else { return raw }
        return date.formatted(date: .abbreviated, time: .shortened)
    }

    func bootstrap() async {
        if let session = defaults.string(forKey: "htvantix.client.sessionToken"), tokenIsUsable(session) {
            isAuthorized = true
            message = ""
            return
        }

        // Session หมดอายุ: ขอ session ใหม่จาก license token ที่มีอยู่ก่อน
        if let licenseToken = defaults.string(forKey: "htvantix.license.token"), tokenIsUsable(licenseToken) {
            do {
                try await createClientSession(licenseToken: licenseToken)
                isAuthorized = true
                message = ""
                return
            } catch {
                // ถ้า token เดิมใช้ไม่ได้ แต่มี key ที่เคยเปิดไว้ ให้ redeem ใหม่อัตโนมัติ
            }
        }

        if !storedKey.isEmpty {
            do {
                try await redeemAndCreateSession(key: storedKey, showBusy: false)
                return
            } catch {
                clearSessionOnly()
                isAuthorized = false
                message = error.localizedDescription
                return
            }
        }

        isAuthorized = false
    }

    func activate(key rawKey: String) async {
        let key = rawKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }
        do {
            try await redeemAndCreateSession(key: key, showBusy: true)
        } catch {
            isAuthorized = false
            message = error.localizedDescription
        }
    }

    func signOutLicense() {
        ["htvantix.license.key", "htvantix.license.expiresAt", "htvantix.license.status", "htvantix.license.token", "htvantix.client.sessionToken"].forEach {
            defaults.removeObject(forKey: $0)
        }
        isAuthorized = false
        message = ""
        objectWillChange.send()
    }

    private func redeemAndCreateSession(key: String, showBusy: Bool) async throws {
        if showBusy {
            isBusy = true
            message = "กำลังตรวจสอบคีย์…"
        }
        defer { if showBusy { isBusy = false } }

        var request = URLRequest(url: baseURL.appendingPathComponent("api/v4/license/redeem"))
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "key": key,
            "deviceId": persistentDeviceID,
            "appVersion": appVersion,
            "buildId": buildID,
            "deviceModel": AppInfo.displayMachineName
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw HTVLicenseError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            throw HTVLicenseError.server(http.statusCode, Self.serverError(data))
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let licenseToken = root["licenseToken"] as? String,
              let license = root["license"] as? [String: Any] else {
            throw HTVLicenseError.invalidResponse
        }

        defaults.set(key, forKey: "htvantix.license.key")
        defaults.set(licenseToken, forKey: "htvantix.license.token")
        defaults.set(license["status"] as? String ?? "active", forKey: "htvantix.license.status")
        defaults.set(license["expiresAt"] as? String ?? "", forKey: "htvantix.license.expiresAt")

        try await createClientSession(licenseToken: licenseToken)
        isAuthorized = true
        message = "เปิดใช้งานสำเร็จ"
        objectWillChange.send()
    }

    private func createClientSession(licenseToken: String) async throws {
        var request = URLRequest(url: baseURL.appendingPathComponent("api/v4/session"))
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(licenseToken)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "deviceId": persistentDeviceID,
            "appVersion": appVersion,
            "buildId": buildID
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw HTVLicenseError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            throw HTVLicenseError.server(http.statusCode, Self.serverError(data))
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let session = root["sessionToken"] as? String else {
            throw HTVLicenseError.invalidResponse
        }
        defaults.set(session, forKey: "htvantix.client.sessionToken")
    }

    private func clearSessionOnly() {
        defaults.removeObject(forKey: "htvantix.client.sessionToken")
    }

    private var persistentDeviceID: String {
        let key = "htvantix.device.id"
        if let existing = defaults.string(forKey: key), existing.count >= 12 { return existing }
        let value = "ios-" + UUID().uuidString.lowercased()
        defaults.set(value, forKey: key)
        return value
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private var buildID: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
    }

    private func tokenIsUsable(_ token: String) -> Bool {
        let parts = token.split(separator: ".")
        guard parts.count == 3,
              let data = Self.base64URLDecode(String(parts[1])),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let exp = object["exp"] as? NSNumber else { return false }
        return exp.doubleValue > Date().timeIntervalSince1970 + 30
    }

    private static func base64URLDecode(_ value: String) -> Data? {
        var text = value.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        let remainder = text.count % 4
        if remainder != 0 { text += String(repeating: "=", count: 4 - remainder) }
        return Data(base64Encoded: text)
    }

    private static func serverError(_ data: Data) -> String {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return "" }
        return object["error"] as? String ?? object["message"] as? String ?? ""
    }
}

private enum HTVLicenseError: LocalizedError {
    case invalidResponse
    case server(Int, String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse:
            return "ข้อมูลตอบกลับจากเซิร์ฟเวอร์ไม่ถูกต้อง"
        case .server(let code, let message):
            let readable: String
            switch message {
            case "LICENSE_NOT_FOUND": readable = "ไม่พบคีย์นี้"
            case "LICENSE_EXPIRED": readable = "คีย์หมดอายุแล้ว"
            case "LICENSE_DISABLED": readable = "คีย์ถูกปิดใช้งาน"
            case "DEVICE_MISMATCH": readable = "คีย์นี้ผูกกับอุปกรณ์อื่นแล้ว"
            case "RATE_LIMIT": readable = "ลองใหม่อีกครั้งในภายหลัง"
            case "SERVER_NOT_CONFIGURED": readable = "เซิร์ฟเวอร์ยังตั้งค่าระบบ Session ไม่ครบ"
            default: readable = message.isEmpty ? "Server HTTP \(code)" : message
            }
            return "\(readable) (HTTP \(code))"
        }
    }
}

struct HTVLicenseGateView: View {
    @EnvironmentObject private var licenseManager: HTVLicenseManager
    @State private var keyInput = ""
    @FocusState private var keyFocused: Bool

    var body: some View {
        ZStack {
            Color(red: 0.015, green: 0.025, blue: 0.03).ignoresSafeArea()

            VStack(spacing: 26) {
                Spacer()

                ZStack {
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .fill(Color.cyan.opacity(0.10))
                        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.cyan.opacity(0.35), lineWidth: 1))
                        .frame(width: 92, height: 92)
                    Image(systemName: "key.fill")
                        .font(.system(size: 38, weight: .bold))
                        .foregroundStyle(.cyan)
                }

                VStack(spacing: 8) {
                    Text("HTVANTIX")
                        .font(.system(size: 32, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text("License Activation")
                        .font(.headline)
                        .foregroundStyle(.cyan)
                    Text("กรอกคีย์เพื่อเปิดใช้งานและเชื่อมต่อระบบไฟล์")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }

                VStack(spacing: 14) {
                    TextField("HTV-XXXX-XXXX-XXXX", text: $keyInput)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .font(.system(.body, design: .monospaced).weight(.semibold))
                        .padding(.horizontal, 16)
                        .frame(height: 56)
                        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.cyan.opacity(keyFocused ? 0.8 : 0.25), lineWidth: 1))
                        .foregroundStyle(.white)
                        .focused($keyFocused)

                    Button {
                        keyFocused = false
                        Task { await licenseManager.activate(key: keyInput) }
                    } label: {
                        HStack(spacing: 10) {
                            if licenseManager.isBusy { ProgressView().tint(.black) }
                            Text(licenseManager.isBusy ? "กำลังตรวจสอบ…" : "เปิดใช้งาน")
                                .font(.headline.weight(.bold))
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.black)
                    .background(Color.cyan, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .disabled(licenseManager.isBusy || keyInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    .opacity((licenseManager.isBusy || keyInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) ? 0.55 : 1)

                    if !licenseManager.message.isEmpty && !licenseManager.isAuthorized {
                        Text(licenseManager.message)
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .multilineTextAlignment(.center)
                    }
                }
                .padding(.horizontal, 30)

                Spacer()

                HStack(spacing: 8) {
                    Image(systemName: "lock.shield.fill")
                    Text("License • Session • Secure API")
                }
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
                .padding(.bottom, 24)
            }
        }
        .onAppear { keyFocused = licenseManager.storedKey.isEmpty }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}
