import Foundation
import Security

struct SecureStore {
    private let service = "com.htblackshop.htvantix.secure"

    func save(_ value: String, account: String) throws {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)

        var insert = base
        insert[kSecValueData as String] = Data(value.utf8)
        // ThisDeviceOnly: survives normal app reinstall on the same device,
        // but is not migrated/restored to another device.
        insert[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly

        let status = SecItemAdd(insert as CFDictionary, nil)
        guard status == errSecSuccess else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status))
        }
    }

    func load(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    func clear(account: String) {
        SecItemDelete([
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ] as CFDictionary)
    }
}

enum DeviceIdentity {
    private static let keychainAccount = "v4-device-id"
    private static let legacyDefaultsKey = "com.htblackshop.device-id"

    /// Stable per-device ID stored in Keychain instead of UserDefaults.
    /// This keeps the same device binding after a normal uninstall/reinstall
    /// when the app is signed with the same signing identity/access group.
    static var id: String {
        let store = SecureStore()

        if let existing = store.load(account: keychainAccount), !existing.isEmpty {
            return existing
        }

        // One-time migration for customers who already used the old build.
        if let legacy = UserDefaults.standard.string(forKey: legacyDefaultsKey), !legacy.isEmpty {
            try? store.save(legacy, account: keychainAccount)
            return legacy
        }

        let newValue = UUID().uuidString
        try? store.save(newValue, account: keychainAccount)
        return newValue
    }
}
