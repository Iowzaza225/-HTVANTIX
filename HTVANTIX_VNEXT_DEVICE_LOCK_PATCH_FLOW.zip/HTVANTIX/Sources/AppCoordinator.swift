import Foundation

@MainActor
final class AppCoordinator: ObservableObject {
    enum State: Equatable {
        case booting
        case locked
        case ready
        case updateRequired(V4VersionState)
        case maintenance(V4VersionState?)
        case blocked(V4VersionState?)
        case error(String)
    }

    @Published private(set) var state: State = .booting
    @Published private(set) var config: V4ClientConfig?
    @Published private(set) var packages: [RemotePackage] = []
    @Published private(set) var licenseInfo: LicenseInfo?
    @Published var isWorking = false

    private let secure = SecureStore()
    private let api = V4APIClient()
    private let licenseAccount = "v4-license-token"
    private let licenseKeyAccount = "v4-license-key"
    private let sessionAccount = "v4-client-session"

    var sessionToken: String? { secure.load(account: sessionAccount) }

    func bootstrap() async {
        if let licenseToken = secure.load(account: licenseAccount), !licenseToken.isEmpty {
            await establishSession(using: licenseToken)
            return
        }

        // Reinstall/session recovery: if the raw key is still in Keychain,
        // redeem it automatically so the customer does not need to type it again.
        if let savedKey = secure.load(account: licenseKeyAccount), !savedKey.isEmpty {
            await activate(key: savedKey)
            return
        }

        state = .locked
    }

    func activate(key: String) async {
        let value = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else {
            state = .error("กรุณากรอก License Key")
            return
        }

        isWorking = true
        defer { isWorking = false }

        do {
            let redeem = try await api.redeemLicense(key: value)
            try secure.save(value, account: licenseKeyAccount)
            try secure.save(redeem.licenseToken, account: licenseAccount)
            licenseInfo = redeem.license
            try handleVersionState(redeem.client)
            await establishSession(using: redeem.licenseToken)
        } catch {
            handle(error)
        }
    }

    private func establishSession(using licenseToken: String) async {
        isWorking = true
        defer { isWorking = false }

        do {
            let result = try await api.createSession(licenseToken: licenseToken)
            try secure.save(result.sessionToken, account: sessionAccount)
            try handleVersionState(result.client)
            let loadedConfig = try await api.loadConfig(sessionToken: result.sessionToken)
            config = loadedConfig
            try handleVersionState(loadedConfig.version)
            packages = try await api.loadPackages(sessionToken: result.sessionToken)
            state = .ready
        } catch {
            handle(error)
        }
    }

    func refreshPackages() async {
        guard let token = sessionToken else {
            await bootstrap()
            return
        }

        do {
            packages = try await api.loadPackages(sessionToken: token)
        } catch APIError.server(status: 401, code: _, client: _) {
            await bootstrap()
        } catch {
            handle(error)
        }
    }

    func download(_ package: RemotePackage) async throws -> URL {
        guard let token = sessionToken else {
            throw APIError.server(status: 401, code: "SESSION_REQUIRED", client: nil)
        }
        return try await api.downloadPackage(package, sessionToken: token)
    }

    func signOut() {
        secure.clear(account: licenseAccount)
        secure.clear(account: licenseKeyAccount)
        secure.clear(account: sessionAccount)
        config = nil
        packages = []
        licenseInfo = nil
        state = .locked
    }

    func clearError() {
        if case .error = state { state = .locked }
    }

    private func handleVersionState(_ version: V4VersionState?) throws {
        guard let version else { return }
        if version.maintenance {
            state = .maintenance(version)
            throw FlowStop()
        }

        if !version.allowedBuilds.isEmpty,
           !version.allowedBuilds.contains(BuildIdentity.buildID) {
            state = .blocked(version)
            throw FlowStop()
        }
    }

    private func handle(_ error: Error) {
        if error is FlowStop { return }

        if case let APIError.server(_, code, client) = error {
            switch code {
            case "UPDATE_REQUIRED":
                if let client { state = .updateRequired(client) }
                else { state = .error(code) }
            case "MAINTENANCE":
                state = .maintenance(client)
            case "BUILD_BLOCKED":
                state = .blocked(client)
            case "SESSION_REQUIRED":
                secure.clear(account: sessionAccount)
                state = .locked
            case "LICENSE_SESSION_REQUIRED":
                secure.clear(account: sessionAccount)
                secure.clear(account: licenseAccount)
                if let savedKey = secure.load(account: licenseKeyAccount), !savedKey.isEmpty {
                    Task { await self.activate(key: savedKey) }
                } else {
                    state = .locked
                }
            case "LICENSE_EXPIRED", "LICENSE_REVOKED":
                secure.clear(account: sessionAccount)
                secure.clear(account: licenseAccount)
                secure.clear(account: licenseKeyAccount)
                state = .locked
            default:
                state = .error(userMessage(for: code))
            }
            return
        }

        state = .error(error.localizedDescription)
    }

    private func userMessage(for code: String) -> String {
        switch code {
        case "DEVICE_MISMATCH": return "คีย์นี้ถูกผูกกับอุปกรณ์อื่น"
        case "RATE_LIMIT": return "ลองใหม่อีกครั้งภายหลัง"
        case "CLIENT_NOT_CONFIGURED": return "Client configuration missing"
        case "BAD_REQUEST": return "ข้อมูลไม่ถูกต้อง"
        default: return code
        }
    }
}

private struct FlowStop: Error {}
