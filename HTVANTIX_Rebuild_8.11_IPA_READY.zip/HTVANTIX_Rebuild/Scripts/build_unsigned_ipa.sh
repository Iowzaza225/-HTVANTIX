#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PROJECT="HTVANTIX.xcodeproj"
SCHEME="HTVANTIX"
CONFIGURATION="Release"
BUILD_DIR="$ROOT/build"
DERIVED_DATA="$BUILD_DIR/DerivedData"
OUTPUT_DIR="$BUILD_DIR/output"

rm -rf "$BUILD_DIR"
mkdir -p "$OUTPUT_DIR"

xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration "$CONFIGURATION" \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$DERIVED_DATA" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  build

APP_PATH=$(find "$DERIVED_DATA/Build/Products/$CONFIGURATION-iphoneos" -maxdepth 1 -name '*.app' -print -quit)
if [[ -z "${APP_PATH:-}" ]]; then
  echo "No .app produced" >&2
  exit 1
fi

PAYLOAD="$OUTPUT_DIR/Payload"
mkdir -p "$PAYLOAD"
cp -R "$APP_PATH" "$PAYLOAD/"

IPA="$OUTPUT_DIR/HTVANTIX_8.11_unsigned.ipa"
(
  cd "$OUTPUT_DIR"
  /usr/bin/zip -qry "$IPA" Payload
)

rm -rf "$PAYLOAD"
echo "Created: $IPA"
