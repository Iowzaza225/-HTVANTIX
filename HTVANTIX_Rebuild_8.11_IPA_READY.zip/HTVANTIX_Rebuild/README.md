# HTVANTIX 8.11 — Reconstructed Source Project

This Xcode project is a clean reconstruction made from the compiled **HTVANTIX 8.11 (build 68)** IPA after the original source was lost. It is not a byte-for-byte decompilation: optimized/compiled Swift cannot be perfectly converted back to the original `.swift` files.

## What is reconstructed

- Xcode project and SwiftUI app entry point
- Product identity: **HTVANTIX 8.11 (68)**
- Original HTVANTIX icon/logo recovered from the IPA
- Dark rounded-card UI for Splash, License, Games, Modules, Settings, Announcement, Maintenance, and network protection
- Original preference keys:
  - `com.htblackshop.license`
  - `com.htblackshop.device-id`
- Original backend base URL:
  - `https://hightapi.netlify.app`
- Recovered API routes:
  - `api/keys/redeem` — License redemption
  - `api/keys/status` — License status
  - `cv/sg` — game catalog
  - `cv/sp` — module/patch catalog
  - `cv/sc` — containers
  - `cv/sn?build=68` — remote notice / maintenance state
  - `cv/sa` — auxiliary route recovered from the binary; exact semantic role was not provable from static analysis
- Recovered module download pattern:
  - `cv/sp/{patch-id}/download`
- Recovered hub request header names:
  - `X-App-Token`
  - `X-Device-Id`
- Recovered License request form fields:
  - `code`
  - `deviceId`
  - `deviceModel`
- Recovered License signing header names:
  - `X-App-Token`
  - `X-Request-Time`
  - `X-Request-Nonce`
  - `X-Request-Sig`
- Flexible data models for games, patches, containers, announcement and maintenance state.
- Preview Mode so every reconstructed UI screen can be tested without pretending a License was activated.

## Backend credentials — intentionally blank

The compiled IPA contained reusable backend credential material. This project intentionally does **not** redistribute those values.

Before enabling the live backend, rotate/reissue your credentials on the server and set new values in either:

- `HTVANTIX/Info.plist`
  - `HTVANTIX_APP_TOKEN`
  - `HTVANTIX_SIGNING_SECRET`
- or Xcode Scheme environment variables with the same names.

`HTRequestSigner.swift` is deliberately a boundary rather than a recreation of the old secret-based signer. Connect it to a new signing implementation that matches your backend after credential rotation.

The Online Hub can be wired with a new app token immediately. Live License activation also requires your new request signer.

## Safe limitation of this rebuild

The original compiled IPA included low-level functionality capable of accessing/replacing files outside the normal app sandbox. That exploit/cross-app patch engine is **not** reconstructed here.

The recovered project supports the safe flow:

`Splash → License/Preview → Games → Modules → Download/Export package → Settings`

Downloaded packages are not applied to another application by this source project.

## Open in Xcode

1. Unzip the project.
2. Open `HTVANTIX.xcodeproj`.
3. Select the **HTVANTIX** target.
4. Open **Signing & Capabilities** and select your Apple Development Team.
5. Change the bundle identifier if required.
6. Run on iOS 16 or newer.
7. Use **Preview Interface** on the License screen to inspect the full recovered UI without backend credentials.

## Bundle identifier

The IPA used `com.apple.mobile.MobileHouseArrest`, which resembles an Apple system-service identifier. The rebuild uses the normal app identifier:

`com.htblackshop.htvantix`

## Validation performed

- All Swift source files: `swiftc -parse` passed with zero syntax errors.
- `Info.plist`: `plutil -lint` passed.
- `project.pbxproj`: `plutil -lint` passed.
- Every `.swift` file is referenced by the Xcode project Sources build phase.

A full iOS link/build still needs Xcode/macOS, Apple SDKs, and your signing team.

## Build an unsigned IPA

This project includes `Scripts/build_unsigned_ipa.sh`. On macOS with Xcode installed, run:

```bash
./Scripts/build_unsigned_ipa.sh
```

The result will be `build/output/HTVANTIX_8.11_unsigned.ipa`.

A GitHub Actions workflow is included at `.github/workflows/build-ipa.yml`. In a repository with Actions enabled, **Run workflow** builds the same unsigned IPA on a macOS runner and uploads it as an artifact.

The IPA is intentionally unsigned. Sign it with your own authorized Apple/development/enterprise signing method before installing it on a device.
