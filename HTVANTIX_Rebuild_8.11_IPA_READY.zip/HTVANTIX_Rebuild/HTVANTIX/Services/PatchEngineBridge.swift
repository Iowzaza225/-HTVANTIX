import Foundation

// Kept only as a compatibility boundary for future, authorized functionality.
// This rebuild intentionally does not restore the original sandbox-escape or
// cross-application file replacement engine found in the compiled IPA.
protocol PatchEngineBridging {
    func apply(_ patch: RemotePatchSummary, to game: RemoteGameSummary) async throws
    func restore(_ patch: RemotePatchSummary, for game: RemoteGameSummary) async throws
}

struct DisabledPatchEngine: PatchEngineBridging {
    func apply(_ patch: RemotePatchSummary, to game: RemoteGameSummary) async throws {
        throw PatchEngineError.notAvailable
    }

    func restore(_ patch: RemotePatchSummary, for game: RemoteGameSummary) async throws {
        throw PatchEngineError.notAvailable
    }
}

enum PatchEngineError: LocalizedError {
    case notAvailable

    var errorDescription: String? {
        "The low-level cross-app patch engine is not included in this recovered source project."
    }
}
