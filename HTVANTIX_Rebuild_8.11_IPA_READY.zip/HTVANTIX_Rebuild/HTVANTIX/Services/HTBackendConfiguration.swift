import Foundation

enum HTBackendConfiguration {
    // Recovered from the HTVANTIX 8.11 IPA.
    static let baseURL = URL(string: "https://hightapi.netlify.app")!
    static let buildNumber = 68

    // Do not embed the credentials recovered from a compiled IPA.
    // Rotate/reissue credentials on your backend, then add the NEW values in
    // Info.plist or as scheme environment variables in Xcode.
    static var appToken: String {
        configurationValue(named: "HTVANTIX_APP_TOKEN")
    }

    static var requestSigningSecret: String {
        configurationValue(named: "HTVANTIX_SIGNING_SECRET")
    }

    static var isHubConfigured: Bool { !appToken.isEmpty }
    static var isLicenseSigningConfigured: Bool {
        !appToken.isEmpty && !requestSigningSecret.isEmpty
    }

    private static func configurationValue(named name: String) -> String {
        if let env = ProcessInfo.processInfo.environment[name], !env.isEmpty {
            return env
        }
        if let plistValue = Bundle.main.object(forInfoDictionaryKey: name) as? String,
           !plistValue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return plistValue
        }
        return ""
    }
}
