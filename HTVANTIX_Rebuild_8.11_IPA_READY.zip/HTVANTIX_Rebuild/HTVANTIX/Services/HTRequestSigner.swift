import Foundation

protocol HTRequestSigning {
    func signedHeaders(for request: URLRequest, body: Data?) throws -> [String: String]
}

struct MissingLegacyRequestSigner: HTRequestSigning {
    func signedHeaders(for request: URLRequest, body: Data?) throws -> [String: String] {
        throw HTAPIError.credentialsMissing(
            "License signing credentials are intentionally not recovered from the compiled IPA. Rotate the backend secret and connect a fresh signer implementation."
        )
    }
}
