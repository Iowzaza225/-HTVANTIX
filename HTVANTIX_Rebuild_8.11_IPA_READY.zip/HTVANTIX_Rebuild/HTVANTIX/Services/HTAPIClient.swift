import Foundation

struct HTAPIClient {
    let baseURL: URL
    let signer: HTRequestSigning
    private let decoder = JSONDecoder()

    init(
        baseURL: URL = HTBackendConfiguration.baseURL,
        signer: HTRequestSigning = MissingLegacyRequestSigner()
    ) {
        self.baseURL = baseURL
        self.signer = signer
    }

    enum Route {
        // Recovered from HTVANTIX 8.11 binary.
        static let redeemKey = "api/keys/redeem"
        static let keyStatus = "api/keys/status"
        static let games = "cv/sg"
        static let patches = "cv/sp"
        static let containers = "cv/sc"
        static let remoteNotice = "cv/sn"
        static let auxiliaryStatus = "cv/sa"
    }

    func fetchRemoteNotice(deviceID: String) async throws -> RemoteNoticePayload? {
        var components = URLComponents(url: routeURL(Route.remoteNotice), resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "build", value: String(HTBackendConfiguration.buildNumber))]
        var request = URLRequest(url: components.url!)
        request.httpMethod = "GET"
        applyHubHeaders(to: &request, deviceID: deviceID)
        return try await decodeOptional(RemoteNoticePayload.self, request: request)
    }

    func fetchGames(deviceID: String) async throws -> [RemoteGameSummary] {
        var request = URLRequest(url: routeURL(Route.games))
        request.httpMethod = "GET"
        applyHubHeaders(to: &request, deviceID: deviceID)
        let data = try await data(for: request)
        if let direct = try? decoder.decode([RemoteGameSummary].self, from: data) {
            return direct.sorted(by: sortGames)
        }
        if let envelope = try? decoder.decode(HubEnvelope.self, from: data), let games = envelope.games {
            return games.sorted(by: sortGames)
        }
        throw HTAPIError.invalidPayload("The games response did not match the recovered HTVANTIX schema.")
    }

    func fetchContainers(deviceID: String) async throws -> [RemoteContainerSummary] {
        var request = URLRequest(url: routeURL(Route.containers))
        request.httpMethod = "GET"
        applyHubHeaders(to: &request, deviceID: deviceID)
        let data = try await data(for: request)
        if let direct = try? decoder.decode([RemoteContainerSummary].self, from: data) { return direct }
        if let envelope = try? decoder.decode(HubEnvelope.self, from: data), let containers = envelope.containers { return containers }
        throw HTAPIError.invalidPayload("The containers response did not match the recovered HTVANTIX schema.")
    }

    func fetchPatches(gameID: String, deviceID: String) async throws -> [RemotePatchSummary] {
        // The binary confirms cv/sp as the patch collection route. Query naming is not
        // completely recoverable, so first request the collection and filter by gameId.
        var request = URLRequest(url: routeURL(Route.patches))
        request.httpMethod = "GET"
        applyHubHeaders(to: &request, deviceID: deviceID)
        let data = try await data(for: request)
        let all: [RemotePatchSummary]
        if let direct = try? decoder.decode([RemotePatchSummary].self, from: data) {
            all = direct
        } else if let envelope = try? decoder.decode(HubEnvelope.self, from: data), let patches = envelope.patches {
            all = patches
        } else {
            throw HTAPIError.invalidPayload("The patches response did not match the recovered HTVANTIX schema.")
        }
        let filtered = all.filter { $0.gameId == nil || $0.gameId == gameID }
        return filtered
    }

    func downloadPatch(_ patch: RemotePatchSummary, deviceID: String) async throws -> DownloadedPatchPackage {
        let path = Route.patches + "/" + patch.id + "/download"
        var request = URLRequest(url: routeURL(path))
        request.httpMethod = "GET"
        request.timeoutInterval = 30
        applyHubHeaders(to: &request, deviceID: deviceID)

        let (temporaryURL, response) = try await URLSession.shared.download(for: request)
        try validate(response)

        let fileName = patch.fileName?.isEmpty == false ? patch.fileName! : "\(patch.id).3105"
        let destination = FileManager.default.temporaryDirectory
            .appendingPathComponent("HTVANTIX-Downloads", isDirectory: true)
            .appendingPathComponent(fileName)
        try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        if FileManager.default.fileExists(atPath: destination.path) {
            try FileManager.default.removeItem(at: destination)
        }
        try FileManager.default.moveItem(at: temporaryURL, to: destination)
        return DownloadedPatchPackage(patchID: patch.id, localURL: destination, suggestedFileName: fileName)
    }

    func redeemKey(code: String, deviceID: String, deviceModel: String) async throws -> KeyResponse {
        guard HTBackendConfiguration.isLicenseSigningConfigured else {
            throw HTAPIError.credentialsMissing("Backend license credentials need to be rotated and configured before live activation can be enabled.")
        }
        let pairs = [
            URLQueryItem(name: "code", value: code),
            URLQueryItem(name: "deviceId", value: deviceID),
            URLQueryItem(name: "deviceModel", value: deviceModel)
        ]
        var components = URLComponents()
        components.queryItems = pairs
        let body = components.percentEncodedQuery?.data(using: .utf8) ?? Data()

        var request = URLRequest(url: routeURL(Route.redeemKey))
        request.httpMethod = "POST"
        request.httpBody = body
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(HTBackendConfiguration.appToken, forHTTPHeaderField: "X-App-Token")
        let signed = try signer.signedHeaders(for: request, body: body)
        signed.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        return try await decode(KeyResponse.self, request: request)
    }

    func keyStatus(code: String, deviceID: String) async throws -> KeyResponse {
        guard HTBackendConfiguration.isLicenseSigningConfigured else {
            throw HTAPIError.credentialsMissing("Backend license credentials need to be rotated and configured before live status checks can be enabled.")
        }
        var components = URLComponents(url: routeURL(Route.keyStatus), resolvingAgainstBaseURL: false)!
        components.queryItems = [
            URLQueryItem(name: "code", value: code),
            URLQueryItem(name: "deviceId", value: deviceID)
        ]
        var request = URLRequest(url: components.url!)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(HTBackendConfiguration.appToken, forHTTPHeaderField: "X-App-Token")
        let signed = try signer.signedHeaders(for: request, body: nil)
        signed.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        return try await decode(KeyResponse.self, request: request)
    }

    private func applyHubHeaders(to request: inout URLRequest, deviceID: String) {
        request.timeoutInterval = 10
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if HTBackendConfiguration.isHubConfigured {
            request.setValue(HTBackendConfiguration.appToken, forHTTPHeaderField: "X-App-Token")
        }
        request.setValue(deviceID, forHTTPHeaderField: "X-Device-Id")
    }

    private func routeURL(_ path: String) -> URL {
        path.split(separator: "/").reduce(baseURL) { url, component in
            url.appendingPathComponent(String(component))
        }
    }

    private func decode<T: Decodable>(_ type: T.Type, request: URLRequest) async throws -> T {
        let data = try await data(for: request)
        do { return try decoder.decode(T.self, from: data) }
        catch { throw HTAPIError.decoding(error.localizedDescription) }
    }

    private func decodeOptional<T: Decodable>(_ type: T.Type, request: URLRequest) async throws -> T? {
        let data = try await data(for: request)
        guard !data.isEmpty else { return nil }
        do { return try decoder.decode(T.self, from: data) }
        catch { throw HTAPIError.decoding(error.localizedDescription) }
    }

    private func data(for request: URLRequest) async throws -> Data {
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response)
        return data
    }

    private func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { return }
        guard (200..<300).contains(http.statusCode) else {
            throw HTAPIError.httpStatus(http.statusCode)
        }
    }

    private func sortGames(_ lhs: RemoteGameSummary, _ rhs: RemoteGameSummary) -> Bool {
        let l = lhs.order ?? Int.max
        let r = rhs.order ?? Int.max
        if l == r { return lhs.name.localizedCaseInsensitiveCompare(rhs.name) == .orderedAscending }
        return l < r
    }
}

enum HTAPIError: LocalizedError {
    case credentialsMissing(String)
    case invalidPayload(String)
    case decoding(String)
    case httpStatus(Int)

    var errorDescription: String? {
        switch self {
        case .credentialsMissing(let message): return message
        case .invalidPayload(let message): return message
        case .decoding(let message): return "Unable to decode server response: \(message)"
        case .httpStatus(let status): return "Server returned HTTP \(status)."
        }
    }
}
