import Foundation
import SwiftUI
import Darwin
import UIKit

@MainActor
final class AppSession: ObservableObject {
    @Published var licenseState: LicenseState = .signedOut
    @Published var games: [RemoteGameSummary] = []
    @Published var maintenance: MaintenanceNotice?
    @Published var announcement: Announcement?
    @Published var isLoadingGames = false
    @Published var lastError: String?

    let api: HTAPIClient
    let networkMonitor = NetworkSecurityMonitor()

    private let licenseKeyName = "com.htblackshop.license"
    private let deviceIDName = "com.htblackshop.device-id"

    init(api: HTAPIClient = HTAPIClient()) {
        self.api = api
    }

    var savedLicenseKey: String {
        UserDefaults.standard.string(forKey: licenseKeyName) ?? ""
    }

    var deviceID: String {
        if let existing = UserDefaults.standard.string(forKey: deviceIDName), !existing.isEmpty {
            return existing
        }
        let id = UUID().uuidString
        UserDefaults.standard.set(id, forKey: deviceIDName)
        return id
    }

    var isPreviewMode: Bool {
        if case .preview = licenseState { return true }
        return false
    }

    var isUnlocked: Bool {
        switch licenseState {
        case .activated, .preview: return true
        default: return false
        }
    }

    var backendConfigurationMessage: String? {
        if !HTBackendConfiguration.isHubConfigured {
            return "Live backend credentials are not configured. Preview Mode is available for UI testing."
        }
        if !HTBackendConfiguration.isLicenseSigningConfigured {
            return "The online hub is configured, but live License activation still needs a new request-signing credential."
        }
        return nil
    }

    func bootstrap() async {
        networkMonitor.refresh()
        await refreshRemoteState()

        guard !savedLicenseKey.isEmpty else {
            licenseState = .signedOut
            return
        }

        guard HTBackendConfiguration.isLicenseSigningConfigured else {
            licenseState = .signedOut
            return
        }

        licenseState = .checking
        do {
            let status = try await api.keyStatus(code: savedLicenseKey, deviceID: deviceID)
            licenseState = .activated(expiry: status.expiresAt)
            await loadGames()
        } catch {
            lastError = error.localizedDescription
            licenseState = .signedOut
        }
    }

    func activate(key: String) async {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            licenseState = .error("Please enter a License Key")
            return
        }
        guard HTBackendConfiguration.isLicenseSigningConfigured else {
            licenseState = .error("Live activation is not configured yet. Rotate/reissue the backend signing credential, add it to the project configuration, or use Preview Mode to test the interface.")
            return
        }

        licenseState = .checking
        do {
            let response = try await api.redeemKey(
                code: trimmed,
                deviceID: deviceID,
                deviceModel: Self.deviceModel
            )
            UserDefaults.standard.set(trimmed, forKey: licenseKeyName)
            licenseState = .activated(expiry: response.expiresAt)
            lastError = nil
            await refreshRemoteState()
            await loadGames()
        } catch {
            licenseState = .error(Self.friendlyLicenseError(error))
        }
    }

    func enterPreviewMode() {
        licenseState = .preview
        maintenance = nil
        announcement = Announcement(
            id: "preview-announcement",
            title: "HTVANTIX Preview",
            message: "This is the reconstructed interface running in Preview Mode. Live data will replace these cards after new backend credentials are configured."
        )
        games = RemoteGameSummary.demo
    }

    func exitPreviewMode() {
        games = []
        announcement = nil
        licenseState = .signedOut
    }

    func signOut() {
        UserDefaults.standard.removeObject(forKey: licenseKeyName)
        games = []
        announcement = nil
        maintenance = nil
        lastError = nil
        licenseState = .signedOut
    }

    func refreshRemoteState() async {
        guard HTBackendConfiguration.isHubConfigured else { return }
        do {
            let notice = try await api.fetchRemoteNotice(deviceID: deviceID)
            maintenance = notice?.resolvedMaintenance
            announcement = notice?.resolvedAnnouncement
        } catch {
            lastError = error.localizedDescription
        }
    }

    func loadGames() async {
        if isPreviewMode {
            games = RemoteGameSummary.demo
            return
        }
        guard HTBackendConfiguration.isHubConfigured else {
            games = []
            lastError = "Online Hub requires a new HTVANTIX_APP_TOKEN in configuration."
            return
        }

        isLoadingGames = true
        defer { isLoadingGames = false }
        do {
            games = try await api.fetchGames(deviceID: deviceID).filter(\.active)
            lastError = nil
        } catch {
            games = []
            lastError = error.localizedDescription
        }
    }

    func patches(for game: RemoteGameSummary) async throws -> [RemotePatchSummary] {
        if isPreviewMode { return game.patches ?? RemotePatchSummary.demoList }
        return try await api.fetchPatches(gameID: game.id, deviceID: deviceID).filter(\.active)
    }

    func download(_ patch: RemotePatchSummary) async throws -> DownloadedPatchPackage {
        guard !isPreviewMode else {
            throw HTAPIError.invalidPayload("Preview Mode does not download remote packages.")
        }
        return try await api.downloadPatch(patch, deviceID: deviceID)
    }

    private static var deviceModel: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        let identifier = mirror.children.reduce(into: "") { result, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            result.append(Character(UnicodeScalar(UInt8(value))))
        }
        return identifier.isEmpty ? UIDevice.current.model : identifier
    }

    private static func friendlyLicenseError(_ error: Error) -> String {
        if let apiError = error as? HTAPIError { return apiError.localizedDescription }
        if let urlError = error as? URLError {
            switch urlError.code {
            case .notConnectedToInternet, .networkConnectionLost, .timedOut:
                return "Unable to connect to the server."
            default: break
            }
        }
        return error.localizedDescription
    }
}
