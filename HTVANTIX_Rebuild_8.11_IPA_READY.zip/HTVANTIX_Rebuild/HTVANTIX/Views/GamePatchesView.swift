import SwiftUI

struct GamePatchesView: View {
    @EnvironmentObject private var session: AppSession
    let game: RemoteGameSummary

    @State private var patches: [RemotePatchSummary] = []
    @State private var isLoading = false
    @State private var downloadingID: String?
    @State private var downloadedPackage: DownloadedPatchPackage?
    @State private var alertMessage: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                gameHeader

                if isLoading {
                    HTCard {
                        HStack(spacing: 12) {
                            ProgressView().tint(.white)
                            Text("Loading modules…").foregroundStyle(HTTheme.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                } else if patches.isEmpty {
                    HTCard {
                        VStack(spacing: 12) {
                            Image(systemName: "square.stack.3d.up.slash").font(.system(size: 34)).foregroundStyle(HTTheme.secondary)
                            Text("No modules available").font(.headline)
                            Text("There are no active packages for this game right now.")
                                .font(.system(size: 13)).foregroundStyle(HTTheme.secondary).multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                    }
                } else {
                    ForEach(patches) { patch in
                        patchCard(patch)
                    }
                }

                safetyNote
            }
            .frame(maxWidth: 760)
            .padding(18)
            .frame(maxWidth: .infinity)
        }
        .background(HTTheme.background)
        .navigationTitle(game.name)
        .navigationBarTitleDisplayMode(.inline)
        .task { await load() }
        .refreshable { await load() }
        .alert("HTVANTIX", isPresented: Binding(
            get: { alertMessage != nil },
            set: { if !$0 { alertMessage = nil } }
        )) {
            Button("OK", role: .cancel) { alertMessage = nil }
        } message: {
            Text(alertMessage ?? "")
        }
        .sheet(item: $downloadedPackage) { package in
            DownloadCompleteView(package: package)
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
        }
    }

    private var gameHeader: some View {
        HTCard {
            HStack(spacing: 14) {
                RoundedRectangle(cornerRadius: 17)
                    .fill(Color(hex: game.bannerColor ?? "") ?? Color.white.opacity(0.08))
                    .frame(width: 64, height: 64)
                    .overlay(Image(systemName: "gamecontroller.fill").font(.system(size: 26)))

                VStack(alignment: .leading, spacing: 5) {
                    Text(game.name).font(.system(size: 22, weight: .black))
                    Text(game.bundleID ?? "ONLINE MODULES")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundStyle(HTTheme.secondary)
                    if session.isPreviewMode { HTStatusPill(text: "Preview", success: false) }
                }
                Spacer()
            }
        }
    }

    private func patchCard(_ patch: RemotePatchSummary) -> some View {
        HTCard {
            VStack(alignment: .leading, spacing: 13) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(patch.title).font(.system(size: 17, weight: .bold))
                        if let version = patch.version {
                            Text("VERSION  \(version)")
                                .font(.system(size: 10, weight: .bold, design: .monospaced))
                                .foregroundStyle(HTTheme.secondary)
                        }
                    }
                    Spacer()
                    HTStatusPill(text: patch.active ? "Active" : "Offline", success: patch.active)
                }

                if let detail = patch.detail, !detail.isEmpty {
                    Text(detail)
                        .font(.system(size: 13))
                        .foregroundStyle(HTTheme.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }

                HStack(spacing: 14) {
                    if let fileName = patch.fileName {
                        Label(fileName, systemImage: "doc.zipper")
                            .lineLimit(1)
                    }
                    if let bytes = patch.sizeBytes {
                        Label(ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file), systemImage: "internaldrive")
                    }
                }
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(Color.white.opacity(0.45))

                Button {
                    Task { await download(patch) }
                } label: {
                    if downloadingID == patch.id {
                        ProgressView().tint(.black)
                    } else {
                        Label(session.isPreviewMode ? "Preview Only" : "Download Package", systemImage: "arrow.down.circle.fill")
                    }
                }
                .buttonStyle(HTPrimaryButton())
                .disabled(downloadingID != nil || session.isPreviewMode)
            }
        }
    }

    private var safetyNote: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "shield.lefthalf.filled")
            Text("This recovery project restores the catalog and package-download interface. The original cross-app/sandbox-escape patch engine is intentionally not included in the rebuilt source.")
        }
        .font(.system(size: 11))
        .foregroundStyle(Color.white.opacity(0.42))
        .padding(.horizontal, 4)
    }

    private func load() async {
        isLoading = true
        defer { isLoading = false }
        do {
            patches = try await session.patches(for: game)
        } catch {
            patches = []
            alertMessage = error.localizedDescription
        }
    }

    private func download(_ patch: RemotePatchSummary) async {
        downloadingID = patch.id
        defer { downloadingID = nil }
        do {
            downloadedPackage = try await session.download(patch)
        } catch {
            alertMessage = error.localizedDescription
        }
    }
}

private struct DownloadCompleteView: View {
    let package: DownloadedPatchPackage

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 44))
                .foregroundStyle(HTTheme.success)
            Text("Package downloaded").font(.title2.bold())
            Text(package.suggestedFileName)
                .font(.system(size: 13, design: .monospaced))
                .foregroundStyle(HTTheme.secondary)
                .lineLimit(2)
            ShareLink(item: package.localURL) {
                Label("Export Package", systemImage: "square.and.arrow.up")
            }
            .buttonStyle(HTPrimaryButton())
            Text("The package is downloaded only. No files in another application are modified by this rebuild.")
                .font(.system(size: 11))
                .foregroundStyle(HTTheme.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(26)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.black)
    }
}
