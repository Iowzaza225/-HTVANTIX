import SwiftUI

struct SplashView: View {
    @Binding var isFinished: Bool
    @State private var progress = 0.0

    var body: some View {
        VStack(spacing: 0) {
            Spacer().frame(height: 115)
            Image("HTLogo")
                .resizable().scaledToFit().frame(width: 220, height: 220)
                .accessibilityHidden(true)
            Text("HTVANTIX")
                .font(.system(size: 34, weight: .black))
                .tracking(2)
            Text(progress < 1 ? "Loading configuration..." : "System ready")
                .font(.system(size: 15, weight: .medium))
                .foregroundStyle(HTTheme.secondary)
                .padding(.top, 10)

            VStack(spacing: 11) {
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color(red: 0.10, green: 0.10, blue: 0.10))
                            .overlay(Capsule().stroke(Color.white.opacity(0.22)))
                        Capsule().fill(LinearGradient(colors: [.white, Color(white: 0.84)], startPoint: .leading, endPoint: .trailing))
                            .frame(width: geo.size.width * progress)
                    }
                }
                .frame(height: 9)

                HStack {
                    Text("ONLINE v8.11")
                    Spacer()
                    Text("\(Int(progress * 100))%")
                }
                .font(.system(size: 13, weight: .bold, design: .monospaced))
                .foregroundStyle(HTTheme.secondary)
            }
            .frame(maxWidth: 470)
            .padding(.horizontal, 34)
            .padding(.top, 34)
            Spacer()
            Text("HTVANTIX • Recovered Source Build")
                .font(.system(size: 12))
                .foregroundStyle(HTTheme.secondary)
                .padding(.bottom, 42)
        }
        .task {
            for i in 0...100 {
                try? await Task.sleep(nanoseconds: 15_000_000)
                withAnimation(.linear(duration: 0.12)) { progress = Double(i) / 100 }
            }
            try? await Task.sleep(nanoseconds: 220_000_000)
            withAnimation(.easeOut(duration: 0.35)) { isFinished = true }
        }
    }
}
