import SwiftUI

struct RootView: View {
    @EnvironmentObject private var session: AppSession
    @State private var splashFinished = false

    var body: some View {
        ZStack {
            HTTheme.background.ignoresSafeArea()

            if !splashFinished {
                SplashView(isFinished: $splashFinished)
            } else if let maintenance = session.maintenance, maintenance.maintenance {
                MaintenanceView(notice: maintenance) {
                    Task { await session.refreshRemoteState() }
                }
            } else if session.isUnlocked,
                      !session.isPreviewMode,
                      (session.networkMonitor.isVPNActive || session.networkMonitor.isProxyActive) {
                VPNBlockView(
                    vpnDetected: session.networkMonitor.isVPNActive,
                    proxyDetected: session.networkMonitor.isProxyActive,
                    onRetry: { session.networkMonitor.refresh() }
                )
            } else {
                switch session.licenseState {
                case .activated, .preview:
                    GamesHomeView()
                default:
                    AccessPanelV()
                }
            }
        }
        .task { await session.bootstrap() }
        .sheet(item: $session.announcement) { announcement in
            AnnouncementSheetView(announcement: announcement)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .preferredColorScheme(.dark)
    }
}
