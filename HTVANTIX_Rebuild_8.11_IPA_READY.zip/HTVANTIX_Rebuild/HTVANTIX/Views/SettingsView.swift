import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var session: AppSession
    @State private var showRoutes = false

    var body: some View {
        NavigationStack {
            List {
                Section("HTVANTIX") {
                    LabeledContent("Version", value: "8.11 (68)")
                    LabeledContent("Backend", value: "hightapi.netlify.app")
                    LabeledContent("Device ID", value: String(session.deviceID.prefix(12)) + "…")
                    LabeledContent("Mode", value: session.isPreviewMode ? "Preview" : "Live")
                }

                Section("Backend recovery") {
                    configurationRow("Online Hub token", configured: HTBackendConfiguration.isHubConfigured)
                    configurationRow("License signer", configured: HTBackendConfiguration.isLicenseSigningConfigured)

                    Button { showRoutes.toggle() } label: {
                        Label(showRoutes ? "Hide recovered routes" : "Show recovered routes", systemImage: "point.3.connected.trianglepath.dotted")
                    }

                    if showRoutes {
                        VStack(alignment: .leading, spacing: 7) {
                            route("License redeem", HTAPIClient.Route.redeemKey)
                            route("License status", HTAPIClient.Route.keyStatus)
                            route("Games", HTAPIClient.Route.games)
                            route("Patches", HTAPIClient.Route.patches)
                            route("Containers", HTAPIClient.Route.containers)
                            route("Notice", HTAPIClient.Route.remoteNotice + "?build=68")
                            route("Auxiliary", HTAPIClient.Route.auxiliaryStatus)
                        }
                        .padding(.vertical, 5)
                    }
                }

                Section("Network") {
                    LabeledContent("VPN", value: session.networkMonitor.isVPNActive ? "Detected" : "Not detected")
                    LabeledContent("Proxy", value: session.networkMonitor.isProxyActive ? "Detected" : "Not detected")
                    Button("Refresh network state") { session.networkMonitor.refresh() }
                }

                Section("Account") {
                    if session.isPreviewMode {
                        Button { session.exitPreviewMode(); dismiss() } label: {
                            Label("Exit Preview Mode", systemImage: "rectangle.portrait.and.arrow.right")
                        }
                    } else {
                        Button(role: .destructive) { session.signOut(); dismiss() } label: {
                            Label("Change License Key", systemImage: "key.horizontal")
                        }
                    }
                }

                Section("Recovered source") {
                    Text("The SwiftUI project structure, app identity, safe backend routes, device identifiers, online catalog models, maintenance/announcement flow and package-download path were reconstructed from HTVANTIX 8.11. Compiled Swift cannot be recovered byte-for-byte as the original source.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    Text("Embedded backend credentials and the original cross-app sandbox/patch exploit are intentionally not copied into this project.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .background(.black)
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    @ViewBuilder
    private func configurationRow(_ title: String, configured: Bool) -> some View {
        HStack {
            Text(title)
            Spacer()
            Text(configured ? "Configured" : "Needs setup")
                .font(.caption.weight(.semibold))
                .foregroundStyle(configured ? HTTheme.success : HTTheme.warning)
        }
    }

    private func route(_ name: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(name).font(.caption.weight(.semibold))
            Text(value).font(.system(size: 11, design: .monospaced)).foregroundStyle(.secondary)
        }
    }
}
