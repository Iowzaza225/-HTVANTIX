import SwiftUI

struct AccessPanelV: View {
    @EnvironmentObject private var session: AppSession
    @State private var key = ""
    @State private var revealKey = false
    @State private var showInfo = false

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                topBar
                brandHeader
                accessCard
                footer
            }
            .frame(maxWidth: 620)
            .padding(.horizontal, 20)
            .padding(.bottom, 28)
            .frame(maxWidth: .infinity)
        }
        .background(HTTheme.background)
        .sheet(isPresented: $showInfo) {
            LicenseInfoView()
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
        }
    }

    private var topBar: some View {
        HStack {
            Button { showInfo = true } label: {
                Image(systemName: "info.circle")
                    .font(.system(size: 18, weight: .semibold))
                    .frame(width: 44, height: 44)
                    .background(Color.white.opacity(0.06))
                    .overlay(Circle().stroke(HTTheme.border))
                    .clipShape(Circle())
            }
            Spacer()
            Button { } label: {
                Label("TH", systemImage: "globe")
                    .font(.system(size: 14, weight: .bold))
                    .padding(.horizontal, 16)
                    .frame(height: 43)
                    .background(Color.white.opacity(0.07))
                    .overlay(Capsule().stroke(HTTheme.border))
                    .clipShape(Capsule())
            }
        }
        .foregroundStyle(.white)
        .padding(.top, 8)
    }

    private var brandHeader: some View {
        VStack(spacing: 0) {
            Image("HTLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 118, height: 118)
                .padding(.top, 8)

            Text("HTVANTIX")
                .font(.system(size: 31, weight: .black))
                .tracking(1.2)

            Text("ONLINE ACCESS")
                .font(.system(size: 13, weight: .heavy, design: .monospaced))
                .tracking(1.6)
                .foregroundStyle(HTTheme.secondary)
                .padding(.top, 12)

            Text("Enter your License Key to open the online panel")
                .font(.system(size: 15))
                .foregroundStyle(HTTheme.tertiary)
                .multilineTextAlignment(.center)
                .padding(.top, 10)
                .padding(.bottom, 26)
        }
    }

    private var accessCard: some View {
        HTCard {
            VStack(alignment: .leading, spacing: 16) {
                if let configurationMessage = session.backendConfigurationMessage {
                    statusMessage(configurationMessage, color: HTTheme.warning, icon: "exclamationmark.triangle.fill")
                }

                if case .error(let message) = session.licenseState {
                    statusMessage(message, color: HTTheme.danger, icon: "xmark.circle.fill")
                }

                Text("LICENSE KEY")
                    .font(.system(size: 12, weight: .heavy, design: .monospaced))
                    .tracking(0.7)
                    .foregroundStyle(HTTheme.secondary)

                HStack(spacing: 10) {
                    Group {
                        if revealKey {
                            TextField("Enter activation key...", text: $key)
                        } else {
                            SecureField("Enter activation key...", text: $key)
                        }
                    }
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .font(.system(size: 16, weight: .medium))

                    Button { revealKey.toggle() } label: {
                        Image(systemName: revealKey ? "eye.slash.fill" : "eye.fill")
                            .foregroundStyle(HTTheme.secondary)
                            .frame(width: 36, height: 36)
                    }
                }
                .padding(.horizontal, 16)
                .frame(height: 58)
                .background(Color.black.opacity(0.55))
                .overlay(RoundedRectangle(cornerRadius: HTTheme.fieldRadius).stroke(HTTheme.strongBorder))
                .clipShape(RoundedRectangle(cornerRadius: HTTheme.fieldRadius))

                Button {
                    Task { await session.activate(key: key) }
                } label: {
                    if case .checking = session.licenseState {
                        ProgressView().tint(.black)
                    } else {
                        HStack(spacing: 9) {
                            Image(systemName: "lock.open.fill")
                            Text("Activate")
                        }
                    }
                }
                .buttonStyle(HTPrimaryButton())
                .disabled(isChecking)

                HStack(spacing: 12) {
                    Rectangle().fill(HTTheme.border).frame(height: 1)
                    Text("OR")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundStyle(HTTheme.secondary)
                    Rectangle().fill(HTTheme.border).frame(height: 1)
                }
                .padding(.vertical, 2)

                Button {
                    session.enterPreviewMode()
                } label: {
                    Label("Preview Interface", systemImage: "rectangle.on.rectangle.angled")
                }
                .buttonStyle(HTSecondaryButton())

                Text("Preview Mode is for rebuilding and checking the UI only. It does not activate a License or apply packages to other apps.")
                    .font(.system(size: 11))
                    .foregroundStyle(HTTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var footer: some View {
        VStack(spacing: 7) {
            HStack(spacing: 8) {
                Circle().fill(HTTheme.success).frame(width: 6, height: 6)
                Text("HTVANTIX 8.11  •  BUILD 68")
            }
            .font(.system(size: 11, weight: .bold, design: .monospaced))
            .foregroundStyle(HTTheme.secondary)
            Text("Reconstructed source project")
                .font(.system(size: 11))
                .foregroundStyle(Color.white.opacity(0.35))
        }
        .padding(.top, 24)
    }

    private var isChecking: Bool {
        if case .checking = session.licenseState { return true }
        return false
    }

    private func statusMessage(_ message: String, color: Color, icon: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: icon).padding(.top, 1)
            Text(message).fixedSize(horizontal: false, vertical: true)
        }
        .font(.system(size: 13, weight: .medium))
        .foregroundStyle(color)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(color.opacity(0.08))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(color.opacity(0.18)))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

private struct LicenseInfoView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Image(systemName: "key.horizontal.fill").font(.system(size: 30))
            Text("HTVANTIX License").font(.title2.bold())
            Text("The original 8.11 IPA used a device-bound License flow. This rebuild preserves the UI and recovered endpoint contract, but intentionally does not redistribute the secret signing credential embedded in the compiled app.")
                .foregroundStyle(HTTheme.secondary)
            Spacer()
        }
        .padding(26)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .background(.black)
    }
}
