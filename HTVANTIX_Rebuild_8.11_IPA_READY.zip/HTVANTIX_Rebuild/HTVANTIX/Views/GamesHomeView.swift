import SwiftUI

struct GamesHomeView: View {
    @EnvironmentObject private var session: AppSession
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    header

                    if session.isPreviewMode {
                        previewBanner
                    }

                    if let error = session.lastError, !session.isPreviewMode {
                        HTCard {
                            Label(error, systemImage: "wifi.exclamationmark")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundStyle(HTTheme.warning)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }

                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("ONLINE MOD MENU")
                                .font(.system(size: 12, weight: .black, design: .monospaced))
                                .tracking(1.0)
                                .foregroundStyle(HTTheme.secondary)
                            Text("Games")
                                .font(.system(size: 30, weight: .black))
                        }
                        Spacer()
                        if session.isLoadingGames {
                            ProgressView().tint(.white)
                        } else {
                            HTStatusPill(text: session.isPreviewMode ? "Preview" : "Online", success: !session.isPreviewMode)
                        }
                    }

                    if session.games.isEmpty && !session.isLoadingGames {
                        emptyState
                    } else {
                        LazyVStack(spacing: 12) {
                            ForEach(session.games) { game in
                                NavigationLink(value: game) {
                                    GameCardView(game: game)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .frame(maxWidth: 760)
                .padding(.horizontal, 18)
                .padding(.top, 14)
                .padding(.bottom, 34)
                .frame(maxWidth: .infinity)
            }
            .background(HTTheme.background)
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: RemoteGameSummary.self) { game in
                GamePatchesView(game: game)
            }
            .refreshable {
                await session.refreshRemoteState()
                await session.loadGames()
            }
            .sheet(isPresented: $showSettings) {
                SettingsView()
                    .environmentObject(session)
            }
        }
    }

    private var header: some View {
        HStack(spacing: 13) {
            Image("HTLogo")
                .resizable().scaledToFit()
                .frame(width: 48, height: 48)
                .clipShape(RoundedRectangle(cornerRadius: 12))

            VStack(alignment: .leading, spacing: 3) {
                Text("HTVANTIX").font(.system(size: 19, weight: .black)).tracking(0.8)
                Text("ONLINE v8.11")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundStyle(HTTheme.secondary)
            }

            Spacer()

            Button { showSettings = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 17, weight: .semibold))
                    .frame(width: 44, height: 44)
                    .background(Color.white.opacity(0.07))
                    .overlay(Circle().stroke(HTTheme.border))
                    .clipShape(Circle())
            }
            .foregroundStyle(.white)
        }
    }

    private var previewBanner: some View {
        HStack(spacing: 12) {
            Image(systemName: "hammer.fill")
            VStack(alignment: .leading, spacing: 2) {
                Text("PREVIEW MODE").font(.system(size: 12, weight: .black, design: .monospaced))
                Text("Using reconstructed sample data. Live License and downloads are disabled.")
                    .font(.system(size: 12)).foregroundStyle(HTTheme.secondary)
            }
            Spacer()
        }
        .padding(14)
        .background(HTTheme.warning.opacity(0.08))
        .overlay(RoundedRectangle(cornerRadius: 15).stroke(HTTheme.warning.opacity(0.20)))
        .clipShape(RoundedRectangle(cornerRadius: 15))
        .foregroundStyle(HTTheme.warning)
    }

    private var emptyState: some View {
        HTCard {
            VStack(spacing: 12) {
                Image(systemName: "gamecontroller").font(.system(size: 36)).foregroundStyle(HTTheme.secondary)
                Text("No games yet").font(.headline)
                Text("The server returned no active games, or the backend credential is not configured.")
                    .font(.system(size: 13)).foregroundStyle(HTTheme.secondary).multilineTextAlignment(.center)
                Button { Task { await session.loadGames() } } label: {
                    Label("Reload", systemImage: "arrow.clockwise")
                }
                .buttonStyle(HTSecondaryButton())
            }
            .frame(maxWidth: .infinity)
        }
    }
}

struct GameCardView: View {
    let game: RemoteGameSummary

    var body: some View {
        HTCard {
            HStack(spacing: 14) {
                icon

                VStack(alignment: .leading, spacing: 6) {
                    Text(game.name)
                        .font(.system(size: 17, weight: .bold))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                    Text(game.subtitle ?? game.bundleID ?? "Available module")
                        .font(.system(size: 13))
                        .foregroundStyle(HTTheme.secondary)
                        .lineLimit(2)
                    if let bundle = game.bundleID {
                        Text(bundle)
                            .font(.system(size: 10, weight: .medium, design: .monospaced))
                            .foregroundStyle(Color.white.opacity(0.34))
                            .lineLimit(1)
                    }
                }

                Spacer(minLength: 8)
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(HTTheme.secondary)
            }
        }
    }

    @ViewBuilder
    private var icon: some View {
        if let path = game.iconPath, let url = absoluteURL(path) {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image): image.resizable().scaledToFill()
                default: iconPlaceholder
                }
            }
            .frame(width: 58, height: 58)
            .clipShape(RoundedRectangle(cornerRadius: 15))
        } else {
            iconPlaceholder
        }
    }

    private var iconPlaceholder: some View {
        RoundedRectangle(cornerRadius: 15)
            .fill(Color(hex: game.bannerColor ?? "") ?? Color.white.opacity(0.08))
            .frame(width: 58, height: 58)
            .overlay(Image(systemName: "gamecontroller.fill").font(.system(size: 23)).foregroundStyle(.white))
    }

    private func absoluteURL(_ value: String) -> URL? {
        if let direct = URL(string: value), direct.scheme != nil { return direct }
        return HTBackendConfiguration.baseURL.appendingPathComponent(value.trimmingCharacters(in: CharacterSet(charactersIn: "/")))
    }
}
