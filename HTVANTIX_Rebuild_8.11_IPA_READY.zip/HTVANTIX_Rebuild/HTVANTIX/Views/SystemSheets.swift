import SwiftUI

struct AnnouncementSheetView: View {
    @Environment(\.openURL) private var openURL
    let announcement: Announcement

    var body: some View {
        VStack(spacing: 18) {
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.white.opacity(0.07))
                .frame(width: 70, height: 70)
                .overlay(Image(systemName: "megaphone.fill").font(.system(size: 29)))
            Text(announcement.title).font(.title2.bold()).multilineTextAlignment(.center)
            Text(announcement.message)
                .foregroundStyle(HTTheme.secondary)
                .multilineTextAlignment(.center)

            if let label = announcement.linkLabel,
               let value = announcement.linkURL,
               let url = URL(string: value) {
                Button { openURL(url) } label: {
                    Label(label, systemImage: "arrow.up.right.square")
                }
                .buttonStyle(HTPrimaryButton())
            }
            Spacer(minLength: 0)
        }
        .padding(26)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.black)
    }
}

struct MaintenanceView: View {
    let notice: MaintenanceNotice
    let retry: () -> Void

    var body: some View {
        VStack(spacing: 18) {
            Image("HTLogo")
                .resizable().scaledToFit().frame(width: 90, height: 90)
            Image(systemName: "wrench.and.screwdriver.fill").font(.system(size: 35))
            Text(notice.maintenanceTitle ?? "Maintenance")
                .font(.system(size: 28, weight: .black))
                .multilineTextAlignment(.center)
            Text(notice.maintenanceMessage ?? "The service is temporarily under maintenance.")
                .foregroundStyle(HTTheme.secondary)
                .multilineTextAlignment(.center)
            Button("Try Again", action: retry)
                .buttonStyle(HTPrimaryButton())
                .frame(maxWidth: 320)
        }
        .padding(24)
        .frame(maxWidth: 520)
    }
}

struct VPNBlockView: View {
    let vpnDetected: Bool
    let proxyDetected: Bool
    let onRetry: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "network.slash").font(.system(size: 42))
            Text("Network protection").font(.title2.bold())
            Text(message)
                .foregroundStyle(HTTheme.secondary)
                .multilineTextAlignment(.center)
            Button("Check Again", action: onRetry)
                .buttonStyle(HTPrimaryButton())
                .frame(maxWidth: 320)
        }
        .padding(24)
        .frame(maxWidth: 520)
    }

    private var message: String {
        switch (vpnDetected, proxyDetected) {
        case (true, true): return "VPN and proxy settings were detected. Turn them off, then check again."
        case (true, false): return "A VPN interface was detected. Turn it off, then check again."
        case (false, true): return "A system proxy was detected. Turn it off, then check again."
        default: return "Network state changed. Check again to continue."
        }
    }
}
