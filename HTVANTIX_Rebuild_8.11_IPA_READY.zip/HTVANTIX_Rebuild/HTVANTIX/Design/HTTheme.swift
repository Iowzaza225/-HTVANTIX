import SwiftUI

@MainActor
enum HTTheme {
    static let background = Color.black
    static let card = Color(red: 0.07, green: 0.07, blue: 0.08)
    static let cardAlt = Color(red: 0.035, green: 0.035, blue: 0.04)
    static let border = Color.white.opacity(0.14)
    static let strongBorder = Color.white.opacity(0.24)
    static let secondary = Color(red: 0.65, green: 0.65, blue: 0.69)
    static let tertiary = Color(red: 0.72, green: 0.72, blue: 0.75)
    static let success = Color(red: 0.38, green: 0.92, blue: 0.62)
    static let danger = Color(red: 1.0, green: 0.42, blue: 0.42)
    static let warning = Color(red: 1.0, green: 0.76, blue: 0.34)

    static let cardRadius: CGFloat = 23
    static let fieldRadius: CGFloat = 19
    static let buttonRadius: CGFloat = 14
}

struct HTCard<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(20)
            .background(
                LinearGradient(
                    colors: [Color(red: 0.10, green: 0.10, blue: 0.11).opacity(0.97), HTTheme.cardAlt.opacity(0.97)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(RoundedRectangle(cornerRadius: HTTheme.cardRadius).stroke(HTTheme.border, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: HTTheme.cardRadius))
    }
}

struct HTPrimaryButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .heavy))
            .foregroundStyle(.black)
            .frame(maxWidth: .infinity, minHeight: 50)
            .background(Color.white.opacity(configuration.isPressed ? 0.84 : 1))
            .clipShape(RoundedRectangle(cornerRadius: HTTheme.buttonRadius))
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

struct HTSecondaryButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .bold))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity, minHeight: 46)
            .background(Color.white.opacity(configuration.isPressed ? 0.11 : 0.07))
            .overlay(RoundedRectangle(cornerRadius: 13).stroke(HTTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 13))
    }
}

struct HTStatusPill: View {
    let text: String
    var success = true

    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(success ? HTTheme.success : HTTheme.warning).frame(width: 6, height: 6)
            Text(text.uppercased())
                .font(.system(size: 10, weight: .black, design: .monospaced))
                .tracking(0.6)
        }
        .foregroundStyle(success ? HTTheme.success : HTTheme.warning)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background((success ? HTTheme.success : HTTheme.warning).opacity(0.10))
        .clipShape(Capsule())
    }
}

extension Color {
    init?(hex: String) {
        var text = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.hasPrefix("#") { text.removeFirst() }
        guard text.count == 6, let value = Int(text, radix: 16) else { return nil }
        self.init(
            red: Double((value >> 16) & 0xFF) / 255,
            green: Double((value >> 8) & 0xFF) / 255,
            blue: Double(value & 0xFF) / 255
        )
    }
}
