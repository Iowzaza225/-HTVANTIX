import SwiftUI

// HTVINTEX production build: attribution UI is intentionally not exposed.
extension View {
    func displayIdentityAttribution(isPresented: Binding<Bool>, enabled: Bool) -> some View { self }
}

struct DisplayAttributionSheet: View {
    var body: some View { EmptyView() }
}
