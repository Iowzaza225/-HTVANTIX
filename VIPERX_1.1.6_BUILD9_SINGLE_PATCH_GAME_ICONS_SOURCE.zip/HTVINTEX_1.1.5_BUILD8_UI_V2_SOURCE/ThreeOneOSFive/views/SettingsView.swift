import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var licenseManager: HTVLicenseManager

    var body: some View {
        NavigationStack {
            ZStack {
                HTVScreenBackground()
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 18) {
                        settingsHeader
                        licenseCard
                        deviceCard
                        supportCard
                        aboutCard
                        footer
                    }
                    .frame(maxWidth: 720)
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, AppTheme.pageInset)
                    .padding(.top, 10)
                    .padding(.bottom, 36)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
        .preferredColorScheme(.dark)
    }

    private var settingsHeader: some View {
        HStack(spacing: 13) {
            AppLogo(size: 52)
            VStack(alignment: .leading, spacing: 3) {
                Text("ตั้งค่า VIPERX")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("จัดการบัญชี อุปกรณ์ และข้อมูลแอป")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button { dismiss() } label: {
                Text("เสร็จสิ้น")
                    .font(.caption.weight(.black))
                    .foregroundStyle(AppTheme.accent)
                    .padding(.horizontal, 14)
                    .frame(height: 40)
                    .background(AppTheme.surfaceRaised, in: Capsule())
                    .overlay(Capsule().stroke(AppTheme.accent.opacity(0.22), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private var licenseCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HTVSectionHeader(title: "สมาชิก VIPERX", subtitle: "สถานะสิทธิ์การใช้งาน")
            HStack(spacing: 12) {
                AppRowIcon(systemName: "key.fill", tint: licenseManager.isAuthorized ? .green : .orange, symbolSize: 19, frameSize: 44)
                VStack(alignment: .leading, spacing: 3) {
                    Text(licenseManager.isAuthorized ? "License พร้อมใช้งาน" : "License ไม่พร้อมใช้งาน")
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.white)
                    Text("หมดอายุ: \(licenseManager.expiryText)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                HTVStatusPill(
                    title: licenseManager.isAuthorized ? "ACTIVE" : "INACTIVE",
                    tint: licenseManager.isAuthorized ? .green : .orange
                )
            }
            Divider().overlay(AppTheme.hairline)
            settingsValueRow(icon: "number", title: "คีย์", value: licenseManager.maskedKey)
            Button(role: .destructive) {
                dismiss()
                licenseManager.signOutLicense()
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                    Text("ออกจาก License")
                        .fontWeight(.bold)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.black))
                }
                .foregroundStyle(.red)
                .padding(.horizontal, 14)
                .frame(height: 46)
                .background(Color.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(.plain)
        }
        .htvCard(accent: licenseManager.isAuthorized ? .green : .orange)
    }

    private var deviceCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HTVSectionHeader(title: "อุปกรณ์", subtitle: "ข้อมูลเครื่องปัจจุบัน")
            settingsValueRow(icon: "iphone.gen3", title: "รุ่นอุปกรณ์", value: AppInfo.displayMachineName)
            Divider().overlay(AppTheme.hairline)
            settingsValueRow(icon: "cpu", title: "ระบบปฏิบัติการ", value: "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))")
            Divider().overlay(AppTheme.hairline)
            HStack(spacing: 12) {
                AppRowIcon(systemName: appState.isSupported ? "checkmark.shield.fill" : "exclamationmark.shield.fill", tint: appState.isSupported ? .green : .orange)
                VStack(alignment: .leading, spacing: 2) {
                    Text("ความเข้ากันได้")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                    Text(appState.isSupported ? "อุปกรณ์นี้อยู่ในช่วงที่รองรับ" : "กรุณาตรวจสอบเวอร์ชันที่รองรับ")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                HTVStatusPill(
                    title: appState.isSupported ? "รองรับ" : "ตรวจสอบ",
                    tint: appState.isSupported ? .green : .orange
                )
            }
        }
        .htvCard()
    }

    private var supportCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HTVSectionHeader(title: "เวอร์ชันที่รองรับ", subtitle: "Verified iOS")
            supportRow(title: "iOS 17", value: ExploitSupportPolicy.verifiedIOS17Range)
            Divider().overlay(AppTheme.hairline)
            supportRow(title: "iOS 18", value: ExploitSupportPolicy.verifiedIOS18Range)
            Divider().overlay(AppTheme.hairline)
            supportRow(title: "iOS 26", value: ExploitSupportPolicy.verifiedIOS26Range)
            if !ExploitSupportPolicy.verifiedIOS27Builds.isEmpty {
                Divider().overlay(AppTheme.hairline)
                VStack(alignment: .leading, spacing: 7) {
                    Text("iOS 27.0")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                    ForEach(ExploitSupportPolicy.verifiedIOS27Builds, id: \.build) { version in
                        Text(versionLabel(version))
                            .font(.caption.monospaced())
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .htvCard()
    }

    private var aboutCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HTVSectionHeader(title: "เกี่ยวกับ", subtitle: "VIPERX")
            settingsValueRow(icon: "shippingbox.fill", title: "เวอร์ชันแอป", value: appVersion)
            Divider().overlay(AppTheme.hairline)
            HStack(spacing: 12) {
                AppRowIcon(systemName: "checkmark.seal.fill", tint: AppTheme.accent)
                VStack(alignment: .leading, spacing: 2) {
                    Text("VIPERX Premium Control")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                    Text("อินเทอร์เฟซสำหรับจัดการไฟล์และแพตช์ของคุณ")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
        }
        .htvCard()
    }

    private func settingsValueRow(icon: String, title: String, value: String) -> some View {
        HStack(spacing: 12) {
            AppRowIcon(systemName: icon)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                Text(value)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            Spacer(minLength: 8)
        }
    }

    private func supportRow(title: String, value: String) -> some View {
        HStack {
            Text(title)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(.white)
            Spacer()
            Text(value)
                .font(.caption.monospaced())
                .foregroundStyle(AppTheme.accent)
        }
    }

    private var footer: some View {
        VStack(spacing: 5) {
            Text("VIPERX")
                .font(.caption2.weight(.black))
                .tracking(4)
                .foregroundStyle(AppTheme.accent)
            Text("PLAY A BETTER TOMORROW")
                .font(.system(size: 9, weight: .bold))
                .tracking(2.4)
                .foregroundStyle(.secondary)
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private func versionLabel(
        _ version: (beta: Int, publicBeta: Int?, build: String)
    ) -> String {
        if let publicBeta = version.publicBeta {
            return language.text(
                "settings.developer_public_beta_build",
                Int64(version.beta),
                Int64(publicBeta),
                version.build
            )
        }
        return language.text(
            "settings.developer_beta_build",
            Int64(version.beta),
            version.build
        )
    }
}
