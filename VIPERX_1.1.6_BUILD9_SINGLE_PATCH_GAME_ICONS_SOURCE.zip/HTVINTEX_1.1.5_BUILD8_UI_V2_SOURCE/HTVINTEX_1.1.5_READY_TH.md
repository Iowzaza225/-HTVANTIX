# HTVINTEX 1.1.5 — ชุดพร้อมประกอบและใช้งาน

ฐานของโปรเจกต์นี้คือ 3105 2.0 โดยคงระบบ `.3105`/Patch/Apply/Restore เดิมไว้ และปรับหน้าใช้งานหลักกับระบบ Server/License ให้เป็น HTVINTEX 1.1.5

## สิ่งที่ผู้ใช้เห็นในแอป

- แท็บหลักเหลือ **Home** และ **Installed**
- หน้า **New / Sources / Search / Files** ยังอยู่ใน source แต่ซ่อนจาก production tab bar
- หน้า **Home** เป็น HTVINTEX Control Center แสดงสถานะเครื่อง, License, Server และจำนวนไฟล์ Free Fire / Free Fire MAX
- หน้า **Installed** รับรายการไฟล์ที่เปิดใช้งานจาก HTVINTEX Server และดาวน์โหลด `.3105` ให้อัตโนมัติ
- ไฟล์จาก Server มีสวิตช์เปิด/ปิด Patch และใช้ Apply/Restore เดิมของ 3105
- ปุ่ม `+` สำหรับ Import/Create แบบ manual ถูกซ่อน แต่ flow/โค้ดยังอยู่ใน source
- หน้า Installed เหลือปุ่ม Settings ที่แถบด้านบน
- License Gate ใช้ Key -> License Token -> Client Session แบบ short-lived
- Session สำหรับ Catalog/Download จะถูกต่ออายุใหม่ก่อนซิงก์ Server
- หาก Admin ปิด/ลบ package จาก Server แอปจะพยายาม Restore patch ที่เปิดอยู่ แล้วล้าง cached package ที่มาจาก Server
- ถ้า Admin อัปเดต package เดิม แอปตรวจ fingerprint/SHA-256 และซิงก์เวอร์ชันใหม่

## จุดตั้งค่าฝั่ง iOS

เปิดไฟล์ `ThreeOneOSFive/Info.plist`

ค่าหลักที่เตรียมไว้แล้ว:

- `CFBundleDisplayName` = `HTVINTEX`
- `CFBundleShortVersionString` = `1.1.5`
- `CFBundleVersion` = `8`
- `HTVLicenseBaseURL` = `https://hightapi.netlify.app`
- `PatchServerBaseURL` = `https://hightapi.netlify.app`
- `PatchCatalogURL` = `https://hightapi.netlify.app/api/v4/packages`

ถ้าเปลี่ยนโดเมน Server ให้แก้ 3 URL ด้านบนให้เป็นโดเมน HTTPS ใหม่

## Deploy Backend

Backend อยู่ในโฟลเดอร์ `Backend/` และใช้ Netlify Functions + Cloudflare R2

Environment Variables ที่ต้องตั้งใน Netlify:

```text
HIGHT_ADMIN_USERNAME=admin
HIGHT_ADMIN_PASSWORD_SCRYPT=<scrypt password record>
HIGHT_SESSION_SECRET=<random secret>
HIGHT_LOG_SALT=<random secret>
HIGHT_RESPONSE_HMAC=<random secret>
HIGHT_APP_TOKEN=<client token>
HIGHT_LICENSE_SECRET=<random secret>
HIGHT_CLIENT_SESSION_SECRET=<separate random secret>
HIGHT_R2_ACCOUNT_ID=<Cloudflare Account ID>
HIGHT_R2_ACCESS_KEY_ID=<R2 Access Key>
HIGHT_R2_SECRET_ACCESS_KEY=<R2 Secret Key>
HIGHT_R2_BUCKET=<Bucket name>
```

ตัวเลือกเพิ่มเติม:

```text
HIGHT_ADMIN_OTP_ISSUER=HTVINTEX
```

ลำดับติดตั้ง Server:

1. สร้าง Cloudflare R2 bucket และ R2 API token
2. ตั้ง Environment Variables ใน Netlify
3. ตั้ง R2 CORS ตาม `Backend/R2_CORS_SAMPLE.json` และเปลี่ยนโดเมนตัวอย่างเป็นโดเมน Netlify จริง
4. Deploy โฟลเดอร์ `Backend/` ไปยัง Netlify
5. เข้า `/admin` และตั้ง OTP ครั้งแรก
6. ที่ Version Gate ตั้ง Current Version = `1.1.5`, Minimum Version = `1.1.5`
7. Allowed Build IDs: เว้นว่างเพื่อรับทุก Build ที่ผ่าน Minimum Version หรือใส่ `8` ถ้าต้องการล็อก Build นี้
8. สร้าง License Key ทดสอบ
9. Upload `.3105` จากหน้า Packages เลือก Game/Category และเปิด Enabled
10. เปิดแอป -> Login Key -> Home -> Installed เพื่อตรวจการซิงก์

## Workflow ฝั่ง Admin -> iPhone

1. Admin อัปโหลด `.3105` ไป R2
2. Server คำนวณ SHA-256 และเก็บ metadata
3. เมื่อ package เป็น Enabled จะปรากฏใน `/api/v4/packages`
4. แอปต่ออายุ Client Session แล้วอ่าน Catalog
5. แอปดาวน์โหลดผ่าน endpoint ที่มีสิทธิ์ และตรวจ SHA-256 ก่อน Import
6. Package ปรากฏใน Installed
7. ผู้ใช้เปิดสวิตช์เพื่อ Apply และปิดสวิตช์เพื่อ Restore

## การตรวจสอบก่อนปล่อยจริง

- ทดสอบ License key ใหม่ / key หมดอายุ / key ถูก disable
- ทดสอบ device binding
- ทดสอบ Version Gate และ Maintenance Mode
- ทดสอบ upload package แล้ว Enabled/Disabled จากหน้า Admin
- ทดสอบแก้ package แล้วอัปโหลดเวอร์ชันใหม่
- ทดสอบเปิด Patch -> ปิด Patch -> Restore สำเร็จ
- ทดสอบปิด package จาก Admin ขณะเคยเปิด Patch ไว้ แล้วกลับหน้า Installed/Refresh เพื่อยืนยัน Restore
- ทดสอบ Free Fire และ Free Fire MAX บนอุปกรณ์จริงที่รองรับ

## หมายเหตุการ Build

Source ชุดนี้ผ่านการตรวจ syntax ของ Swift ทุกไฟล์ และตรวจ syntax ของ Netlify `.mjs` แล้วในสภาพแวดล้อมจัดทำไฟล์นี้ แต่การ Build/Signing iOS จริงต้องทำบน macOS ที่มี Xcode และต้องใช้ signing method/certificate ที่ฟีเจอร์ของ 3105 รองรับตามข้อกำหนดของ upstream project

เครดิต upstream 3105 / YangJiii และ third-party notices ยังคงอยู่ในโปรเจกต์
