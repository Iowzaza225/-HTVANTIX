import SwiftUI

enum AppTheme {
    static let accent = Color(red: 0.10, green: 0.72, blue: 0.95)
    static let pageBackground = Color(red: 0.018, green: 0.031, blue: 0.045)
    static let cardBackground = Color(red: 0.032, green: 0.055, blue: 0.075)
    static let border = Color(red: 0.12, green: 0.26, blue: 0.34).opacity(0.72)
    static let consoleBackground = Color(red: 0.025, green: 0.045, blue: 0.063)
    static let pageInset: CGFloat = 16
    static let rowIconSize: CGFloat = 17
    static let rowIconFrame: CGFloat = 28
    static let fileRowIconSize: CGFloat = 17
    static let fileRowIconFrame: CGFloat = 30
    static let fileRowHeight: CGFloat = 60
    static let appIconSize: CGFloat = 32
    static let emptyIconSize: CGFloat = 30
    static let selectionIconSize: CGFloat = 18
}

struct AppRowIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var symbolSize: CGFloat = AppTheme.rowIconSize
    var frameSize: CGFloat = AppTheme.rowIconFrame

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7, style: .continuous)
                .fill(tint.opacity(0.12))
            Image(systemName: systemName)
                .font(.system(size: symbolSize, weight: .medium))
                .foregroundStyle(tint)
        }
        .frame(width: frameSize, height: frameSize)
        .accessibilityHidden(true)
    }
}

struct AppSearchField: View {
    @Binding var text: String
    let prompt: String
    let clearLabel: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)

            TextField(prompt, text: $text)
                .font(.body)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(clearLabel)
            }
        }
        .padding(.horizontal, 11)
        .frame(minHeight: 36)
        .background(
            Color(uiColor: .secondarySystemFill),
            in: RoundedRectangle(cornerRadius: 10, style: .continuous)
        )
        .padding(.horizontal, AppTheme.pageInset)
        .padding(.vertical, 8)
        .background(.bar)
    }
}

struct AppLogo: View {
    var size: CGFloat = 44

    var body: some View {
        Group {
            if let icon = UIImage(named: "AppIcon60x60")
                ?? Bundle.main.path(forResource: "AppIcon60x60@2x", ofType: "png").flatMap(UIImage.init(contentsOfFile:))
                ?? UIImage(named: "AppIcon") {
                Image(uiImage: icon)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "slider.horizontal.3")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(AppTheme.accent)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
        .accessibilityHidden(true)
    }
}


/// Visual-only HTVANTIX brand mark shown by the app shell.
/// Uses the user-supplied artwork and crops the lower caption area at render time.
struct HTVBrandWatermark: View {
    var body: some View {
        ZStack {
            Image("HTVLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 54, height: 55)
                .offset(y: -6)
        }
        .frame(width: 34, height: 34, alignment: .top)
        .clipped()
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .stroke(Color.cyan.opacity(0.28), lineWidth: 0.7)
        )
        .opacity(0.82)
        .accessibilityHidden(true)
        .allowsHitTesting(false)
    }
}

// MARK: - HTVANTIX Motion Layer
// Visual-only motion helpers. These views never start network requests, mutate
// license/session state, or touch patch files. Respect Reduce Motion automatically.

struct MotionStatusDot: View {
    var color: Color = .green
    var size: CGFloat = 7
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var pulse = false

    var body: some View {
        ZStack {
            Circle()
                .fill(color.opacity(pulse ? 0.08 : 0.22))
                .frame(width: size * 2.5, height: size * 2.5)
                .scaleEffect(pulse ? 1.18 : 0.72)

            Circle()
                .fill(color)
                .frame(width: size, height: size)
                .shadow(color: color.opacity(0.58), radius: pulse ? 7 : 3)
        }
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.easeInOut(duration: 1.45).repeatForever(autoreverses: true)) {
                pulse = true
            }
        }
        .accessibilityHidden(true)
        .allowsHitTesting(false)
    }
}

struct MotionSpinner: View {
    var tint: Color = AppTheme.accent
    var size: CGFloat = 18
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var spinning = false

    var body: some View {
        ZStack {
            Circle()
                .stroke(tint.opacity(0.15), lineWidth: 2.2)
            Circle()
                .trim(from: 0.08, to: 0.72)
                .stroke(
                    AngularGradient(colors: [tint.opacity(0.18), tint], center: .center),
                    style: StrokeStyle(lineWidth: 2.2, lineCap: .round)
                )
                .rotationEffect(.degrees(spinning ? 360 : 0))
        }
        .frame(width: size, height: size)
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.linear(duration: 0.82).repeatForever(autoreverses: false)) {
                spinning = true
            }
        }
        .accessibilityHidden(true)
        .allowsHitTesting(false)
    }
}

struct MotionPressButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.965 : 1)
            .opacity(configuration.isPressed ? 0.88 : 1)
            .animation(.spring(response: 0.24, dampingFraction: 0.78), value: configuration.isPressed)
    }
}

private struct MotionEntranceModifier: ViewModifier {
    let active: Bool
    let delay: Double
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func body(content: Content) -> some View {
        content
            .opacity(active ? 1 : 0)
            .offset(y: reduceMotion ? 0 : (active ? 0 : 12))
            .scaleEffect(reduceMotion ? 1 : (active ? 1 : 0.985))
            .animation(
                reduceMotion ? .easeOut(duration: 0.12) : .spring(response: 0.52, dampingFraction: 0.88).delay(delay),
                value: active
            )
    }
}

extension View {
    func motionEntrance(active: Bool, delay: Double = 0) -> some View {
        modifier(MotionEntranceModifier(active: active, delay: delay))
    }
}

struct MotionScannerLine: View {
    var tint: Color = AppTheme.accent
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var travel = false

    var body: some View {
        GeometryReader { proxy in
            Capsule()
                .fill(
                    LinearGradient(
                        colors: [.clear, tint.opacity(0.85), .clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .frame(width: max(34, proxy.size.width * 0.30), height: 2)
                .blur(radius: 0.35)
                .offset(x: travel ? proxy.size.width : -proxy.size.width * 0.35)
        }
        .frame(height: 2)
        .clipped()
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.linear(duration: 2.4).repeatForever(autoreverses: false)) {
                travel = true
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct MotionBreatheSymbol: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var size: CGFloat = 20
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var breathe = false

    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: size, weight: .bold))
            .foregroundStyle(tint)
            .scaleEffect(breathe && !reduceMotion ? 1.07 : 0.97)
            .shadow(color: tint.opacity(breathe && !reduceMotion ? 0.32 : 0.10), radius: breathe && !reduceMotion ? 9 : 3)
            .onAppear {
                guard !reduceMotion else { return }
                withAnimation(.easeInOut(duration: 1.55).repeatForever(autoreverses: true)) {
                    breathe = true
                }
            }
            .allowsHitTesting(false)
    }
}
