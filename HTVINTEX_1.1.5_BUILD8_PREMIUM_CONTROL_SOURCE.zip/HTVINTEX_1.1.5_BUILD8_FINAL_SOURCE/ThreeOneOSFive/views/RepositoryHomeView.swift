import SwiftUI

struct RepositoryHomeView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var licenseManager: HTVLicenseManager
    @StateObject private var serverCatalog = PatchServerCatalog()

    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void
    let onOpenInstalled: () -> Void

    var body: some View {
        NavigationStack {
            ZStack {
                dashboardBackground

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        header
                        heroCard
                        statusGrid

                        VStack(alignment: .leading, spacing: 10) {
                            Text("GAME PATCHES")
                                .htvSectionLabel()

                            gameCard(
                                title: "Free Fire",
                                subtitle: "ไฟล์ยิง • ไฟล์มอง • มอดสกิน",
                                systemImage: "scope",
                                game: "ff",
                                count: serverCatalog.items.filter { $0.game == "ff" }.count
                            )

                            gameCard(
                                title: "Free Fire MAX",
                                subtitle: "ไฟล์ที่เปิดจาก Server พร้อมซิงก์อัตโนมัติ",
                                systemImage: "bolt.shield.fill",
                                game: "ffmax",
                                count: serverCatalog.items.filter { $0.game == "ffmax" }.count
                            )
                        }

                        footer
                    }
                    .frame(maxWidth: 720)
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 18)
                    .padding(.top, 8)
                    .padding(.bottom, 34)
                }
                .refreshable { await refreshServer() }
            }
            .toolbar(.hidden, for: .navigationBar)
            .task {
                if serverCatalog.items.isEmpty, !serverCatalog.isLoading {
                    await refreshServer()
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var dashboardBackground: some View {
        ZStack {
            Color(red: 0.006, green: 0.013, blue: 0.020)
                .ignoresSafeArea()

            LinearGradient(
                colors: [
                    AppTheme.accent.opacity(0.10),
                    Color.blue.opacity(0.025),
                    Color.clear
                ],
                startPoint: .topLeading,
                endPoint: .center
            )
            .ignoresSafeArea()
        }
    }

    private var header: some View {
        HStack(spacing: 13) {
            AppLogo(size: 52)

            VStack(alignment: .leading, spacing: 2) {
                Text("HTVINTEX")
                    .font(.system(size: 26, weight: .black, design: .rounded))
                    .foregroundStyle(.white)

                Text("1.1.5 • CONTROL CENTER")
                    .font(.caption2.weight(.black))
                    .tracking(1.8)
                    .foregroundStyle(AppTheme.accent)
            }

            Spacer()

            Button(action: onOpenSettings) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(Color.white.opacity(0.06), in: Circle())
                    .overlay(Circle().stroke(AppTheme.accent.opacity(0.24), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private var heroCard: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 17, style: .continuous)
                    .fill(AppTheme.accent.opacity(0.10))
                    .frame(width: 58, height: 58)
                Image(systemName: serverCatalog.errorMessage == nil ? "checkmark.shield.fill" : "exclamationmark.shield.fill")
                    .font(.system(size: 25, weight: .semibold))
                    .foregroundStyle(serverCatalog.errorMessage == nil ? Color.green : Color.orange)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("HTVINTEX SYSTEM")
                    .font(.headline.weight(.black))
                    .foregroundStyle(.white)

                Text(serverStatusText)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }

            Spacer()

            if serverCatalog.isLoading {
                ProgressView().controlSize(.small)
            } else {
                Circle()
                    .fill(serverCatalog.errorMessage == nil ? Color.green : Color.orange)
                    .frame(width: 9, height: 9)
                    .shadow(
                        color: (serverCatalog.errorMessage == nil ? Color.green : Color.orange).opacity(0.55),
                        radius: 6
                    )
            }
        }
        .htvDashboardCard()
    }

    private var statusGrid: some View {
        HStack(spacing: 10) {
            statusChip(
                icon: "iphone.gen3",
                title: AppInfo.displayMachineName,
                subtitle: "iOS \(AppInfo.osVersion)",
                tint: appState.isSupported ? .green : .orange
            )

            statusChip(
                icon: "key.fill",
                title: "LICENSE",
                subtitle: licenseManager.expiryText == "—" ? "ACTIVE" : licenseManager.expiryText,
                tint: .green
            )
        }
    }

    private func statusChip(icon: String, title: String, subtitle: String, tint: Color) -> some View {
        HStack(spacing: 9) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(tint)
                .frame(width: 34, height: 34)
                .background(tint.opacity(0.10), in: RoundedRectangle(cornerRadius: 10))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(subtitle)
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(tint)
                    .lineLimit(1)
            }

            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity)
        .htvDashboardCard(padding: 12)
    }

    private func gameCard(
        title: String,
        subtitle: String,
        systemImage: String,
        game: String,
        count: Int
    ) -> some View {
        NavigationLink {
            PatchProjectsView(
                gameFilter: game,
                screenTitle: title,
                onOpenSettings: onOpenSettings,
                onOpenLogs: onOpenLogs
            )
        } label: {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(AppTheme.accent.opacity(0.10))
                        .frame(width: 56, height: 56)
                    Image(systemName: systemImage)
                        .font(.system(size: 24, weight: .bold))
                        .foregroundStyle(AppTheme.accent)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.headline.weight(.black))
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text("\(count)")
                        .font(.title3.weight(.black))
                        .foregroundStyle(count > 0 ? Color.green : Color.secondary)
                    Text("FILES")
                        .font(.caption2.weight(.black))
                        .foregroundStyle(.secondary)
                }

                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(AppTheme.accent)
            }
            .htvDashboardCard()
        }
        .buttonStyle(.plain)
    }

    private var serverStatusText: String {
        if serverCatalog.isLoading { return "กำลังเชื่อมต่อและตรวจสอบรายการไฟล์…" }
        if let error = serverCatalog.errorMessage { return "Server: \(error)" }
        return "API Online • \(serverCatalog.items.count) ไฟล์พร้อมใช้งาน"
    }

    private var footer: some View {
        HStack(spacing: 8) {
            Circle().fill(AppTheme.accent).frame(width: 6, height: 6)
            Text("HTVINTEX • Secure Session")
                .font(.caption2.weight(.bold))
                .tracking(0.8)
                .foregroundStyle(.secondary)
        }
        .padding(.top, 2)
    }

    @MainActor
    private func refreshServer() async {
        do {
            await licenseManager.bootstrap(forceSessionRefresh: true)
            guard licenseManager.isAuthorized else {
                let message = licenseManager.message.isEmpty
                    ? "Session หมดอายุ กรุณาตรวจสอบ License ใหม่"
                    : licenseManager.message
                serverCatalog.fail(
                    NSError(
                        domain: "HTVINTEX",
                        code: 401,
                        userInfo: [NSLocalizedDescriptionKey: message]
                    )
                )
                return
            }
            _ = try await serverCatalog.load()
            serverCatalog.finishSync()
        } catch {
            serverCatalog.fail(error)
        }
    }
}

private extension View {
    func htvDashboardCard(padding: CGFloat = 16) -> some View {
        self
            .padding(padding)
            .background(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(Color(red: 0.025, green: 0.040, blue: 0.055))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(AppTheme.accent.opacity(0.14), lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.22), radius: 12, y: 7)
    }

    func htvSectionLabel() -> some View {
        self
            .font(.caption2.weight(.black))
            .tracking(1.8)
            .foregroundStyle(.secondary)
    }
}

struct RepositoryNewView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var store: PackageRepositoryStore
    @State private var packages: [RepositoryPackageRecord] = []
    @State private var showSimulatedPackageDetail = false
    @State private var simulatedPackageDetailGate = OneShotPresentationGate()

    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    var body: some View {
        NavigationStack {
            List {
                if packages.isEmpty {
                    Section {
                        emptyState
                    }
                } else {
                    Section {
                        ForEach(packages) { record in
                            NavigationLink(value: record) {
                                RepositoryNewPackageRow(record: record)
                            }
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle(language.text("tab.new"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                AppUtilityToolbar(
                    language: language,
                    onOpenSettings: onOpenSettings,
                    onOpenLogs: onOpenLogs
                )
            }
            .navigationDestination(for: RepositoryPackageRecord.self) { record in
                RepositoryPackageDetailView(record: record)
            }
            .navigationDestination(isPresented: $showSimulatedPackageDetail) {
                if let record = packages.first {
                    RepositoryPackageDetailView(record: record)
                }
            }
            .refreshable {
                await store.refreshAllAndWait()
                rebuildPackages()
            }
            .onAppear {
                store.refreshAllIfNeeded()
                rebuildPackages()
                openSimulatedPackageDetailIfNeeded()
            }
            .onChange(of: store.packages) { _ in
                rebuildPackages()
                openSimulatedPackageDetailIfNeeded()
            }
        }
    }

    @ViewBuilder
    private var emptyState: some View {
        if store.isRefreshing && !store.sources.isEmpty {
            HStack(spacing: 10) {
                ProgressView()
                Text(language.text("repository.refreshing"))
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 32)
        } else {
            VStack(spacing: 12) {
                Image(systemName: store.sources.isEmpty ? "shippingbox" : "clock")
                    .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                    .foregroundStyle(AppTheme.accent)
                Text(language.text(
                    store.sources.isEmpty
                        ? "repository.no_sources_title"
                        : "repository.new_empty_title"
                ))
                .font(.headline)
                Text(language.text(
                    store.sources.isEmpty
                        ? "repository.no_sources_message"
                        : "repository.new_empty_message"
                ))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 48)
        }
    }

    private func rebuildPackages() {
        packages = PackageRepositoryFeedPolicy.newest(store.packages)
    }

    private func openSimulatedPackageDetailIfNeeded() {
#if targetEnvironment(simulator)
        guard ProcessInfo.processInfo.arguments.contains(
            "--simulate-package-detail"
        ), !packages.isEmpty, simulatedPackageDetailGate.claim() else {
            return
        }
        DispatchQueue.main.async {
            showSimulatedPackageDetail = true
        }
#endif
    }
}

struct RepositorySearchView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var store: PackageRepositoryStore
    @State private var searchText = ""

    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    private var query: String {
        searchText.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var results: [RepositoryPackageRecord] {
        guard !query.isEmpty else { return [] }
        return store.packages.filter { record in
            let package = record.package
            return package.name.localizedCaseInsensitiveContains(query)
                || package.author.localizedCaseInsensitiveContains(query)
                || package.summary.localizedCaseInsensitiveContains(query)
                || package.identifier.localizedCaseInsensitiveContains(query)
                || record.sourceName.localizedCaseInsensitiveContains(query)
                || (package.category?.localizedCaseInsensitiveContains(query) ?? false)
                || package.tags.contains {
                    $0.localizedCaseInsensitiveContains(query)
                }
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                AppSearchField(
                    text: $searchText,
                    prompt: language.text("repository.search_prompt"),
                    clearLabel: language.text("common.clear")
                )
                Divider()
                List {
                    if query.isEmpty {
                        searchPrompt
                            .listRowSeparator(.hidden)
                    } else if results.isEmpty {
                        searchEmpty
                            .listRowSeparator(.hidden)
                    } else {
                        Section(language.text(
                            "repository.search_results",
                            Int64(results.count)
                        )) {
                            ForEach(results) { record in
                                NavigationLink(value: record) {
                                    RepositoryPackageRow(record: record)
                                }
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .scrollDismissesKeyboard(.interactively)
                .refreshable {
                    await store.refreshAllAndWait()
                }
            }
            .navigationTitle(language.text("repository.search"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                AppUtilityToolbar(
                    language: language,
                    onOpenSettings: onOpenSettings,
                    onOpenLogs: onOpenLogs
                )
            }
            .navigationDestination(for: RepositoryPackageRecord.self) { record in
                RepositoryPackageDetailView(record: record)
            }
            .onAppear {
                store.refreshAllIfNeeded()
            }
        }
    }

    private var searchPrompt: some View {
        VStack(spacing: 12) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(AppTheme.accent)
            Text(language.text("repository.search_title"))
                .font(.headline)
            Text(language.text("repository.search_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var searchEmpty: some View {
        VStack(spacing: 12) {
            Image(systemName: "shippingbox")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(.secondary)
            Text(language.text("repository.search_empty"))
                .font(.headline)
            Text(language.text("repository.search_empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }
}

private struct RepositoryFeaturedCard: View {
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @StateObject private var imageLoader = RepositoryImageLoader()
    let record: RepositoryPackageRecord
    let width: CGFloat
    let height: CGFloat

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            artwork

            LinearGradient(
                stops: [
                    .init(color: .clear, location: 0.28),
                    .init(color: .black.opacity(0.16), location: 0.56),
                    .init(color: .black.opacity(0.78), location: 1)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 4) {
                Text(record.package.name)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .lineLimit(dynamicTypeSize.isAccessibilitySize ? 3 : 2)

                Text(record.package.author)
                    .font(.caption2.weight(.medium))
                    .foregroundStyle(.white.opacity(0.84))
                    .lineLimit(dynamicTypeSize.isAccessibilitySize ? 2 : 1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(10)
            .shadow(color: .black.opacity(0.42), radius: 1, y: 1)
        }
        .frame(width: width, height: height, alignment: .bottomLeading)
        .background(Color(uiColor: .secondarySystemFill))
        .clipShape(
            RoundedRectangle(
                cornerRadius: 14,
                style: .continuous
            )
        )
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(
                    Color(uiColor: .separator).opacity(0.24),
                    lineWidth: 0.5
                )
                .accessibilityHidden(true)
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
        .task(id: record.package.iconURL) {
            guard let iconURL = record.package.iconURL else { return }
            await imageLoader.load(url: iconURL, maximumPixelSize: 640)
        }
    }

    private var artwork: some View {
        Rectangle()
            .fill(Color(uiColor: .secondarySystemFill))
            .overlay {
                if let image = imageLoader.image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if imageLoader.didFail {
                    placeholder
                } else if record.package.iconURL == nil {
                    placeholder
                } else {
                    ProgressView()
                        .tint(.white)
                }
            }
            .clipped()
            .accessibilityHidden(true)
    }

    private var placeholder: some View {
        Image(systemName: record.package.kind == .wallpaper
            ? "photo.fill"
            : "shippingbox.fill")
            .font(.system(size: 30, weight: .medium))
            .foregroundStyle(.white.opacity(0.82))
    }
}

private struct RepositoryCardButtonStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.72 : 1)
            .animation(
                reduceMotion ? nil : .easeOut(duration: 0.12),
                value: configuration.isPressed
            )
    }
}

private struct RepositoryNewPackageRow: View {
    @Environment(\.appLanguage) private var language
    let record: RepositoryPackageRecord

    var body: some View {
        HStack(spacing: 12) {
            RepositoryPackageIcon(package: record.package, size: 38)
            VStack(alignment: .leading, spacing: 3) {
                Text(record.package.name)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                Text(language.text(
                    "repository.home_package_meta",
                    record.package.author,
                    record.sourceName
                ))
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            }
            Spacer(minLength: 8)
            if let publishedAt = record.package.publishedAt {
                Text(
                    publishedAt,
                    format: .dateTime.day().month(.abbreviated)
                )
                .font(.caption2.weight(.medium))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.trailing)
            }
        }
        .padding(.vertical, 3)
        .accessibilityElement(children: .combine)
    }
}
