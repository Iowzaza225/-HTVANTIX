import SwiftUI

struct LicenseView: View {
    @EnvironmentObject private var app: AppCoordinator
    @State private var key = ""

    var body: some View {
        ScrollView {
            VStack(spacing: 22) {
                Spacer(minLength: 60)

                Image("HTBrandIcon")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 86, height: 86)
                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))

                VStack(spacing: 7) {
                    Text("HTVANTIX")
                        .font(.system(size: 32, weight: .black, design: .rounded))
                    Text("SECURE CLIENT")
                        .font(.system(size: 11, weight: .bold))
                        .tracking(3)
                        .foregroundStyle(HTTheme.muted)
                }

                HTCard {
                    VStack(alignment: .leading, spacing: 13) {
                        Text("LICENSE KEY")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(HTTheme.muted)

                        TextField("XXXX-XXXX-XXXX", text: $key)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .padding(15)
                            .background(Color.black.opacity(0.36), in: RoundedRectangle(cornerRadius: 14))
                            .overlay(
                                RoundedRectangle(cornerRadius: 14)
                                    .stroke(HTTheme.border)
                            )

                        Button {
                            Task { await app.activate(key: key) }
                        } label: {
                            HStack {
                                if app.isWorking { ProgressView().tint(.black) }
                                Text(app.isWorking ? "กำลังตรวจสอบ..." : "เข้าสู่ระบบ")
                            }
                        }
                        .buttonStyle(HTPrimaryButtonStyle())
                        .disabled(app.isWorking)
                    }
                }

                Text("HTVANTIX • v\(BuildIdentity.version) • Secure Session")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(HTTheme.muted2)
            }
            .padding(22)
        }
    }
}
