import SwiftUI
import UIKit

struct HomeView: View {
    @EnvironmentObject private var app: AppCoordinator

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    header
                    deviceCard
                    gameCard(id: "ff", title: "Free Fire", image: "FreeFireIcon")
                    gameCard(id: "ffmax", title: "Free Fire MAX", image: "FreeFireMaxIcon")
                    licenseCard
                    updateCard

                    Text("HTVANTIX • v\(BuildIdentity.version) • Secure Session")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(HTTheme.muted2)
                        .padding(.top, 5)
                }
                .padding(18)
            }
            .background(HTBackground())
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text("HTVANTIX")
                    .font(.system(size: 26, weight: .black, design: .rounded))
                Text("HOME")
                    .font(.caption.weight(.bold))
                    .tracking(2)
                    .foregroundStyle(HTTheme.muted)
            }

            Spacer()

            NavigationLink {
                SettingsView()
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 17, weight: .bold))
                    .frame(width: 44, height: 44)
                    .background(HTTheme.surface2, in: RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(HTTheme.border))
            }
        }
    }

    private var deviceCard: some View {
        HTCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Label("DEVICE", systemImage: "iphone")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(HTTheme.muted)
                    Spacer()
                    Text("READY")
                        .font(.caption2.weight(.black))
                        .foregroundStyle(HTTheme.green)
                }
                row("Model", UIDevice.current.model)
                row("iOS", UIDevice.current.systemVersion)
                row("Compatibility", "พร้อมใช้งาน")
            }
        }
    }

    private func gameCard(id: String, title: String, image: String) -> some View {
        NavigationLink {
            GameHubView(gameID: id, gameTitle: title, gameImage: image)
        } label: {
            HTCard {
                HStack(spacing: 15) {
                    Image(image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 62, height: 62)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))

                    VStack(alignment: .leading, spacing: 6) {
                        Text(title)
                            .font(.system(size: 19, weight: .bold))
                            .foregroundStyle(.white)
                        Text("เลือกฟังก์ชันที่ต้องการ")
                            .font(.caption)
                            .foregroundStyle(HTTheme.muted)
                    }

                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundStyle(HTTheme.accent)
                }
            }
        }
        .buttonStyle(.plain)
    }

    private var licenseCard: some View {
        HTCard {
            HStack {
                VStack(alignment: .leading, spacing: 6) {
                    Text("LICENSE")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(HTTheme.muted)
                    Text("Active")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(HTTheme.green)
                    if let expiry = app.licenseInfo?.expiresAt {
                        Text("หมดอายุ: \(expiry)")
                            .font(.caption2)
                            .foregroundStyle(HTTheme.muted)
                    }
                }
                Spacer()
                Image(systemName: "checkmark.shield.fill")
                    .font(.system(size: 30))
                    .foregroundStyle(HTTheme.green)
            }
        }
    }

    private var updateCard: some View {
        HTCard {
            VStack(alignment: .leading, spacing: 7) {
                Text("HTVANTIX UPDATE")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(HTTheme.muted)
                Text("เวอร์ชัน \(app.config?.version.currentVersion ?? BuildIdentity.version)")
                    .font(.headline)
                Text(app.config?.version.releaseNotes ?? "ระบบพร้อมใช้งาน")
                    .font(.caption)
                    .foregroundStyle(HTTheme.muted)
            }
        }
    }

    private func row(_ left: String, _ right: String) -> some View {
        HStack {
            Text(left).foregroundStyle(HTTheme.muted)
            Spacer()
            Text(right).fontWeight(.semibold)
        }
        .font(.caption)
    }
}
