import SwiftUI

enum HTTheme {
    static let background = Color.black
    static let surface = Color(red: 0.035, green: 0.055, blue: 0.08)
    static let surface2 = Color(red: 0.055, green: 0.085, blue: 0.12)
    static let border = Color(red: 0.16, green: 0.66, blue: 0.92).opacity(0.20)
    static let accent = Color(red: 0.25, green: 0.80, blue: 1.00)
    static let green = Color(red: 0.25, green: 0.90, blue: 0.66)
    static let muted = Color.white.opacity(0.52)
    static let muted2 = Color.white.opacity(0.32)
}

struct HTBackground: View {
    var body: some View {
        ZStack {
            Color.black
            RadialGradient(
                colors: [HTTheme.accent.opacity(0.10), .clear],
                center: .topTrailing,
                startRadius: 0,
                endRadius: 420
            )
        }
        .ignoresSafeArea()
    }
}

struct HTCard<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                LinearGradient(
                    colors: [HTTheme.surface2.opacity(0.95), HTTheme.surface.opacity(0.98)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 22, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(HTTheme.border, lineWidth: 1)
            )
    }
}

struct HTPrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .bold))
            .foregroundStyle(.black)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(HTTheme.accent, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .opacity(configuration.isPressed ? 0.72 : 1)
    }
}
