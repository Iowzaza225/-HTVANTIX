import SwiftUI
import CryptoKit

struct GameHubView: View {
    @EnvironmentObject private var app: AppCoordinator
    let gameID: String
    let gameTitle: String
    let gameImage: String

    @State private var selectedCategory = "shoot"

    private var categories: [V4ClientConfig.Item] {
        app.config?.categories ?? [
            .init(id: "shoot", title: "ไฟล์ยิง"),
            .init(id: "visual", title: "ไฟล์มอง"),
            .init(id: "skin_free", title: "มอดสกิน ฟรี")
        ]
    }

    private var filtered: [RemotePackage] {
        app.packages.filter {
            $0.game == gameID && $0.category == selectedCategory
        }
    }

    var body: some View {
        ZStack {
            HTBackground()

            ScrollView {
                VStack(spacing: 14) {
                    categoryTabs

                    if filtered.isEmpty {
                        HTCard {
                            VStack(spacing: 10) {
                                Image(systemName: "tray")
                                    .font(.system(size: 30))
                                    .foregroundStyle(HTTheme.muted)
                                Text("ยังไม่มีรายการในหมวดนี้")
                                    .foregroundStyle(HTTheme.muted)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 20)
                        }
                    } else {
                        ForEach(filtered) { item in
                            FeatureToggleRow(package: item)
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 24)
            }
            .refreshable { await app.refreshPackages() }
        }
        .navigationTitle(gameTitle)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var categoryTabs: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 9) {
                ForEach(categories.filter { ["shoot", "visual", "skin_free", "other"].contains($0.id) }) { item in
                    Button {
                        selectedCategory = item.id
                    } label: {
                        Text(item.title)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(selectedCategory == item.id ? .black : .white)
                            .padding(.horizontal, 15)
                            .frame(height: 40)
                            .background(
                                selectedCategory == item.id ? HTTheme.accent : HTTheme.surface2,
                                in: Capsule()
                            )
                            .overlay(
                                Capsule().stroke(selectedCategory == item.id ? Color.clear : HTTheme.border)
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.vertical, 2)
        }
    }
}

private struct FeatureToggleRow: View {
    @EnvironmentObject private var app: AppCoordinator
    let package: RemotePackage

    @State private var isEnabled = false
    @State private var isWorking = false
    @State private var workingText = ""
    @State private var errorText = ""
    @State private var showError = false

    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.white.opacity(0.045))
                    .frame(width: 58, height: 58)

                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundStyle(HTTheme.accent)
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(package.name)
                    .font(.system(size: 19, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(2)

                Text(statusText)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(isEnabled ? HTTheme.green : HTTheme.muted)
            }

            Spacer(minLength: 10)

            if isWorking {
                ProgressView()
                    .controlSize(.regular)
                    .tint(HTTheme.accent)
                    .frame(width: 52, height: 44)
            } else {
                Toggle("", isOn: toggleBinding)
                    .labelsHidden()
                    .tint(HTTheme.accent)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 15)
        .frame(maxWidth: .infinity, minHeight: 92)
        .background(
            Color(red: 0.035, green: 0.045, blue: 0.06),
            in: RoundedRectangle(cornerRadius: 22, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
        .onAppear {
            isEnabled = ManagedPatchStore.isApplied(package)
        }
        .alert("ไม่สามารถดำเนินการได้", isPresented: $showError) {
            Button("ตกลง", role: .cancel) { }
        } message: {
            Text(errorText)
        }
    }

    private var statusText: String {
        if isWorking { return workingText.isEmpty ? "กำลังดำเนินการ..." : workingText }
        return isEnabled ? "เปิดอยู่" : "ปิดอยู่"
    }

    private var toggleBinding: Binding<Bool> {
        Binding(
            get: { isEnabled },
            set: { newValue in
                guard !isWorking else { return }
                if newValue {
                    enablePackage()
                } else {
                    disablePackage()
                }
            }
        )
    }

    private func enablePackage() {
        isWorking = true
        workingText = "กำลังดึงไฟล์..."

        Task {
            do {
                // API client checks SHA-256 and file size before returning this URL.
                let downloadedURL = try await app.download(package)

                await MainActor.run {
                    workingText = "กำลังเปิด..."
                }

                try ManagedPatchStore.verify(downloadedURL, package: package)
                try ManagedPatchStore.apply(downloadedURL, package: package)

                await MainActor.run {
                    isEnabled = true
                    isWorking = false
                    workingText = ""
                }
            } catch {
                await MainActor.run {
                    isEnabled = ManagedPatchStore.isApplied(package)
                    isWorking = false
                    workingText = ""
                    errorText = error.localizedDescription
                    showError = true
                }
            }
        }
    }

    private func disablePackage() {
        isWorking = true
        workingText = "กำลังปิด..."

        Task {
            do {
                try ManagedPatchStore.restore(package)
                try ManagedPatchStore.removeDownloadedPackage(package)

                await MainActor.run {
                    isEnabled = false
                    isWorking = false
                    workingText = ""
                }
            } catch {
                await MainActor.run {
                    isEnabled = ManagedPatchStore.isApplied(package)
                    isWorking = false
                    workingText = ""
                    errorText = error.localizedDescription
                    showError = true
                }
            }
        }
    }
}

/// Manages the package apply/restore lifecycle inside HTVANTIX's own iOS sandbox.
/// File metadata stays internal; the UI only exposes the feature name and on/off state.
private enum ManagedPatchStore {
    private static let fm = FileManager.default

    static func isApplied(_ package: RemotePackage) -> Bool {
        guard let marker = try? markerURL(for: package) else { return false }
        return fm.fileExists(atPath: marker.path)
    }

    static func verify(_ url: URL, package: RemotePackage) throws {
        let data = try Data(contentsOf: url)

        if package.sizeBytes > 0, data.count != package.sizeBytes {
            throw PatchError.integrityFailed
        }

        let hash = SHA256.hash(data: data)
            .map { String(format: "%02x", $0) }
            .joined()

        guard hash.caseInsensitiveCompare(package.sha256) == .orderedSame else {
            throw PatchError.integrityFailed
        }
    }

    static func apply(_ downloadedURL: URL, package: RemotePackage) throws {
        let runtimeDir = try runtimeDirectory(for: package)
        let backupDir = try backupDirectory(for: package)
        let stateDir = try stateDirectory()
        let targetURL = runtimeDir.appendingPathComponent(safeComponent(package.fileName))
        let marker = try markerURL(for: package)

        try fm.createDirectory(at: runtimeDir, withIntermediateDirectories: true)
        try fm.createDirectory(at: backupDir, withIntermediateDirectories: true)
        try fm.createDirectory(at: stateDir, withIntermediateDirectories: true)

        // Preserve an existing managed target before replacing it.
        if let existing = firstRegularFile(in: runtimeDir) {
            try? fm.removeItem(at: backupDir)
            try fm.createDirectory(at: backupDir, withIntermediateDirectories: true)
            let backupURL = backupDir.appendingPathComponent(existing.lastPathComponent)
            try fm.copyItem(at: existing, to: backupURL)
        }

        // Replace the runtime package atomically from a temp file.
        let tempURL = runtimeDir.appendingPathComponent(".incoming-")
            .appendingPathExtension(UUID().uuidString)
        try? fm.removeItem(at: tempURL)
        try fm.copyItem(at: downloadedURL, to: tempURL)

        if let existing = firstRegularFile(in: runtimeDir), existing != tempURL {
            try? fm.removeItem(at: existing)
        }
        try? fm.removeItem(at: targetURL)
        try fm.moveItem(at: tempURL, to: targetURL)

        // Marker is written only after the package has been applied successfully.
        let state = targetURL.lastPathComponent.data(using: .utf8) ?? Data()
        try state.write(to: marker, options: .atomic)
    }

    static func restore(_ package: RemotePackage) throws {
        let runtimeDir = try runtimeDirectory(for: package)
        let backupDir = try backupDirectory(for: package)
        let marker = try markerURL(for: package)

        if fm.fileExists(atPath: runtimeDir.path) {
            try fm.removeItem(at: runtimeDir)
        }
        try fm.createDirectory(at: runtimeDir, withIntermediateDirectories: true)

        // Restore the previous managed file if one existed before apply.
        if let backup = firstRegularFile(in: backupDir) {
            let restored = runtimeDir.appendingPathComponent(backup.lastPathComponent)
            try fm.copyItem(at: backup, to: restored)
        }

        if fm.fileExists(atPath: backupDir.path) {
            try fm.removeItem(at: backupDir)
        }
        if fm.fileExists(atPath: marker.path) {
            try fm.removeItem(at: marker)
        }
    }

    static func removeDownloadedPackage(_ package: RemotePackage) throws {
        let docs = try fm.url(
            for: .documentDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let downloads = docs.appendingPathComponent("HTVANTIX", isDirectory: true)
        let file = downloads.appendingPathComponent(safeComponent(package.fileName))

        if fm.fileExists(atPath: file.path) {
            try fm.removeItem(at: file)
        }
    }

    private static func rootDirectory() throws -> URL {
        let base = try fm.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let root = base.appendingPathComponent("HTVANTIX", isDirectory: true)
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }

    private static func runtimeDirectory(for package: RemotePackage) throws -> URL {
        try rootDirectory()
            .appendingPathComponent("ManagedRuntime", isDirectory: true)
            .appendingPathComponent(safeComponent(package.id), isDirectory: true)
    }

    private static func backupDirectory(for package: RemotePackage) throws -> URL {
        try rootDirectory()
            .appendingPathComponent("Backups", isDirectory: true)
            .appendingPathComponent(safeComponent(package.id), isDirectory: true)
    }

    private static func stateDirectory() throws -> URL {
        try rootDirectory().appendingPathComponent("State", isDirectory: true)
    }

    private static func markerURL(for package: RemotePackage) throws -> URL {
        let dir = try stateDirectory()
        return dir.appendingPathComponent(safeComponent(package.id) + ".active")
    }

    private static func firstRegularFile(in directory: URL) -> URL? {
        guard fm.fileExists(atPath: directory.path),
              let entries = try? fm.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.isRegularFileKey],
                options: [.skipsHiddenFiles]
              ) else {
            return nil
        }

        return entries.first { url in
            (try? url.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true
        }
    }

    private static func safeComponent(_ value: String) -> String {
        var result = value
            .replacingOccurrences(of: "..", with: "_")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "\\", with: "_")
            .replacingOccurrences(of: ":", with: "_")

        if result.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            result = UUID().uuidString
        }
        return result
    }
}

private enum PatchError: LocalizedError {
    case integrityFailed

    var errorDescription: String? {
        switch self {
        case .integrityFailed:
            return "ไฟล์ไม่ผ่านการตรวจสอบความถูกต้อง"
        }
    }
}
