import Foundation

struct V4VersionState: Codable, Equatable {
    let currentVersion: String
    let minimumVersion: String
    let updateURL: String
    let message: String
    let releaseNotes: String?
    let maintenance: Bool
    let allowedBuilds: [String]
}

struct LicenseInfo: Codable, Equatable {
    let id: String?
    let status: String?
    let expiresAt: String?
    let activatedAt: String?
    let deviceBoundAt: String?
}

struct LicenseRedeemResponse: Decodable {
    let ok: Bool
    let licenseToken: String
    let license: LicenseInfo?
    let client: V4VersionState?
}

struct SessionResponse: Decodable {
    let ok: Bool
    let sessionToken: String
    let expiresAt: String
    let client: V4VersionState?
}

struct V4ClientConfig: Decodable {
    struct Item: Decodable, Identifiable, Hashable {
        let id: String
        let title: String
    }

    struct Policy: Decodable {
        let privacyShield: Bool
        let screenCaptureCover: String
        let appSwitcherCover: String
    }

    let ok: Bool
    let version: V4VersionState
    let games: [Item]
    let categories: [Item]
    let clientPolicy: Policy
}

struct RemotePackage: Decodable, Identifiable, Hashable {
    let id: String
    let name: String
    let description: String
    let version: String
    let game: String?
    let category: String
    let fileName: String
    let sizeBytes: Int
    let sha256: String
    let createdAt: String
}

struct PackageListResponse: Decodable {
    let ok: Bool
    let packages: [RemotePackage]
}

struct APIErrorEnvelope: Decodable {
    let error: String
    let client: V4VersionState?
}

enum APIError: LocalizedError {
    case server(status: Int, code: String, client: V4VersionState?)
    case malformed
    case clientNotConfigured
    case integrityFailed
    case fileWriteFailed

    var errorDescription: String? {
        switch self {
        case .server(_, let code, _): return code
        case .malformed: return "MALFORMED_RESPONSE"
        case .clientNotConfigured: return "CLIENT_NOT_CONFIGURED"
        case .integrityFailed: return "HASH_MISMATCH"
        case .fileWriteFailed: return "FILE_WRITE_FAILED"
        }
    }
}
