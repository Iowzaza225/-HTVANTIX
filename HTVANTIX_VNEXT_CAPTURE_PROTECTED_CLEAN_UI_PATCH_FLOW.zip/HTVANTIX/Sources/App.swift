import SwiftUI

@main
struct HTVANTIXApp: App {
    @StateObject private var coordinator = AppCoordinator()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(coordinator)
                .preferredColorScheme(.dark)
                .htvantixPrivacyShield()
                .task { await coordinator.bootstrap() }
        }
    }
}
