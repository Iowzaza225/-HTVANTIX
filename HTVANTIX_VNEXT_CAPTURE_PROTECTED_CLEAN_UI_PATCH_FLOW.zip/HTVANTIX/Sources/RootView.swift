import SwiftUI

struct RootView: View {
    @EnvironmentObject private var app: AppCoordinator

    var body: some View {
        ZStack {
            HTBackground()
            switch app.state {
            case .booting:
                BootView()
            case .locked:
                LicenseView()
            case .ready:
                HomeView()
            case .updateRequired(let state):
                UpdateRequiredView(state: state)
            case .maintenance(let state):
                MaintenanceView(message: state?.message)
            case .blocked:
                BlockedBuildView()
            case .error(let message):
                ErrorView(message: message)
            }
        }
    }
}

private struct BootView: View {
    var body: some View {
        VStack(spacing: 16) {
            Image("HTBrandIcon")
                .resizable()
                .scaledToFit()
                .frame(width: 78, height: 78)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            ProgressView().tint(HTTheme.accent)
            Text("HTVANTIX")
                .font(.system(size: 26, weight: .black, design: .rounded))
        }
    }
}

private struct ErrorView: View {
    @EnvironmentObject private var app: AppCoordinator
    let message: String

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 40))
                .foregroundStyle(.orange)
            Text("HTVANTIX")
                .font(.system(size: 24, weight: .black))
            Text(message)
                .foregroundStyle(HTTheme.muted)
                .multilineTextAlignment(.center)
            Button("กลับไปหน้า License") { app.clearError() }
                .buttonStyle(HTPrimaryButtonStyle())
        }
        .padding(28)
    }
}

struct UpdateRequiredView: View {
    let state: V4VersionState

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "arrow.down.circle.fill")
                .font(.system(size: 48))
                .foregroundStyle(HTTheme.accent)
            Text("UPDATE REQUIRED")
                .font(.system(size: 25, weight: .black, design: .rounded))
            Text(state.message.isEmpty ? "กรุณาอัปเดต HTVANTIX เป็นเวอร์ชันล่าสุด" : state.message)
                .foregroundStyle(HTTheme.muted)
                .multilineTextAlignment(.center)
            if let notes = state.releaseNotes, !notes.isEmpty {
                Text(notes)
                    .font(.footnote)
                    .foregroundStyle(HTTheme.muted2)
                    .multilineTextAlignment(.center)
            }
            if let url = URL(string: state.updateURL), !state.updateURL.isEmpty {
                Link("อัปเดต HTVANTIX", destination: url)
                    .buttonStyle(HTPrimaryButtonStyle())
            }
        }
        .padding(28)
    }
}

struct MaintenanceView: View {
    let message: String?

    var body: some View {
        VStack(spacing: 14) {
            ProgressView().tint(.white)
            Text("SYSTEM MAINTENANCE")
                .font(.system(size: 22, weight: .black))
            Text((message?.isEmpty == false) ? message! : "ระบบกำลังอัปเดต กรุณาลองใหม่ภายหลัง")
                .foregroundStyle(HTTheme.muted)
                .multilineTextAlignment(.center)
        }
        .padding(28)
    }
}

struct BlockedBuildView: View {
    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: "lock.shield.fill")
                .font(.system(size: 44))
                .foregroundStyle(.orange)
            Text("BUILD BLOCKED")
                .font(.system(size: 23, weight: .black))
            Text("เวอร์ชันนี้ไม่ได้รับอนุญาตจาก Server")
                .foregroundStyle(HTTheme.muted)
        }
        .padding(28)
    }
}
