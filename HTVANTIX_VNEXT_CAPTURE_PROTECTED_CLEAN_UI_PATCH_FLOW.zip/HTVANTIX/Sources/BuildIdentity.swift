import Foundation

enum BuildIdentity {
    static var version: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "8.11"
    }

    static var build: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "68"
    }

    // Build ID is an identifier, not a secret. Server may allow/deny it.
    static var buildID: String {
        Bundle.main.object(forInfoDictionaryKey: "HTVANTIXBuildID") as? String ?? "HTV-811-68-V41"
    }

    static var appToken: String {
        Bundle.main.object(forInfoDictionaryKey: "HTVANTIXAppToken") as? String ?? ""
    }

    static let baseURL = URL(string: "https://hightapi.netlify.app")!
}
