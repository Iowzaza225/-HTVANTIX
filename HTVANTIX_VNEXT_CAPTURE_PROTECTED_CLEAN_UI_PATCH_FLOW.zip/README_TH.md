# HTVANTIX VNEXT — CLEAN UI + MANAGED PATCH FLOW

รุ่นนี้แก้จาก CLEAN UI โดยนำ flow จัดการ package กลับมา โดยไม่แสดง metadata ของไฟล์บนหน้าแอป

## UI
- การ์ดแต่ละรายการเป็นสวิตช์ เปิด/ปิด
- แสดงเฉพาะชื่อฟังก์ชัน + เปิดอยู่/ปิดอยู่
- ระหว่างดาวน์โหลด/Apply/Restore แสดง spinner
- ไม่แสดง filename, SHA-256, version หรือขนาดไฟล์

## Flow
เปิดสวิตช์:
1. ดาวน์โหลด package จาก API
2. ตรวจ SHA-256 และขนาดไฟล์
3. สำรอง managed target เดิม (ถ้ามี)
4. Apply package ลง managed runtime ของ HTVANTIX
5. บันทึก active state

ปิดสวิตช์:
1. Restore managed target เดิม (ถ้ามี backup)
2. ลบ active state
3. ลบไฟล์ดาวน์โหลดใน Documents/HTVANTIX

> หมายเหตุ: การ Apply/Restore ทำภายใน sandbox ของ HTVANTIX ตามข้อจำกัดของ iOS

ระบบเดิมที่คงไว้: API V4.1.0, License, Version Gate, Package API, SHA/size validation, Capture Protection.
