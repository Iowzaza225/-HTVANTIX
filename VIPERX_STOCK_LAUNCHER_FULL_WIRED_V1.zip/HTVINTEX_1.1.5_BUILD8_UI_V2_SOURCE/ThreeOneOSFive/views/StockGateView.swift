import SwiftUI

struct StockGateView: View {
    @State private var enterMain = false

    var body: some View {
        if enterMain {
            ContentView()
        } else {
            StockLauncherHomeView {
                enterMain = true
            }
        }
    }
}