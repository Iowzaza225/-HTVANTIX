import SwiftUI

struct StockLauncherHomeView: View {
    let onEnter: () -> Void
    @State private var search = ""

    private let items = [
        ("USDT-USD", "Tether USDt USD", true),
        ("BTC-USD", "Bitcoin USD", false)
    ]

    var body: some View {
        NavigationStack {
            List {
                ForEach(items.filter {
                    search.isEmpty || $0.0.contains(search)
                }, id: \.0) { item in
                    Button {
                        if item.2 { onEnter() }
                    } label: {
                        HStack {
                            VStack(alignment:.leading) {
                                Text(item.0).font(.headline)
                                Text(item.1).font(.caption)
                            }
                            Spacer()
                            Text(">")
                        }
                    }
                }
            }
            .navigationTitle("Stocks")
            .searchable(text:$search)
        }
    }
}