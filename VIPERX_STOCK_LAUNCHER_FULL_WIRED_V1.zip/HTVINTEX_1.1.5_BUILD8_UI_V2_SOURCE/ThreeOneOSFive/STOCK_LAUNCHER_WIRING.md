Wired:
App launch -> StockGate -> StockLauncher -> ContentView

Entry symbol:
USDT-USD

Original ContentView remains as main system.