import SwiftUI

@main
struct HTVANTIXApp: App {
    @StateObject private var session = AppSession()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
                .preferredColorScheme(.dark)
                .htvantixPrivacyShield()
        }
    }
}
