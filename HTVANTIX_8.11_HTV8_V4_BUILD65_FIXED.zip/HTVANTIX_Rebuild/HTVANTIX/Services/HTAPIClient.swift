import Foundation

struct HTAPIClient {
    let baseURL: URL
    private let decoder = JSONDecoder()

    init(baseURL: URL = HTBackendConfiguration.baseURL) {
        self.baseURL = baseURL
    }

    enum Route {
        static let status = "api/v4/status"
        static let redeemKey = "api/v4/license/redeem"
        static let session = "api/v4/session"
        static let clientConfig = "api/v4/client/config"
        static let packages = "api/v4/packages"
        static func packageDownload(_ id: String) -> String { "api/v4/packages/\(id)/download" }
    }

    func fetchStatus() async throws -> V4StatusResponse {
        var request = URLRequest(url: routeURL(Route.status))
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        return try await decode(V4StatusResponse.self, request: request)
    }

    func redeemKey(key: String, deviceID: String, deviceModel: String) async throws -> V4LicenseRedeemResponse {
        try requireAppToken()
        let body = V4LicenseRedeemRequest(
            key: key,
            deviceId: deviceID,
            appVersion: HTBackendConfiguration.appVersion,
            buildId: HTBackendConfiguration.buildID,
            deviceModel: deviceModel
        )
        var request = URLRequest(url: routeURL(Route.redeemKey))
        request.httpMethod = "POST"
        request.httpBody = try JSONEncoder().encode(body)
        applyAppHeaders(to: &request)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        return try await decode(V4LicenseRedeemResponse.self, request: request)
    }

    func createSession(licenseToken: String, deviceID: String) async throws -> V4SessionResponse {
        try requireAppToken()
        let body = V4SessionRequest(
            appVersion: HTBackendConfiguration.appVersion,
            buildId: HTBackendConfiguration.buildID,
            deviceId: deviceID
        )
        var request = URLRequest(url: routeURL(Route.session))
        request.httpMethod = "POST"
        request.httpBody = try JSONEncoder().encode(body)
        applyAppHeaders(to: &request)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(licenseToken)", forHTTPHeaderField: "Authorization")
        return try await decode(V4SessionResponse.self, request: request)
    }

    func fetchClientConfig(sessionToken: String) async throws -> V4ClientConfigResponse {
        var request = URLRequest(url: routeURL(Route.clientConfig))
        request.httpMethod = "GET"
        applySessionHeaders(to: &request, sessionToken: sessionToken)
        return try await decode(V4ClientConfigResponse.self, request: request)
    }

    func fetchPackages(sessionToken: String) async throws -> [RemotePatchSummary] {
        var request = URLRequest(url: routeURL(Route.packages))
        request.httpMethod = "GET"
        applySessionHeaders(to: &request, sessionToken: sessionToken)
        let envelope = try await decode(V4PackagesResponse.self, request: request)
        return envelope.packages
    }

    func downloadPatch(_ patch: RemotePatchSummary, sessionToken: String) async throws -> DownloadedPatchPackage {
        try requireAppToken()
        var request = URLRequest(url: routeURL(Route.packageDownload(patch.id)))
        request.httpMethod = "GET"
        request.timeoutInterval = 120
        applySessionHeaders(to: &request, sessionToken: sessionToken)

        let (temporaryURL, response) = try await URLSession.shared.download(for: request)
        try validate(response)

        let fileName = sanitizedFileName(
            patch.fileName?.isEmpty == false ? patch.fileName! : "\(patch.id).bin"
        )
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("HTVANTIX-Downloads", isDirectory: true)
        let destination = directory.appendingPathComponent(fileName)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        if FileManager.default.fileExists(atPath: destination.path) {
            try FileManager.default.removeItem(at: destination)
        }
        try FileManager.default.moveItem(at: temporaryURL, to: destination)
        return DownloadedPatchPackage(patchID: patch.id, localURL: destination, suggestedFileName: fileName)
    }

    private func requireAppToken() throws {
        guard HTBackendConfiguration.isHubConfigured else {
            throw HTAPIError.credentialsMissing("HTVANTIX_APP_TOKEN is not configured for the V4 backend.")
        }
    }

    private func applyAppHeaders(to request: inout URLRequest) {
        request.timeoutInterval = 15
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(HTBackendConfiguration.appToken, forHTTPHeaderField: "X-App-Token")
    }

    private func applySessionHeaders(to request: inout URLRequest, sessionToken: String) {
        applyAppHeaders(to: &request)
        request.setValue("Bearer \(sessionToken)", forHTTPHeaderField: "Authorization")
    }

    private func routeURL(_ path: String) -> URL {
        path.split(separator: "/").reduce(baseURL) { url, component in
            url.appendingPathComponent(String(component))
        }
    }

    private func decode<T: Decodable>(_ type: T.Type, request: URLRequest) async throws -> T {
        let data = try await data(for: request)
        do { return try decoder.decode(T.self, from: data) }
        catch { throw HTAPIError.decoding(error.localizedDescription) }
    }

    private func data(for request: URLRequest) async throws -> Data {
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response, body: data)
        return data
    }

    private func validate(_ response: URLResponse, body: Data? = nil) throws {
        guard let http = response as? HTTPURLResponse else { return }
        guard (200..<300).contains(http.statusCode) else {
            if let body,
               let payload = try? decoder.decode(V4ErrorResponse.self, from: body),
               let code = payload.error, !code.isEmpty {
                throw HTAPIError.server(code: code, status: http.statusCode)
            }
            throw HTAPIError.httpStatus(http.statusCode)
        }
    }

    private func sanitizedFileName(_ raw: String) -> String {
        let leaf = URL(fileURLWithPath: raw).lastPathComponent
        return leaf.isEmpty || leaf == "." || leaf == ".." ? "package.bin" : leaf
    }
}

enum HTAPIError: LocalizedError {
    case credentialsMissing(String)
    case invalidPayload(String)
    case decoding(String)
    case httpStatus(Int)
    case server(code: String, status: Int)

    var errorDescription: String? {
        switch self {
        case .credentialsMissing(let message): return message
        case .invalidPayload(let message): return message
        case .decoding(let message): return "Unable to decode server response: \(message)"
        case .httpStatus(let status): return "Server returned HTTP \(status)."
        case .server(let code, let status):
            switch code {
            case "TOKEN_ENV_MISSING": return "Backend HIGHT_APP_TOKEN is not configured."
            case "TOKEN_HEADER_MISSING": return "The app did not send X-App-Token."
            case let value where value.hasPrefix("TOKEN_MISMATCH_"): return "HTVANTIX_APP_TOKEN does not match the backend."
            case "RATE_LIMIT": return "Too many requests. Please try again shortly."
            case "BAD_REQUEST": return "The backend rejected the request data."
            case "LICENSE_NOT_FOUND", "NOT_FOUND": return "License or package was not found."
            case "LICENSE_DISABLED", "DISABLED": return "This License is disabled."
            case "LICENSE_EXPIRED", "EXPIRED": return "This License has expired."
            case "DEVICE_MISMATCH": return "This License is already bound to another device."
            case "LICENSE_SESSION_REQUIRED": return "License session expired. Please activate again."
            case "SESSION_REQUIRED": return "Client session expired. Please retry."
            case "UPDATE_REQUIRED": return "This app version is below the backend minimum version."
            case "BUILD_BLOCKED": return "This build is not allowed by the backend version gate."
            case "MAINTENANCE": return "The backend is currently in maintenance mode."
            case "SERVICE_UNAVAILABLE": return "This backend service is temporarily disabled."
            case "SERVER_NOT_CONFIGURED": return "The V4 client-session backend is not fully configured."
            case "STORAGE_ERROR": return "The package storage service returned an error."
            default: return "Server error \(code) (HTTP \(status))."
            }
        }
    }
}
