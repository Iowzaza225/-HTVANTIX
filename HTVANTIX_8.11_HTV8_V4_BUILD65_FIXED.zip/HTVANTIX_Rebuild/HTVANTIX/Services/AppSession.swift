import Foundation
import SwiftUI
import Darwin
import UIKit

@MainActor
final class AppSession: ObservableObject {
    @Published var licenseState: LicenseState = .signedOut
    @Published var games: [RemoteGameSummary] = []
    @Published var maintenance: MaintenanceNotice?
    @Published var announcement: Announcement?
    @Published var isLoadingGames = false
    @Published var lastError: String?

    let api: HTAPIClient
    let networkMonitor = NetworkSecurityMonitor()

    private let secureStore = SecureStore()
    private let licenseKeyAccount = "v4-license-key"
    private let legacyLicenseDefaultsKey = "com.htblackshop.license"

    private var licenseToken: String?
    private var clientSessionToken: String?
    private var clientSessionExpiry: Date?

    init(api: HTAPIClient = HTAPIClient()) {
        self.api = api
    }

    var savedLicenseKey: String {
        if let existing = secureStore.load(account: licenseKeyAccount), !existing.isEmpty {
            return existing
        }
        if let legacy = UserDefaults.standard.string(forKey: legacyLicenseDefaultsKey), !legacy.isEmpty {
            try? secureStore.save(legacy, account: licenseKeyAccount)
            UserDefaults.standard.removeObject(forKey: legacyLicenseDefaultsKey)
            return legacy
        }
        return ""
    }

    var deviceID: String { DeviceIdentity.id }

    var isPreviewMode: Bool {
        if case .preview = licenseState { return true }
        return false
    }

    var isUnlocked: Bool {
        switch licenseState {
        case .activated, .preview: return true
        default: return false
        }
    }

    var backendConfigurationMessage: String? {
        guard HTBackendConfiguration.isHubConfigured else {
            return "V4 backend is ready, but HTVANTIX_APP_TOKEN still needs to be configured in the app."
        }
        return nil
    }

    func bootstrap() async {
        networkMonitor.refresh()

        guard !savedLicenseKey.isEmpty else {
            licenseState = .signedOut
            return
        }
        guard HTBackendConfiguration.isHubConfigured else {
            licenseState = .signedOut
            return
        }

        licenseState = .checking
        do {
            let redeem = try await redeemSavedKey()
            licenseState = .activated(expiry: redeem.license.expiresAt)
            try await establishClientSession(using: redeem.licenseToken)
            await loadGames()
        } catch {
            clearEphemeralTokens()
            lastError = Self.friendlyLicenseError(error)
            licenseState = .signedOut
        }
    }

    func activate(key: String) async {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            licenseState = .error("Please enter a License Key")
            return
        }
        guard HTBackendConfiguration.isHubConfigured else {
            licenseState = .error("HTVANTIX_APP_TOKEN is not configured for the V4 backend.")
            return
        }

        licenseState = .checking
        do {
            let redeem = try await api.redeemKey(
                key: trimmed,
                deviceID: deviceID,
                deviceModel: Self.deviceModel
            )
            try secureStore.save(trimmed, account: licenseKeyAccount)
            licenseToken = redeem.licenseToken
            licenseState = .activated(expiry: redeem.license.expiresAt)
            try await establishClientSession(using: redeem.licenseToken)
            lastError = nil
            await loadGames()
        } catch {
            clearEphemeralTokens()
            licenseState = .error(Self.friendlyLicenseError(error))
        }
    }

    func enterPreviewMode() {
        clearEphemeralTokens()
        licenseState = .preview
        maintenance = nil
        announcement = Announcement(
            id: "preview-announcement",
            title: "HTVANTIX Preview",
            message: "Preview Mode shows the interface only. Live V4 packages require the configured backend token and a valid License."
        )
        games = RemoteGameSummary.demo
    }

    func exitPreviewMode() {
        games = []
        announcement = nil
        clearEphemeralTokens()
        licenseState = .signedOut
    }

    func signOut() {
        secureStore.clear(account: licenseKeyAccount)
        UserDefaults.standard.removeObject(forKey: legacyLicenseDefaultsKey)
        games = []
        announcement = nil
        maintenance = nil
        lastError = nil
        clearEphemeralTokens()
        licenseState = .signedOut
    }

    func refreshRemoteState() async {
        guard HTBackendConfiguration.isHubConfigured else { return }
        do {
            _ = try await api.fetchStatus()
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    func loadGames() async {
        if isPreviewMode {
            games = RemoteGameSummary.demo
            return
        }
        guard HTBackendConfiguration.isHubConfigured else {
            games = []
            lastError = "Online Hub requires HTVANTIX_APP_TOKEN to match HIGHT_APP_TOKEN on the backend."
            return
        }

        isLoadingGames = true
        defer { isLoadingGames = false }
        do {
            let token = try await validClientSessionToken()
            let config = try await api.fetchClientConfig(sessionToken: token)
            games = config.games.filter(\.active)
            lastError = nil
        } catch {
            games = []
            lastError = Self.friendlyLicenseError(error)
        }
    }

    func patches(for game: RemoteGameSummary) async throws -> [RemotePatchSummary] {
        if isPreviewMode { return game.patches ?? RemotePatchSummary.demoList }
        let token = try await validClientSessionToken()
        let all = try await api.fetchPackages(sessionToken: token)
        return all.filter { patch in
            patch.active && (patch.gameId == nil || patch.gameId == game.id)
        }
    }

    func download(_ patch: RemotePatchSummary) async throws -> DownloadedPatchPackage {
        guard !isPreviewMode else {
            throw HTAPIError.invalidPayload("Preview Mode does not download remote packages.")
        }
        let token = try await validClientSessionToken()
        do {
            return try await api.downloadPatch(patch, sessionToken: token)
        } catch HTAPIError.server(let code, _) where code == "SESSION_REQUIRED" {
            clientSessionToken = nil
            clientSessionExpiry = nil
            let refreshed = try await validClientSessionToken(forceRefresh: true)
            return try await api.downloadPatch(patch, sessionToken: refreshed)
        }
    }

    private func validClientSessionToken(forceRefresh: Bool = false) async throws -> String {
        if !forceRefresh,
           let token = clientSessionToken,
           let expiry = clientSessionExpiry,
           expiry.timeIntervalSinceNow > 60 {
            return token
        }

        var currentLicenseToken = licenseToken
        if currentLicenseToken == nil {
            let redeem = try await redeemSavedKey()
            currentLicenseToken = redeem.licenseToken
            licenseState = .activated(expiry: redeem.license.expiresAt)
        }

        guard let currentLicenseToken else {
            throw HTAPIError.invalidPayload("No active License token is available.")
        }

        do {
            try await establishClientSession(using: currentLicenseToken)
        } catch HTAPIError.server(let code, _) where code == "LICENSE_SESSION_REQUIRED" {
            let redeem = try await redeemSavedKey()
            try await establishClientSession(using: redeem.licenseToken)
            licenseState = .activated(expiry: redeem.license.expiresAt)
        }

        guard let token = clientSessionToken else {
            throw HTAPIError.invalidPayload("The V4 backend did not create a client session.")
        }
        return token
    }

    private func redeemSavedKey() async throws -> V4LicenseRedeemResponse {
        let key = savedLicenseKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else {
            throw HTAPIError.invalidPayload("No saved License Key is available.")
        }
        let redeem = try await api.redeemKey(
            key: key,
            deviceID: deviceID,
            deviceModel: Self.deviceModel
        )
        licenseToken = redeem.licenseToken
        return redeem
    }

    private func establishClientSession(using token: String) async throws {
        let response = try await api.createSession(licenseToken: token, deviceID: deviceID)
        licenseToken = token
        clientSessionToken = response.sessionToken
        clientSessionExpiry = Self.parseISO8601(response.expiresAt)
    }

    private func clearEphemeralTokens() {
        licenseToken = nil
        clientSessionToken = nil
        clientSessionExpiry = nil
    }

    private static func parseISO8601(_ value: String) -> Date? {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = formatter.date(from: value) { return date }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: value)
    }

    private static var deviceModel: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        let identifier = mirror.children.reduce(into: "") { result, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            result.append(Character(UnicodeScalar(UInt8(value))))
        }
        return identifier.isEmpty ? UIDevice.current.model : identifier
    }

    private static func friendlyLicenseError(_ error: Error) -> String {
        if let apiError = error as? HTAPIError { return apiError.localizedDescription }
        if let urlError = error as? URLError {
            switch urlError.code {
            case .notConnectedToInternet, .networkConnectionLost, .timedOut:
                return "Unable to connect to the server."
            default: break
            }
        }
        return error.localizedDescription
    }
}
