import Foundation

enum HTBackendConfiguration {
    static let baseURL = URL(string: "https://hightapi.netlify.app")!
    static let buildNumber = 68

    static var appVersion: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String) ?? "8.11"
    }

    static var buildID: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String) ?? String(buildNumber)
    }

    // V4 intentionally treats the app token as a client credential, not a master secret.
    // Configure the same value as HIGHT_APP_TOKEN on Netlify via the Xcode scheme
    // environment or HTVANTIX_APP_TOKEN in Info.plist for a release build.
    static var appToken: String {
        configurationValue(named: "HTVANTIX_APP_TOKEN")
    }

    static var isHubConfigured: Bool { !appToken.isEmpty }
    static var isLicenseSigningConfigured: Bool { isHubConfigured }

    private static func configurationValue(named name: String) -> String {
        if let env = ProcessInfo.processInfo.environment[name], !env.isEmpty {
            return env
        }
        if let plistValue = Bundle.main.object(forInfoDictionaryKey: name) as? String,
           !plistValue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return plistValue
        }
        return ""
    }
}
