import Foundation
import Network
import CFNetwork

@MainActor
final class NetworkSecurityMonitor: ObservableObject {
    @Published private(set) var isVPNActive = false
    @Published private(set) var isProxyActive = false

    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "com.htblackshop.htvantix.network-monitor")

    init() {
        monitor.pathUpdateHandler = { [weak self] path in
            let vpn = path.availableInterfaces.contains { interface in
                let name = interface.name.lowercased()
                return name.contains("utun") || name.contains("ppp") || name.contains("ipsec") || name.contains("tap") || name.contains("tun")
            }
            let proxy = Self.systemProxyEnabled()
            Task { @MainActor in
                self?.isVPNActive = vpn
                self?.isProxyActive = proxy
            }
        }
        monitor.start(queue: queue)
    }

    deinit { monitor.cancel() }

    func refresh() {
        isProxyActive = Self.systemProxyEnabled()
    }

    private nonisolated static func systemProxyEnabled() -> Bool {
        guard let settings = CFNetworkCopySystemProxySettings()?.takeRetainedValue() as? [String: Any] else {
            return false
        }
        let http = (settings["HTTPEnable"] as? NSNumber)?.boolValue ?? false
        let https = (settings["HTTPSEnable"] as? NSNumber)?.boolValue ?? false
        return http || https
    }
}
