import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var session: AppSession
    @State private var showRoutes = false

    var body: some View {
        NavigationStack {
            List {
                Section("HTVANTIX") {
                    LabeledContent("Version", value: "8.11 (68)")
                    LabeledContent("Backend", value: "hightapi.netlify.app")
                    LabeledContent("Device ID", value: String(session.deviceID.prefix(12)) + "…")
                    LabeledContent("Mode", value: session.isPreviewMode ? "Preview" : "Live")
                }

                Section("HIGHT API V4") {
                    configurationRow("Online Hub token", configured: HTBackendConfiguration.isHubConfigured)
                                        Button { showRoutes.toggle() } label: {
                        Label(showRoutes ? "Hide V4 routes" : "Show V4 routes", systemImage: "point.3.connected.trianglepath.dotted")
                    }

                    if showRoutes {
                        VStack(alignment: .leading, spacing: 7) {
                            route("Status", HTAPIClient.Route.status)
                            route("License redeem", HTAPIClient.Route.redeemKey)
                            route("Client session", HTAPIClient.Route.session)
                            route("Client config", HTAPIClient.Route.clientConfig)
                            route("Packages", HTAPIClient.Route.packages)
                            route("Download", "api/v4/packages/:id/download")
                        }
                        .padding(.vertical, 5)
                    }
                }

                Section("Network") {
                    LabeledContent("VPN", value: session.networkMonitor.isVPNActive ? "Detected" : "Not detected")
                    LabeledContent("Proxy", value: session.networkMonitor.isProxyActive ? "Detected" : "Not detected")
                    Button("Refresh network state") { session.networkMonitor.refresh() }
                }

                Section("Account") {
                    if session.isPreviewMode {
                        Button { session.exitPreviewMode(); dismiss() } label: {
                            Label("Exit Preview Mode", systemImage: "rectangle.portrait.and.arrow.right")
                        }
                    } else {
                        Button(role: .destructive) { session.signOut(); dismiss() } label: {
                            Label("Change License Key", systemImage: "key.horizontal")
                        }
                    }
                }

                Section("Backend integration") {
                    Text("HTVANTIX is connected to the HIGHT API V4 flow: License redeem → short client session → config/packages → signed R2 download.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    Text("HTVANTIX_APP_TOKEN must match HIGHT_APP_TOKEN on Netlify. The app keeps the License Key in Keychain; V4 session tokens stay in memory and refresh automatically.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .background(.black)
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    @ViewBuilder
    private func configurationRow(_ title: String, configured: Bool) -> some View {
        HStack {
            Text(title)
            Spacer()
            Text(configured ? "Configured" : "Needs setup")
                .font(.caption.weight(.semibold))
                .foregroundStyle(configured ? HTTheme.success : HTTheme.warning)
        }
    }

    private func route(_ name: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(name).font(.caption.weight(.semibold))
            Text(value).font(.system(size: 11, design: .monospaced)).foregroundStyle(.secondary)
        }
    }
}
