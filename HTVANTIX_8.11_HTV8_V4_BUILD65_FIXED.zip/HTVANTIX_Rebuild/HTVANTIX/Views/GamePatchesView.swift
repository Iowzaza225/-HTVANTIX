import SwiftUI

struct GamePatchesView: View {
    @EnvironmentObject private var session: AppSession
    let game: RemoteGameSummary

    @State private var patches: [RemotePatchSummary] = []
    @State private var isLoading = false
    @State private var downloadingID: String?
    @State private var downloadedPackage: DownloadedPatchPackage?
    @State private var alertMessage: String?
    @State private var selectedCategory = "shoot"

    private let categoryOrder: [(id: String, title: String)] = [
        ("shoot", "ไฟล์ยิง"),
        ("visual", "ไฟล์มอง"),
        ("skin_free", "มอดสกิน ฟรี"),
        ("other", "อื่นๆ")
    ]

    private var filteredPatches: [RemotePatchSummary] {
        patches.filter { normalizedCategory($0.category) == selectedCategory }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                gameHeader
                categoryTabs

                if isLoading {
                    HTCard {
                        HStack(spacing: 12) {
                            ProgressView().tint(.white)
                            Text("Loading modules…").foregroundStyle(HTTheme.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                } else if filteredPatches.isEmpty {
                    HTCard {
                        VStack(spacing: 10) {
                            Image(systemName: "tray")
                                .font(.system(size: 30))
                                .foregroundStyle(HTTheme.secondary)
                            Text("ยังไม่มีรายการในหมวดนี้")
                                .foregroundStyle(HTTheme.secondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 20)
                    }
                } else {
                    ForEach(filteredPatches) { patch in
                        patchCard(patch)
                    }
                }

                safetyNote
            }
            .frame(maxWidth: 760)
            .padding(18)
            .frame(maxWidth: .infinity)
        }
        .background(HTBackground())
        .navigationTitle(game.name)
        .navigationBarTitleDisplayMode(.inline)
        .task { await load() }
        .refreshable { await load() }
        .alert("HTVANTIX", isPresented: Binding(
            get: { alertMessage != nil },
            set: { if !$0 { alertMessage = nil } }
        )) {
            Button("OK", role: .cancel) { alertMessage = nil }
        } message: {
            Text(alertMessage ?? "")
        }
        .sheet(item: $downloadedPackage) { package in
            DownloadCompleteView(package: package)
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
        }
    }

    private var categoryTabs: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 9) {
                ForEach(categoryOrder, id: \.id) { item in
                    Button {
                        selectedCategory = item.id
                    } label: {
                        Text(item.title)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(selectedCategory == item.id ? .black : .white)
                            .padding(.horizontal, 15)
                            .frame(height: 40)
                            .background(
                                selectedCategory == item.id ? HTTheme.accent : HTTheme.surface2,
                                in: Capsule()
                            )
                            .overlay(
                                Capsule().stroke(selectedCategory == item.id ? Color.clear : HTTheme.border)
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.vertical, 2)
        }
    }

    private func normalizedCategory(_ raw: String?) -> String {
        let value = (raw ?? "other").lowercased()
        switch value {
        case "shoot", "aim", "aimbot", "ยิง": return "shoot"
        case "visual", "esp", "มอง": return "visual"
        case "skin_free", "skin", "skins", "มอดสกิน": return "skin_free"
        default: return "other"
        }
    }

    private var gameHeader: some View {
        HTCard {
            HStack(spacing: 14) {
                RoundedRectangle(cornerRadius: 17)
                    .fill(Color(hex: game.bannerColor ?? "") ?? Color.white.opacity(0.08))
                    .frame(width: 64, height: 64)
                    .overlay(Image(systemName: "gamecontroller.fill").font(.system(size: 26)))

                VStack(alignment: .leading, spacing: 5) {
                    Text(game.name).font(.system(size: 22, weight: .black))
                    Text(game.bundleID ?? "ONLINE MODULES")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundStyle(HTTheme.secondary)
                    if session.isPreviewMode { HTStatusPill(text: "Preview", success: false) }
                }
                Spacer()
            }
        }
    }

    private func patchCard(_ patch: RemotePatchSummary) -> some View {
        HStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.white.opacity(0.045))
                    .frame(width: 58, height: 58)

                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundStyle(HTTheme.accent)
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(patch.title)
                    .font(.system(size: 19, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(2)

                Text(downloadingID == patch.id ? "กำลังดึงไฟล์..." : (patch.active ? "พร้อมใช้งาน" : "ปิดอยู่"))
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(patch.active ? HTTheme.green : HTTheme.secondary)
            }

            Spacer(minLength: 10)

            Button {
                Task { await download(patch) }
            } label: {
                if downloadingID == patch.id {
                    ProgressView()
                        .tint(HTTheme.accent)
                        .frame(width: 44, height: 44)
                } else {
                    Image(systemName: "arrow.down.circle.fill")
                        .font(.system(size: 27, weight: .semibold))
                        .foregroundStyle(session.isPreviewMode ? HTTheme.secondary : HTTheme.accent)
                        .frame(width: 44, height: 44)
                }
            }
            .buttonStyle(.plain)
            .disabled(downloadingID != nil || session.isPreviewMode || !patch.active)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 15)
        .frame(maxWidth: .infinity, minHeight: 92)
        .background(
            HTTheme.surface,
            in: RoundedRectangle(cornerRadius: 22, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(HTTheme.border, lineWidth: 1)
        )
    }

    private var safetyNote: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "shield.lefthalf.filled")
            Text("This recovery project restores the catalog and package-download interface. The original cross-app/sandbox-escape patch engine is intentionally not included in the rebuilt source.")
        }
        .font(.system(size: 11))
        .foregroundStyle(Color.white.opacity(0.42))
        .padding(.horizontal, 4)
    }

    private func load() async {
        isLoading = true
        defer { isLoading = false }
        do {
            patches = try await session.patches(for: game)
        } catch {
            patches = []
            alertMessage = error.localizedDescription
        }
    }

    private func download(_ patch: RemotePatchSummary) async {
        downloadingID = patch.id
        defer { downloadingID = nil }
        do {
            downloadedPackage = try await session.download(patch)
        } catch {
            alertMessage = error.localizedDescription
        }
    }
}

private struct DownloadCompleteView: View {
    let package: DownloadedPatchPackage

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 44))
                .foregroundStyle(HTTheme.success)
            Text("Package downloaded").font(.title2.bold())
            Text(package.suggestedFileName)
                .font(.system(size: 13, design: .monospaced))
                .foregroundStyle(HTTheme.secondary)
                .lineLimit(2)
            ShareLink(item: package.localURL) {
                Label("Export Package", systemImage: "square.and.arrow.up")
            }
            .buttonStyle(HTPrimaryButton())
            Text("The package is downloaded only. No files in another application are modified by this rebuild.")
                .font(.system(size: 11))
                .foregroundStyle(HTTheme.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(26)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.black)
    }
}
