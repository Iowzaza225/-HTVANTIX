import SwiftUI

@MainActor
enum HTTheme {
    // HTV8 visual system: near-black + deep navy + restrained cyan.
    static let background = Color(red: 0.010, green: 0.015, blue: 0.024)
    static let card = Color(red: 0.025, green: 0.043, blue: 0.067)
    static let cardAlt = Color(red: 0.040, green: 0.070, blue: 0.105)
    static let surface = Color(red: 0.025, green: 0.043, blue: 0.067)
    static let surface2 = Color(red: 0.040, green: 0.070, blue: 0.105)
    static let surface3 = Color(red: 0.055, green: 0.095, blue: 0.140)
    static let border = Color(red: 0.22, green: 0.72, blue: 0.96).opacity(0.22)
    static let strongBorder = Color(red: 0.30, green: 0.82, blue: 1.00).opacity(0.34)
    static let accent = Color(red: 0.30, green: 0.82, blue: 1.00)
    static let accentSoft = Color(red: 0.30, green: 0.82, blue: 1.00).opacity(0.12)
    static let secondary = Color.white.opacity(0.58)
    static let tertiary = Color.white.opacity(0.34)
    static let success = Color(red: 0.22, green: 0.88, blue: 0.52)
    static let green = success
    static let danger = Color(red: 1.0, green: 0.42, blue: 0.42)
    static let warning = Color(red: 1.0, green: 0.76, blue: 0.34)

    static let cardRadius: CGFloat = 23
    static let fieldRadius: CGFloat = 19
    static let buttonRadius: CGFloat = 14
}

struct HTBackground: View {
    var body: some View {
        ZStack {
            HTTheme.background
            LinearGradient(
                colors: [
                    Color(red: 0.015, green: 0.045, blue: 0.075),
                    HTTheme.background,
                    Color.black
                ],
                startPoint: .topTrailing,
                endPoint: .bottomLeading
            )
            .opacity(0.78)

            RadialGradient(
                colors: [HTTheme.accent.opacity(0.085), .clear],
                center: .topTrailing,
                startRadius: 10,
                endRadius: 460
            )
        }
        .ignoresSafeArea()
    }
}

struct HTCard<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(20)
            .background(
                LinearGradient(
                    colors: [Color(red: 0.10, green: 0.10, blue: 0.11).opacity(0.97), HTTheme.cardAlt.opacity(0.97)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(RoundedRectangle(cornerRadius: HTTheme.cardRadius).stroke(HTTheme.border, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: HTTheme.cardRadius))
    }
}

struct HTPrimaryButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .heavy))
            .foregroundStyle(.black)
            .frame(maxWidth: .infinity, minHeight: 50)
            .background(HTTheme.accent.opacity(configuration.isPressed ? 0.78 : 1))
            .clipShape(RoundedRectangle(cornerRadius: HTTheme.buttonRadius))
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

struct HTSecondaryButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .bold))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity, minHeight: 46)
            .background(Color.white.opacity(configuration.isPressed ? 0.11 : 0.07))
            .overlay(RoundedRectangle(cornerRadius: 13).stroke(HTTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 13))
    }
}

struct HTStatusPill: View {
    let text: String
    var success = true

    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(success ? HTTheme.success : HTTheme.warning).frame(width: 6, height: 6)
            Text(text.uppercased())
                .font(.system(size: 10, weight: .black, design: .monospaced))
                .tracking(0.6)
        }
        .foregroundStyle(success ? HTTheme.success : HTTheme.warning)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background((success ? HTTheme.success : HTTheme.warning).opacity(0.10))
        .clipShape(Capsule())
    }
}

extension Color {
    init?(hex: String) {
        var text = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.hasPrefix("#") { text.removeFirst() }
        guard text.count == 6, let value = Int(text, radix: 16) else { return nil }
        self.init(
            red: Double((value >> 16) & 0xFF) / 255,
            green: Double((value >> 8) & 0xFF) / 255,
            blue: Double(value & 0xFF) / 255
        )
    }
}
