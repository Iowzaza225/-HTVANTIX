import Foundation

struct RemoteContainerSummary: Identifiable, Codable, Hashable {
    let id: String
    var name: String
    var bundleID: String?
    var bannerColor: String?
    var iconPath: String?
    var createdAt: String?
}

struct RemoteGameSummary: Identifiable, Codable, Hashable {
    let id: String
    var name: String
    var subtitle: String?
    var bundleID: String?
    var bannerColor: String?
    var iconPath: String?
    var order: Int?
    var active: Bool
    var patches: [RemotePatchSummary]?

    var bundleId: String? { bundleID }

    init(
        id: String,
        name: String,
        subtitle: String? = nil,
        bundleID: String? = nil,
        bannerColor: String? = nil,
        iconPath: String? = nil,
        order: Int? = nil,
        active: Bool = true,
        patches: [RemotePatchSummary]? = nil
    ) {
        self.id = id
        self.name = name
        self.subtitle = subtitle
        self.bundleID = bundleID
        self.bannerColor = bannerColor
        self.iconPath = iconPath
        self.order = order
        self.active = active
        self.patches = patches
    }

    enum CodingKeys: String, CodingKey {
        case id, gameId, name, title, subtitle, description
        case bundleID, bundleId, bannerColor, iconPath, icon, order, active, enabled, patches
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let decodedID = try c.decodeIfPresent(String.self, forKey: .id)
            ?? c.decodeIfPresent(String.self, forKey: .gameId)
            ?? UUID().uuidString
        id = decodedID
        name = try c.decodeIfPresent(String.self, forKey: .name)
            ?? c.decodeIfPresent(String.self, forKey: .title)
            ?? "Untitled Game"
        subtitle = try c.decodeIfPresent(String.self, forKey: .subtitle)
            ?? c.decodeIfPresent(String.self, forKey: .description)
        bundleID = try c.decodeIfPresent(String.self, forKey: .bundleID)
            ?? c.decodeIfPresent(String.self, forKey: .bundleId)
        bannerColor = try c.decodeIfPresent(String.self, forKey: .bannerColor)
        iconPath = try c.decodeIfPresent(String.self, forKey: .iconPath)
            ?? c.decodeIfPresent(String.self, forKey: .icon)
        order = try c.decodeIfPresent(Int.self, forKey: .order)
        active = try c.decodeIfPresent(Bool.self, forKey: .active)
            ?? c.decodeIfPresent(Bool.self, forKey: .enabled)
            ?? true
        patches = try c.decodeIfPresent([RemotePatchSummary].self, forKey: .patches)
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(id, forKey: .id)
        try c.encode(name, forKey: .name)
        try c.encodeIfPresent(subtitle, forKey: .subtitle)
        try c.encodeIfPresent(bundleID, forKey: .bundleID)
        try c.encodeIfPresent(bannerColor, forKey: .bannerColor)
        try c.encodeIfPresent(iconPath, forKey: .iconPath)
        try c.encodeIfPresent(order, forKey: .order)
        try c.encode(active, forKey: .active)
        try c.encodeIfPresent(patches, forKey: .patches)
    }

    static let demo: [RemoteGameSummary] = [
        .init(
            id: "preview-game",
            name: "HTVANTIX Game Library",
            subtitle: "Preview interface — connect your backend to load live games",
            bundleID: "com.example.game",
            bannerColor: "#171719",
            active: true,
            patches: RemotePatchSummary.demoList
        )
    ]
}

struct RemotePatchSummary: Identifiable, Codable, Hashable {
    let id: String
    var gameId: String?
    var category: String?
    var title: String
    var detail: String?
    var version: String?
    var fileName: String?
    var sizeBytes: Int64?
    var sha256: String?
    var containerId: String?
    var password: String?
    var active: Bool

    enum CodingKeys: String, CodingKey {
        case id, gameId, game, category, categoryId, name, title, detail, description, version
        case fileName, sizeBytes, sha256, containerId, password, active, enabled
    }

    init(
        id: String,
        gameId: String? = nil,
        category: String? = nil,
        title: String,
        detail: String? = nil,
        version: String? = nil,
        fileName: String? = nil,
        sizeBytes: Int64? = nil,
        sha256: String? = nil,
        containerId: String? = nil,
        password: String? = nil,
        active: Bool = true
    ) {
        self.id = id
        self.gameId = gameId
        self.category = category
        self.title = title
        self.detail = detail
        self.version = version
        self.fileName = fileName
        self.sizeBytes = sizeBytes
        self.sha256 = sha256
        self.containerId = containerId
        self.password = password
        self.active = active
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decodeIfPresent(String.self, forKey: .id) ?? UUID().uuidString
        gameId = try c.decodeIfPresent(String.self, forKey: .gameId)
            ?? c.decodeIfPresent(String.self, forKey: .game)
        category = try c.decodeIfPresent(String.self, forKey: .category)
            ?? c.decodeIfPresent(String.self, forKey: .categoryId)
        title = try c.decodeIfPresent(String.self, forKey: .title)
            ?? c.decodeIfPresent(String.self, forKey: .name)
            ?? "Untitled Module"
        detail = try c.decodeIfPresent(String.self, forKey: .detail)
            ?? c.decodeIfPresent(String.self, forKey: .description)
        version = try c.decodeIfPresent(String.self, forKey: .version)
        fileName = try c.decodeIfPresent(String.self, forKey: .fileName)
        sizeBytes = try c.decodeIfPresent(Int64.self, forKey: .sizeBytes)
        sha256 = try c.decodeIfPresent(String.self, forKey: .sha256)
        containerId = try c.decodeIfPresent(String.self, forKey: .containerId)
        password = try c.decodeIfPresent(String.self, forKey: .password)
        active = try c.decodeIfPresent(Bool.self, forKey: .active)
            ?? c.decodeIfPresent(Bool.self, forKey: .enabled)
            ?? true
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(id, forKey: .id)
        try c.encodeIfPresent(gameId, forKey: .gameId)
        try c.encodeIfPresent(category, forKey: .category)
        try c.encode(title, forKey: .title)
        try c.encodeIfPresent(detail, forKey: .detail)
        try c.encodeIfPresent(version, forKey: .version)
        try c.encodeIfPresent(fileName, forKey: .fileName)
        try c.encodeIfPresent(sizeBytes, forKey: .sizeBytes)
        try c.encodeIfPresent(sha256, forKey: .sha256)
        try c.encodeIfPresent(containerId, forKey: .containerId)
        try c.encodeIfPresent(password, forKey: .password)
        try c.encode(active, forKey: .active)
    }

    static let demoList: [RemotePatchSummary] = [
        .init(id: "preview-1", gameId: "preview-game", category: "shoot", title: "Stable Module", detail: "Preview card for the recovered online module interface.", version: "8.11", fileName: "preview.3105", sizeBytes: 1_420_000),
        .init(id: "preview-2", gameId: "preview-game", category: "visual", title: "Alternative Module", detail: "Safe preview only. The cross-app patch engine is not included.", version: "1.0", fileName: "preview-alt.3105", sizeBytes: 910_000)
    ]
}

struct HubEnvelope: Codable, Hashable {
    var containers: [RemoteContainerSummary]?
    var patches: [RemotePatchSummary]?
    var games: [RemoteGameSummary]?
}

struct Announcement: Identifiable, Codable, Hashable {
    let id: String
    var title: String
    var message: String
    var linkLabel: String?
    var linkURL: String?

    init(id: String, title: String, message: String, linkLabel: String? = nil, linkURL: String? = nil) {
        self.id = id
        self.title = title
        self.message = message
        self.linkLabel = linkLabel
        self.linkURL = linkURL
    }
}

struct MaintenanceNotice: Codable, Hashable {
    var maintenance: Bool
    var maintenanceTitle: String?
    var maintenanceMessage: String?
}

struct RemoteNoticePayload: Codable, Hashable {
    var maintenance: Bool?
    var maintenanceTitle: String?
    var maintenanceMessage: String?
    var announcemenx: Announcement?
    var announcement: Announcement?
    var enabled: Bool?

    var resolvedMaintenance: MaintenanceNotice? {
        guard maintenance == true else { return nil }
        return MaintenanceNotice(
            maintenance: true,
            maintenanceTitle: maintenanceTitle,
            maintenanceMessage: maintenanceMessage
        )
    }

    var resolvedAnnouncement: Announcement? { announcemenx ?? announcement }
}

struct KeyResponse: Codable, Hashable {
    var redeemedAt: String?
    var durationDays: Int?
    var expiresAt: String?
}

enum LicenseState: Equatable {
    case checking
    case signedOut
    case activated(expiry: String?)
    case preview
    case error(String)
}

struct DownloadedPatchPackage: Identifiable, Hashable {
    var id: String { patchID }
    let patchID: String
    let localURL: URL
    let suggestedFileName: String
}


// MARK: - HIGHT API V4 wire models

struct V4StatusResponse: Codable, Hashable {
    var ok: Bool
    var service: String?
    var diagnosticBuild: String?
    var deployedAt: String?
}

struct V4LicenseRedeemRequest: Codable {
    let key: String
    let deviceId: String
    let appVersion: String
    let buildId: String
    let deviceModel: String
}

struct V4SessionRequest: Codable {
    let appVersion: String
    let buildId: String
    let deviceId: String
}

struct V4LicensePublic: Codable, Hashable {
    var id: String?
    var keyHint: String?
    var durationDays: Int?
    var durationMinutes: Int?
    var activationMode: String?
    var status: String?
    var createdAt: String?
    var activatedAt: String?
    var expiresAt: String?
    var remainingSeconds: Int?
    var deviceBound: Bool?
    var deviceHint: String?
    var deviceBoundAt: String?
    var lastVerifiedAt: String?
    var lastAppVersion: String?
}

struct V4LicenseRedeemResponse: Codable, Hashable {
    var ok: Bool
    var licenseToken: String
    var license: V4LicensePublic
}

struct V4SessionResponse: Codable, Hashable {
    var ok: Bool
    var sessionToken: String
    var expiresAt: String
}

struct V4CategorySummary: Identifiable, Codable, Hashable {
    let id: String
    var title: String
}

struct V4ClientConfigResponse: Codable, Hashable {
    var ok: Bool
    var games: [RemoteGameSummary]
    var categories: [V4CategorySummary]
}

struct V4PackagesResponse: Codable, Hashable {
    var ok: Bool
    var packages: [RemotePatchSummary]
}

struct V4ErrorResponse: Codable, Hashable {
    var error: String?
    var detail: String?
}
