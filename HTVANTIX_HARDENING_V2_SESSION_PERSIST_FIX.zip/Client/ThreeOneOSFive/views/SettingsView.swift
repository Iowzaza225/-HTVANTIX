import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var licenseManager: HTVLicenseManager
    @AppStorage("htvantix.license.key") private var storedLicenseKey = ""
    @AppStorage("htvantix.license.expiresAt") private var storedLicenseExpiresAt = ""
    @AppStorage("htvantix.license.status") private var storedLicenseStatus = ""
    @State private var now = Date()
    @State private var showSignOutConfirm = false

    var body: some View {
        NavigationStack {
            ZStack {
                ZStack {
                    Color(red: 0.006, green: 0.013, blue: 0.020)
                    LinearGradient(
                        colors: [Color.cyan.opacity(0.045), Color.clear],
                        startPoint: .topLeading,
                        endPoint: .center
                    )
                }
                .ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 14) {
                        brandCard
                        supportedIOSCard
                        licenseCard
                        creditFooter
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 12)
                    .padding(.bottom, 34)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .safeAreaInset(edge: .top) {
                HStack {
                    Text("HTVANTIX")
                        .font(.headline.weight(.black))
                        .foregroundStyle(.white)

                    Spacer()

                    Button("Done") { dismiss() }
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(AppTheme.accent)
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(AppTheme.pageBackground.opacity(0.96))
            }
            .confirmationDialog(
                "ออกจากคีย์นี้?",
                isPresented: $showSignOutConfirm,
                titleVisibility: .visible
            ) {
                Button("ออกจากคีย์", role: .destructive) {
                    dismiss()
                    licenseManager.signOutLicense()
                }
                Button("ยกเลิก", role: .cancel) {}
            } message: {
                Text("Session และข้อมูลคีย์ที่บันทึกไว้ในเครื่องนี้จะถูกล้าง")
            }
            .task {
                while !Task.isCancelled {
                    now = Date()
                    try? await Task.sleep(nanoseconds: 60_000_000_000)
                }
            }
        }
    }

    private var brandCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 14) {
                Image("HTVLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 72, height: 72)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(AppTheme.accent.opacity(0.35), lineWidth: 1)
                    )

                VStack(alignment: .leading, spacing: 5) {
                    Text("HTVANTIX")
                        .font(.title3.weight(.black))
                        .foregroundStyle(.white)
                    Text("GAME ENHANCER")
                        .font(.caption2.weight(.bold))
                        .tracking(1.8)
                        .foregroundStyle(AppTheme.accent)
                    Text("Developed by HTVANTIX")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Divider().overlay(AppTheme.border)

            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("APP VERSION")
                        .htSettingsLabel()
                    Text(appVersion)
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.white)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text("BUILD")
                        .htSettingsLabel()
                    Text(buildVersion)
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.white)
                }
            }
        }
        .htSettingsCard()
    }

    private var supportedIOSCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("SUPPORTED iOS")
                        .font(.headline.weight(.black))
                        .foregroundStyle(.white)
                    Text("เครื่องนี้: iOS \(AppInfo.osVersion)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Label(
                    appState.isSupported ? "รองรับ" : "ไม่รองรับ",
                    systemImage: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill"
                )
                .font(.caption.weight(.bold))
                .foregroundStyle(appState.isSupported ? Color.green : Color.red)
            }

            Divider().overlay(AppTheme.border)

            supportRow("iOS 17", "17.0–17.7.x")
            supportRow("iOS 18", "18.0–18.7.1")
            supportRow("iOS 26", "26.0–26.6.1")
            supportRow("iOS 27", "Developer / Public Beta")
        }
        .htSettingsCard()
    }

    private func supportRow(_ title: String, _ range: String) -> some View {
        HStack {
            Image(systemName: "checkmark.circle.fill")
                .foregroundStyle(Color.green)
            Text(title)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(.white)
            Spacer()
            Text(range)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private var licenseCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("LICENSE")
                        .font(.headline.weight(.black))
                        .foregroundStyle(.white)
                    Text(maskedLicenseKey)
                        .font(.system(.caption, design: .monospaced).weight(.semibold))
                        .foregroundStyle(.secondary)
                }

                Spacer()

                HStack(spacing: 6) {
                    Circle()
                        .fill(licenseStatusColor)
                        .frame(width: 8, height: 8)
                    Text(licenseStatusText)
                        .font(.caption.weight(.bold))
                        .foregroundStyle(licenseStatusColor)
                }
            }

            Divider().overlay(AppTheme.border)

            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("เวลาที่เหลือ")
                        .htSettingsLabel()
                    Text(remainingTimeText)
                        .font(.title3.weight(.black))
                        .foregroundStyle(remainingTimeColor)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text("หมดอายุ")
                        .htSettingsLabel()
                    Text(expiryDateText)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white)
                        .multilineTextAlignment(.trailing)
                }
            }

            Button(role: .destructive) {
                showSignOutConfirm = true
            } label: {
                Label("ออกจากคีย์เก่า", systemImage: "rectangle.portrait.and.arrow.right")
                    .font(.subheadline.weight(.bold))
                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.red)
            .background(Color.red.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.red.opacity(0.28), lineWidth: 1)
            )
            .disabled(storedLicenseKey.isEmpty)
            .opacity(storedLicenseKey.isEmpty ? 0.5 : 1)
        }
        .htSettingsCard()
    }

    private var creditFooter: some View {
        VStack(spacing: 10) {
            Image("HTVLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 44, height: 44)
                .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))

            Text("HTVANTIX")
                .font(.headline.weight(.black))
                .foregroundStyle(.white)

            Text("Developed by HTVANTIX")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 20)
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private var buildVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
    }

    private var maskedLicenseKey: String {
        let key = storedLicenseKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return "ยังไม่มีคีย์" }
        if key.count <= 10 { return key }
        return "\(key.prefix(5))••••\(key.suffix(5))"
    }

    private var licenseStatusText: String {
        switch storedLicenseStatus.lowercased() {
        case "active": return "ACTIVE"
        case "expired": return "EXPIRED"
        case "disabled": return "DISABLED"
        default: return storedLicenseKey.isEmpty ? "NO KEY" : "UNKNOWN"
        }
    }

    private var licenseStatusColor: Color {
        switch storedLicenseStatus.lowercased() {
        case "active": return .green
        case "expired", "disabled": return .red
        default: return .secondary
        }
    }

    private var expiryDate: Date? {
        let raw = storedLicenseExpiresAt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return nil }
        return ISO8601DateFormatter().date(from: raw)
    }

    private var expiryDateText: String {
        guard let date = expiryDate else { return "—" }
        return date.formatted(date: .abbreviated, time: .shortened)
    }

    private var remainingTimeText: String {
        guard let expiry = expiryDate else { return "—" }
        let seconds = expiry.timeIntervalSince(now)
        guard seconds > 0 else { return "หมดอายุแล้ว" }

        let totalHours = Int(seconds / 3600)
        let days = totalHours / 24
        let hours = totalHours % 24

        if days > 0 {
            return "\(days) วัน \(hours) ชม."
        }

        let minutes = max(0, Int(seconds / 60) % 60)
        return "\(hours) ชม. \(minutes) นาที"
    }

    private var remainingTimeColor: Color {
        guard let expiry = expiryDate else { return .secondary }
        let hours = expiry.timeIntervalSince(now) / 3600
        if hours <= 0 { return .red }
        if hours <= 24 { return .orange }
        return .green
    }
}

private extension View {
    func htSettingsCard() -> some View {
        self
            .padding(18)
            .background(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(Color(red: 0.025, green: 0.040, blue: 0.055))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.cyan.opacity(0.14), lineWidth: 1)
            )
    }

    func htSettingsLabel() -> some View {
        self
            .font(.caption2.weight(.bold))
            .tracking(1.2)
            .foregroundStyle(.secondary)
    }
}
