import SwiftUI

enum AppTheme {
    static let accent = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.18, green: 0.86, blue: 1.00, alpha: 1.00)
                : UIColor(red: 0.00, green: 0.58, blue: 0.72, alpha: 1.00)
        }
    )
    static let canvas = Color(red: 0.006, green: 0.013, blue: 0.020)
    static let surface = Color(red: 0.025, green: 0.040, blue: 0.055)
    static let surfaceRaised = Color(red: 0.035, green: 0.055, blue: 0.072)
    static let hairline = Color.white.opacity(0.075)
    static let success = Color.green
    static let warning = Color.orange
    static let danger = Color.red
    static let pageBackground = canvas
    static let consoleBackground = surface
    static let pageInset: CGFloat = 18
    static let rowIconSize: CGFloat = 17
    static let rowIconFrame: CGFloat = 30
    static let fileRowIconSize: CGFloat = 17
    static let fileRowIconFrame: CGFloat = 30
    static let fileRowHeight: CGFloat = 60
    static let appIconSize: CGFloat = 32
    static let emptyIconSize: CGFloat = 30
    static let selectionIconSize: CGFloat = 18
    static let contentCardCornerRadius: CGFloat = 22
    static let contentCardInset: CGFloat = 18
    static let contentCardPadding: CGFloat = 16
}

struct HTVScreenBackground: View {
    var body: some View {
        ZStack {
            AppTheme.canvas
            LinearGradient(
                colors: [
                    AppTheme.accent.opacity(0.14),
                    Color.blue.opacity(0.035),
                    Color.clear
                ],
                startPoint: .topLeading,
                endPoint: .center
            )
            RadialGradient(
                colors: [AppTheme.accent.opacity(0.08), .clear],
                center: .bottomTrailing,
                startRadius: 20,
                endRadius: 420
            )
        }
        .ignoresSafeArea()
    }
}

struct HTVStatusPill: View {
    let title: String
    var systemImage: String? = nil
    var tint: Color = AppTheme.accent

    var body: some View {
        HStack(spacing: 6) {
            if let systemImage {
                Image(systemName: systemImage)
                    .font(.system(size: 11, weight: .bold))
            } else {
                Circle().frame(width: 6, height: 6)
            }
            Text(title)
                .font(.caption2.weight(.bold))
                .lineLimit(1)
        }
        .foregroundStyle(tint)
        .padding(.horizontal, 10)
        .frame(height: 28)
        .background(tint.opacity(0.10), in: Capsule())
        .overlay(Capsule().stroke(tint.opacity(0.24), lineWidth: 1))
    }
}

struct HTVSectionHeader: View {
    let title: String
    var subtitle: String? = nil

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Capsule()
                .fill(AppTheme.accent)
                .frame(width: 4, height: 22)
                .shadow(color: AppTheme.accent.opacity(0.55), radius: 5)
            Text(title)
                .font(.title3.weight(.black))
                .foregroundStyle(.white)
            Spacer()
            if let subtitle {
                Text(subtitle)
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.trailing)
            }
        }
    }
}

struct AppCardBorder: View {
    var body: some View {
        RoundedRectangle(cornerRadius: AppTheme.contentCardCornerRadius, style: .continuous)
            .strokeBorder(AppTheme.accent.opacity(0.16), lineWidth: 1)
            .accessibilityHidden(true)
    }
}

struct AppRowIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var symbolSize: CGFloat = AppTheme.rowIconSize
    var frameSize: CGFloat = AppTheme.rowIconFrame

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: frameSize * 0.30, style: .continuous)
                .fill(tint.opacity(0.12))
            Image(systemName: systemName)
                .font(.system(size: symbolSize, weight: .semibold))
                .foregroundStyle(tint)
        }
        .frame(width: frameSize, height: frameSize)
        .overlay(
            RoundedRectangle(cornerRadius: frameSize * 0.30, style: .continuous)
                .stroke(tint.opacity(0.14), lineWidth: 1)
        )
        .accessibilityHidden(true)
    }
}

struct AppSearchField: View {
    @Binding var text: String
    let prompt: String
    let clearLabel: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)
            TextField(prompt, text: $text)
                .font(.body)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)
            if !text.isEmpty {
                Button { text = "" } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(clearLabel)
            }
        }
        .padding(.horizontal, 12)
        .frame(minHeight: 40)
        .background(AppTheme.surfaceRaised, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.hairline, lineWidth: 1))
        .padding(.horizontal, AppTheme.pageInset)
        .padding(.vertical, 8)
    }
}

struct AppLogo: View {
    var size: CGFloat = 44

    var body: some View {
        Image("HTVLogo")
            .resizable()
            .scaledToFit()
            .frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: size * 0.24, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                    .stroke(AppTheme.accent.opacity(0.28), lineWidth: 1)
            )
            .shadow(color: AppTheme.accent.opacity(0.16), radius: 10)
            .accessibilityHidden(true)
    }
}

private struct HTVCardModifier: ViewModifier {
    let padding: CGFloat
    let accent: Color?

    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background(
                RoundedRectangle(cornerRadius: AppTheme.contentCardCornerRadius, style: .continuous)
                    .fill(AppTheme.surface.opacity(0.96))
            )
            .overlay(
                RoundedRectangle(cornerRadius: AppTheme.contentCardCornerRadius, style: .continuous)
                    .stroke((accent ?? AppTheme.accent).opacity(0.16), lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.30), radius: 18, y: 10)
    }
}

extension View {
    func htvCard(padding: CGFloat = 16, accent: Color? = nil) -> some View {
        modifier(HTVCardModifier(padding: padding, accent: accent))
    }
}
