import SwiftUI

struct RepositoryHomeView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var licenseManager: HTVLicenseManager
    @StateObject private var serverCatalog = PatchServerCatalog()

    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void
    let onOpenInstalled: () -> Void

    private var freeFireCount: Int { serverCatalog.items.filter { $0.game == "ff" }.count }
    private var freeFireMaxCount: Int { serverCatalog.items.filter { $0.game == "ffmax" }.count }
    private var totalPatchCount: Int { serverCatalog.items.count }

    var body: some View {
        NavigationStack {
            ZStack {
                HTVScreenBackground()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 18) {
                        brandHeader
                        systemCard

                        VStack(alignment: .leading, spacing: 12) {
                            HTVSectionHeader(
                                title: "แอปที่พร้อมใช้งาน",
                                subtitle: "เลือกเกมเพื่อจัดการไฟล์"
                            )
                            gameCard(
                                title: "Free Fire",
                                subtitle: "จัดการไฟล์และแพตช์สำหรับ Free Fire",
                                systemImage: "scope",
                                game: "ff",
                                count: freeFireCount,
                                badge: "FF"
                            )
                            gameCard(
                                title: "Free Fire MAX",
                                subtitle: "จัดการไฟล์และแพตช์สำหรับ Free Fire MAX",
                                systemImage: "bolt.shield.fill",
                                game: "ffmax",
                                count: freeFireMaxCount,
                                badge: "MAX"
                            )
                        }

                        quickOverview
                        footer
                    }
                    .frame(maxWidth: 720)
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, AppTheme.pageInset)
                    .padding(.top, 10)
                    .padding(.bottom, 36)
                }
                .refreshable { await refreshServer() }
            }
            .toolbar(.hidden, for: .navigationBar)
            .task {
                if serverCatalog.items.isEmpty, !serverCatalog.isLoading {
                    await refreshServer()
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var brandHeader: some View {
        HStack(spacing: 13) {
            AppLogo(size: 54)

            VStack(alignment: .leading, spacing: 4) {
                Text("HTVINTEX")
                    .font(.system(size: 27, weight: .black, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.white, AppTheme.accent],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                Text("PREMIUM CONTROL")
                    .font(.caption2.weight(.black))
                    .tracking(2.2)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Button(action: onOpenSettings) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(AppTheme.accent)
                    .frame(width: 46, height: 46)
                    .background(AppTheme.surfaceRaised, in: Circle())
                    .overlay(Circle().stroke(AppTheme.accent.opacity(0.22), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private var systemCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 15, style: .continuous)
                        .fill(systemTint.opacity(0.12))
                        .frame(width: 52, height: 52)
                    Image(systemName: systemIcon)
                        .font(.system(size: 23, weight: .bold))
                        .foregroundStyle(systemTint)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text("HTVINTEX พร้อมใช้งาน")
                        .font(.headline.weight(.black))
                        .foregroundStyle(.white)
                    Text(systemStatusText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }

                Spacer()
                if serverCatalog.isLoading {
                    ProgressView().controlSize(.small)
                } else {
                    Circle()
                        .fill(systemTint)
                        .frame(width: 9, height: 9)
                        .shadow(color: systemTint.opacity(0.55), radius: 7)
                }
            }

            Divider().overlay(AppTheme.hairline)

            HStack(spacing: 8) {
                HTVStatusPill(
                    title: licenseManager.expiryText == "—" ? "License Active" : licenseManager.expiryText,
                    systemImage: "key.fill",
                    tint: licenseManager.isAuthorized ? .green : .orange
                )
                HTVStatusPill(title: "v1.1.5", systemImage: "shippingbox.fill")
                Spacer(minLength: 0)
            }
        }
        .htvCard(accent: systemTint)
    }

    private var systemTint: Color {
        serverCatalog.errorMessage == nil ? .green : .orange
    }

    private var systemIcon: String {
        serverCatalog.errorMessage == nil ? "checkmark.shield.fill" : "exclamationmark.shield.fill"
    }

    private func gameCard(
        title: String,
        subtitle: String,
        systemImage: String,
        game: String,
        count: Int,
        badge: String
    ) -> some View {
        NavigationLink {
            PatchProjectsView(
                gameFilter: game,
                screenTitle: title,
                onOpenSettings: onOpenSettings,
                onOpenLogs: onOpenLogs
            )
        } label: {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 14) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .fill(
                                LinearGradient(
                                    colors: [AppTheme.accent.opacity(0.22), AppTheme.accent.opacity(0.07)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 62, height: 62)
                        Image(systemName: systemImage)
                            .font(.system(size: 26, weight: .black))
                            .foregroundStyle(AppTheme.accent)
                    }

                    VStack(alignment: .leading, spacing: 5) {
                        Text(title)
                            .font(.title3.weight(.black))
                            .foregroundStyle(.white)
                        Text(subtitle)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }

                    Spacer(minLength: 10)

                    HTVStatusPill(
                        title: badge,
                        systemImage: count > 0 ? "checkmark.circle.fill" : "circle",
                        tint: count > 0 ? .green : .secondary
                    )
                }

                HStack(spacing: 10) {
                    Image(systemName: "folder.fill")
                        .foregroundStyle(AppTheme.accent)
                    Text("จัดการไฟล์")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                    Spacer()
                    Text("\(count) ไฟล์")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(count > 0 ? Color.green : Color.secondary)
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.black))
                        .foregroundStyle(AppTheme.accent)
                }
                .padding(.horizontal, 14)
                .frame(height: 46)
                .background(AppTheme.accent.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(AppTheme.accent.opacity(0.18), lineWidth: 1))
            }
            .htvCard()
        }
        .buttonStyle(.plain)
    }

    private var quickOverview: some View {
        VStack(alignment: .leading, spacing: 12) {
            HTVSectionHeader(title: "ภาพรวม", subtitle: "สถานะปัจจุบัน")
            HStack(spacing: 0) {
                overviewMetric(icon: "doc.fill", value: "\(totalPatchCount)", label: "ไฟล์พร้อมใช้", tint: AppTheme.accent)
                Divider().frame(height: 56).overlay(AppTheme.hairline)
                overviewMetric(icon: "gamecontroller.fill", value: "2", label: "เกมรองรับ", tint: .cyan)
                Divider().frame(height: 56).overlay(AppTheme.hairline)
                overviewMetric(
                    icon: "iphone.gen3",
                    value: appState.isSupported ? "พร้อม" : "ตรวจสอบ",
                    label: "iOS \(AppInfo.osVersion)",
                    tint: appState.isSupported ? .green : .orange
                )
            }
            .htvCard(padding: 14)
        }
    }

    private func overviewMetric(icon: String, value: String, label: String, tint: Color) -> some View {
        VStack(spacing: 5) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(tint)
            Text(value)
                .font(.headline.weight(.black))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.72)
            Text(label)
                .font(.caption2.weight(.semibold))
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity)
    }

    private var systemStatusText: String {
        if serverCatalog.isLoading { return "กำลังตรวจสอบรายการไฟล์…" }
        if let error = serverCatalog.errorMessage { return "เชื่อมต่อไม่สำเร็จ • \(error)" }
        return "ออนไลน์ • \(serverCatalog.items.count) ไฟล์พร้อมใช้งาน"
    }

    private var footer: some View {
        VStack(spacing: 5) {
            Text("HTVINTEX")
                .font(.caption2.weight(.black))
                .tracking(4)
                .foregroundStyle(AppTheme.accent)
            Text("PLAY A BETTER TOMORROW")
                .font(.system(size: 9, weight: .bold))
                .tracking(2.4)
                .foregroundStyle(.secondary)
        }
        .padding(.top, 4)
    }

    @MainActor
    private func refreshServer() async {
        do {
            await licenseManager.bootstrap(forceSessionRefresh: true)
            guard licenseManager.isAuthorized else {
                let message = licenseManager.message.isEmpty
                    ? "Session หมดอายุ กรุณาตรวจสอบ License ใหม่"
                    : licenseManager.message
                serverCatalog.fail(
                    NSError(
                        domain: "HTVINTEX",
                        code: 401,
                        userInfo: [NSLocalizedDescriptionKey: message]
                    )
                )
                return
            }
            _ = try await serverCatalog.load()
            serverCatalog.finishSync()
        } catch {
            serverCatalog.fail(error)
        }
    }
}

struct RepositoryNewView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var store: PackageRepositoryStore
    @State private var packages: [RepositoryPackageRecord] = []
    @State private var showSimulatedPackageDetail = false
    @State private var simulatedPackageDetailGate = OneShotPresentationGate()

    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    var body: some View {
        NavigationStack {
            List {
                if packages.isEmpty {
                    Section {
                        emptyState
                    }
                } else {
                    Section {
                        ForEach(packages) { record in
                            NavigationLink(value: record) {
                                RepositoryNewPackageRow(record: record)
                            }
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle(language.text("tab.new"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                AppUtilityToolbar(
                    language: language,
                    onOpenSettings: onOpenSettings,
                    onOpenLogs: onOpenLogs
                )
            }
            .navigationDestination(for: RepositoryPackageRecord.self) { record in
                RepositoryPackageDetailView(record: record)
            }
            .navigationDestination(isPresented: $showSimulatedPackageDetail) {
                if let record = packages.first {
                    RepositoryPackageDetailView(record: record)
                }
            }
            .refreshable {
                await store.refreshAllAndWait()
                rebuildPackages()
            }
            .onAppear {
                store.refreshAllIfNeeded()
                rebuildPackages()
                openSimulatedPackageDetailIfNeeded()
            }
            .onChange(of: store.packages) { _ in
                rebuildPackages()
                openSimulatedPackageDetailIfNeeded()
            }
        }
    }

    @ViewBuilder
    private var emptyState: some View {
        if store.isRefreshing && !store.sources.isEmpty {
            HStack(spacing: 10) {
                ProgressView()
                Text(language.text("repository.refreshing"))
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 32)
        } else {
            VStack(spacing: 12) {
                Image(systemName: store.sources.isEmpty ? "shippingbox" : "clock")
                    .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                    .foregroundStyle(AppTheme.accent)
                Text(language.text(
                    store.sources.isEmpty
                        ? "repository.no_sources_title"
                        : "repository.new_empty_title"
                ))
                .font(.headline)
                Text(language.text(
                    store.sources.isEmpty
                        ? "repository.no_sources_message"
                        : "repository.new_empty_message"
                ))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 48)
        }
    }

    private func rebuildPackages() {
        packages = PackageRepositoryFeedPolicy.newest(store.packages)
    }

    private func openSimulatedPackageDetailIfNeeded() {
#if targetEnvironment(simulator)
        guard ProcessInfo.processInfo.arguments.contains(
            "--simulate-package-detail"
        ), !packages.isEmpty, simulatedPackageDetailGate.claim() else {
            return
        }
        DispatchQueue.main.async {
            showSimulatedPackageDetail = true
        }
#endif
    }
}

struct RepositorySearchView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var store: PackageRepositoryStore
    @State private var searchText = ""

    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    private var query: String {
        searchText.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var results: [RepositoryPackageRecord] {
        guard !query.isEmpty else { return [] }
        return store.packages.filter { record in
            let package = record.package
            return package.name.localizedCaseInsensitiveContains(query)
                || package.author.localizedCaseInsensitiveContains(query)
                || package.summary.localizedCaseInsensitiveContains(query)
                || package.identifier.localizedCaseInsensitiveContains(query)
                || record.sourceName.localizedCaseInsensitiveContains(query)
                || (package.category?.localizedCaseInsensitiveContains(query) ?? false)
                || package.tags.contains {
                    $0.localizedCaseInsensitiveContains(query)
                }
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                AppSearchField(
                    text: $searchText,
                    prompt: language.text("repository.search_prompt"),
                    clearLabel: language.text("common.clear")
                )
                Divider()
                List {
                    if query.isEmpty {
                        searchPrompt
                            .listRowSeparator(.hidden)
                    } else if results.isEmpty {
                        searchEmpty
                            .listRowSeparator(.hidden)
                    } else {
                        Section(language.text(
                            "repository.search_results",
                            Int64(results.count)
                        )) {
                            ForEach(results) { record in
                                NavigationLink(value: record) {
                                    RepositoryPackageRow(record: record)
                                }
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .scrollDismissesKeyboard(.interactively)
                .refreshable {
                    await store.refreshAllAndWait()
                }
            }
            .navigationTitle(language.text("repository.search"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                AppUtilityToolbar(
                    language: language,
                    onOpenSettings: onOpenSettings,
                    onOpenLogs: onOpenLogs
                )
            }
            .navigationDestination(for: RepositoryPackageRecord.self) { record in
                RepositoryPackageDetailView(record: record)
            }
            .onAppear {
                store.refreshAllIfNeeded()
            }
        }
    }

    private var searchPrompt: some View {
        VStack(spacing: 12) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(AppTheme.accent)
            Text(language.text("repository.search_title"))
                .font(.headline)
            Text(language.text("repository.search_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var searchEmpty: some View {
        VStack(spacing: 12) {
            Image(systemName: "shippingbox")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(.secondary)
            Text(language.text("repository.search_empty"))
                .font(.headline)
            Text(language.text("repository.search_empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }
}

private struct RepositoryFeaturedCard: View {
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @StateObject private var imageLoader = RepositoryImageLoader()
    let record: RepositoryPackageRecord
    let width: CGFloat
    let height: CGFloat

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            artwork

            LinearGradient(
                stops: [
                    .init(color: .clear, location: 0.28),
                    .init(color: .black.opacity(0.16), location: 0.56),
                    .init(color: .black.opacity(0.78), location: 1)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 4) {
                Text(record.package.name)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .lineLimit(dynamicTypeSize.isAccessibilitySize ? 3 : 2)

                Text(record.package.author)
                    .font(.caption2.weight(.medium))
                    .foregroundStyle(.white.opacity(0.84))
                    .lineLimit(dynamicTypeSize.isAccessibilitySize ? 2 : 1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(10)
            .shadow(color: .black.opacity(0.42), radius: 1, y: 1)
        }
        .frame(width: width, height: height, alignment: .bottomLeading)
        .background(Color(uiColor: .secondarySystemFill))
        .clipShape(
            RoundedRectangle(
                cornerRadius: 14,
                style: .continuous
            )
        )
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(
                    Color(uiColor: .separator).opacity(0.24),
                    lineWidth: 0.5
                )
                .accessibilityHidden(true)
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
        .task(id: record.package.iconURL) {
            guard let iconURL = record.package.iconURL else { return }
            await imageLoader.load(url: iconURL, maximumPixelSize: 640)
        }
    }

    private var artwork: some View {
        Rectangle()
            .fill(Color(uiColor: .secondarySystemFill))
            .overlay {
                if let image = imageLoader.image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if imageLoader.didFail {
                    placeholder
                } else if record.package.iconURL == nil {
                    placeholder
                } else {
                    ProgressView()
                        .tint(.white)
                }
            }
            .clipped()
            .accessibilityHidden(true)
    }

    private var placeholder: some View {
        Image(systemName: record.package.kind == .wallpaper
            ? "photo.fill"
            : "shippingbox.fill")
            .font(.system(size: 30, weight: .medium))
            .foregroundStyle(.white.opacity(0.82))
    }
}

private struct RepositoryCardButtonStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.72 : 1)
            .animation(
                reduceMotion ? nil : .easeOut(duration: 0.12),
                value: configuration.isPressed
            )
    }
}

private struct RepositoryNewPackageRow: View {
    @Environment(\.appLanguage) private var language
    let record: RepositoryPackageRecord

    var body: some View {
        HStack(spacing: 12) {
            RepositoryPackageIcon(package: record.package, size: 38)
            VStack(alignment: .leading, spacing: 3) {
                Text(record.package.name)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                Text(language.text(
                    "repository.home_package_meta",
                    record.package.author,
                    record.sourceName
                ))
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            }
            Spacer(minLength: 8)
            if let publishedAt = record.package.publishedAt {
                Text(
                    publishedAt,
                    format: .dateTime.day().month(.abbreviated)
                )
                .font(.caption2.weight(.medium))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.trailing)
            }
        }
        .padding(.vertical, 3)
        .accessibilityElement(children: .combine)
    }
}
