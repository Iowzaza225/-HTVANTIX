import SwiftUI
import UIKit
import Security

private enum HTVLicenseAPI {
    static var baseURL: URL {
        if let raw = Bundle.main.object(forInfoDictionaryKey: "HTVLicenseBaseURL") as? String,
           let url = URL(string: raw),
           url.scheme?.lowercased() == "https" {
            return url
        }
        return URL(string: "https://hightapi.netlify.app")!
    }

    static let redeemPath = "api/v4/license/redeem"
    static let sessionPath = "api/v4/session"
}

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @StateObject private var patchStore = PatchProjectStore()
    @StateObject private var repositoryStore = PackageRepositoryStore()
    @StateObject private var licenseManager = HTVLicenseManager()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var showOnboarding = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    init() {
        setupLogCapture()
        log("app: HTVINTEX launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environmentObject(patchStore)
                    .environmentObject(repositoryStore)
                    .environmentObject(licenseManager)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .preferredColorScheme(.dark)
                    .opacity((showOnboarding || licenseManager.requiresLicenseGate) ? 0 : 1)
                    .allowsHitTesting(!showOnboarding && !licenseManager.requiresLicenseGate)

                if !showOnboarding && licenseManager.requiresLicenseGate {
                    HTVLicenseGateView()
                        .environmentObject(licenseManager)
                        .transition(
                            reduceMotion
                                ? .opacity
                                : .opacity.combined(with: .scale(scale: 0.985))
                        )
                        .zIndex(2)
                }

                if showOnboarding {
                    OnboardingView {
                        OnboardingStore.markCompleted()
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.24)) {
                            showOnboarding = false
                        }
                        appState.detectSupport()
                        checkForUpdate()
                        Task { await licenseManager.bootstrap() }
                    }
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .transition(
                        reduceMotion
                            ? .opacity
                            : .opacity.combined(with: .scale(scale: 0.98))
                    )
                    .zIndex(3)
                }
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        UIApplication.shared.open(offer.url)
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .onAppear {
                guard !showOnboarding else { return }
                appState.detectSupport()
                checkForUpdate()
                Task { await licenseManager.bootstrap() }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding else { return }
                appState.detectSupport()
                Task { await licenseManager.bootstrap() }
            }
            .onOpenURL { url in
                patchDraftCoordinator.presentImport(url)
            }
        }
    }
}

func htvParseISO8601Date(_ rawValue: String) -> Date? {
    let raw = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !raw.isEmpty else { return nil }

    let fractional = ISO8601DateFormatter()
    fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    if let date = fractional.date(from: raw) { return date }

    let standard = ISO8601DateFormatter()
    standard.formatOptions = [.withInternetDateTime]
    return standard.date(from: raw)
}

@MainActor
final class HTVLicenseManager: ObservableObject {
    @Published var isAuthorized = false
    @Published var isBusy = false
    @Published var message = ""
    private var bootstrapInFlight = false

    private let defaults = UserDefaults.standard

    var requiresLicenseGate: Bool { !isAuthorized }
    var storedKey: String { defaults.string(forKey: "htvantix.license.key") ?? "" }
    var storedStatus: String { defaults.string(forKey: "htvantix.license.status") ?? "" }
    var storedExpiresAt: String { defaults.string(forKey: "htvantix.license.expiresAt") ?? "" }

    var maskedKey: String {
        let key = storedKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return "—" }
        if key.count <= 10 { return key }
        return "\(key.prefix(5))••••\(key.suffix(5))"
    }

    var expiryText: String {
        let raw = storedExpiresAt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return "—" }
        guard let date = htvParseISO8601Date(raw) else { return raw }
        return date.formatted(date: .abbreviated, time: .shortened)
    }

    func bootstrap(forceSessionRefresh: Bool = false) async {
        guard !bootstrapInFlight else { return }
        bootstrapInFlight = true
        defer { bootstrapInFlight = false }

        if !forceSessionRefresh,
           let session = defaults.string(forKey: "htvantix.client.sessionToken"),
           tokenIsUsable(session) {
            isAuthorized = true
            message = ""
            return
        }

        if let licenseToken = defaults.string(forKey: "htvantix.license.token"),
           tokenIsUsable(licenseToken) {
            do {
                try await createClientSession(licenseToken: licenseToken)
                isAuthorized = true
                message = ""
                return
            } catch {
                clearSessionOnly()
                isAuthorized = false
                message = error.localizedDescription
                return
            }
        }

        if !storedKey.isEmpty {
            do {
                try await redeemAndCreateSession(key: storedKey, showBusy: false)
                return
            } catch {
                clearSessionOnly()
                isAuthorized = false
                message = error.localizedDescription
                return
            }
        }

        isAuthorized = false
    }

    func activate(key rawKey: String) async {
        let key = rawKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }
        do {
            try await redeemAndCreateSession(key: key, showBusy: true)
        } catch {
            isAuthorized = false
            message = error.localizedDescription
        }
    }

    func signOutLicense() {
        [
            "htvantix.license.key",
            "htvantix.license.expiresAt",
            "htvantix.license.status",
            "htvantix.license.token",
            "htvantix.client.sessionToken"
        ].forEach { defaults.removeObject(forKey: $0) }
        isAuthorized = false
        message = ""
        objectWillChange.send()
    }

    private func redeemAndCreateSession(key: String, showBusy: Bool) async throws {
        if showBusy {
            isBusy = true
            message = "กำลังตรวจสอบคีย์…"
        }
        defer { if showBusy { isBusy = false } }

        var request = URLRequest(
            url: HTVLicenseAPI.baseURL.appendingPathComponent(HTVLicenseAPI.redeemPath)
        )
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "key": key,
            "deviceId": persistentDeviceID,
            "appVersion": appVersion,
            "buildId": buildID,
            "deviceModel": AppInfo.displayMachineName
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw HTVLicenseError.invalidResponse
        }
        guard (200..<300).contains(http.statusCode) else {
            throw HTVLicenseError.server(http.statusCode, Self.serverError(data))
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let licenseToken = root["licenseToken"] as? String,
              let license = root["license"] as? [String: Any] else {
            throw HTVLicenseError.invalidResponse
        }

        defaults.set(key, forKey: "htvantix.license.key")
        defaults.set(licenseToken, forKey: "htvantix.license.token")
        defaults.set(license["status"] as? String ?? "active", forKey: "htvantix.license.status")
        defaults.set(license["expiresAt"] as? String ?? "", forKey: "htvantix.license.expiresAt")

        try await createClientSession(licenseToken: licenseToken)
        isAuthorized = true
        message = "เปิดใช้งานสำเร็จ"
        objectWillChange.send()
    }

    private func createClientSession(licenseToken: String) async throws {
        var request = URLRequest(
            url: HTVLicenseAPI.baseURL.appendingPathComponent(HTVLicenseAPI.sessionPath)
        )
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(licenseToken)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "deviceId": persistentDeviceID,
            "appVersion": appVersion,
            "buildId": buildID
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw HTVLicenseError.invalidResponse
        }
        guard (200..<300).contains(http.statusCode) else {
            throw HTVLicenseError.server(http.statusCode, Self.serverError(data))
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let session = root["sessionToken"] as? String else {
            throw HTVLicenseError.invalidResponse
        }
        defaults.set(session, forKey: "htvantix.client.sessionToken")
    }

    private func clearSessionOnly() {
        defaults.removeObject(forKey: "htvantix.client.sessionToken")
    }

    private var persistentDeviceID: String {
        let legacyKey = "htvantix.device.id"
        let service = "com.apple.mobile.MobileHouseArrest.htvantix-license"
        let account = "persistent-device-id-v2"

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        if SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
           let data = result as? Data,
           let existing = String(data: data, encoding: .utf8),
           existing.count >= 12 {
            return existing
        }

        let value: String
        if let legacy = defaults.string(forKey: legacyKey), legacy.count >= 12 {
            value = legacy
        } else {
            value = "ios-" + UUID().uuidString.lowercased()
        }

        let data = Data(value.utf8)
        let add: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemDelete([
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ] as CFDictionary)
        SecItemAdd(add as CFDictionary, nil)
        defaults.set(value, forKey: legacyKey)
        return value
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? "1.0"
    }

    private var buildID: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
    }

    private func tokenIsUsable(_ token: String) -> Bool {
        let parts = token.split(separator: ".", omittingEmptySubsequences: false)
        let payloadPart: Substring
        switch parts.count {
        case 2: payloadPart = parts[0]
        case 3: payloadPart = parts[1]
        default: return false
        }

        guard let data = Self.base64URLDecode(String(payloadPart)),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let exp = object["exp"] as? NSNumber else {
            return false
        }
        return exp.doubleValue > Date().timeIntervalSince1970 + 30
    }

    private static func base64URLDecode(_ value: String) -> Data? {
        var text = value
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let remainder = text.count % 4
        if remainder != 0 {
            text += String(repeating: "=", count: 4 - remainder)
        }
        return Data(base64Encoded: text)
    }

    private static func serverError(_ data: Data) -> String {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return ""
        }
        return object["error"] as? String ?? object["message"] as? String ?? ""
    }
}

private enum HTVLicenseError: LocalizedError {
    case invalidResponse
    case server(Int, String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse:
            return "ข้อมูลตอบกลับจากเซิร์ฟเวอร์ไม่ถูกต้อง"
        case .server(let code, let message):
            let readable: String
            switch message {
            case "LICENSE_NOT_FOUND": readable = "ไม่พบคีย์นี้"
            case "LICENSE_EXPIRED": readable = "คีย์หมดอายุแล้ว"
            case "LICENSE_DISABLED": readable = "คีย์ถูกปิดใช้งาน"
            case "DEVICE_MISMATCH": readable = "คีย์นี้ผูกกับอุปกรณ์อื่นแล้ว"
            case "RATE_LIMIT": readable = "ลองใหม่อีกครั้งในภายหลัง"
            case "SERVER_NOT_CONFIGURED": readable = "เซิร์ฟเวอร์ยังตั้งค่าระบบ Session ไม่ครบ"
            case "UPDATE_REQUIRED": readable = "แอปเวอร์ชันนี้ต้องอัปเดตก่อนใช้งาน"
            case "BUILD_BLOCKED": readable = "Build นี้ไม่ได้รับอนุญาตจาก Server"
            case "MAINTENANCE": readable = "ระบบกำลังปิดปรับปรุงชั่วคราว"
            case "LICENSE_SESSION_REQUIRED": readable = "Session หมดอายุ กรุณาตรวจสอบ License ใหม่"
            default: readable = message.isEmpty ? "Server HTTP \(code)" : message
            }
            return "\(readable) (HTTP \(code))"
        }
    }
}

struct HTVLicenseGateView: View {
    @EnvironmentObject private var licenseManager: HTVLicenseManager
    @State private var keyInput = ""
    @FocusState private var keyFocused: Bool

    var body: some View {
        ZStack {
            Color(red: 0.006, green: 0.013, blue: 0.020)
                .ignoresSafeArea()

            RadialGradient(
                colors: [AppTheme.accent.opacity(0.16), .clear],
                center: .top,
                startRadius: 10,
                endRadius: 430
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 0) {
                    Spacer(minLength: 62)

                    Image("HTVLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)
                        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 28, style: .continuous)
                                .stroke(AppTheme.accent.opacity(0.38), lineWidth: 1)
                        )
                        .shadow(color: AppTheme.accent.opacity(0.20), radius: 24)

                    Text("HTVINTEX")
                        .font(.system(size: 35, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.top, 26)

                    Text("SECURE ACCESS")
                        .font(.caption.weight(.black))
                        .tracking(3.2)
                        .foregroundStyle(AppTheme.accent)
                        .padding(.top, 7)

                    Text("กรอก License Key เพื่อเปิดใช้งานแอปและเชื่อมต่อระบบไฟล์")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.top, 14)
                        .padding(.horizontal, 34)

                    VStack(spacing: 14) {
                        HStack(spacing: 12) {
                            Image(systemName: "key.fill")
                                .foregroundStyle(AppTheme.accent)

                            TextField("HTV-XXXX-XXXX-XXXX", text: $keyInput)
                                .textInputAutocapitalization(.characters)
                                .autocorrectionDisabled()
                                .font(.system(.body, design: .monospaced).weight(.semibold))
                                .foregroundStyle(.white)
                                .focused($keyFocused)
                        }
                        .padding(.horizontal, 18)
                        .frame(height: 60)
                        .background(
                            Color.white.opacity(0.065),
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .stroke(
                                    AppTheme.accent.opacity(keyFocused ? 0.85 : 0.30),
                                    lineWidth: 1.2
                                )
                        )

                        Button {
                            keyFocused = false
                            Task { await licenseManager.activate(key: keyInput) }
                        } label: {
                            HStack(spacing: 10) {
                                if licenseManager.isBusy {
                                    ProgressView().tint(.black)
                                }
                                Text(licenseManager.isBusy ? "กำลังตรวจสอบ…" : "เปิดใช้งาน")
                                    .font(.system(size: 19, weight: .black, design: .rounded))
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 58)
                        }
                        .buttonStyle(.plain)
                        .foregroundStyle(.black)
                        .background(
                            AppTheme.accent,
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous)
                        )
                        .disabled(
                            licenseManager.isBusy ||
                            keyInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                        )
                        .opacity(
                            (licenseManager.isBusy ||
                             keyInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                                ? 0.55 : 1
                        )

                        if !licenseManager.message.isEmpty && !licenseManager.isAuthorized {
                            Text(licenseManager.message)
                                .font(.caption)
                                .foregroundStyle(.orange)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 8)
                        }
                    }
                    .padding(.horizontal, 28)
                    .padding(.top, 28)

                    Spacer(minLength: 70)

                    HStack(spacing: 8) {
                        Image(systemName: "lock.shield.fill")
                        Text("License • Secure Session • HTVINTEX")
                    }
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .padding(.bottom, 30)
                }
                .frame(maxWidth: .infinity)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .preferredColorScheme(.dark)
        .onAppear {
            keyInput = licenseManager.storedKey
            keyFocused = licenseManager.storedKey.isEmpty
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}
