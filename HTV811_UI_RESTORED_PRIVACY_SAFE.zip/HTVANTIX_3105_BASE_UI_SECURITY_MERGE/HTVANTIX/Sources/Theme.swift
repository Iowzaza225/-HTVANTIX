import SwiftUI

enum HTTheme {
    // HTVANTIX signature: near-black + deep navy + restrained cyan.
    static let background = Color(red: 0.010, green: 0.015, blue: 0.024)
    static let surface = Color(red: 0.025, green: 0.043, blue: 0.067)
    static let surface2 = Color(red: 0.040, green: 0.070, blue: 0.105)
    static let surface3 = Color(red: 0.055, green: 0.095, blue: 0.140)
    static let border = Color(red: 0.22, green: 0.72, blue: 0.96).opacity(0.22)
    static let accent = Color(red: 0.30, green: 0.82, blue: 1.00)
    static let accentSoft = Color(red: 0.30, green: 0.82, blue: 1.00).opacity(0.12)
    static let green = Color(red: 0.22, green: 0.88, blue: 0.52)
    static let muted = Color.white.opacity(0.58)
    static let muted2 = Color.white.opacity(0.34)
}

struct HTBackground: View {
    var body: some View {
        ZStack {
            HTTheme.background
            LinearGradient(
                colors: [
                    Color(red: 0.015, green: 0.045, blue: 0.075),
                    HTTheme.background,
                    Color.black
                ],
                startPoint: .topTrailing,
                endPoint: .bottomLeading
            )
            .opacity(0.78)

            RadialGradient(
                colors: [HTTheme.accent.opacity(0.085), .clear],
                center: .topTrailing,
                startRadius: 10,
                endRadius: 460
            )
        }
        .ignoresSafeArea()
    }
}

struct HTCard<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                LinearGradient(
                    colors: [HTTheme.surface2.opacity(0.96), HTTheme.surface.opacity(0.99)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 22, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(HTTheme.border, lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.22), radius: 14, x: 0, y: 8)
    }
}

struct HTPrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .bold))
            .foregroundStyle(.black)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(HTTheme.accent, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .opacity(configuration.isPressed ? 0.72 : 1)
    }
}
