import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var app: AppCoordinator

    var body: some View {
        ZStack {
            HTBackground()
            ScrollView {
                VStack(spacing: 16) {
                    HTCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("CLIENT")
                                .font(.caption.weight(.bold))
                                .foregroundStyle(HTTheme.muted)
                            settingRow("Version", BuildIdentity.version)
                            settingRow("Build", BuildIdentity.build)
                            settingRow("Build ID", BuildIdentity.buildID)
                            settingRow("Server", "HIGHT API V4")
                        }
                    }

                    HTCard {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("PRIVACY")
                                .font(.caption.weight(.bold))
                                .foregroundStyle(HTTheme.muted)
                            Label("Screen capture shield", systemImage: "rectangle.slash")
                            Label("App switcher privacy cover", systemImage: "eye.slash.fill")
                            Text("Screen Share / Recording ใช้ Protected Rendering เพื่อให้เจ้าของเครื่องใช้งานต่อได้ ขณะที่ภาพที่ส่งออกถูกป้องกัน และ App Switcher จะปิดด้วยสีดำ")
                                .font(.caption)
                                .foregroundStyle(HTTheme.muted)
                        }
                    }

                    Button(role: .destructive) {
                        app.signOut()
                    } label: {
                        Text("ออกจากระบบ")
                            .font(.system(size: 16, weight: .bold))
                            .frame(maxWidth: .infinity)
                            .frame(height: 54)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red.opacity(0.75))
                }
                .padding(18)
            }
        }
        .navigationTitle("Settings")
    }

    private func settingRow(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title).foregroundStyle(HTTheme.muted)
            Spacer()
            Text(value).fontWeight(.semibold)
        }
        .font(.caption)
    }
}
