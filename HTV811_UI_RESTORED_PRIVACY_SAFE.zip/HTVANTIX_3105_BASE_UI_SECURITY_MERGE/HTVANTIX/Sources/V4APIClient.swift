import Foundation
import CryptoKit
import UIKit

final class V4APIClient {
    private let baseURL: URL
    private let appToken: String
    private let urlSession: URLSession

    init(baseURL: URL = BuildIdentity.baseURL, appToken: String = BuildIdentity.appToken) {
        self.baseURL = baseURL
        self.appToken = appToken
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 25
        config.timeoutIntervalForResource = 90
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        self.urlSession = URLSession(configuration: config)
    }

    private func makeRequest(
        path: String,
        method: String = "GET",
        bearer: String? = nil,
        json: [String: Any]? = nil
    ) throws -> URLRequest {
        guard !appToken.isEmpty, appToken != "__HTVANTIX_APP_TOKEN__" else {
            throw APIError.clientNotConfigured
        }

        var req = URLRequest(url: baseURL.appendingPathComponent(path))
        req.httpMethod = method
        req.setValue(appToken, forHTTPHeaderField: "X-App-Token")
        req.setValue(BuildIdentity.version, forHTTPHeaderField: "X-App-Version")
        req.setValue(BuildIdentity.buildID, forHTTPHeaderField: "X-Build-ID")
        req.setValue("application/json", forHTTPHeaderField: "Accept")

        if let bearer {
            req.setValue("Bearer \(bearer)", forHTTPHeaderField: "Authorization")
        }

        if let json {
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.httpBody = try JSONSerialization.data(withJSONObject: json)
        }

        return req
    }

    private func decode<T: Decodable>(_ type: T.Type, data: Data, response: URLResponse) throws -> T {
        guard let http = response as? HTTPURLResponse else { throw APIError.malformed }
        guard (200..<300).contains(http.statusCode) else {
            let envelope = try? JSONDecoder().decode(APIErrorEnvelope.self, from: data)
            throw APIError.server(
                status: http.statusCode,
                code: envelope?.error ?? "HTTP_\(http.statusCode)",
                client: envelope?.client
            )
        }
        return try JSONDecoder().decode(type, from: data)
    }

    func redeemLicense(key: String) async throws -> LicenseRedeemResponse {
        let request = try makeRequest(
            path: "api/v4/license/redeem",
            method: "POST",
            json: [
                "key": key,
                "deviceId": DeviceIdentity.id,
                "appVersion": BuildIdentity.version,
                "buildId": BuildIdentity.buildID,
                "deviceModel": UIDevice.current.model
            ]
        )
        let (data, response) = try await urlSession.data(for: request)
        return try decode(LicenseRedeemResponse.self, data: data, response: response)
    }

    func createSession(licenseToken: String) async throws -> SessionResponse {
        let request = try makeRequest(
            path: "api/v4/session",
            method: "POST",
            bearer: licenseToken,
            json: [
                "deviceId": DeviceIdentity.id,
                "appVersion": BuildIdentity.version,
                "buildId": BuildIdentity.buildID
            ]
        )
        let (data, response) = try await urlSession.data(for: request)
        return try decode(SessionResponse.self, data: data, response: response)
    }

    func loadConfig(sessionToken: String) async throws -> V4ClientConfig {
        let request = try makeRequest(path: "api/v4/client/config", bearer: sessionToken)
        let (data, response) = try await urlSession.data(for: request)
        return try decode(V4ClientConfig.self, data: data, response: response)
    }

    func loadPackages(sessionToken: String) async throws -> [RemotePackage] {
        let request = try makeRequest(path: "api/v4/packages", bearer: sessionToken)
        let (data, response) = try await urlSession.data(for: request)
        return try decode(PackageListResponse.self, data: data, response: response).packages
    }

    func downloadPackage(_ package: RemotePackage, sessionToken: String) async throws -> URL {
        // Send the package id directly to the Netlify Function instead of relying
        // on a pretty-URL rewrite. Some manual Netlify deploys were dropping the
        // :id rewrite value, which made the server log the File ID as "unknown".
        guard var components = URLComponents(
            url: baseURL.appendingPathComponent(".netlify/functions/v4-download"),
            resolvingAgainstBaseURL: false
        ) else {
            throw APIError.malformed
        }
        components.queryItems = [URLQueryItem(name: "id", value: package.id)]
        guard let downloadURL = components.url else {
            throw APIError.malformed
        }

        guard !appToken.isEmpty, appToken != "__HTVANTIX_APP_TOKEN__" else {
            throw APIError.clientNotConfigured
        }

        var request = URLRequest(url: downloadURL)
        request.httpMethod = "GET"
        request.setValue(appToken, forHTTPHeaderField: "X-App-Token")
        request.setValue(BuildIdentity.version, forHTTPHeaderField: "X-App-Version")
        request.setValue(BuildIdentity.buildID, forHTTPHeaderField: "X-Build-ID")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(sessionToken)", forHTTPHeaderField: "Authorization")

        let (tempURL, response) = try await urlSession.download(for: request)

        guard let http = response as? HTTPURLResponse else { throw APIError.malformed }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError.server(status: http.statusCode, code: "DOWNLOAD_HTTP_\(http.statusCode)", client: nil)
        }

        let data = try Data(contentsOf: tempURL)
        let hash = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        guard hash.caseInsensitiveCompare(package.sha256) == .orderedSame else {
            throw APIError.integrityFailed
        }
        if package.sizeBytes > 0, data.count != package.sizeBytes {
            throw APIError.integrityFailed
        }

        let fm = FileManager.default
        let docs = try fm.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let dir = docs.appendingPathComponent("HTVANTIX", isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)

        let cleanName = package.fileName.replacingOccurrences(of: "/", with: "_")
        let finalURL = dir.appendingPathComponent(cleanName)
        try? fm.removeItem(at: finalURL)
        do {
            try data.write(to: finalURL, options: .atomic)
        } catch {
            throw APIError.fileWriteFailed
        }
        return finalURL
    }
}
