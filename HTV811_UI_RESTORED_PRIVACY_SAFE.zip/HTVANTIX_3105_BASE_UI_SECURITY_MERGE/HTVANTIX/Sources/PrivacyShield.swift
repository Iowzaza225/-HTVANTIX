import SwiftUI
import UIKit

// MARK: - HTVANTIX Privacy Shield (stable UI version)
//
// This version deliberately does NOT move the SwiftUI hierarchy into a
// UITextField secure-rendering canvas. That technique is undocumented and can
// make the owner's UI disappear or stop receiving touches on some iOS builds.
//
// What this shield guarantees locally:
// - HTVANTIX remains visible and interactive to the owner.
// - App-switcher/background snapshots are covered in black.
// - Screen-capture state is detected and available to the app.
//
// iOS does not provide a public API that guarantees an arbitrary app remains
// visible to the owner while becoming black only in screen-share/recording
// output. Any stronger capture exclusion must therefore be treated as
// best-effort and should not be allowed to break the live UI.

@MainActor
final class PrivacyShieldState: ObservableObject {
    @Published private(set) var screenCaptured = UIScreen.main.isCaptured
    @Published private(set) var appInactive = false

    private var observers: [NSObjectProtocol] = []

    init() {
        observers.append(NotificationCenter.default.addObserver(
            forName: UIScreen.capturedDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.screenCaptured = UIScreen.main.isCaptured
        })

        observers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.willResignActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.appInactive = true
        })

        observers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.appInactive = false
            self?.screenCaptured = UIScreen.main.isCaptured
        })
    }

    deinit {
        observers.forEach(NotificationCenter.default.removeObserver)
    }
}

struct PrivacyShieldModifier: ViewModifier {
    @StateObject private var state = PrivacyShieldState()

    func body(content: Content) -> some View {
        ZStack {
            // Keep the real app hierarchy mounted normally so every screen,
            // navigation link and control remains visible and interactive.
            content

            // Cover only when the app is leaving the foreground. This protects
            // app-switcher snapshots without hiding the live app from its owner.
            if state.appInactive {
                Color.black
                    .ignoresSafeArea()
                    .zIndex(999_999)
                    .accessibilityHidden(true)
            }
        }
        .background(Color.black)
    }
}

extension View {
    func htvantixPrivacyShield() -> some View {
        modifier(PrivacyShieldModifier())
    }
}
