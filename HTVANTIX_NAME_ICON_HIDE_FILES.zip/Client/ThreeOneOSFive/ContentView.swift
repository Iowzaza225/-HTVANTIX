import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator

    var body: some View {
        HTVANTIXHomeView()
            .preferredColorScheme(.dark)
            .tint(AppTheme.accent)
    }
}

private struct HTVANTIXHomeView: View {
    @EnvironmentObject private var appState: AppState
    @Environment(\.appLanguage) private var language
    @State private var showSettings = false
    @StateObject private var homeCatalog = PatchServerCatalog()

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.pageBackground.ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 14) {
                        header
                        compactDeviceCard

                        Text("YOUR GAMES")
                            .htSectionLabel()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.top, 4)

                        NavigationLink {
                            PatchProjectsView(gameFilter: "ff", gameTitle: "Free Fire")
                        } label: {
                            gameCard(
                                game: "ff",
                                title: "Free Fire",
                                imageName: "FreeFireIcon"
                            )
                        }
                        .buttonStyle(.plain)

                        NavigationLink {
                            PatchProjectsView(gameFilter: "ffmax", gameTitle: "Free Fire MAX")
                        } label: {
                            gameCard(
                                game: "ffmax",
                                title: "Free Fire MAX",
                                imageName: "FreeFireMaxIcon"
                            )
                        }
                        .buttonStyle(.plain)

                        systemCard
                    }
                    .padding(.horizontal, 18)
                    .padding(.bottom, 28)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSettings) {
                SettingsView()
                    .preferredColorScheme(.dark)
            }
            .task {
                do {
                    _ = try await homeCatalog.load()
                    homeCatalog.finishSync()
                } catch {
                    homeCatalog.fail(error)
                }
            }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image("HTVLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 44, height: 44)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text("HTVANTIX")
                    .font(.system(size: 23, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("GAME ENHANCER")
                    .font(.caption2.weight(.semibold))
                    .tracking(2.0)
                    .foregroundStyle(AppTheme.accent)
            }

            Spacer()

            Button {
                showSettings = true
            } label: {
                Image(systemName: "person.crop.circle.fill")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(AppTheme.cardBackground, in: Circle())
                    .overlay(Circle().stroke(AppTheme.border, lineWidth: 1))
            }
            .accessibilityLabel(language.text("settings.title"))
        }
        .padding(.top, 10)
        .padding(.bottom, 2)
    }

    private var compactDeviceCard: some View {
        HStack(spacing: 12) {
            AppRowIcon(
                systemName: "iphone.gen3",
                tint: AppTheme.accent,
                symbolSize: 20,
                frameSize: 44
            )

            VStack(alignment: .leading, spacing: 3) {
                Text(AppInfo.displayMachineName)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                Text("iOS \(AppInfo.osVersion)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Label(
                appState.isSupported ? "รองรับ" : "ไม่รองรับ",
                systemImage: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill"
            )
            .font(.caption.weight(.bold))
            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
        }
        .htCard(padding: 14)
    }

    private func items(for game: String) -> [PatchServerCatalog.RemoteItem] {
        homeCatalog.items.filter { $0.game == game }
    }

    private func categoryTitles(for game: String) -> [String] {
        let ordered = ["shoot", "visual", "skin_free", "other"]
        let present = Set(items(for: game).map(\.category))
        return ordered
            .filter { present.contains($0) }
            .map { homeCatalog.categoryTitle($0) }
    }

    private func gameCard(game: String, title: String, imageName: String) -> some View {
        let gameItems = items(for: game)
        let categories = categoryTitles(for: game)
        let isReady = !gameItems.isEmpty
        let countText = isReady ? "\(gameItems.count) ฟังก์ชันพร้อมใช้งาน" : "ยังไม่มีฟังก์ชัน"

        return HStack(spacing: 14) {
            Image(imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 66, height: 66)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(AppTheme.accent.opacity(0.32), lineWidth: 1)
                )

            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)

                HStack(spacing: 6) {
                    Circle()
                        .fill(isReady ? Color.green : Color.secondary)
                        .frame(width: 7, height: 7)
                    Text(countText)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(isReady ? Color.green : Color.secondary)
                }

                if !categories.isEmpty {
                    Text(categories.prefix(3).joined(separator: " • "))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                } else if homeCatalog.isLoading {
                    Text("กำลังโหลดข้อมูล…")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                } else {
                    Text("แตะเพื่อดูรายการ Patch")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(AppTheme.accent)
        }
        .htCard(padding: 14)
    }

    private var systemCard: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color.green.opacity(0.14))
                    .frame(width: 48, height: 48)
                Circle()
                    .fill(Color.green)
                    .frame(width: 12, height: 12)
                    .shadow(color: .green.opacity(0.85), radius: 7)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("HTVANTIX SYSTEM")
                    .font(.caption.weight(.black))
                    .tracking(1.2)
                    .foregroundStyle(.white)

                Text(systemStatusText)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "checkmark.shield.fill")
                .font(.title2)
                .foregroundStyle(appState.isSupported ? Color.green : Color.secondary)
        }
        .htCard(padding: 14)
    }

    private var systemStatusText: String {
        if homeCatalog.isLoading {
            return "กำลังเชื่อมต่อระบบไฟล์…"
        }
        if homeCatalog.errorMessage != nil {
            return "License Active • กำลังรอ Server"
        }
        return "API Online • License Active • \(homeCatalog.items.count) ฟังก์ชัน"
    }
}

private extension View {
    func htCard(padding: CGFloat = 18) -> some View {
        self
            .padding(padding)
            .background(
                RoundedRectangle(cornerRadius: 19, style: .continuous)
                    .fill(AppTheme.cardBackground)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 19, style: .continuous)
                    .stroke(AppTheme.border, lineWidth: 1)
            )
    }

    func htSectionLabel() -> some View {
        self
            .font(.caption2.weight(.bold))
            .tracking(1.8)
            .foregroundStyle(.secondary)
    }
}
