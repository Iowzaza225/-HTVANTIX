import SwiftUI
import UIKit
import UniformTypeIdentifiers

/// Patch home screen.
///
/// A .3105 package is now an action item rather than a document the user has
/// to open and edit. The server/catalog layer can populate PatchProjectStore;
/// this view only presents packages and toggles their enabled state.
struct PatchProjectsView: View {
    let gameFilter: String?
    let gameTitle: String

    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var draftCoordinator: PatchDraftCoordinator
    @StateObject private var store = PatchProjectStore()
    @StateObject private var serverCatalog = PatchServerCatalog()
    @State private var activeProjectIDs: Set<UUID> = []
    @State private var workingProjectIDs: Set<UUID> = []
    @State private var userDisabledProjectIDs: Set<UUID> = Self.loadUserDisabledProjectIDs()
    @State private var selectedCategory = "all"

    init(gameFilter: String? = nil, gameTitle: String = "Patches") {
        self.gameFilter = gameFilter
        self.gameTitle = gameTitle
    }

    private var serverVisibleItems: [PatchLibraryItem] {
        let allowedPackageIDs = serverCatalog.visibleLocalPackageIDs
        guard !allowedPackageIDs.isEmpty else { return [] }
        return store.items.filter { item in
            guard allowedPackageIDs.contains(item.id) else { return false }
            guard let gameFilter else { return true }
            return serverCatalog.remoteItem(forLocalPackageID: item.id)?.game == gameFilter
        }
    }

    private var filteredItems: [PatchLibraryItem] {
        let categoryFiltered = serverVisibleItems.filter { item in
            guard selectedCategory != "all" else { return true }
            return serverCatalog.remoteItem(forLocalPackageID: item.id)?.category == selectedCategory
        }
        return categoryFiltered
    }

    private struct PatchCategoryOption: Identifiable {
        let id: String
        let title: String
    }

    private let patchCategories: [PatchCategoryOption] = [
        PatchCategoryOption(id: "all", title: "ทั้งหมด"),
        PatchCategoryOption(id: "shoot", title: "ไฟล์ยิง"),
        PatchCategoryOption(id: "visual", title: "ไฟล์มอง"),
        PatchCategoryOption(id: "skin_free", title: "มอดสกิน"),
        PatchCategoryOption(id: "other", title: "อื่น ๆ")
    ]


    private func categoryIcon(_ category: String) -> String {
        switch category {
        case "shoot": return "scope"
        case "visual": return "eye.fill"
        case "skin_free": return "sparkles"
        default: return "shippingbox.fill"
        }
    }

    private var gameImageName: String {
        gameFilter == "ffmax" ? "FreeFireMaxIcon" : "FreeFireIcon"
    }

    var body: some View {
        VStack(spacing: 0) {
                gameHeader

                if !serverCatalog.items.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(patchCategories) { category in
                                Button {
                                    withAnimation(.easeInOut(duration: 0.16)) {
                                        selectedCategory = category.id
                                    }
                                } label: {
                                    HStack(spacing: 7) {
                                        Image(systemName: category.id == "all" ? "square.grid.2x2.fill" : categoryIcon(category.id))
                                        Text(category.title)
                                    }
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(selectedCategory == category.id ? Color.black : Color.white.opacity(0.88))
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 10)
                                    .background(
                                        Capsule(style: .continuous)
                                            .fill(
                                                selectedCategory == category.id
                                                ? Color.cyan
                                                : Color.white.opacity(0.055)
                                            )
                                    )
                                    .overlay(
                                        Capsule(style: .continuous)
                                            .stroke(
                                                selectedCategory == category.id
                                                ? Color.cyan.opacity(0.9)
                                                : Color.cyan.opacity(0.12),
                                                lineWidth: 1
                                            )
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                    }
                }

                List {
                    if serverCatalog.isLoading {
                        HStack(spacing: 12) {
                            ProgressView()
                            Text("Syncing patch files…")
                                .foregroundStyle(.secondary)
                        }
                        .listRowSeparator(.hidden)
                    }

                    if let message = serverCatalog.errorMessage, serverVisibleItems.isEmpty {
                        VStack(spacing: 8) {
                            Image(systemName: "exclamationmark.triangle")
                                .foregroundStyle(.orange)
                            Text("Server unavailable")
                                .font(.headline)
                            Text(message)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 26)
                        .listRowSeparator(.hidden)
                    }

                    if serverVisibleItems.isEmpty && !store.isBusy && !serverCatalog.isLoading {
                        emptyState
                            .listRowSeparator(.hidden)
                    } else if filteredItems.isEmpty && !store.isBusy && !serverCatalog.isLoading {
                        searchEmptyState
                            .listRowSeparator(.hidden)
                    } else {
                        Section {
                            ForEach(filteredItems) { item in
                                patchToggleRow(item)
                                    .listRowSeparator(.hidden)
                                    .listRowBackground(Color.clear)
                            }
                        } header: {
                            Text("PATCH FILES")
                                .font(.caption.weight(.semibold))
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .scrollContentBackground(.hidden)
                .background(AppTheme.pageBackground)
                .refreshable {
                    await refreshServerCatalog()
                }
            }
            .navigationTitle(gameTitle)
            .navigationBarTitleDisplayMode(.inline)
            .background(AppTheme.pageBackground)
            .preferredColorScheme(.dark)
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { _ in
                PatchUnlockView(store: store)
            }
            .alert(item: $store.alert) { alert in
                Alert(
                    title: Text(language.text(alert.titleKey)),
                    message: Text(alert.message(language: language)),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
            .onAppear {
                consumeExternalImport()
                syncActiveStates()
                Task { await refreshServerCatalog() }
            }
            .onChange(of: draftCoordinator.importRequest?.id) { _ in
                consumeExternalImport()
            }
            .onChange(of: store.items.map(\.id)) { _ in
                syncActiveStates()
            }
    }

    private var gameHeader: some View {
        HStack(spacing: 13) {
            ZStack {
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .fill(AppTheme.accent.opacity(0.16))
                    .frame(width: 52, height: 52)
                Image(systemName: "gamecontroller.fill")
                    .font(.system(size: 21, weight: .bold))
                    .foregroundStyle(AppTheme.accent)
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(gameTitle)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                HStack(spacing: 6) {
                    Circle().fill(Color.green).frame(width: 7, height: 7)
                    Text("พร้อม")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(Color.green)
                }
            }

            Spacer()

            Text("HTVANTIX")
                .font(.caption2.weight(.black))
                .tracking(1.2)
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 13)
        .background(AppTheme.cardBackground)
        .overlay(alignment: .bottom) { Divider().overlay(AppTheme.border) }
    }

    @MainActor
    private func refreshServerCatalog() async {
        do {
            let remoteItems = try await serverCatalog.load()
            for remote in remoteItems {
                if serverCatalog.localPackageID(forRemoteID: remote.id) != nil {
                    continue
                }
                let packageID = try await store.importRemotePackageSilently(
                    from: serverCatalog.downloadURL(for: remote),
                    headers: serverCatalog.requestHeaders
                )
                serverCatalog.bind(remoteID: remote.id, to: packageID)
            }
            store.reload()
            serverCatalog.finishSync()
            syncActiveStates()
        } catch {
            serverCatalog.fail(error)
        }
    }

    private func consumeExternalImport() {
        guard let request = draftCoordinator.importRequest else { return }
        draftCoordinator.clearImport()
        store.importPackage(from: request.source)
    }

    @ViewBuilder
    private func patchToggleRow(_ item: PatchLibraryItem) -> some View {
        let isActive = activeProjectIDs.contains(item.id)
        let isWorking = workingProjectIDs.contains(item.id)
        // Server/admin package name is the single source of truth for remote packages.
        // This makes a rename in the web admin appear in the app on the next catalog refresh,
        // without rebuilding or re-importing the local .3105 package.
        let displayName = serverCatalog.remoteItem(forLocalPackageID: item.id)?.name
            ?? item.project?.name
            ?? item.packageURL.deletingPathExtension().lastPathComponent

        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(AppTheme.accent.opacity(0.12))
                    .frame(width: 46, height: 46)
                Image(systemName: isActive ? "shippingbox.fill" : "shippingbox")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(AppTheme.accent)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(displayName)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)

                if let remote = serverCatalog.remoteItem(forLocalPackageID: item.id) {
                    HStack(spacing: 5) {
                        Text(serverCatalog.gameTitle(remote.game))
                        Text("•")
                        Text(serverCatalog.categoryTitle(remote.category))
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)

                    if !remote.description.isEmpty {
                        Text(remote.description)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                } else if item.isLocked {
                    Label(language.text("patch.tap_to_unlock"), systemImage: "lock.fill")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    Text(isActive ? "เปิดใช้งาน" : "ปิดใช้งาน")
                        .font(.caption)
                        .foregroundStyle(isActive ? AppTheme.accent : .secondary)
                }
            }

            Spacer(minLength: 10)

            if isWorking {
                ProgressView()
                    .controlSize(.small)
                    .frame(width: 46)
            } else if item.isLocked {
                Button {
                    store.requestUnlock(for: item)
                } label: {
                    Image(systemName: "lock.fill")
                        .frame(width: 46, height: 32)
                }
                .buttonStyle(.borderless)
            } else {
                Toggle("", isOn: Binding(
                    get: { activeProjectIDs.contains(item.id) },
                    set: { newValue in setEnabled(newValue, for: item) }
                ))
                .labelsHidden()
                .disabled(store.isBusy || isWorking)
            }
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 14)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(AppTheme.cardBackground)
        )
        .padding(.vertical, 3)
    }

    private func setEnabled(_ enabled: Bool, for item: PatchLibraryItem) {
        guard !workingProjectIDs.contains(item.id), !item.isLocked else { return }
        workingProjectIDs.insert(item.id)

        Task.detached(priority: .userInitiated) {
            do {
                if enabled {
                    guard let baseProject = item.project else {
                        throw PatchPackageError.invalidProject
                    }
                    let project = item.summary.schemaVersion >= 2
                        ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                        : baseProject

                    // Apply ใช้วิธีเดิมทั้งหมด เมื่อ Apply สำเร็จจึงล้างสถานะ OFF ที่ผู้ใช้เคยเลือก
                    _ = try DevicePatchService.apply(project: project)

                    await MainActor.run {
                        userDisabledProjectIDs.remove(item.id)
                        saveUserDisabledProjectIDs()
                    }
                } else {
                    // ผู้ใช้สั่ง OFF: จำเจตนาของผู้ใช้ไว้ก่อน
                    // Restore safety check ยังคงใช้ของเดิมและไม่มีการบังคับเขียนไฟล์
                    await MainActor.run {
                        userDisabledProjectIDs.insert(item.id)
                        saveUserDisabledProjectIDs()
                    }

                    if let receipt = DevicePatchService.latestReceipt(projectID: item.id) {
                        try DevicePatchService.restore(receipt: receipt)
                    }
                }

                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    syncActiveStates()
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)

                    // ถ้า Restore ล้มเหลว ให้สวิตช์คง OFF ตามคำสั่งผู้ใช้
                    // แต่ยังแจ้ง error เดิม และไม่แก้/ลบ receipt
                    if !enabled {
                        userDisabledProjectIDs.insert(item.id)
                        saveUserDisabledProjectIDs()
                    }

                    syncActiveStates()
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)

                    if !enabled {
                        userDisabledProjectIDs.insert(item.id)
                        saveUserDisabledProjectIDs()
                    }

                    syncActiveStates()
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: enabled ? "patch.error.apply" : "patch.error.restore"
                    )
                }
            }
        }
    }

    private func syncActiveStates() {
        activeProjectIDs = Set(
            store.items.compactMap { item in
                guard !userDisabledProjectIDs.contains(item.id) else { return nil }
                return DevicePatchService.latestReceipt(projectID: item.id) == nil ? nil : item.id
            }
        )
    }

    private static let userDisabledProjectsKey = "htvantix.patch.userDisabledProjectIDs.v1"

    private static func loadUserDisabledProjectIDs() -> Set<UUID> {
        let values = UserDefaults.standard.stringArray(forKey: userDisabledProjectsKey) ?? []
        return Set(values.compactMap(UUID.init(uuidString:)))
    }

    private func saveUserDisabledProjectIDs() {
        UserDefaults.standard.set(
            userDisabledProjectIDs.map(\.uuidString).sorted(),
            forKey: Self.userDisabledProjectsKey
        )
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "arrow.down.circle")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(AppTheme.accent)
            Text("No patch files")
                .font(.headline)
            Text("Files enabled on the server will appear here automatically.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var searchEmptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(.secondary)
            Text(language.text("patch.search_empty"))
                .font(.headline)
            Text(language.text("patch.search_empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }
}

private struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in
                            store.clearUnlockError()
                        }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text(language.text("patch.password_once_message"))
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showEditor = false
    @State private var editingRule: PatchRule?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?
    @State private var shareRequest: PatchShareRequest?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    var body: some View {
        List {
            if let item, let project = item.project {
                if isWorkspaceProject {
                    Section {
                        ForEach(project.allBundleIdentifiers, id: \.self) { bundleID in
                            Label {
                                Text(bundleID)
                                    .font(.subheadline.monospaced())
                            } icon: {
                                Image(systemName: "app.dashed")
                                    .foregroundStyle(AppTheme.accent)
                            }
                        }
                        LabeledContent(language.text("patch.files")) {
                            Text("\(project.rules.count)")
                        }
                        LabeledContent(language.text("patch.folders")) {
                            Text("\(project.directories.count)")
                        }
                        if let workspaceURL = item.workspaceURL {
                            NavigationLink {
                                FileBrowserView(
                                    containerPath: workspaceURL.path,
                                    title: project.name,
                                    bundleID: nil
                                )
                            } label: {
                                Label(
                                    language.text("patch.open_workspace"),
                                    systemImage: "folder"
                                )
                            }
                        }
                    } header: {
                        Text(language.text("patch.workspace"))
                    } footer: {
                        Text(language.text("patch.workspace_detail_footer"))
                    }
                } else {
                    Section {
                        ForEach(project.rules) { rule in
                            Button {
                                editingRule = rule
                            } label: {
                                HStack(spacing: 10) {
                                    ruleSummary(rule)
                                    Spacer(minLength: 8)
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityHint(language.text("patch.edit_rule_hint"))
                        }
                    } header: {
                        Text(language.text("patch.rules"))
                    } footer: {
                        Text(language.text("patch.legacy_footer"))
                    }
                }

                Section(language.text("patch.password")) {
                    HStack(spacing: 12) {
                        Image(systemName: item.summary.isPasswordProtected ? "lock.fill" : "lock.open")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)
                        Text(language.text(item.summary.isPasswordProtected
                            ? "patch.password_locked"
                            : "patch.no_password"))
                            .font(.subheadline)
                    }
                }

                Section {
                    Toggle(isOn: Binding(
                        get: { receipt != nil },
                        set: { enabled in
                            if enabled {
                                apply()
                            } else if receipt != nil {
                                restore()
                            }
                        }
                    )) {
                        Label(
                            receipt != nil ? "Patch ON" : "Patch OFF",
                            systemImage: receipt != nil ? "checkmark.shield.fill" : "shield"
                        )
                    }
                    .disabled(isWorking)

                    Button(action: prepareExport) {
                        actionLabel("patch.export", systemImage: "square.and.arrow.up")
                    }
                    .disabled(isWorking)
                } footer: {
                    Text("ON จะวางไฟล์จากแพ็กเกจ .3105 ลงในพื้นที่จัดการของ 3105 อัตโนมัติ และ OFF จะคืนสถานะก่อนเปิด โดยไม่เขียนเข้า private container ของแอปอื่น")
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(item?.project?.name ?? language.text("patch.title"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                } else if !isWorkspaceProject {
                    Button(language.text("patch.edit")) { showEditor = true }
                        .disabled(item?.project == nil)
                }
            }
        }
        .sheet(isPresented: $showEditor) {
            if let item, let project = item.project {
                PatchProjectEditorView(
                    existingProject: project,
                    passwordIsProtected: item.summary.isPasswordProtected
                ) { updatedProject, _ in
                    store.update(project: updatedProject)
                }
            }
        }
        .sheet(item: $editingRule) { rule in
            PatchRuleEditorView(rule: rule) { updatedRule in
                updateRule(updatedRule)
            }
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .sheet(item: $shareRequest) { request in
            PatchActivityView(items: [request.url])
                .ignoresSafeArea()
        }
    }

    private func actionLabel(_ key: String, systemImage: String) -> some View {
        Label(language.text(key), systemImage: systemImage)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func updateRule(_ updatedRule: PatchRule) {
        guard var project = item?.project,
              let index = project.rules.firstIndex(where: { $0.id == updatedRule.id }) else {
            return
        }
        project.rules[index] = updatedRule
        project.updatedAt = Date()
        do {
            try PatchPackageCodec.validate(project)
            store.update(project: project)
        } catch let error as PatchPackageError {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: error.localizationKey,
                messageArgument: error.localizationArgument
            )
        } catch {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func prepareExport() {
        guard let item else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                if item.summary.schemaVersion >= 2 {
                    _ = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                }
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    shareRequest = PatchShareRequest(url: item.packageURL)
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.invalid_project"
                    )
                }
            }
        }
    }

    private func restore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}

private struct PatchShareRequest: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PatchActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(
        _ uiViewController: UIActivityViewController,
        context: Context
    ) {}
}

// MARK: - Server patch catalog

@MainActor
final class PatchServerCatalog: ObservableObject {
    struct RemoteItem: Identifiable, Hashable {
        let id: String
        let name: String
        let description: String
        let version: String
        let game: String?
        let category: String
        let fileName: String
        let sizeBytes: Int?
        let sha256: String?
    }

    @Published private(set) var items: [RemoteItem] = []
    @Published private(set) var isLoading = false
    @Published private(set) var errorMessage: String?

    private let mappingKey = "patch.server.remoteToLocal.v1"
    private var remoteToLocal: [String: String]

    init() {
        remoteToLocal = UserDefaults.standard.dictionary(forKey: mappingKey) as? [String: String] ?? [:]
    }

    var visibleLocalPackageIDs: Set<UUID> {
        Set(items.compactMap { item in
            guard let value = remoteToLocal[item.id] else { return nil }
            return UUID(uuidString: value)
        })
    }

    func remoteItem(forLocalPackageID packageID: UUID) -> RemoteItem? {
        guard let entry = remoteToLocal.first(where: { $0.value == packageID.uuidString }) else { return nil }
        return items.first(where: { $0.id == entry.key })
    }

    func categoryTitle(_ category: String) -> String {
        switch category {
        case "shoot": return "ไฟล์ยิง"
        case "visual": return "ไฟล์มอง"
        case "skin_free": return "มอดสกิน"
        default: return "อื่น ๆ"
        }
    }

    func gameTitle(_ game: String?) -> String {
        switch game {
        case "ff": return "Free Fire"
        case "ffmax": return "Free Fire MAX"
        default: return "ทั่วไป"
        }
    }

    var requestHeaders: [String: String] {
        var headers: [String: String] = ["Accept": "application/json"]
        if let bearer = UserDefaults.standard.string(forKey: "htvantix.client.sessionToken"),
           !bearer.isEmpty {
            headers["Authorization"] = "Bearer \(bearer)"
        }
        return headers
    }

    func localPackageID(forRemoteID id: String) -> UUID? {
        guard let raw = remoteToLocal[id] else { return nil }
        return UUID(uuidString: raw)
    }

    func bind(remoteID: String, to packageID: UUID) {
        remoteToLocal[remoteID] = packageID.uuidString
        UserDefaults.standard.set(remoteToLocal, forKey: mappingKey)
        objectWillChange.send()
    }

    func load() async throws -> [RemoteItem] {
        isLoading = true
        errorMessage = nil

        var request = URLRequest(url: catalogURL)
        request.httpMethod = "GET"
        for (name, value) in requestHeaders {
            request.setValue(value, forHTTPHeaderField: name)
        }

        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 25
        config.timeoutIntervalForResource = 60
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw PatchServerError.http((response as? HTTPURLResponse)?.statusCode ?? -1)
        }

        let parsed = try Self.parseCatalog(data)
        items = parsed
        return parsed
    }

    func finishSync() {
        isLoading = false
        errorMessage = nil
    }

    func fail(_ error: Error) {
        isLoading = false
        errorMessage = error.localizedDescription
    }

    func downloadURL(for item: RemoteItem) -> URL {
        baseURL
            .appendingPathComponent("api/v4/packages")
            .appendingPathComponent(item.id)
            .appendingPathComponent("download")
    }

    private var baseURL: URL {
        if let raw = Bundle.main.object(forInfoDictionaryKey: "PatchServerBaseURL") as? String,
           let url = URL(string: raw),
           url.scheme?.lowercased() == "https" {
            return url
        }
        return URL(string: HTVNetVaultV4.catalogBase)!
    }

    private var catalogURL: URL {
        if let raw = Bundle.main.object(forInfoDictionaryKey: "PatchCatalogURL") as? String,
           let url = URL(string: raw),
           url.scheme?.lowercased() == "https" {
            return url
        }
        return baseURL.appendingPathComponent(HTVNetVaultV4.catalogPath)
    }

    private static func parseCatalog(_ data: Data) throws -> [RemoteItem] {
        let root = try JSONSerialization.jsonObject(with: data)
        let rawItems: [[String: Any]]
        if let array = root as? [[String: Any]] {
            rawItems = array
        } else if let object = root as? [String: Any],
                  let array = (object["packages"] ?? object["patches"] ?? object["files"]) as? [[String: Any]] {
            rawItems = array
        } else {
            throw PatchServerError.malformed
        }

        return rawItems.compactMap { object in
            let enabled = (object["enabled"] as? Bool) ?? (object["active"] as? Bool) ?? true
            guard enabled else { return nil }
            guard let id = Self.stringValue(object["id"] ?? object["packageId"] ?? object["_id"]), !id.isEmpty else {
                return nil
            }
            let name = Self.stringValue(object["name"] ?? object["title"]) ?? "Patch"
            let description = Self.stringValue(object["description"]) ?? ""
            let version = Self.stringValue(object["version"]) ?? "1.0"
            let game = Self.stringValue(object["game"])
            let category = Self.stringValue(object["category"]) ?? "other"
            let fileName = Self.stringValue(object["fileName"] ?? object["filename"]) ?? "\(id).3105"
            let sizeBytes = object["sizeBytes"] as? Int
            let sha256 = Self.stringValue(object["sha256"])
            return RemoteItem(
                id: id,
                name: name,
                description: description,
                version: version,
                game: game,
                category: category,
                fileName: fileName,
                sizeBytes: sizeBytes,
                sha256: sha256
            )
        }
    }

    private static func stringValue(_ value: Any?) -> String? {
        if let string = value as? String { return string }
        if let number = value as? NSNumber { return number.stringValue }
        return nil
    }
}

private enum PatchServerError: LocalizedError {
    case http(Int)
    case malformed

    var errorDescription: String? {
        switch self {
        case .http(let status): return "HTTP \(status)"
        case .malformed: return "Invalid patch catalog response"
        }
    }
}

