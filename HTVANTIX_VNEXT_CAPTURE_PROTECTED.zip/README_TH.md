# HTVANTIX VNext Full Source

Clean SwiftUI client for HIGHT API V4.

Included:
- License redeem through `/api/v4/license/redeem`
- Short client session through `/api/v4/session`
- Server Version Gate / Maintenance / Build Block
- HOME with Device, Free Fire, Free Fire MAX, License, Update cards
- Game categories: ไฟล์ยิง / ไฟล์มอง / มอดสกิน ฟรี / อื่น ๆ
- Remote package list
- Download to app Documents only
- SHA-256 + size verification before saving
- Keychain storage for license/session token
- Screen Recording/Mirroring privacy shield (black)
- App Switcher privacy cover (black)
- No GitHub URL in runtime UI
- Release stripping/optimization settings
- GitHub Actions workflow for unsigned IPA

Important:
This clean source intentionally excludes exploit/kexploit, sandbox escape,
cross-app file replacement, and game modification/application logic.

Setup:
1. Deploy HIGHT API V4.1.0 server.
2. Add GitHub repository secret `HTVANTIX_APP_TOKEN`.
3. In Admin Version Gate, allow build ID `HTV-811-68-V41` if build allowlist is enabled.
4. Run workflow: `Build HTVANTIX unsigned IPA`.

Build identity:
- Version: 8.11
- Build: 68
- Build ID: HTV-811-68-V41

The client token is a low-privilege client credential and remains extractable from an IPA.
Do not use it as a server master secret.

## Screen Capture Protection
- เพิ่ม Protected Capture: ผู้ใช้บนเครื่องยังเห็น UI ตามปกติ แต่ระบบพยายามซ่อน UI จาก screenshot / screen recording / screen share ผ่าน secure UIKit rendering.
- หาก secure rendering ใช้งานไม่ได้บน iOS ในอนาคต ระบบจะ fallback เป็นจอดำระหว่าง capture เพื่อไม่ให้ข้อมูลรั่ว.
