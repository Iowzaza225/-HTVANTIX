import SwiftUI

struct GameHubView: View {
    @EnvironmentObject private var app: AppCoordinator
    let gameID: String
    let gameTitle: String
    let gameImage: String

    @State private var selectedCategory = "shoot"

    private var categories: [V4ClientConfig.Item] {
        app.config?.categories ?? [
            .init(id: "shoot", title: "ไฟล์ยิง"),
            .init(id: "visual", title: "ไฟล์มอง"),
            .init(id: "skin_free", title: "มอดสกิน ฟรี")
        ]
    }

    private var filtered: [RemotePackage] {
        app.packages.filter {
            $0.game == gameID && $0.category == selectedCategory
        }
    }

    var body: some View {
        ZStack {
            HTBackground()
            ScrollView {
                VStack(spacing: 16) {
                    header
                    categoryTabs

                    if filtered.isEmpty {
                        HTCard {
                            VStack(spacing: 10) {
                                Image(systemName: "tray")
                                    .font(.system(size: 30))
                                    .foregroundStyle(HTTheme.muted)
                                Text("ยังไม่มีรายการในหมวดนี้")
                                    .foregroundStyle(HTTheme.muted)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 20)
                        }
                    } else {
                        ForEach(filtered) { item in
                            PackageRow(package: item)
                        }
                    }
                }
                .padding(18)
            }
            .refreshable { await app.refreshPackages() }
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var header: some View {
        HTCard {
            HStack(spacing: 15) {
                Image(gameImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 72, height: 72)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

                VStack(alignment: .leading, spacing: 7) {
                    Text(gameTitle)
                        .font(.system(size: 25, weight: .black))
                    Text("เลือกฟังก์ชันที่ต้องการ")
                        .foregroundStyle(HTTheme.muted)
                    Label("พร้อม", systemImage: "checkmark.circle.fill")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(HTTheme.green)
                }
                Spacer()
            }
        }
    }

    private var categoryTabs: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 9) {
                ForEach(categories.filter { ["shoot", "visual", "skin_free", "other"].contains($0.id) }) { item in
                    Button {
                        selectedCategory = item.id
                    } label: {
                        Text(item.title)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(selectedCategory == item.id ? .black : .white)
                            .padding(.horizontal, 15)
                            .frame(height: 42)
                            .background(
                                selectedCategory == item.id ? HTTheme.accent : HTTheme.surface2,
                                in: Capsule()
                            )
                            .overlay(
                                Capsule().stroke(selectedCategory == item.id ? Color.clear : HTTheme.border)
                            )
                    }
                }
            }
        }
    }
}

private struct PackageRow: View {
    @EnvironmentObject private var app: AppCoordinator
    let package: RemotePackage

    @State private var downloading = false
    @State private var savedURL: URL?
    @State private var errorText: String?

    var body: some View {
        HTCard {
            VStack(alignment: .leading, spacing: 13) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(package.name)
                            .font(.system(size: 17, weight: .bold))
                        if !package.description.isEmpty {
                            Text(package.description)
                                .font(.caption)
                                .foregroundStyle(HTTheme.muted)
                        }
                    }
                    Spacer()
                    Text(package.version)
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(HTTheme.accent)
                }

                HStack {
                    Text(byteText(package.sizeBytes))
                    Spacer()
                    Text("SHA \(package.sha256.prefix(10))…")
                }
                .font(.caption2.monospaced())
                .foregroundStyle(HTTheme.muted2)

                if let savedURL {
                    Label("ดาวน์โหลดแล้ว • \(savedURL.lastPathComponent)", systemImage: "checkmark.circle.fill")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(HTTheme.green)
                } else if let errorText {
                    Text(errorText)
                        .font(.caption)
                        .foregroundStyle(.red.opacity(0.9))
                }

                Button {
                    downloading = true
                    errorText = nil
                    Task {
                        defer { downloading = false }
                        do {
                            savedURL = try await app.download(package)
                        } catch {
                            errorText = error.localizedDescription
                        }
                    }
                } label: {
                    HStack {
                        if downloading { ProgressView().tint(.black) }
                        Image(systemName: "arrow.down.circle.fill")
                        Text(downloading ? "กำลังดาวน์โหลด..." : "ดาวน์โหลดไฟล์")
                    }
                }
                .buttonStyle(HTPrimaryButtonStyle())
                .disabled(downloading)
            }
        }
    }

    private func byteText(_ value: Int) -> String {
        ByteCountFormatter.string(fromByteCount: Int64(value), countStyle: .file)
    }
}
