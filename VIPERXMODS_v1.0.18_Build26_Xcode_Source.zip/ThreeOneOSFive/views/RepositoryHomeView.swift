import SwiftUI

// VIPERXMODS UI v2 — Presentation-only replacement. Backend models, license
// validation, game filters, and existing file actions remain unchanged.

private enum StarSection: Int, CaseIterable {
    case home, versions, security, settings
    var title: String {
        switch self {
        case .home: return "หน้าหลัก"
        case .versions: return "เวอร์ชัน"
        case .security: return "ความปลอดภัย"
        case .settings: return "ตั้งค่า"
        }
    }
    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .versions: return "clock.arrow.circlepath"
        case .security: return "shield.lefthalf.filled"
        case .settings: return "gearshape.fill"
        }
    }
}

struct RepositoryHomeView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var licenseManager: HTVLicenseManager
    @StateObject private var serverCatalog = PatchServerCatalog()
    @State private var section: StarSection = .home

    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void
    let onOpenInstalled: () -> Void

    private var freeFireCount: Int { serverCatalog.items.filter { $0.game == "ff" }.count }
    private var freeFireMaxCount: Int { serverCatalog.items.filter { $0.game == "ffmax" }.count }
    private var totalCount: Int { serverCatalog.items.count }
    private var version: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
    }
    private var build: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
    }

    var body: some View {
        NavigationStack {
            ZStack {
                HTVScreenBackground()
                StarclinetAmbientLightning()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 20) {
                        if section == .versions {
                            ViperXPageArtBanner(asset: "VIPERXUpdatesArt", height: 110)
                        } else if section == .security {
                            ViperXPageArtBanner(asset: "VIPERXInstalledArt", height: 110)
                        }
                        switch section {
                        case .home: homeContent
                        case .versions: versionContent
                        case .security: securityContent
                        case .settings: homeContent
                        }
                        footer
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 18)
                    .padding(.top, 14)
                    .padding(.bottom, 30)
                }
                .refreshable { await refreshServer() }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) { bottomNavigation }
            .toolbar(.hidden, for: .navigationBar)
            .task {
                if serverCatalog.items.isEmpty, !serverCatalog.isLoading {
                    await refreshServer()
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var homeContent: some View {
        VStack(alignment: .leading, spacing: 17) {
            topBar
            welcomeBanner
            sectionHeading("เกมที่รองรับ", detail: "เลือกเกมเพื่อจัดการไฟล์ของคุณ")
            gameCard(title: "Free Fire", game: "ff", image: "Star29FreeFire", count: freeFireCount)
            gameCard(title: "Free Fire MAX", game: "ffmax", image: "Star29FreeFireMax", count: freeFireMaxCount)
            sectionHeading("ภาพรวมระบบ", detail: "สถานะปัจจุบัน")
            HStack(spacing: 8) {
                overviewItem(icon: "doc.fill", value: "\(totalCount)", caption: "ไฟล์พร้อมใช้")
                overviewItem(icon: "gamecontroller.fill", value: "2", caption: "เกมรองรับ")
                overviewItem(icon: "iphone", value: AppInfo.osVersion, caption: "iOS")
            }
            .padding(12)
            .background(StarStyle.panel, in: RoundedRectangle(cornerRadius: 18))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(StarStyle.line, lineWidth: 1))
        }
    }

    private var topBar: some View {
        HStack(spacing: 10) {
            Image("StarclinetWordmark")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 174, maxHeight: 48)
                .accessibilityLabel("VIPERXMODS Game Panel")
            Spacer()
            Button { Task { await refreshServer() } } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 16, weight: .bold))
                    .frame(width: 40, height: 40)
                    .background(StarStyle.panel, in: Circle())
            }
            .accessibilityLabel("รีเฟรชรายการไฟล์")
            Button(action: onOpenSettings) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 17, weight: .bold))
                    .frame(width: 40, height: 40)
                    .background(StarStyle.panel, in: Circle())
            }
            .accessibilityLabel("ตั้งค่า")
        }
        .foregroundStyle(.white)
        .buttonStyle(.plain)
    }

    private var welcomeBanner: some View {
        ZStack(alignment: .bottomLeading) {
            Star28ResponsiveBanner(image: "Star29Hero", height: 178)
            LinearGradient(
                colors: [Color.black.opacity(0.85), Color.black.opacity(0.28), Color.black.opacity(0.82)],
                startPoint: .leading, endPoint: .trailing
            )
            VStack(alignment: .leading, spacing: 6) {
                Text("WELCOME TO")
                    .font(.system(size: 11, weight: .black, design: .monospaced))
                    .tracking(1.5)
                Text("VIPERXMODS")
                    .font(.system(size: 29, weight: .black, design: .rounded))
                    .italic()
                    .foregroundStyle(StarStyle.orange)
                Text("จัดการไฟล์เกม Free Fire และ Free Fire MAX")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(.white.opacity(0.88))
                HStack(spacing: 6) {
                    Image(systemName: serverCatalog.errorMessage == nil ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                    Text(serverCatalog.isLoading ? "กำลังตรวจสอบ…" : serverCatalog.errorMessage == nil ? "ระบบพร้อมใช้งาน" : "เชื่อมต่อไม่สำเร็จ")
                }
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(serverCatalog.errorMessage == nil ? StarStyle.green : StarStyle.orange)
            }
            .padding(16)
        }
        .frame(height: 178)
        .clipShape(RoundedRectangle(cornerRadius: 19, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 19).stroke(StarStyle.orange.opacity(0.52), lineWidth: 1))
    }

    private func gameCard(title: String, game: String, image: String, count: Int) -> some View {
        NavigationLink {
            PatchProjectsView(
                gameFilter: game,
                screenTitle: title,
                onOpenSettings: onOpenSettings,
                onOpenLogs: onOpenLogs
            )
        } label: {
            VStack(spacing: 0) {
                ZStack(alignment: .bottomLeading) {
                    Star28ResponsiveBanner(image: image, height: 126)
                    LinearGradient(colors: [.clear, .black.opacity(0.78)], startPoint: .center, endPoint: .bottom)
                    HStack {
                        Text(title.uppercased())
                            .font(.system(size: 24, weight: .black, design: .rounded))
                            .italic()
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                            .shadow(color: .black, radius: 5)
                        Spacer()
                        Image(systemName: "chevron.right.circle.fill")
                            .font(.title2)
                            .foregroundStyle(StarStyle.orange)
                    }
                    .foregroundStyle(.white)
                    .padding(14)
                }
                .frame(height: 126)
                HStack(spacing: 12) {
                    Image(systemName: game == "ff" ? "scope" : "bolt.shield.fill")
                        .font(.system(size: 23, weight: .bold))
                        .foregroundStyle(StarStyle.orange)
                        .frame(width: 47, height: 47)
                        .background(StarStyle.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                    VStack(alignment: .leading, spacing: 4) {
                        Text("จัดการไฟล์และแพตช์")
                            .font(.subheadline.weight(.bold))
                            .foregroundStyle(.white)
                        Text("\(count) ไฟล์พร้อมใช้")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Text(count > 0 ? "READY" : "EMPTY")
                        .font(.system(size: 10, weight: .black))
                        .foregroundStyle(count > 0 ? StarStyle.green : .secondary)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(count > 0 ? StarStyle.green.opacity(0.12) : Color.white.opacity(0.07), in: Capsule())
                }
                .padding(13)
            }
            .background(StarStyle.panel, in: RoundedRectangle(cornerRadius: 20))
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(StarStyle.orange.opacity(0.38), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .contentShape(RoundedRectangle(cornerRadius: 20))
        .accessibilityLabel("\(title), \(count) ไฟล์, เปิดไฟล์ของเกมโดยตรง")
    }

    private var filesContent: some View {
        VStack(alignment: .leading, spacing: 17) {
            pageHeading("จัดการไฟล์", subtitle: "ไฟล์เกมที่เชื่อมกับระบบจริง")
            sectionHeading("เลือกเกม", detail: "\(totalCount) ไฟล์ทั้งหมด")
            fileRoute(title: "Free Fire", game: "ff", count: freeFireCount)
            fileRoute(title: "Free Fire MAX", game: "ffmax", count: freeFireMaxCount)
            if totalCount == 0 {
                VStack(spacing: 14) {
                    Image(systemName: "folder.badge.questionmark")
                        .font(.system(size: 48, weight: .ultraLight))
                        .foregroundStyle(StarStyle.orange)
                    Text(serverCatalog.isLoading ? "กำลังโหลดรายการไฟล์…" : "ยังไม่มีไฟล์ในขณะนี้")
                        .font(.headline.weight(.bold))
                    Text(serverCatalog.errorMessage ?? "ตรวจสอบการเชื่อมต่อหรือรอเพิ่มไฟล์จากเซิร์ฟเวอร์")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                    Button { Task { await refreshServer() } } label: {
                        Label("ตรวจสอบอีกครั้ง", systemImage: "arrow.clockwise")
                            .starPrimaryButton()
                    }
                    .buttonStyle(.plain)
                }
                .frame(maxWidth: .infinity)
                .padding(24)
                .htvCard()
            }
        }
    }

    private func fileRoute(title: String, game: String, count: Int) -> some View {
        NavigationLink {
            PatchProjectsView(
                gameFilter: game,
                screenTitle: title,
                onOpenSettings: onOpenSettings,
                onOpenLogs: onOpenLogs
            )
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "folder.fill")
                    .foregroundStyle(StarStyle.orange)
                    .font(.title3)
                    .frame(width: 44, height: 44)
                    .background(StarStyle.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.headline.weight(.bold)).foregroundStyle(.white)
                    Text("\(count) ไฟล์").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(StarStyle.orange)
            }
            .padding(14)
            .background(StarStyle.panel, in: RoundedRectangle(cornerRadius: 17))
            .overlay(RoundedRectangle(cornerRadius: 17).stroke(StarStyle.line, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    // Build 26: Apple-inspired cards. Keep technical identifiers in Info.plist,
    // not in the interface. Server status is derived from the real catalog state.
    private var versionContent: some View {
        VStack(alignment: .leading, spacing: 21) {
            VStack(alignment: .leading, spacing: 6) {
                Text("อัปเดตและข่าวสาร")
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text("ทุกอย่างที่ควรรู้เกี่ยวกับ VIPERXMODS")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.50))
            }
            HStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 21)
                        .fill(LinearGradient(colors: [StarStyle.orange.opacity(0.19), StarStyle.orange.opacity(0.035)], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 82, height: 82)
                    Image(systemName: "sparkles.rectangle.stack.fill")
                        .font(.system(size: 36, weight: .light))
                        .foregroundStyle(StarStyle.orange)
                }
                VStack(alignment: .leading, spacing: 6) {
                    Text("พร้อมสำหรับสิ่งใหม่")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Text("ตรวจสอบรายการใหม่ได้ในที่เดียว")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.63))
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
            }
            .padding(22)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 26))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(Color.white.opacity(0.085)))

            VStack(alignment: .leading, spacing: 16) {
                HStack(spacing: 12) {
                    Image(systemName: serverCatalog.errorMessage == nil ? "checkmark.circle.fill" : "wifi.exclamationmark")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(serverCatalog.errorMessage == nil ? StarStyle.green : StarStyle.orange)
                        .frame(width: 43, height: 43)
                        .background((serverCatalog.errorMessage == nil ? StarStyle.green : StarStyle.orange).opacity(0.11), in: RoundedRectangle(cornerRadius: 14))
                    VStack(alignment: .leading, spacing: 3) {
                        Text(serverCatalog.isLoading ? "กำลังตรวจสอบข้อมูล" : serverCatalog.errorMessage == nil ? "การเชื่อมต่อพร้อมใช้งาน" : "ควรตรวจสอบการเชื่อมต่อ")
                            .font(.headline.weight(.semibold))
                            .foregroundStyle(.white)
                        Text("สถานะการเชื่อมต่อกับเซิร์ฟเวอร์")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                Rectangle().fill(Color.white.opacity(0.09)).frame(height: 1)
                HStack(spacing: 11) {
                    Image(systemName: "shippingbox.fill")
                        .foregroundStyle(StarStyle.orange)
                        .frame(width: 25)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("คลังรายการพร้อมตรวจสอบ")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                        Text("รายการไฟล์จะอัปเดตเมื่อเชื่อมต่อสำเร็จ")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "checkmark.seal")
                        .foregroundStyle(StarStyle.orange)
                }
            }
            .padding(19)
            .background(StarStyle.panel, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(StarStyle.line))

            Button {
                Task { await refreshServer() }
            } label: {
                HStack(spacing: 11) {
                    if serverCatalog.isLoading {
                        ProgressView().tint(.black)
                    } else {
                        Image(systemName: "arrow.triangle.2.circlepath")
                    }
                    Text(serverCatalog.isLoading ? "กำลังตรวจสอบ…" : "ตรวจสอบการอัปเดต")
                }
                .starPrimaryButton()
            }
            .buttonStyle(.plain)
            .disabled(serverCatalog.isLoading)
            Text("VIPERXMODS • PLAY A BETTER TOMORROW")
                .font(.system(size: 10, weight: .medium, design: .rounded))
                .tracking(1.5)
                .foregroundStyle(.white.opacity(0.35))
                .frame(maxWidth: .infinity)
        }
        .padding(.top, 7)
    }

    private var securityContent: some View {
        VStack(alignment: .leading, spacing: 20) {
            VStack(alignment: .leading, spacing: 6) {
                Text("ความปลอดภัย")
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text("จัดการการเข้าถึงของคุณอย่างเป็นส่วนตัว")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.52))
            }

            VStack(spacing: 12) {
                ZStack {
                    Circle().fill(StarStyle.orange.opacity(0.09)).frame(width: 116, height: 116)
                    Circle().stroke(StarStyle.orange.opacity(0.25), lineWidth: 1).frame(width: 108, height: 108)
                    Image(systemName: licenseManager.isAuthorized ? "checkmark.shield.fill" : "lock.shield.fill")
                        .font(.system(size: 51, weight: .light))
                        .foregroundStyle(licenseManager.isAuthorized ? StarStyle.green : StarStyle.orange)
                        .symbolRenderingMode(.hierarchical)
                }
                Text(licenseManager.isAuthorized ? "คุณพร้อมใช้งาน" : "รอการยืนยันสิทธิ์")
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text(licenseManager.isAuthorized ? "เซสชันปัจจุบันได้รับการยืนยันแล้ว" : "โปรดเข้าสู่ระบบเพื่อตรวจสอบสิทธิ์")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                Label(licenseManager.isAuthorized ? "ACTIVE SESSION" : "ACTION REQUIRED", systemImage: licenseManager.isAuthorized ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                    .font(.system(size: 11, weight: .heavy, design: .rounded))
                    .foregroundStyle(licenseManager.isAuthorized ? StarStyle.green : StarStyle.orange)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    .background((licenseManager.isAuthorized ? StarStyle.green : StarStyle.orange).opacity(0.09), in: Capsule())
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 26)
            .padding(.horizontal, 14)
            .background(StarStyle.panel, in: RoundedRectangle(cornerRadius: 27))
            .overlay(RoundedRectangle(cornerRadius: 27).stroke(StarStyle.line))

            VStack(spacing: 0) {
                securityStatusRow(icon: "lock.shield", title: "การยืนยันตัวตน", subtitle: "ตรวจสอบสิทธิ์ก่อนเข้าถึงข้อมูล", valid: licenseManager.isAuthorized)
                Divider().overlay(StarStyle.line).padding(.leading, 61)
                securityStatusRow(icon: "iphone.gen3", title: "ความเข้ากันได้", subtitle: "สถานะระบบของอุปกรณ์นี้", valid: appState.isSupported)
                Divider().overlay(StarStyle.line).padding(.leading, 61)
                securityStatusRow(icon: "arrow.triangle.2.circlepath", title: "ข้อมูลจากเซิร์ฟเวอร์", subtitle: "ตรวจสอบสถานะการเชื่อมต่อ", valid: serverCatalog.errorMessage == nil)
            }
            .background(StarStyle.panel, in: RoundedRectangle(cornerRadius: 23))
            .overlay(RoundedRectangle(cornerRadius: 23).stroke(StarStyle.line))

            Button(action: onOpenSettings) {
                HStack(spacing: 10) {
                    Image(systemName: "slider.horizontal.3")
                    Text("จัดการบัญชีและการตั้งค่า")
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.bold))
                }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white)
                .padding(18)
                .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 17))
                .overlay(RoundedRectangle(cornerRadius: 17).stroke(Color.white.opacity(0.13)))
            }
            .buttonStyle(.plain)
        }
        .padding(.top, 7)
    }

    private func securityStatusRow(icon: String, title: String, subtitle: String, valid: Bool) -> some View {
        HStack(spacing: 13) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(StarStyle.orange)
                .frame(width: 43, height: 43)
                .background(StarStyle.orange.opacity(0.09), in: RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.white)
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 4)
            Image(systemName: valid ? "checkmark.circle.fill" : "exclamationmark.circle")
                .font(.system(size: 18))
                .foregroundStyle(valid ? StarStyle.green : StarStyle.orange)
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 13)
    }

    private func pageHeading(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 28, weight: .black)).foregroundStyle(.white)
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .padding(.top, 7)
    }

    private func sectionHeading(_ title: String, detail: String) -> some View {
        HStack(spacing: 9) {
            Capsule().fill(StarStyle.orange).frame(width: 4, height: 23)
            Text(title).font(.title3.weight(.black)).foregroundStyle(.white)
            Spacer()
            Text(detail).font(.caption2).foregroundStyle(.secondary)
                .lineLimit(1).minimumScaleFactor(0.7)
        }
    }

    private func overviewItem(icon: String, value: String, caption: String) -> some View {
        VStack(spacing: 7) {
            Image(systemName: icon).foregroundStyle(StarStyle.orange)
            Text(value).font(.headline.weight(.black)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.65)
            Text(caption).font(.system(size: 10, weight: .medium)).foregroundStyle(.secondary).lineLimit(1)
        }
        .frame(maxWidth: .infinity)
    }

    private func infoRow(_ title: String, value: String) -> some View {
        HStack {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 8)
            Text(value).foregroundStyle(.white).lineLimit(2).multilineTextAlignment(.trailing)
        }
        .font(.subheadline)
    }

    private var bottomNavigation: some View {
        HStack(spacing: 2) {
            ForEach(StarSection.allCases, id: \.rawValue) { tab in
                Button {
                    if tab == .settings { onOpenSettings() }
                    else { withAnimation(.easeInOut(duration: 0.15)) { section = tab } }
                } label: {
                    VStack(spacing: 5) {
                        Image(systemName: tab.icon).font(.system(size: 18, weight: .semibold))
                        Text(tab.title).font(.system(size: 9, weight: .semibold)).lineLimit(1)
                    }
                    .foregroundStyle(section == tab ? StarStyle.orange : Color.white.opacity(0.62))
                    .frame(maxWidth: .infinity)
                    .frame(height: 55)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 8)
        .padding(.top, 7)
        .background(StarStyle.canvas.opacity(0.97))
        .overlay(alignment: .top) { Rectangle().fill(StarStyle.line).frame(height: 1) }
    }

    private var footer: some View {
        VStack(spacing: 5) {
            Text("S T A R C L I N E T")
                .font(.system(size: 11, weight: .black, design: .monospaced))
                .foregroundStyle(.white)
            Text("PLAY A BETTER TOMORROW")
                .font(.system(size: 9, weight: .bold))
                .tracking(2.2)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 13)
    }

    @MainActor private func refreshServer() async {
        do {
            await licenseManager.bootstrap(forceSessionRefresh: true)
            guard licenseManager.isAuthorized else {
                serverCatalog.fail(NSError(
                    domain: "VIPERXMODS", code: 401,
                    userInfo: [NSLocalizedDescriptionKey: licenseManager.message.isEmpty ? "กรุณาตรวจสอบ License" : licenseManager.message]
                ))
                return
            }
            _ = try await serverCatalog.load()
            serverCatalog.finishSync()
        } catch { serverCatalog.fail(error) }
    }
}


// Width-safe 3:1 image rendering: fixes unwanted horizontal expansion.
// Decorative ambient energy: soft low-contrast traces, never an overlay on controls.
struct StarclinetAmbientLightning: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var floatUp = false
    private let warm = AppTheme.accent

    var body: some View {
        GeometryReader { geometry in
            let w = geometry.size.width
            let h = geometry.size.height
            ZStack {
                Path { line in
                    line.move(to: CGPoint(x: w * 0.94, y: h * 0.04))
                    line.addLine(to: CGPoint(x: w * 0.83, y: h * 0.16))
                    line.addLine(to: CGPoint(x: w * 0.87, y: h * 0.23))
                    line.addLine(to: CGPoint(x: w * 0.73, y: h * 0.39))
                }
                .stroke(warm.opacity(0.58), style: StrokeStyle(lineWidth: 1.1, lineCap: .round, lineJoin: .round))
                .blur(radius: 0.7)
                .opacity(reduceMotion ? 0.10 : (floatUp ? 0.22 : 0.07))
                .offset(y: reduceMotion ? 0 : (floatUp ? 15 : -12))

                Path { line in
                    line.move(to: CGPoint(x: w * 0.10, y: h * 0.70))
                    line.addLine(to: CGPoint(x: w * 0.19, y: h * 0.77))
                    line.addLine(to: CGPoint(x: w * 0.16, y: h * 0.81))
                    line.addLine(to: CGPoint(x: w * 0.31, y: h * 0.95))
                }
                .stroke(warm.opacity(0.35), style: StrokeStyle(lineWidth: 0.9, lineCap: .round, lineJoin: .round))
                .opacity(reduceMotion ? 0.07 : (floatUp ? 0.08 : 0.17))
                .offset(y: reduceMotion ? 0 : (floatUp ? -9 : 11))
            }
            .frame(width: w, height: h)
            .clipped()
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
        .onAppear {
            if !reduceMotion {
                withAnimation(.easeInOut(duration: 6.5).repeatForever(autoreverses: true)) {
                    floatUp = true
                }
            }
        }
    }
}

private struct Star28ResponsiveBanner: View {
    let image: String
    let height: CGFloat

    var body: some View {
        GeometryReader { geometry in
            Image(image)
                .resizable()
                .interpolation(.high)
                .scaledToFill()
                .frame(width: max(geometry.size.width, 1), height: height, alignment: .center)
                .clipped()
        }
        .frame(height: height)
        .clipped()
        .accessibilityHidden(true)
    }
}

private enum StarStyle {
    static let canvas = AppTheme.canvas
    static let panel = AppTheme.surface
    static let line = Color.white.opacity(0.12)
    static let orange = AppTheme.accent
    static let green = Color(red: 0.20, green: 0.86, blue: 0.46)
}

private extension View {
    func starPrimaryButton() -> some View {
        self.font(.headline.weight(.black))
            .foregroundStyle(Color.black)
            .frame(maxWidth: .infinity)
            .frame(height: 50)
            .background(
                LinearGradient(colors: [StarStyle.orange, AppTheme.gold],
                               startPoint: .top, endPoint: .bottom),
                in: RoundedRectangle(cornerRadius: 13)
            )
            .shadow(color: StarStyle.orange.opacity(0.26), radius: 12, y: 5)
    }
}

private struct StarclinetGameLanding: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let game: String
    let image: String
    let count: Int
    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    var body: some View {
        ZStack {
            HTVScreenBackground()
            StarclinetAmbientLightning()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 17) {
                    HStack {
                        Button { dismiss() } label: {
                            Label("กลับ", systemImage: "chevron.left")
                                .foregroundStyle(.white)
                        }
                        .buttonStyle(.plain)
                        Spacer()
                        Text("VIPERXMODS").font(.caption.weight(.black)).foregroundStyle(StarStyle.orange)
                    }
                    ZStack(alignment: .bottomLeading) {
                        Star28ResponsiveBanner(image: image, height: 190)
                        LinearGradient(colors: [.clear, .black.opacity(0.85)], startPoint: .center, endPoint: .bottom)
                        Text(title.uppercased())
                            .font(.system(size: 30, weight: .black, design: .rounded)).italic()
                            .foregroundStyle(.white)
                            .padding(18)
                    }
                    .frame(height: 190)
                    .clipShape(RoundedRectangle(cornerRadius: 19))
                    .overlay(RoundedRectangle(cornerRadius: 19).stroke(StarStyle.orange.opacity(0.38)))
                    HStack {
                        Image(systemName: "gamecontroller.fill").foregroundStyle(StarStyle.orange)
                        Text("\(title) • เกมที่รองรับ").font(.headline.weight(.bold))
                        Spacer()
                        HTVStatusPill(title: count > 0 ? "READY" : "NO FILES", tint: count > 0 ? StarStyle.green : StarStyle.orange)
                    }
                    .htvCard()
                    HStack {
                        Image(systemName: "folder.fill").foregroundStyle(StarStyle.orange)
                        Text("ไฟล์พร้อมใช้")
                        Spacer()
                        Text("\(count)").font(.headline.weight(.black))
                    }
                    .htvCard()
                    NavigationLink {
                        PatchProjectsView(
                            gameFilter: game,
                            screenTitle: title,
                            onOpenSettings: onOpenSettings,
                            onOpenLogs: onOpenLogs
                        )
                    } label: {
                        Label("จัดการไฟล์", systemImage: "folder.fill")
                            .starPrimaryButton()
                    }
                    .buttonStyle(.plain)
                    Text("รายการไฟล์มาจากเซิร์ฟเวอร์ที่เชื่อมต่อกับ License ของคุณ")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(18)
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .preferredColorScheme(.dark)
    }
}


struct RepositoryNewView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var store: PackageRepositoryStore
    @State private var packages: [RepositoryPackageRecord] = []
    @State private var showSimulatedPackageDetail = false
    @State private var simulatedPackageDetailGate = OneShotPresentationGate()

    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    var body: some View {
        NavigationStack {
            List {
                if packages.isEmpty {
                    Section {
                        emptyState
                    }
                } else {
                    Section {
                        ForEach(packages) { record in
                            NavigationLink(value: record) {
                                RepositoryNewPackageRow(record: record)
                            }
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle(language.text("tab.new"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                AppUtilityToolbar(
                    language: language,
                    onOpenSettings: onOpenSettings,
                    onOpenLogs: onOpenLogs
                )
            }
            .navigationDestination(for: RepositoryPackageRecord.self) { record in
                RepositoryPackageDetailView(record: record)
            }
            .navigationDestination(isPresented: $showSimulatedPackageDetail) {
                if let record = packages.first {
                    RepositoryPackageDetailView(record: record)
                }
            }
            .refreshable {
                await store.refreshAllAndWait()
                rebuildPackages()
            }
            .onAppear {
                store.refreshAllIfNeeded()
                rebuildPackages()
                openSimulatedPackageDetailIfNeeded()
            }
            .onChange(of: store.packages) { _ in
                rebuildPackages()
                openSimulatedPackageDetailIfNeeded()
            }
        }
    }

    @ViewBuilder
    private var emptyState: some View {
        if store.isRefreshing && !store.sources.isEmpty {
            HStack(spacing: 10) {
                ProgressView()
                Text(language.text("repository.refreshing"))
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 32)
        } else {
            VStack(spacing: 12) {
                Image(systemName: store.sources.isEmpty ? "shippingbox" : "clock")
                    .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                    .foregroundStyle(AppTheme.accent)
                Text(language.text(
                    store.sources.isEmpty
                        ? "repository.no_sources_title"
                        : "repository.new_empty_title"
                ))
                .font(.headline)
                Text(language.text(
                    store.sources.isEmpty
                        ? "repository.no_sources_message"
                        : "repository.new_empty_message"
                ))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 48)
        }
    }

    private func rebuildPackages() {
        packages = PackageRepositoryFeedPolicy.newest(store.packages)
    }

    private func openSimulatedPackageDetailIfNeeded() {
#if targetEnvironment(simulator)
        guard ProcessInfo.processInfo.arguments.contains(
            "--simulate-package-detail"
        ), !packages.isEmpty, simulatedPackageDetailGate.claim() else {
            return
        }
        DispatchQueue.main.async {
            showSimulatedPackageDetail = true
        }
#endif
    }
}

struct RepositorySearchView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var store: PackageRepositoryStore
    @State private var searchText = ""

    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    private var query: String {
        searchText.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var results: [RepositoryPackageRecord] {
        guard !query.isEmpty else { return [] }
        return store.packages.filter { record in
            let package = record.package
            return package.name.localizedCaseInsensitiveContains(query)
                || package.author.localizedCaseInsensitiveContains(query)
                || package.summary.localizedCaseInsensitiveContains(query)
                || package.identifier.localizedCaseInsensitiveContains(query)
                || record.sourceName.localizedCaseInsensitiveContains(query)
                || (package.category?.localizedCaseInsensitiveContains(query) ?? false)
                || package.tags.contains {
                    $0.localizedCaseInsensitiveContains(query)
                }
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                AppSearchField(
                    text: $searchText,
                    prompt: language.text("repository.search_prompt"),
                    clearLabel: language.text("common.clear")
                )
                Divider()
                List {
                    if query.isEmpty {
                        searchPrompt
                            .listRowSeparator(.hidden)
                    } else if results.isEmpty {
                        searchEmpty
                            .listRowSeparator(.hidden)
                    } else {
                        Section(language.text(
                            "repository.search_results",
                            Int64(results.count)
                        )) {
                            ForEach(results) { record in
                                NavigationLink(value: record) {
                                    RepositoryPackageRow(record: record)
                                }
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .scrollDismissesKeyboard(.interactively)
                .refreshable {
                    await store.refreshAllAndWait()
                }
            }
            .navigationTitle(language.text("repository.search"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                AppUtilityToolbar(
                    language: language,
                    onOpenSettings: onOpenSettings,
                    onOpenLogs: onOpenLogs
                )
            }
            .navigationDestination(for: RepositoryPackageRecord.self) { record in
                RepositoryPackageDetailView(record: record)
            }
            .onAppear {
                store.refreshAllIfNeeded()
            }
        }
    }

    private var searchPrompt: some View {
        VStack(spacing: 12) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(AppTheme.accent)
            Text(language.text("repository.search_title"))
                .font(.headline)
            Text(language.text("repository.search_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var searchEmpty: some View {
        VStack(spacing: 12) {
            Image(systemName: "shippingbox")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(.secondary)
            Text(language.text("repository.search_empty"))
                .font(.headline)
            Text(language.text("repository.search_empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }
}

private struct RepositoryFeaturedCard: View {
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @StateObject private var imageLoader = RepositoryImageLoader()
    let record: RepositoryPackageRecord
    let width: CGFloat
    let height: CGFloat

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            artwork

            LinearGradient(
                stops: [
                    .init(color: .clear, location: 0.28),
                    .init(color: .black.opacity(0.16), location: 0.56),
                    .init(color: .black.opacity(0.78), location: 1)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 4) {
                Text(record.package.name)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .lineLimit(dynamicTypeSize.isAccessibilitySize ? 3 : 2)

                Text(record.package.author)
                    .font(.caption2.weight(.medium))
                    .foregroundStyle(.white.opacity(0.84))
                    .lineLimit(dynamicTypeSize.isAccessibilitySize ? 2 : 1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(10)
            .shadow(color: .black.opacity(0.42), radius: 1, y: 1)
        }
        .frame(width: width, height: height, alignment: .bottomLeading)
        .background(Color(uiColor: .secondarySystemFill))
        .clipShape(
            RoundedRectangle(
                cornerRadius: 14,
                style: .continuous
            )
        )
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(
                    Color(uiColor: .separator).opacity(0.24),
                    lineWidth: 0.5
                )
                .accessibilityHidden(true)
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
        .task(id: record.package.iconURL) {
            guard let iconURL = record.package.iconURL else { return }
            await imageLoader.load(url: iconURL, maximumPixelSize: 640)
        }
    }

    private var artwork: some View {
        Rectangle()
            .fill(Color(uiColor: .secondarySystemFill))
            .overlay {
                if let image = imageLoader.image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if imageLoader.didFail {
                    placeholder
                } else if record.package.iconURL == nil {
                    placeholder
                } else {
                    ProgressView()
                        .tint(.white)
                }
            }
            .clipped()
            .accessibilityHidden(true)
    }

    private var placeholder: some View {
        Image(systemName: record.package.kind == .wallpaper
            ? "photo.fill"
            : "shippingbox.fill")
            .font(.system(size: 30, weight: .medium))
            .foregroundStyle(.white.opacity(0.82))
    }
}

private struct RepositoryCardButtonStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.72 : 1)
            .animation(
                reduceMotion ? nil : .easeOut(duration: 0.12),
                value: configuration.isPressed
            )
    }
}

private struct RepositoryNewPackageRow: View {
    @Environment(\.appLanguage) private var language
    let record: RepositoryPackageRecord

    var body: some View {
        HStack(spacing: 12) {
            RepositoryPackageIcon(package: record.package, size: 38)
            VStack(alignment: .leading, spacing: 3) {
                Text(record.package.name)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                Text(language.text(
                    "repository.home_package_meta",
                    record.package.author,
                    record.sourceName
                ))
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            }
            Spacer(minLength: 8)
            if let publishedAt = record.package.publishedAt {
                Text(
                    publishedAt,
                    format: .dateTime.day().month(.abbreviated)
                )
                .font(.caption2.weight(.medium))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.trailing)
            }
        }
        .padding(.vertical, 3)
        .accessibilityElement(children: .combine)
    }
}
