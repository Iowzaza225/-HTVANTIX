import SwiftUI

// VIPERXMODS Build 26: a privacy-first, native iPhone-style settings sheet.
// The authorization and sign-out behaviors are the existing production ones.
struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var licenseManager: HTVLicenseManager
    @State private var askSignOut = false
    @State private var checking = false

    private let orange = AppTheme.accent
    private let green = Color(red: 0.20, green: 0.86, blue: 0.46)
    private let panel = AppTheme.surface

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.012, green: 0.008, blue: 0.010).ignoresSafeArea()
                StarclinetAmbientLightning().ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 23) {
                        HStack(alignment: .center, spacing: 12) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("ตั้งค่า")
                                    .font(.system(size: 35, weight: .bold, design: .rounded))
                                    .foregroundStyle(.white)
                                Text("ปรับแต่งการใช้งานในแบบของคุณ")
                                    .font(.subheadline)
                                    .foregroundStyle(.white.opacity(0.54))
                            }
                            Spacer()
                            Button { dismiss() } label: {
                                Image(systemName: "xmark")
                                    .font(.system(size: 14, weight: .bold))
                                    .foregroundStyle(.white.opacity(0.78))
                                    .frame(width: 36, height: 36)
                                    .background(Color.white.opacity(0.1), in: Circle())
                            }
                            .accessibilityLabel("ปิดการตั้งค่า")
                            .buttonStyle(.plain)
                        }

                        ViperXPageArtBanner(asset: "VIPERXSettingsArt", height: 94)

                        HStack(spacing: 13) {
                            AppLogo(size: 56)
                            VStack(alignment: .leading, spacing: 5) {
                                Text("VIPERXMODS")
                                    .font(.system(size: 20, weight: .black, design: .rounded))
                                    .foregroundStyle(.white)
                                Text("PLAY A BETTER TOMORROW")
                                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                                    .tracking(1.4)
                                    .foregroundStyle(.white.opacity(0.5))
                            }
                            Spacer()
                            Image(systemName: "sparkles")
                                .font(.system(size: 19))
                                .foregroundStyle(orange)
                        }
                        .padding(18)
                        .background(
                            LinearGradient(colors: [orange.opacity(0.15), panel], startPoint: .topLeading, endPoint: .bottomTrailing),
                            in: RoundedRectangle(cornerRadius: 24)
                        )
                        .overlay(RoundedRectangle(cornerRadius: 24).stroke(orange.opacity(0.24)))

                        VStack(alignment: .leading, spacing: 10) {
                            groupTitle("บัญชี", caption: "การเข้าใช้งานของคุณ")
                            VStack(spacing: 0) {
                                settingsRow(icon: "checkmark.shield.fill", title: "สถานะการเข้าใช้งาน", detail: licenseManager.isAuthorized ? "ยืนยันสิทธิ์แล้ว" : "ยังไม่ยืนยัน", status: licenseManager.isAuthorized)
                                dividingLine
                                settingsRow(icon: "calendar.badge.clock", title: "กำหนดสิ้นสุด", detail: licenseManager.expiryText, status: nil)
                            }
                            .background(panel, in: RoundedRectangle(cornerRadius: 21))
                        }

                        VStack(alignment: .leading, spacing: 10) {
                            groupTitle("ระบบ", caption: "สถานะของอุปกรณ์นี้")
                            VStack(spacing: 0) {
                                settingsRow(icon: "iphone.gen3", title: "การรองรับอุปกรณ์", detail: appState.isSupported ? "รองรับการใช้งาน" : "ควรตรวจสอบความเข้ากันได้", status: appState.isSupported)
                                dividingLine
                                Button {
                                    guard !checking else { return }
                                    checking = true
                                    Task {
                                        await licenseManager.bootstrap(forceSessionRefresh: true)
                                        checking = false
                                    }
                                } label: {
                                    HStack(spacing: 13) {
                                        Image(systemName: "arrow.clockwise.shield")
                                            .font(.system(size: 19, weight: .medium))
                                            .foregroundStyle(orange)
                                            .frame(width: 38, height: 38)
                                            .background(orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text("ตรวจสอบเซสชันอีกครั้ง")
                                                .font(.subheadline.weight(.semibold))
                                                .foregroundStyle(.white)
                                            Text("เชื่อมต่อเพื่อตรวจสอบสิทธิ์ปัจจุบัน")
                                                .font(.caption)
                                                .foregroundStyle(.secondary)
                                        }
                                        Spacer(minLength: 5)
                                        if checking { ProgressView().tint(orange) }
                                        else { Image(systemName: "arrow.up.right").foregroundStyle(.secondary) }
                                    }
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 12)
                                }
                                .disabled(checking)
                                .buttonStyle(.plain)
                            }
                            .background(panel, in: RoundedRectangle(cornerRadius: 21))
                        }

                        VStack(alignment: .leading, spacing: 10) {
                            groupTitle("ข้อมูลส่วนตัว", caption: "ควบคุมสิทธิ์การเข้าถึง")
                            Button {
                                askSignOut = true
                            } label: {
                                HStack(spacing: 13) {
                                    Image(systemName: "rectangle.portrait.and.arrow.right")
                                        .font(.system(size: 19, weight: .semibold))
                                        .foregroundStyle(.red)
                                        .frame(width: 38, height: 38)
                                        .background(Color.red.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                                    Text("ออกจากระบบ")
                                        .font(.subheadline.weight(.semibold))
                                        .foregroundStyle(.red)
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.secondary)
                                }
                                .padding(15)
                                .background(panel, in: RoundedRectangle(cornerRadius: 20))
                            }
                            .buttonStyle(.plain)
                        }
                        Text("VIPERXMODS · PRIVATE BY DESIGN")
                            .font(.system(size: 10, weight: .medium, design: .rounded))
                            .tracking(1.4)
                            .foregroundStyle(.white.opacity(0.30))
                            .frame(maxWidth: .infinity)
                            .padding(.top, 5)
                    }
                    .frame(maxWidth: 650)
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 20)
                    .padding(.top, 19)
                    .padding(.bottom, 34)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
        .confirmationDialog("ออกจากระบบ VIPERXMODS?", isPresented: $askSignOut, titleVisibility: .visible) {
            Button("ออกจากระบบ", role: .destructive) {
                dismiss()
                licenseManager.signOutLicense()
            }
            Button("ยกเลิก", role: .cancel) { }
        } message: {
            Text("คุณจะต้องเปิดใช้งานด้วย License อีกครั้ง")
        }
        .preferredColorScheme(.dark)
    }

    private func groupTitle(_ title: String, caption: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(title).font(.system(size: 19, weight: .bold, design: .rounded)).foregroundStyle(.white)
            Spacer()
            Text(caption).font(.caption).foregroundStyle(.secondary)
        }
        .padding(.horizontal, 4)
    }

    private var dividingLine: some View {
        Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1).padding(.leading, 65)
    }

    private func settingsRow(icon: String, title: String, detail: String, status: Bool?) -> some View {
        HStack(spacing: 13) {
            Image(systemName: icon)
                .font(.system(size: 19, weight: .medium))
                .foregroundStyle(orange)
                .frame(width: 38, height: 38)
                .background(orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.white)
                Text(detail).font(.caption).foregroundStyle(.secondary).lineLimit(2)
            }
            Spacer(minLength: 6)
            if let status {
                Image(systemName: status ? "checkmark.circle.fill" : "exclamationmark.circle")
                    .font(.system(size: 18))
                    .foregroundStyle(status ? green : orange)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
    }
}
