import SwiftUI
import UIKit
import Security

private enum HTVLicenseAPI {
    static var baseURL: URL {
        if let raw = Bundle.main.object(forInfoDictionaryKey: "HTVLicenseBaseURL") as? String,
           let url = URL(string: raw),
           url.scheme?.lowercased() == "https" {
            return url
        }
        return URL(string: "https://hightapi.netlify.app")!
    }

    static let redeemPath = "api/v4/license/redeem"
    static let sessionPath = "api/v4/session"
}

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @StateObject private var patchStore = PatchProjectStore()
    @StateObject private var repositoryStore = PackageRepositoryStore()
    @StateObject private var licenseManager = HTVLicenseManager()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var showOnboarding = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    init() {
        setupLogCapture()
        log("app: VIPERXMODS launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environmentObject(patchStore)
                    .environmentObject(repositoryStore)
                    .environmentObject(licenseManager)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .preferredColorScheme(.dark)
                    .opacity((showOnboarding || licenseManager.requiresLicenseGate) ? 0 : 1)
                    .allowsHitTesting(!showOnboarding && !licenseManager.requiresLicenseGate)

                if !showOnboarding && licenseManager.requiresLicenseGate {
                    HTVLicenseGateView()
                        .environmentObject(licenseManager)
                        .transition(
                            reduceMotion
                                ? .opacity
                                : .opacity.combined(with: .scale(scale: 0.985))
                        )
                        .zIndex(2)
                }

                if showOnboarding {
                    OnboardingView {
                        OnboardingStore.markCompleted()
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.24)) {
                            showOnboarding = false
                        }
                        appState.detectSupport()
                        checkForUpdate()
                        Task { await licenseManager.bootstrap() }
                    }
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .transition(
                        reduceMotion
                            ? .opacity
                            : .opacity.combined(with: .scale(scale: 0.98))
                    )
                    .zIndex(3)
                }
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        UIApplication.shared.open(offer.url)
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .onAppear {
                guard !showOnboarding else { return }
                appState.detectSupport()
                checkForUpdate()
                Task { await licenseManager.bootstrap() }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding else { return }
                appState.detectSupport()
                Task { await licenseManager.bootstrap() }
            }
            .onOpenURL { url in
                patchDraftCoordinator.presentImport(url)
            }
        }
    }
}

func htvParseISO8601Date(_ rawValue: String) -> Date? {
    let raw = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !raw.isEmpty else { return nil }

    let fractional = ISO8601DateFormatter()
    fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    if let date = fractional.date(from: raw) { return date }

    let standard = ISO8601DateFormatter()
    standard.formatOptions = [.withInternetDateTime]
    return standard.date(from: raw)
}

@MainActor
final class HTVLicenseManager: ObservableObject {
    @Published var isAuthorized = false
    @Published var isBusy = false
    @Published var message = ""
    private var bootstrapInFlight = false

    private let defaults = UserDefaults.standard

    var requiresLicenseGate: Bool { !isAuthorized }
    var storedKey: String { defaults.string(forKey: "htvantix.license.key") ?? "" }
    var storedStatus: String { defaults.string(forKey: "htvantix.license.status") ?? "" }
    var storedExpiresAt: String { defaults.string(forKey: "htvantix.license.expiresAt") ?? "" }

    var maskedKey: String {
        let key = storedKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return "—" }
        if key.count <= 10 { return key }
        return "\(key.prefix(5))••••\(key.suffix(5))"
    }

    var expiryText: String {
        let raw = storedExpiresAt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return "—" }
        guard let date = htvParseISO8601Date(raw) else { return raw }
        return date.formatted(date: .abbreviated, time: .shortened)
    }

    func bootstrap(forceSessionRefresh: Bool = false) async {
        guard !bootstrapInFlight else { return }
        bootstrapInFlight = true
        defer { bootstrapInFlight = false }
        prepareStarclinetLicenseScope()

        if !forceSessionRefresh,
           let session = defaults.string(forKey: "htvantix.client.sessionToken"),
           tokenIsUsable(session) {
            isAuthorized = true
            message = ""
            return
        }

        if let licenseToken = defaults.string(forKey: "htvantix.license.token"),
           tokenIsUsable(licenseToken) {
            do {
                try await createClientSession(licenseToken: licenseToken)
                isAuthorized = true
                message = ""
                return
            } catch {
                clearSessionOnly()
                isAuthorized = false
                message = error.localizedDescription
                return
            }
        }

        if !storedKey.isEmpty {
            do {
                try await redeemAndCreateSession(key: storedKey, showBusy: false)
                return
            } catch {
                clearSessionOnly()
                isAuthorized = false
                message = error.localizedDescription
                return
            }
        }

        isAuthorized = false
    }

    func activate(key rawKey: String) async {
        prepareStarclinetLicenseScope()
        let key = rawKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }
        do {
            try await redeemAndCreateSession(key: key, showBusy: true)
        } catch {
            isAuthorized = false
            message = error.localizedDescription
        }
    }

    func signOutLicense() {
        [
            "htvantix.license.key",
            "htvantix.license.expiresAt",
            "htvantix.license.status",
            "htvantix.license.token",
            "htvantix.client.sessionToken"
        ].forEach { defaults.removeObject(forKey: $0) }
        isAuthorized = false
        message = ""
        objectWillChange.send()
    }

    private func redeemAndCreateSession(key: String, showBusy: Bool) async throws {
        if showBusy {
            isBusy = true
            message = "กำลังตรวจสอบคีย์…"
        }
        defer { if showBusy { isBusy = false } }

        var request = URLRequest(
            url: HTVLicenseAPI.baseURL.appendingPathComponent(HTVLicenseAPI.redeemPath)
        )
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "key": key,
            "appId": "starclinet",
            "deviceId": persistentDeviceID,
            "appVersion": appVersion,
            "buildId": buildID,
            "deviceModel": AppInfo.displayMachineName
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw HTVLicenseError.invalidResponse
        }
        guard (200..<300).contains(http.statusCode) else {
            throw HTVLicenseError.server(http.statusCode, Self.serverError(data))
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let licenseToken = root["licenseToken"] as? String,
              let license = root["license"] as? [String: Any] else {
            throw HTVLicenseError.invalidResponse
        }

        defaults.set(key, forKey: "htvantix.license.key")
        defaults.set(licenseToken, forKey: "htvantix.license.token")
        defaults.set(license["status"] as? String ?? "active", forKey: "htvantix.license.status")
        defaults.set(license["expiresAt"] as? String ?? "", forKey: "htvantix.license.expiresAt")

        try await createClientSession(licenseToken: licenseToken)
        isAuthorized = true
        message = "เปิดใช้งานสำเร็จ"
        objectWillChange.send()
    }

    private func createClientSession(licenseToken: String) async throws {
        var request = URLRequest(
            url: HTVLicenseAPI.baseURL.appendingPathComponent(HTVLicenseAPI.sessionPath)
        )
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(licenseToken)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "appId": "starclinet",
            "deviceId": persistentDeviceID,
            "appVersion": appVersion,
            "buildId": buildID
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw HTVLicenseError.invalidResponse
        }
        guard (200..<300).contains(http.statusCode) else {
            throw HTVLicenseError.server(http.statusCode, Self.serverError(data))
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let session = root["sessionToken"] as? String else {
            throw HTVLicenseError.invalidResponse
        }
        defaults.set(session, forKey: "htvantix.client.sessionToken")
    }

    private func prepareStarclinetLicenseScope() {
        let scopeKey = "htvantix.license.activeAppId"
        guard defaults.string(forKey: scopeKey) != "starclinet" else { return }
        [
            "htvantix.license.key",
            "htvantix.license.expiresAt",
            "htvantix.license.status",
            "htvantix.license.token",
            "htvantix.client.sessionToken"
        ].forEach { defaults.removeObject(forKey: $0) }
        defaults.set("starclinet", forKey: scopeKey)
        isAuthorized = false
    }

    private func clearSessionOnly() {
        defaults.removeObject(forKey: "htvantix.client.sessionToken")
    }

    private var persistentDeviceID: String {
        let legacyKey = "htvantix.device.id"
        let service = "com.apple.mobile.MobileHouseArrest.htvantix-license"
        let account = "persistent-device-id-v2"

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        if SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
           let data = result as? Data,
           let existing = String(data: data, encoding: .utf8),
           existing.count >= 12 {
            return existing
        }

        let value: String
        if let legacy = defaults.string(forKey: legacyKey), legacy.count >= 12 {
            value = legacy
        } else {
            value = "ios-" + UUID().uuidString.lowercased()
        }

        let data = Data(value.utf8)
        let add: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemDelete([
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ] as CFDictionary)
        SecItemAdd(add as CFDictionary, nil)
        defaults.set(value, forKey: legacyKey)
        return value
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? "1.0"
    }

    private var buildID: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
    }

    private func tokenIsUsable(_ token: String) -> Bool {
        let parts = token.split(separator: ".", omittingEmptySubsequences: false)
        let payloadPart: Substring
        switch parts.count {
        case 2: payloadPart = parts[0]
        case 3: payloadPart = parts[1]
        default: return false
        }

        guard let data = Self.base64URLDecode(String(payloadPart)),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let exp = object["exp"] as? NSNumber else {
            return false
        }
        return exp.doubleValue > Date().timeIntervalSince1970 + 30
    }

    private static func base64URLDecode(_ value: String) -> Data? {
        var text = value
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let remainder = text.count % 4
        if remainder != 0 {
            text += String(repeating: "=", count: 4 - remainder)
        }
        return Data(base64Encoded: text)
    }

    private static func serverError(_ data: Data) -> String {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return ""
        }
        return object["error"] as? String ?? object["message"] as? String ?? ""
    }
}

private enum HTVLicenseError: LocalizedError {
    case invalidResponse
    case server(Int, String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse:
            return "ข้อมูลตอบกลับจากเซิร์ฟเวอร์ไม่ถูกต้อง"
        case .server(let code, let message):
            let readable: String
            switch message {
            case "LICENSE_NOT_FOUND": readable = "ไม่พบคีย์นี้"
            case "LICENSE_EXPIRED", "EXPIRED": readable = "คีย์หมดอายุแล้ว กรุณาต่ออายุจากผู้ให้บริการ"
            case "LICENSE_DISABLED": readable = "คีย์ถูกปิดใช้งาน"
            case "DEVICE_MISMATCH": readable = "คีย์นี้ผูกกับอุปกรณ์อื่นแล้ว"
            case "RATE_LIMIT": readable = "ลองใหม่อีกครั้งในภายหลัง"
            case "SERVER_NOT_CONFIGURED": readable = "เซิร์ฟเวอร์ยังตั้งค่าระบบ Session ไม่ครบ"
            case "UPDATE_REQUIRED": readable = "แอปเวอร์ชันนี้ต้องอัปเดตก่อนใช้งาน"
            case "BUILD_BLOCKED": readable = "Build นี้ไม่ได้รับอนุญาตจาก Server"
            case "MAINTENANCE": readable = "ระบบกำลังปิดปรับปรุงชั่วคราว"
            case "LICENSE_SESSION_REQUIRED": readable = "Session หมดอายุ กรุณาตรวจสอบ License ใหม่"
            default: readable = message.isEmpty ? "Server HTTP \(code)" : message
            }
            return "\(readable) (HTTP \(code))"
        }
    }
}

struct HTVLicenseGateView: View {
    @EnvironmentObject private var licenseManager: HTVLicenseManager
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var keyInput = ""
    @State private var showKey = false
    @State private var appear = false
    @State private var glowing = false
    @FocusState private var keyFocused: Bool

    private let orange = AppTheme.accent
    private let charcoal = AppTheme.surface
    private var ready: Bool {
        !licenseManager.isBusy && !keyInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        ZStack {
            Color(red: 0.012, green: 0.008, blue: 0.010).ignoresSafeArea()
            Image("StarclinetLoginConcept")
                .resizable()
                .scaledToFill()
                .blur(radius: 36)
                .opacity(0.11)
                .ignoresSafeArea()
                .allowsHitTesting(false)
            LinearGradient(
                colors: [.black.opacity(0.12), charcoal.opacity(0.38), .black.opacity(0.84)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            ).ignoresSafeArea()
            StarclinetAmbientLightning().ignoresSafeArea()

            GeometryReader { screen in
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {
                        Spacer(minLength: 28)

                        VStack(spacing: 12) {
                            Image("HTVLogo")
                                .resizable()
                                .interpolation(.high)
                                .scaledToFit()
                                .frame(width: 94, height: 94)
                                .clipShape(RoundedRectangle(cornerRadius: 23, style: .continuous))
                                .overlay {
                                    RoundedRectangle(cornerRadius: 23, style: .continuous)
                                        .stroke(orange.opacity(0.44), lineWidth: 1)
                                }
                                .shadow(color: orange.opacity(glowing ? 0.31 : 0.12), radius: glowing ? 25 : 12)
                                .scaleEffect(glowing ? 1.018 : 1.0)
                                .accessibilityLabel("VIPERXMODS")

                            Text("VIPERXMODS")
                                .font(.system(size: 33, weight: .black, design: .rounded))
                                .tracking(0.5)
                                .foregroundStyle(.white)
                                .lineLimit(1)
                                .minimumScaleFactor(0.78)
                                .padding(.top, 9)
                            Text("SECURE GAME ACCESS")
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                .tracking(2.5)
                                .foregroundStyle(orange)
                            Text("เข้าถึง VIPERXMODS ด้วยคีย์ของคุณ")
                                .font(.subheadline)
                                .foregroundStyle(.white.opacity(0.64))
                                .multilineTextAlignment(.center)
                                .padding(.top, 9)
                        }

                        VStack(alignment: .leading, spacing: 13) {
                            HStack(spacing: 8) {
                                Image(systemName: "key.horizontal.fill")
                                    .foregroundStyle(orange)
                                Text("LICENSE KEY")
                                    .foregroundStyle(.white.opacity(0.8))
                            }
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .tracking(1.4)

                            HStack(spacing: 12) {
                                Image(systemName: "lock.shield.fill")
                                    .foregroundStyle(orange)
                                Group {
                                    if showKey {
                                        TextField("HTV-XXXX-XXXX-XXXX", text: $keyInput)
                                            .focused($keyFocused)
                                    } else {
                                        SecureField("HTV-XXXX-XXXX-XXXX", text: $keyInput)
                                            .focused($keyFocused)
                                    }
                                }
                                .font(.system(size: 15, weight: .medium, design: .monospaced))
                                .foregroundStyle(.white)
                                .textInputAutocapitalization(.characters)
                                .autocorrectionDisabled()
                                .submitLabel(.done)
                                .onSubmit { keyFocused = false }
                                Button { showKey.toggle() } label: {
                                    Image(systemName: showKey ? "eye.slash.fill" : "eye.fill")
                                        .font(.system(size: 15))
                                        .foregroundStyle(.white.opacity(0.55))
                                }
                                .buttonStyle(.plain)
                                .accessibilityLabel(showKey ? "ซ่อนคีย์" : "แสดงคีย์")
                            }
                            .padding(.horizontal, 17)
                            .frame(height: 58)
                            .background(charcoal, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                            .overlay {
                                RoundedRectangle(cornerRadius: 17, style: .continuous)
                                    .stroke(orange.opacity(keyFocused ? 0.78 : 0.24), lineWidth: 1)
                            }

                            Button {
                                keyFocused = false
                                Task { await licenseManager.activate(key: keyInput) }
                            } label: {
                                HStack(spacing: 10) {
                                    if licenseManager.isBusy { ProgressView().tint(.black) }
                                    else { Image(systemName: "bolt.fill") }
                                    Text(licenseManager.isBusy ? "กำลังตรวจสอบ…" : "เปิดใช้งาน")
                                }
                                .font(.system(size: 17, weight: .bold, design: .rounded))
                                .foregroundStyle(.black)
                                .frame(maxWidth: .infinity)
                                .frame(height: 57)
                                .background(
                                    LinearGradient(colors: [Color(red: 1, green: 0.69, blue: 0.11), orange],
                                                   startPoint: .topLeading, endPoint: .bottomTrailing),
                                    in: RoundedRectangle(cornerRadius: 17, style: .continuous)
                                )
                                .shadow(color: orange.opacity(ready ? 0.22 : 0.03), radius: 15, y: 6)
                            }
                            .buttonStyle(.plain)
                            .disabled(!ready)
                            .opacity(ready ? 1 : 0.55)
                            .padding(.top, 5)

                            if !licenseManager.message.isEmpty && !licenseManager.isAuthorized {
                                Label(licenseManager.message, systemImage: "exclamationmark.circle.fill")
                                    .font(.caption)
                                    .foregroundStyle(Color(red: 1, green: 0.68, blue: 0.36))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(13)
                                    .background(orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
                            }
                        }
                        .padding(20)
                        .background(charcoal.opacity(0.83), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 26, style: .continuous)
                                .stroke(.white.opacity(0.10), lineWidth: 1)
                        }
                        .padding(.top, 30)

                        Spacer(minLength: 24)
                        Label("เชื่อมต่ออย่างปลอดภัย", systemImage: "checkmark.shield.fill")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.45))
                            .padding(.bottom, 28)
                    }
                    .frame(maxWidth: 390)
                    .frame(minHeight: screen.size.height)
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 20)
                    .opacity(appear ? 1 : 0)
                    .offset(y: appear ? 0 : 13)
                }
                .scrollDismissesKeyboard(.interactively)
            }
        }
        .preferredColorScheme(.dark)
        .onAppear {
            keyInput = licenseManager.storedKey
            if reduceMotion { appear = true }
            else {
                withAnimation(.easeOut(duration: 0.52)) { appear = true }
                withAnimation(.easeInOut(duration: 4.3).repeatForever(autoreverses: true)) {
                    glowing = true
                }
            }
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}
