# VIPERXMODS — v1.0.18 (Build 26)

ฐาน: STARCLINET Build 30 / VIPERXMOD Rebrand Build 01

## ผลการปรับแก้
- App Display Name: VIPERXMODS
- Marketing Version / CFBundleShortVersionString: 1.0.18
- Build Number / CFBundleVersion: 26
- AppReleaseDisplayVersion: 1.0.18
- Target / Product Name: VIPERXMODS / Xcode project: VIPERXMODS.xcodeproj
- ใช้ภาพแดง–ดำชุดที่ผู้ใช้เลือก: App Icon, Wordmark, Hero, Free Fire, Free Fire MAX และภาพประกอบหมวดต่าง ๆ
- ปรับสีพื้นหลัง Login/Settings ให้เป็นดำโทนอุ่น แทนสีดำออกน้ำเงิน
- อัปเดตชื่อที่แสดงใน Swift UI และข้อความแปลทุกภาษาเป็น VIPERXMODS
- **คง Bundle ID, URL schemes, API endpoints, signing settings, compatibility policy, และกลไกแอปเดิม**
- ไม่เพิ่มระบบใหม่สำหรับ iOS 27

## สถานะทดสอบ
- ตรวจความสมบูรณ์ของไฟล์ ZIP และโครงสร้าง assets + Info.plist ผ่าน
- ยังไม่ Compile ด้วย Xcode หรือสร้าง IPA จริง เพราะ runtime นี้ไม่มี macOS/Xcode และ signing identity
- ไฟล์เป็น **Xcode Source ZIP** ไม่ใช่ IPA

## วิธี Build
1. เปิด `VIPERXMODS.xcodeproj` ด้วย Xcode บน macOS
2. ตรวจ Signing/Provisioning และ Bundle ID เดิมให้เหมาะกับใบรับรองที่จะใช้
3. เลือก scheme/target แล้ว Build หรือ Archive
4. ตรวจบนอุปกรณ์จริงว่าแสดงชื่อ VIPERXMODS, เวอร์ชัน 1.0.18 (26) และภาพครบ

## หมายเหตุเรื่องชื่อโลโก้
ภาพโลโก้ที่ได้รับอนุมัติยังใช้คำว่า VIPERX ซึ่งเป็นแบรนด์กราฟิก ขณะที่ชื่อแอปและข้อความบนหน้าจอเป็น VIPERXMODS ตามคำสั่งล่าสุด

## Asset Maps
- `AppIcon` ← `VIPERX_AppIcon_1024x1024.png`
- `HTVLogo` ← `VIPERX_AppIcon_1024x1024.png`
- `StarclinetWordmark` ← `VIPERX_Wordmark_840x280.png`
- `StarclinetLoginConcept` ← `VIPERX_Login_1200x800.jpg`
- `Star29Hero` ← `VIPERX_Hero_1448x724.jpg`
- `Star29FreeFire` ← `VIPERX_FreeFire_1200x400.jpg`
- `Star29FreeFireMax` ← `VIPERX_FreeFireMAX_1200x400.jpg`
- `Star28FreeFireBanner` ← `VIPERX_FreeFire_1200x400.jpg`
- `Star28FreeFireMaxBanner` ← `VIPERX_FreeFireMAX_1200x400.jpg`
- `StarclinetFFMaxBanner` ← `VIPERX_FreeFireMAX_1200x400.jpg`
- `FreeFireArtwork` ← `VIPERX_FreeFire_1200x400.jpg`
- `VIPERXHomeArt` ← `VIPERX_Home_1200x800.jpg`
- `VIPERXUpdatesArt` ← `VIPERX_Versions_1200x800.jpg`
- `VIPERXSourcesArt` ← `VIPERX_Sources_1200x800.jpg`
- `VIPERXInstalledArt` ← `VIPERX_Installed_1200x800.jpg`
- `VIPERXFilesArt` ← `VIPERX_Files_1200x800.jpg`
- `VIPERXSearchArt` ← `VIPERX_Search_1200x800.jpg`
- `VIPERXSettingsArt` ← `VIPERX_Settings_1200x800.jpg`
- `VIPERXLoginArt` ← `VIPERX_Login_1200x800.jpg`
