import Foundation
import CryptoKit
import UIKit

/// V3.3 compatibility client.
/// The filename/class name stays V4APIClient so the Xcode project does not need
/// target-membership changes. Patch/apply logic is intentionally untouched.
final class V4APIClient {
    private let baseURL: URL
    private let appToken: String
    private let urlSession: URLSession

    init(baseURL: URL = BuildIdentity.baseURL, appToken: String = BuildIdentity.appToken) {
        self.baseURL = baseURL
        self.appToken = appToken
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 25
        config.timeoutIntervalForResource = 90
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        self.urlSession = URLSession(configuration: config)
    }

    private func configuredRequest(url: URL, method: String = "GET") throws -> URLRequest {
        guard !appToken.isEmpty, appToken != "__HTVANTIX_APP_TOKEN__" else {
            throw APIError.clientNotConfigured
        }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(appToken, forHTTPHeaderField: "X-App-Token")
        req.setValue(BuildIdentity.version, forHTTPHeaderField: "X-App-Version")
        req.setValue(BuildIdentity.buildID, forHTTPHeaderField: "X-Build-ID")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        return req
    }

    private func ensure2xx(_ data: Data, _ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { throw APIError.malformed }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError.server(status: http.statusCode, code: "HTTP_\(http.statusCode)", client: nil)
        }
    }

    func redeemLegacyKey(_ key: String) async throws -> LegacyLicenseResponse {
        let url = baseURL.appendingPathComponent("api/keys/redeem")
        var req = try configuredRequest(url: url, method: "POST")
        req.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
        var form = URLComponents()
        form.queryItems = [
            URLQueryItem(name: "code", value: key),
            URLQueryItem(name: "deviceId", value: DeviceIdentity.id),
            URLQueryItem(name: "deviceModel", value: UIDevice.current.model)
        ]
        req.httpBody = form.percentEncodedQuery?.data(using: .utf8)
        let (data, response) = try await urlSession.data(for: req)
        try ensure2xx(data, response)
        let decoded = try JSONDecoder().decode(LegacyLicenseResponse.self, from: data)
        guard decoded.ok else {
            throw APIError.server(status: 401, code: decoded.error ?? "LICENSE_INVALID", client: nil)
        }
        return decoded
    }

    func verifyLegacyKey(_ key: String) async throws -> LegacyLicenseResponse {
        guard var c = URLComponents(url: baseURL.appendingPathComponent("api/keys/status"), resolvingAgainstBaseURL: false) else {
            throw APIError.malformed
        }
        c.queryItems = [
            URLQueryItem(name: "code", value: key),
            URLQueryItem(name: "deviceId", value: DeviceIdentity.id)
        ]
        guard let url = c.url else { throw APIError.malformed }
        let req = try configuredRequest(url: url)
        let (data, response) = try await urlSession.data(for: req)
        try ensure2xx(data, response)
        let decoded = try JSONDecoder().decode(LegacyLicenseResponse.self, from: data)
        guard decoded.ok else {
            throw APIError.server(status: 401, code: decoded.error ?? "LICENSE_INVALID", client: nil)
        }
        return decoded
    }

    func loadPackagesLegacy() async throws -> [RemotePackage] {
        let req = try configuredRequest(url: baseURL.appendingPathComponent("cv/sp"))
        let (data, response) = try await urlSession.data(for: req)
        try ensure2xx(data, response)
        return try JSONDecoder().decode(LegacyPatchListResponse.self, from: data).patches
    }

    func downloadPackage(_ package: RemotePackage, sessionToken: String = "") async throws -> URL {
        let url = baseURL
            .appendingPathComponent("cv/sp")
            .appendingPathComponent(package.id)
            .appendingPathComponent("download")
        let req = try configuredRequest(url: url)
        let (tempURL, response) = try await urlSession.download(for: req)
        guard let http = response as? HTTPURLResponse else { throw APIError.malformed }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError.server(status: http.statusCode, code: "DOWNLOAD_HTTP_\(http.statusCode)", client: nil)
        }

        let data = try Data(contentsOf: tempURL)
        let hash = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        guard hash.caseInsensitiveCompare(package.sha256) == .orderedSame else { throw APIError.integrityFailed }
        if package.sizeBytes > 0, data.count != package.sizeBytes { throw APIError.integrityFailed }

        let fm = FileManager.default
        let docs = try fm.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let dir = docs.appendingPathComponent("HTVANTIX", isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let finalURL = dir.appendingPathComponent(package.fileName.replacingOccurrences(of: "/", with: "_"))
        try? fm.removeItem(at: finalURL)
        do { try data.write(to: finalURL, options: .atomic) }
        catch { throw APIError.fileWriteFailed }
        return finalURL
    }
}
