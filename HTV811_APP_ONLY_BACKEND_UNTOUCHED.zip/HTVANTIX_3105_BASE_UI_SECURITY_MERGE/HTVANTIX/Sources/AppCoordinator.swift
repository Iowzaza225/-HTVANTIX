import Foundation

@MainActor
final class AppCoordinator: ObservableObject {
    enum State: Equatable {
        case booting
        case locked
        case ready
        case updateRequired(V4VersionState)
        case maintenance(V4VersionState?)
        case blocked(V4VersionState?)
        case error(String)
    }

    @Published private(set) var state: State = .booting
    @Published private(set) var config: V4ClientConfig?
    @Published private(set) var packages: [RemotePackage] = []
    @Published private(set) var licenseInfo: LicenseInfo?
    @Published var isWorking = false

    private let secure = SecureStore()
    private let api = V4APIClient()
    private let licenseKeyAccount = "htvantix-v33-license-key"

    // Kept for view/source compatibility. V3.3 content access does not use a V4 session token.
    var sessionToken: String? { secure.load(account: licenseKeyAccount) }

    func bootstrap() async {
        guard let savedKey = secure.load(account: licenseKeyAccount), !savedKey.isEmpty else {
            state = .locked
            return
        }
        await verifySavedKey(savedKey)
    }

    func activate(key: String) async {
        let value = key.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !value.isEmpty else {
            state = .error("กรุณากรอก License Key")
            return
        }

        isWorking = true
        defer { isWorking = false }
        do {
            let result = try await api.redeemLegacyKey(value)
            try secure.save(value, account: licenseKeyAccount)
            licenseInfo = LicenseInfo(id: nil, status: "active", expiresAt: result.expiresAt, activatedAt: result.redeemedAt, deviceBoundAt: result.redeemedAt)
            packages = try await api.loadPackagesLegacy()
            state = .ready
        } catch {
            handle(error)
        }
    }

    private func verifySavedKey(_ key: String) async {
        isWorking = true
        defer { isWorking = false }
        do {
            let result = try await api.verifyLegacyKey(key)
            licenseInfo = LicenseInfo(id: nil, status: "active", expiresAt: result.expiresAt, activatedAt: result.redeemedAt, deviceBoundAt: result.redeemedAt)
            packages = try await api.loadPackagesLegacy()
            state = .ready
        } catch {
            secure.clear(account: licenseKeyAccount)
            packages = []
            state = .locked
        }
    }

    func refreshPackages() async {
        guard secure.load(account: licenseKeyAccount) != nil else {
            state = .locked
            return
        }
        do { packages = try await api.loadPackagesLegacy() }
        catch { handle(error) }
    }

    func download(_ package: RemotePackage) async throws -> URL {
        try await api.downloadPackage(package)
    }

    func signOut() {
        secure.clear(account: licenseKeyAccount)
        config = nil
        packages = []
        licenseInfo = nil
        state = .locked
    }

    func clearError() {
        if case .error = state { state = .locked }
    }

    private func handle(_ error: Error) {
        if case let APIError.server(_, code, _) = error {
            state = .error(userMessage(for: code))
            return
        }
        state = .error(error.localizedDescription)
    }

    private func userMessage(for code: String) -> String {
        switch code.lowercased() {
        case "device_mismatch": return "คีย์นี้ถูกผูกกับอุปกรณ์อื่น"
        case "expired": return "คีย์หมดอายุแล้ว"
        case "revoked": return "คีย์ถูกปิดใช้งาน"
        case "not_found", "license_invalid": return "ไม่พบ License Key"
        case "network": return "เชื่อมต่อระบบคีย์ไม่สำเร็จ"
        case "client_not_configured": return "Client configuration missing"
        default: return code
        }
    }
}
